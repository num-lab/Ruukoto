import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { test } from 'node:test';
import { getWorkflowStep, listWorkflowExecutions, requireWorkflowRun } from '@ruukoto/core/workflow.ts';
import type { OpResult } from '@ruukoto/control/ops.ts';
import { product } from '../apps/ruukoto-code/src/product.ts';
import { initGitRepo } from './helpers/git-fixture.ts';
import { afterTool, lastUserText, realTools, startTestRuntime, waitFor } from './helpers/testkit.ts';

test('诊断：验证工具已写入且结果完整，模型输出格式错误产生安全暂停', async () => {
  const t = await startTestRuntime('diag-write-result', req => {
    const verify = lastUserText(req).includes('VERIFY_ITEM_1');
    if (afterTool(req)) return { kind: 'text', text: verify ? 'not-json' : '修改完成' };
    return { kind: 'tool_calls', calls: [{ id: verify ? 'verify' : 'write', name: verify ? 'bash' : 'write', arguments: verify ? { command: 'test "$(cat item.txt)" = changed && printf proof > verification.txt' } : { path: 'item.txt', content: 'changed\n' } }] };
  }, { workDirs: 1, config: { ...realTools(), product: product.runtime } });
  try {
    fs.writeFileSync(path.join(t.work[0], 'item.txt'), 'base\n');
    initGitRepo(t.work[0]);
    const rt = t.runtime, session = await rt.createSession({ projectName: 'diagnostic', cwd: t.work[0] });
    await rt.setSessionDefaultMode({ sessionId: session.id, expectedVersion: session.defaultAccessModeVersion, mode: 'full_access' });
    await t.client.request('workflow_save', { name: 'diagnostic', script: 'await agent("change",{request:"CHANGE_ITEM_1",target:"."}); return await agent("verify",{request:"VERIFY_ITEM_1",verify:"change",dependsOn:["change"]});', expected_digest: null, request_id: 'save' });
    const started = await t.client.request<OpResult<'workflow_start'>>('workflow_start', { session_id: session.id, name: 'diagnostic', request_id: 'start', input: null });
    await waitFor('写后输出格式错误暂停', () => requireWorkflowRun(rt.store, started.run.id).status === 'paused', 90_000);
    const run = requireWorkflowRun(rt.store, started.run.id);
    const step = getWorkflowStep(rt.store, run.id, 'verify')!;
    assert.equal(run.reason, 'write_result_missing');
    assert.equal(step.status, 'failed');
    assert.equal(step.resultRecorded, true);
    const execution = listWorkflowExecutions(rt.store, run.id).find(item => item.stepKey === 'verify' && item.kind === 'agent')!;
    const ops = rt.store.listToolOpsByTask(execution.taskId);
    assert.equal(ops.length, 1);
    assert.equal(ops[0].isError, false);
    assert.notEqual(ops[0].resultSummary, null);
    assert.equal(execution.stopVerified, true);
    assert.equal(step.attempts, 1);
    process.stderr.write('[DEBUG-ci-122] '+JSON.stringify({run,step,ops,task:rt.store.getTask(execution.taskId)})+'\n');
  } finally { await t.shutdown(); }
});
