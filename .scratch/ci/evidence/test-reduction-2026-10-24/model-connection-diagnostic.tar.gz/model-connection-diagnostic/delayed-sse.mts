import assert from 'node:assert/strict';
import { MockModelServer } from './mock-provider-fixed.ts';
import { stream } from '/Users/eitrous/Developer/ruukoto/node_modules/@earendil-works/pi-ai/dist/api/openai-completions.js';
const expected = '延迟流必须完整传输中文和 ASCII chunks；连接仅在响应结束后关闭。';
const server = new MockModelServer(() => ({ kind: 'text', text: expected, chunkDelayMs: 20 }));
const baseUrl = await server.start();
const model = {id:'mock-model',name:'Mock',api:'openai-completions',provider:'mock',baseUrl,reasoning:false,input:['text'],cost:{input:0,output:0,cacheRead:0,cacheWrite:0},contextWindow:200000,maxTokens:1024,compat:{supportsUsageInStreaming:true}} as const;
let result;
try {
  const response = stream(model as any,{messages:[{role:'user',content:'stream probe',timestamp:Date.now()}]} as any,{apiKey:'mock-key',maxRetries:0});
  const pieces: string[] = [];
  for await (const event of response) if (event.type === 'text_delta') pieces.push(event.delta);
  result = await response.result();
  assert.equal(pieces.join(''), expected);
  assert.ok(pieces.length > 1);
  assert.equal(result.stopReason, 'stop');
  assert.equal(result.usage.input,100);
  assert.equal(result.usage.output,10);
  assert.equal(server.calls.length,1);
  process.stdout.write(JSON.stringify({stopReason:result.stopReason,pieces,usage:result.usage,serverCalls:server.calls.length})+'\n');
} finally { await server.close(); }
