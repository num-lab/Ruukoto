import assert from 'node:assert/strict';
import fs from 'node:fs';
import diagnostics from 'node:diagnostics_channel';
import { MockModelServer } from './mock-provider-fixed.ts';
import { stream } from '/Users/eitrous/Developer/ruukoto/node_modules/@earendil-works/pi-ai/dist/api/openai-completions.js';
const mode = process.argv[2] ?? 'baseline', blockMs = Number(process.argv[3] ?? 6300), warmupMs = Number(process.argv[4] ?? 0);
const started = performance.now(), events: unknown[] = [];
const event = (name: string, details: unknown = null) => events.push({ milliseconds: Math.round(performance.now() - started), name, details });
const errorView = (error: unknown): unknown => error instanceof Error ? { name: error.name, message: error.message, code: (error as Error & {code?:string}).code, cause: errorView(error.cause) } : error;
for (const name of ['undici:request:create', 'undici:request:error', 'undici:client:connected', 'undici:client:connectError']) diagnostics.channel(name).subscribe(message => {
  const value = message as { error?: unknown; request?: { method?:string; path?:string }; socket?: {localPort?:number;remotePort?:number} };
  event(name, { error: errorView(value.error), request: value.request ? { method: value.request.method, path: value.request.path } : undefined, socket: value.socket ? { localPort:value.socket.localPort, remotePort:value.socket.remotePort } : undefined });
});
const server = new MockModelServer((_request,index) => index === 0 ? {kind:'tool_calls',calls:[{id:'pause-call',name:'pause',arguments:{}}]} : {kind:'text',text:'done'});
const httpServer = server['server'];
let releaseExpiry!: () => void;
const expiry = mode.includes('timeout-gate') ? new Promise<void>(resolve => { releaseExpiry = resolve; }) : null;
if (expiry) httpServer.on('timeout', socket => { event('server-timeout',{port:socket.remotePort}); socket.destroy(); releaseExpiry(); });
if (mode.startsWith('idle-disabled')) httpServer.keepAliveTimeout = 0;
httpServer.on('connection', socket => { const id = socket.remotePort; event('server-connection',{id}); if (mode.includes('stack')) { const destroy = socket.destroy; socket.destroy = function(error?: Error) { event('server-destroy',{id,error:errorView(error),stack:new Error().stack}); return destroy.call(this,error); }; } socket.on('close', hadError => event('server-close',{id,hadError})); socket.on('end', () => event('server-end',{id})); socket.on('error', error => event('server-error',{id,error:errorView(error)})); });
httpServer.on('request', (request,response) => {
  event('server-request',{port:request.socket.remotePort});
  if (mode.startsWith('connection-close')) {
    const original = response.writeHead;
    response.writeHead = function (status: number, headers: any) { return original.call(this, status, {...headers,Connection:'close'}); } as typeof response.writeHead;
  }
});
const baseUrl = await server.start();
const model = {id:'mock-model',name:'Mock',api:'openai-completions',provider:'mock',baseUrl,reasoning:false,input:['text'],cost:{input:0,output:0,cacheRead:0,cacheWrite:0},contextWindow:200000,maxTokens:1024,compat:{supportsUsageInStreaming:true}} as const;
const context = { messages:[{role:'user',content:'probe',timestamp:Date.now()}], tools:[{name:'pause',description:'probe',parameters:{type:'object',properties:{}}}] };
const fetchProbe: typeof fetch = async (input, init) => {
  event('fetch-before');
  try { const response = await fetch(input,init); event('fetch-response',{status:response.status,connection:response.headers.get('connection'),keepAlive:response.headers.get('keep-alive')}); return response; }
  catch (error) { event('fetch-error',errorView(error)); throw error; }
};
const options = {apiKey:'mock-key',maxRetries:0,fetch:fetchProbe};
let first,second;
try {
  first = await stream(model as any,context as any,options).result();
  event('first-result',{stopReason:first.stopReason,error:first.errorMessage,serverCalls:server.calls.length});
  if (warmupMs) { event('idle-start',{warmupMs}); await new Promise(resolve => setTimeout(resolve,warmupMs)); event('idle-end'); }
  if (mode.includes('immediate')) { await new Promise(resolve => setImmediate(resolve)); event('check-phase'); }
  const resumeDeadline = mode.includes('deadline') ? new Promise<void>(resolve => setTimeout(() => { event('resume-timer'); resolve(); }, 6100)) : null;
  event('block-start',{blockMs});
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,blockMs);
  event('block-end');
  if (resumeDeadline) await resumeDeadline;
  if (expiry) await expiry;
  if (mode.includes('yield')) { await new Promise(resolve => setTimeout(resolve,0)); event('post-block-yield'); }
  if (mode.includes('manual-close')) { httpServer.closeIdleConnections(); event('manual-idle-close'); }
  const next = {...context,messages:[...context.messages,first,{role:'toolResult',toolCallId:'pause-call',toolName:'pause',content:[{type:'text',text:'done'}],isError:false,timestamp:Date.now()}]};
  second = await stream(model as any,next as any,options).result();
  event('second-result',{stopReason:second.stopReason,error:second.errorMessage,serverCalls:server.calls.length});
} finally {
  httpServer.closeAllConnections();
  await server.close();
}
const result = {mode,blockMs,warmupMs,node:process.version,undici:process.versions.undici,keepAliveTimeout:httpServer.keepAliveTimeout,keepAliveTimeoutBuffer:httpServer.keepAliveTimeoutBuffer,first:{stopReason:first?.stopReason,error:first?.errorMessage},second:{stopReason:second?.stopReason,error:second?.errorMessage},serverCalls:server.calls.length,events};
fs.writeFileSync(`/tmp/ruukoto-model-keepalive-diagnosis/${mode}-${blockMs}.json`,JSON.stringify(result,null,2)+'\n');
process.stdout.write(JSON.stringify(result)+'\n');
assert.equal(first?.stopReason, 'toolUse');
assert.equal(second?.stopReason, 'stop');
assert.equal(server.calls.length, 2);
