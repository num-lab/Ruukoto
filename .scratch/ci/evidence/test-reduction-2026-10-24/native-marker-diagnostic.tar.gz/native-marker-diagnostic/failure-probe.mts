import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {finished} from 'node:stream/promises';
import {launchMacosNative} from './native-macos.fixed.ts';
import {ExecutionError,type LaunchedUnit} from '/Users/eitrous/Developer/ruukoto/packages/agent/src/execution/launchers.ts';
import type {PreparedNativeLaunch} from '/Users/eitrous/Developer/ruukoto/packages/agent/src/execution/native.ts';
const out='/tmp/ruukoto-native-bootstrap-publication';
const helper='/Users/eitrous/Developer/ruukoto/worker/native-macos-supervisor';
const results=[];
for(const fault of ['write','rename']){
 const directory=fs.realpathSync(fs.mkdtempSync('/tmp/rk-bootstrap-fault-'));
 const workspace=path.join(directory,'work'),tempDir=path.join(directory,'tmp');fs.mkdirSync(workspace);fs.mkdirSync(tempDir);
 const workerPath=path.join(workspace,'fixture.mjs'),loaded=path.join(workspace,'imported'),preload=path.join(workspace,'fault.cjs'),marker=path.join(tempDir,'native-started');
 fs.writeFileSync(workerPath,`import fs from 'node:fs';fs.writeFileSync(${JSON.stringify(loaded)},'imported');setTimeout(()=>{},20000);`);
 fs.writeFileSync(preload,`const fs=require('node:fs'),write=fs.writeFileSync,rename=fs.renameSync;
  fs.writeFileSync=(file,...args)=>{if(${JSON.stringify(fault)}==='write'&&file===${JSON.stringify(marker+'.tmp')}){write(file,'partial');throw new Error('controlled_marker_write_failure');}return write(file,...args);};
  fs.renameSync=(from,to)=>{if(${JSON.stringify(fault)}==='rename'&&from===${JSON.stringify(marker+'.tmp')})throw new Error('controlled_marker_rename_failure');return rename(from,to);};`);
 const nodePath=fs.realpathSync(process.execPath);
 const prepared:PreparedNativeLaunch={workspace,tempDir,workerPath,nodePath,runtimeReadRoots:['/System/Library','/usr/lib','/usr/bin','/bin',path.dirname(path.dirname(nodePath))],toolAliases:[],mounts:[{path:workspace,access:'read_write'}],env:{PATH:'/usr/bin:/bin',HOME:tempDir,TMPDIR:tempDir,NODE_OPTIONS:`--require=${JSON.stringify(preload)}`}};
 let unit:LaunchedUnit|null=null,error:ExecutionError|undefined;
 try{unit=await launchMacosNative(prepared,{taskId:'marker-failure-'+fault,mode:'confirm',workspace,grantedPaths:[]},helper);assert.fail('bootstrap should reject before worker import')}
 catch(value){assert.ok(value instanceof ExecutionError);error=value;assert.ok(value.unit);unit=value.unit}
 assert.ok(unit&&error);unit.stdout.resume();unit.stderr.resume();
 const stop=await unit.entry.stop();const [exit]=await Promise.all([unit.exit,finished(unit.stdout),finished(unit.stderr)]);
 assert.equal(error.code,'execution_unavailable');assert.equal(error.reason,'sandbox_rejected');assert.equal(fs.existsSync(marker),false);assert.equal(fs.existsSync(loaded),false);
 const workerPid=Number(unit.entry.label.match(/worker=(\d+)/)?.[1]);
 if(workerPid)assert.throws(()=>process.kill(workerPid,0),value=>!!value&&typeof value==='object'&&'code'in value&&value.code==='ESRCH');
 const result={fault,directory,code:error.code,reason:error.reason,stop,exit,workerImported:false,markerPublished:false,temporary:fs.readFileSync(marker+'.tmp','utf8'),stdoutClosed:unit.stdout.readableEnded,stderrClosed:unit.stderr.readableEnded,workerPid,workerExited:true};
 results.push(result);fs.writeFileSync(path.join(out,'failure-results.json'),JSON.stringify(results,null,2)+'\n');process.stdout.write(JSON.stringify(result)+'\n');
 if(stop)fs.rmSync(directory,{recursive:true,force:true});
}
