from pathlib import Path
import hashlib,json,re,subprocess,sys
repo=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
patch=Path(sys.argv[3]).resolve()
expected={'original':'ae688ea6e4c32b3d247f11cecdcc5486e9b19d17aa3308f7fdcd6f388634eeee','candidate':'9bc371a8ddedc1a2239333c665e86fd85ce5303e938e720c9c5dd0e83984b8ba','patch':'2412e8fde77da35780d14ee56e2159c8092c1adf4590989e82b9c42b1f132f8e'}
sha=lambda value:hashlib.sha256(value.encode()).hexdigest()
original=(repo/'test/15-tui-pty.test.ts').read_text()
assert sha(original)==expected['original'],sha(original)
assert sha(patch.read_text())==expected['patch'],sha(patch.read_text())
candidate=out/'candidate/test/15-tui-pty.test.ts';candidate.parent.mkdir(parents=True,exist_ok=True);candidate.write_text(original)
subprocess.run(['git','apply','--unsafe-paths',str(patch)],cwd=out/'candidate',check=True,capture_output=True,text=True)
fixed=candidate.read_text();assert sha(fixed)==expected['candidate'],sha(fixed)
files=[]
for version,value in [('original',original),('fixed',fixed)]:
 for delayed in [False,True]:
  name=version+('-delayed' if delayed else '')
  probe=re.sub(r'from "(\.\.?/[^"\n]+)"',lambda match:'from '+json.dumps(str((repo/'test'/match.group(1)).resolve())),value)
  if delayed:
   before='cmd: ["npx", "tsx", "apps/ruukoto-code/src/main.ts", ...args],'
   after='cmd: ["python3", "-c", "import os,sys,time; time.sleep(12); os.execvp(sys.argv[1],sys.argv[1:])", "npx", "tsx", "apps/ruukoto-code/src/main.ts", ...args],'
   assert probe.count(before)==1;probe=probe.replace(before,after)
  before='    assert.equal(result.exitCode, 0, result.tail); assert.equal(result.expectSeen, result.expectTotal, result.tail);'
  after='    fs.writeFileSync('+json.dumps(str(out/(name+'.result.json')))+', JSON.stringify(result, null, 2));\n'+before
  assert probe.count(before)==1;probe=probe.replace(before,after)
  target=out/(name+'.test.mts');target.write_text(probe)
  files.append({'name':name,'path':str(target),'sha256':sha(probe),'startupDelaySeconds':12 if delayed else 0})
link=out/'node_modules'
if not link.exists():link.symlink_to(repo/'node_modules',target_is_directory=True)
manifest={'repo':str(repo),'out':str(out),'sourceSha256':expected,'generated':files,'testNamePattern':'PTY：工作流逐层启动','driverTimeoutSeconds':40,'testTimeoutSeconds':60}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest))
