import fs from 'node:fs';
const record = kind => fs.appendFileSync('/tmp/ruukoto-workflow-reviewer-diagnosis/tail-processes.jsonl',JSON.stringify({kind,time:new Date().toISOString(),milliseconds:Date.now(),pid:process.pid,ppid:process.ppid,argv:process.argv,context:process.env.NODE_TEST_CONTEXT??null})+'\n');
record('start');process.on('exit',()=>record('exit'));
