from pathlib import Path
import subprocess,json,time,os,signal
root=Path('/Users/eitrous/Developer/ruukoto');out=Path('/tmp/ruukoto-workflow-reviewer-diagnosis')
files=json.loads((out/'tail-files.json').read_text())
cmd=['node','--import',str(out/'process-marker.mjs'),'--import','tsx','--test','--test-concurrency=2',*[str(out/'tail/test'/f) for f in files]]
env=dict(os.environ,RUN_MODEL_CHECK='0',RUN_BACKGROUND_BROWSER_CHECK='0');started=time.monotonic();timedout=False
with (out/'tail.log').open('w') as log:
    proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:code=proc.wait(timeout=240)
    except subprocess.TimeoutExpired:
        timedout=True;os.killpg(proc.pid,signal.SIGTERM)
        try:code=proc.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=10)
result={'command':cmd,'pid':proc.pid,'exitCode':code,'timeout':timedout,'seconds':time.monotonic()-started}
(out/'tail-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(code if code>=0 else 1)
