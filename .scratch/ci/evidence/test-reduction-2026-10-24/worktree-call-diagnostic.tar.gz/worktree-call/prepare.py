from pathlib import Path
import hashlib,json,re
root=Path('/Users/eitrous/Developer/ruukoto');out=Path('/tmp/ruukoto-worktree-call-diagnosis')
original=(root/'test/83-subagent-worktrees.test.ts').read_text()
start='for (const operation of ["create", "integrate"] as const) {'
end='test("临时单元停止成功期间取消父任务，迟到模式切换不能修改终态权限"'
a=original.index(start);b=original.index(end)
block=original[a:b]
old='''      let runtime: Runtime | null = null;
      let parentSessionId = "";
'''
new='''      let runtime: Runtime | null = null;
      let parentSessionId = "", diagnosticParentId = "";
      const diagnosticStart = performance.now(), diagnosticDirectory = fs.mkdtempSync("/tmp/rk-wt-call-evidence-");
      let diagnosticIndex = 0, lastWaitSignature = "";
      const modelCalls: unknown[] = [];
      const capture = (stage: string, extra: unknown = null, fromStore?: Store) => {
        let state: unknown = null;
        try {
          const store = fromStore ?? runtime?.store;
          if (store) {
            const works = parentSessionId ? store.listWorkDelegationsBySession(parentSessionId) : [];
            const tasks = new Map((parentSessionId ? store.listTasksBySession(parentSessionId) : []).map(task => [task.id, task]));
            for (const work of works) for (const task of store.listTasksByWork(work.id)) tasks.set(task.id, task);
            state = {
              tasks: [...tasks.values()].map(task => ({ id: task.id, sessionId: task.sessionId, parentTaskId: task.parentTaskId, workId: task.workId, status: task.status, errorMessage: task.errorMessage, interruptReason: task.interruptReason, cancelRequested: task.cancelRequested, effectUnknown: task.effectUnknown, resultSummary: task.resultSummary, resultRef: task.resultRef, readScope: task.readScope })),
              works, occupancy: store.listAllOccupancy(),
              toolOps: [...tasks.values()].flatMap(task => store.listToolOpsByTask(task.id)).map(op => ({ id: op.id, taskId: op.taskId, toolName: op.toolName, sdkCallId: op.sdkCallId, resultSummary: op.resultSummary, isError: op.isError, effectUnknown: op.effectUnknown, params: { workId: op.params.workId, copyDir: op.params.copyDir, workspace: op.params.workspace, source: op.params.source, branch: op.params.branch } })),
              events: store.getEventsAfter(Math.max(0, store.getMaxSeq() - 35)).map(event => ({ seq: event.seq, taskId: event.taskId, type: event.body.type })),
            };
          }
        } catch (error) { state = { captureError: error instanceof Error ? error.message : String(error) }; }
        const target = path.join(diagnosticDirectory, `${String(diagnosticIndex++).padStart(3, "0")}-${stage}.json`);
        fs.writeFileSync(target, JSON.stringify({ stage, milliseconds: performance.now() - diagnosticStart, operation, phase, diagnosticParentId, state, specs: controlled.specs, requests: controlled.requests.map(request => ({ type: request.type, ...(request.type === "tool_call" ? { name: request.name, opId: request.opId } : {}) })), modelCalls: modelCalls.slice(-12), extra }, null, 2) + "\\n");
        process.stderr.write(`[DEBUG-wt-call] ${stage} ${target}\\n`);
      };
'''
assert block.count(old)==1;block=block.replace(old,new)
old='''      const responder: Responder = async (req) => {
        if (lastUserText(req).includes("[SubAgent 委派")) return { kind: "text", text: "子任务完成" };
        if (!afterTool(req)) return { kind: "tool_calls", calls: [{ id: "delegate", name: "subagent_delegate", arguments: { key: "create", request: "修改", target: "." } }] };
        const work = runtime!.store.listWorkDelegationsBySession(parentSessionId)[0]!;
        await waitFor("子任务完成", () => runtime!.store.listTasksByWork(work.id).every((task) => task.resultSummary !== null));
        fs.writeFileSync(path.join(work.writeTarget!.path, "source.txt"), "副本成果\\n");
        runtime!.launcherFor = () => controlled.launcher;
        return { kind: "tool_calls", calls: [{ id: "integrate", name: "subagent_integrate", arguments: { work_id: work.id } }] };
      };'''
new='''      const responder: Responder = async (req) => {
        const child = lastUserText(req).includes("[SubAgent 委派"), after = afterTool(req);
        modelCalls.push({ milliseconds: performance.now() - diagnosticStart, child, afterTool: after, messages: req.messages.slice(-3).map(message => ({ role: message.role, name: message.name, tool_call_id: message.tool_call_id, tool_calls: message.tool_calls, ...(message.role === "tool" ? { content: message.content } : {}) })) });
        capture("model-request");
        try {
          if (child) { capture("model-child-reply"); return { kind: "text", text: "子任务完成" }; }
          if (!after) { capture("model-delegate-reply"); return { kind: "tool_calls", calls: [{ id: "delegate", name: "subagent_delegate", arguments: { key: "create", request: "修改", target: "." } }] }; }
          const work = runtime!.store.listWorkDelegationsBySession(parentSessionId)[0]!;
          capture("child-result-wait-before");
          await waitFor("子任务完成", () => runtime!.store.listTasksByWork(work.id).every((task) => task.resultSummary !== null));
          capture("child-result-wait-after");
          fs.writeFileSync(path.join(work.writeTarget!.path, "source.txt"), "副本成果\\n");
          runtime!.launcherFor = () => controlled.launcher;
          capture("model-integrate-reply");
          return { kind: "tool_calls", calls: [{ id: "integrate", name: "subagent_integrate", arguments: { work_id: work.id } }] };
        } catch (error) { capture("responder-error", { error: error instanceof Error ? error.message : String(error) }); throw error; }
      };'''
assert block.count(old)==1;block=block.replace(old,new)
old='''        await waitFor("目标临时单元已产生", () => phase === "call" ? controlled.requests.some((request) => request.type === "tool_call") : controlled.specs.length === 1, 60_000);
        await rt.stop("test_backend_stop");'''
new='''        diagnosticParentId = parent.id;
        capture("target-wait-before");
        await waitFor("目标临时单元已产生", () => {
          const reached = phase === "call" ? controlled.requests.some(request => request.type === "tool_call") : controlled.specs.length === 1;
          const current = rt.store.getTask(parent.id), works = rt.store.listWorkDelegationsBySession(session.id), children = works.flatMap(work => rt.store.listTasksByWork(work.id));
          const signature = JSON.stringify({ parent: current?.status, children: children.map(task => [task.id, task.status, task.resultSummary]), specs: controlled.specs.length, requests: controlled.requests.map(request => request.type) });
          if (signature !== lastWaitSignature) { lastWaitSignature = signature; capture("target-wait-progress"); }
          if (!reached && current && ["completed", "failed", "canceled", "interrupted"].includes(current.status)) {
            capture("target-missing-parent-terminal");
            throw new Error(`目标临时单元未出现，父任务已${current.status}：${current.errorMessage ?? current.interruptReason ?? "无额外错误"}；诊断 ${diagnosticDirectory}`);
          }
          const failedChild = children.find(task => ["failed", "canceled", "interrupted"].includes(task.status));
          if (!reached && failedChild) {
            capture("target-missing-child-terminal");
            throw new Error(`目标临时单元未出现，子任务已${failedChild.status}：${failedChild.errorMessage ?? failedChild.interruptReason ?? failedChild.resultSummary ?? "无额外错误"}；诊断 ${diagnosticDirectory}`);
          }
          return reached;
        }, 60_000);
        capture("target-wait-after");
        capture("runtime-stop-before");
        await rt.stop("test_backend_stop");
        capture("runtime-stop-after");'''
assert block.count(old)==1;block=block.replace(old,new)
old='''        assert.equal(controlled.specs.length, 1);
      } finally {
        db?.close();'''
new='''        assert.equal(controlled.specs.length, 1);
        capture("assertions-complete", null, store);
      } catch (error) {
        capture("test-error", { error: error instanceof Error ? error.stack : String(error) });
        throw error;
      } finally {
        capture("cleanup-before");
        db?.close();'''
assert block.count(old)==1;block=block.replace(old,new)
text=original[:a]+block+original[b:]
text=re.sub(r'(["\'])\./helpers/([^"\']+)\1',lambda m:json.dumps(str(root/'test/helpers'/m.group(2))),text)
text=text.replace('const source = fileURLToPath(new URL("../packages/', 'const source = fileURLToPath(new URL("../packages/')
target=out/'diagnostic.test.mts';target.write_text(text)
(out/'node_modules').symlink_to(root/'node_modules',target_is_directory=True) if not (out/'node_modules').exists() else None
meta={'source':str(root/'test/83-subagent-worktrees.test.ts'),'sourceSha256':hashlib.sha256(original.encode()).hexdigest(),'variant':str(target),'variantSha256':hashlib.sha256(text.encode()).hexdigest(),'changes':'Only target block diagnostics and fail-fast on parent/non-success child terminal; original assertions and budgets preserved. Relative helper imports point to main source.','testPattern':'后台停止覆盖 SDK 中的 integrate 临时 worker call 阶段','executed':False}
(out/'prepared.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(meta,ensure_ascii=False))
