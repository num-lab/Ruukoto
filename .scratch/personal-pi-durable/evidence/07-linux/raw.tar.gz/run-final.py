import subprocess,pathlib,json,hashlib,os,time,tarfile,sys,signal
root=pathlib.Path(__file__).resolve().parent
source=root/'source'
with tarfile.open(root/'delta-final.tar.gz','r:gz') as tar: tar.extractall(source,filter='data')
for name in ['tmp','npm-cache','results-final']: (root/name).mkdir(exist_ok=True)
for name in ['npm-user.rc','npm-global.rc','gitconfig']: (root/name).write_text('')
env={'PATH':'/usr/local/bin:/usr/bin:/bin','RUN_MODEL_CHECK':'0','TMPDIR':str(root/'tmp'),'NPM_CONFIG_USERCONFIG':str(root/'npm-user.rc'),'NPM_CONFIG_GLOBALCONFIG':str(root/'npm-global.rc'),'NPM_CONFIG_CACHE':str(root/'npm-cache'),'NPM_CONFIG_AUDIT':'false','NPM_CONFIG_FUND':'false','NPM_CONFIG_UPDATE_NOTIFIER':'false','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':str(root/'gitconfig'),'GIT_TERMINAL_PROMPT':'0'}
manifest=json.loads((root/'source-manifest-final.json').read_text())
def verify():
 mismatches=[]
 for entry in manifest:
  path=source/entry['path']
  if 'link' in entry:
   if not path.is_symlink() or os.readlink(path)!=entry['link']: mismatches.append(entry['path'])
  elif not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']: mismatches.append(entry['path'])
 return mismatches
initial=verify()
(root/'results-final'/'source-before.json').write_text(json.dumps({'mismatches':initial,'count':len(manifest)})+'\n')
if initial: raise RuntimeError('source mismatches before run')
subprocess.run(['git','init','--quiet'],cwd=source,env=env,check=True)
def probe(argv): return subprocess.check_output(argv,cwd=source,env=env,text=True,stderr=subprocess.STDOUT).strip()
environment={'node':probe(['node','--version']),'npm':probe(['npm','--version']),'platform':probe(['uname','-a']),'identity':probe(['id']),'python':probe(['python3','--version']),'cwd':str(source),'sourceManifestSha256':hashlib.sha256((root/'source-manifest-final.json').read_bytes()).hexdigest(),'archiveSha256':hashlib.sha256((root/'source.tar.gz').read_bytes()).hexdigest(),'RUN_MODEL_CHECK':'0','inheritedEnvironment':False,'npmConfiguration':'isolated empty user/global rc','diskBefore':probe(['df','-h','/','/dev/shm'])}
(root/'results-final'/'environment.json').write_text(json.dumps(environment,ensure_ascii=False,indent=2)+'\n')
commands=[]
for name,argv in [('personal',['npx','--no-install','tsx','--test','test/personal-durable.test.ts','test/personal-cli.test.ts','test/personal-services.test.ts','test/personal-work.test.ts','test/personal-service-operations.test.ts','test/personal-telegram.test.ts']),('build',['npm','run','build'])]:
 print('START '+name,flush=True)
 before=time.monotonic()
 with (root/'results-final'/(name+'.log')).open('wb') as log:
  proc=subprocess.Popen(argv,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (root/'results-final'/'active-command.json').write_text(json.dumps({'name':name,'pid':proc.pid,'pgid':proc.pid})+'\n')
  try: status=proc.wait(timeout=600)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGTERM)
   try: proc.wait(timeout=10)
   except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL); proc.wait()
   status=124
 command={'name':name,'argv':argv,'cwd':str(source),'RUN_MODEL_CHECK':'0','exitCode':status,'durationSeconds':round(time.monotonic()-before,3)}
 commands.append(command)
 (root/'results-final'/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 print(json.dumps(command),flush=True)
 if status!=0:
  print((root/'results-final'/(name+'.log')).read_text(errors='replace')[-14000:],flush=True)
  if name=='setup': break
final=verify()
(root/'results-final'/'source-after.json').write_text(json.dumps({'mismatches':final,'count':len(manifest)})+'\n')
(root/'results-final'/'summary.json').write_text(json.dumps({'commands':commands,'sourceChanged':final,'diskAfter':probe(['df','-h','/','/dev/shm'])},ensure_ascii=False,indent=2)+'\n')
(root/'results-final'/'active-command.json').unlink(missing_ok=True)
print('FINISHED '+json.dumps({'commands':commands,'sourceChanged':final}),flush=True)
