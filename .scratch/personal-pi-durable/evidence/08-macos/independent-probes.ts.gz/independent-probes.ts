import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as path from "node:path";
import * as http from "node:http";
import { createHash, randomUUID } from "node:crypto";
import { tmpdir } from "node:os";
import { once } from "node:events";
import { setTimeout as delay } from "node:timers/promises";
import { test, type TestContext } from "node:test";
import { BACKGROUND_CONTEXT } from "@earendil-works/chord/context";
import { SessionFailed } from "@earendil-works/pi-durable";
import { openNodeSqliteStorage } from "@earendil-works/pi-durable/storage/sqlite/node";
import { openPersonalHarness, type PersonalHarness } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-harness.ts";
import { personalProvider, type PersonalModelConfig } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-model.ts";
import { PersonalError } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-error.ts";
import { PersonalPermissionsDoc } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-permissions.ts";
import { PersonalTelegramDoc, PersonalTelegramReceiptDoc } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-telegram.ts";
import { PersonalServiceGrantsDoc, PersonalServiceOperationDoc, type PersonalServiceOperationRef } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-service-operations.ts";
import type { PersonalTelegramConfig } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-telegram-config.ts";
import type { TelegramUpdate } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-telegram-api.ts";
import { MockModelServer } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/test/helpers/mock-provider.ts";

const context = BACKGROUND_CONTEXT;
const UNIT = "approval-test.service";
const code = (expected: string) => (error: unknown) => error instanceof PersonalError && error.code === expected;
async function until(check: () => Promise<boolean>) {
  const deadline = Date.now() + 10000;
  while (!await check()) { assert.ok(Date.now() < deadline, "等待审批事实超时"); await delay(10); }
}

async function fixture(t: TestContext) {
  const root = fs.mkdtempSync(path.join(process.platform === "darwin" ? "/tmp" : tmpdir(), "rk-tg-perm-"));
  const helper = path.join(root, "helper"); fs.mkdirSync(path.join(helper, "units"), { recursive: true }); fs.mkdirSync(path.join(helper, "ops"));
  const helperPath = path.join(helper, "helper.mjs"); fs.copyFileSync(new URL("file:///Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/test/helpers/fake-service-helper.mjs"), helperPath);
  const policyPath = path.join(helper, "services.json"); fs.writeFileSync(policyPath, JSON.stringify({ machineId: "test-machine", inspectUid: 1, inspectGid: 1, services: { [UNIT]: { actions: ["restart"] } } }));
  fs.writeFileSync(path.join(helper, "units", UNIT), "[Service]\nExecStart=/usr/bin/true\n");
  fs.writeFileSync(path.join(helper, "state.json"), JSON.stringify({ [UNIT]: { loadState: "loaded", activeState: "active", subState: "running", mainPid: 123, invocationId: "before", result: "success", activeEnterTimestamp: "2026-10-17T00:00:00Z", starts: 0 } }));
  const sends: { text: string; messageId: number }[] = []; let failure = false;
  const bot = http.createServer(async (req, res) => {
    const chunks: Buffer[] = []; for await (const chunk of req) chunks.push(Buffer.from(chunk));
    const body = JSON.parse(Buffer.concat(chunks).toString()) as { text: string; chat_id: string };
    assert.match(req.url!, /\/sendMessage$/);
    sends.push({ text: body.text, messageId: 1000 + sends.length + 1 });
    if (failure) { failure = false; res.destroy(); return; }
    res.end(JSON.stringify({ ok: true, result: { message_id: sends.at(-1)!.messageId, chat: { id: Number(body.chat_id), type: "private" } } }));
  });
  bot.listen(0, "127.0.0.1"); await once(bot, "listening"); const address = bot.address(); assert.ok(address && typeof address !== "string");
  const model = new MockModelServer(() => ({ kind: "text", text: "收到" }));
  const config: PersonalModelConfig = { api: "openai-completions", baseUrl: await model.start(), modelId: "mock-model", apiKeyEnv: "RUUKOTO_PERMISSIONS_MODEL_KEY", contextWindow: 128000, maxTokens: 1024 };
  const telegram: PersonalTelegramConfig = { version: 1, enabled: true, generation: randomUUID(), apiBase: `http://127.0.0.1:${address.port}`, tokenEnv: "RUUKOTO_PERMISSIONS_BOT_KEY", tokenDigest: createHash("sha256").update("123:test-token").digest("hex"), botId: "123", ownerId: "456", boundary: 0 };
  const oldModel = process.env[config.apiKeyEnv]; const oldBot = process.env[telegram.tokenEnv]; process.env[config.apiKeyEnv] = "test-only"; process.env[telegram.tokenEnv] = "123:test-token";
  const options = { directory: path.join(root, "profile"), provider: personalProvider(config), modelId: config.modelId, telegram, service: { helperPath, policyPath, useSudo: false, sudoPath: "/usr/bin/sudo", timeouts: { inspectMs: 1000, restartMs: 2000, stopMs: 1000 } }, serviceOperations: true };
  let p: PersonalHarness; let id = 0;
  t.after(async () => { await p?.close(); bot.closeAllConnections(); await new Promise<void>(resolve => bot.close(() => resolve())); await model.close(); fs.rmSync(root, { recursive: true, force: true }); for (const [key, previous] of [[config.apiKeyEnv, oldModel], [telegram.tokenEnv, oldBot]]) { if (previous === undefined) delete process.env[key!]; else process.env[key!] = previous; } });
  const receive = async (text: string, replyTo?: number, extra: Record<string, unknown> = {}) => {
    const messageId = ++id;
    const update: TelegramUpdate = { update_id: id, message: { message_id: messageId, chat: { id: 456, type: "private" }, from: { id: 456, is_bot: false }, text, ...(replyTo === undefined ? {} : { reply_to_message: { message_id: replyTo, from: { id: 123, is_bot: true } } }), ...extra } };
    await p.telegram.receive(update);
    const key = `telegram:123:456:${messageId}`; const value = (await p.harness.snapshot(PersonalTelegramReceiptDoc, key, context))!.receipt!;
    await p.harness.waitForTask(value.taskId, context);
    return { key, update, value: (await p.harness.snapshot(PersonalTelegramReceiptDoc, key, context))!.receipt! };
  };
  const request = async () => { const source = await receive("重启测试服务"); const ref = await p.service!.request({ requestId: randomUUID(), sourceRequestId: source.key, unit: UNIT }); await until(async () => !!(await p.service!.status(ref)).operation.snapshot); return ref; };
  return { options, telegram, root, model, sends, helper, receive, request,
    open: async (overrides: Partial<Omit<Parameters<typeof openPersonalHarness>[0], "directory" | "profile">> = {}) => p = await openPersonalHarness({ ...options, ...overrides }),
    starts: () => (JSON.parse(fs.readFileSync(path.join(helper, "state.json"), "utf8")) as Record<string, { starts: number }>)[UNIT].starts,
    touch: (name: string) => fs.writeFileSync(path.join(helper, name), ""),
    loseSend: () => { failure = true; },
  };
}
async function menu(f: Awaited<ReturnType<typeof fixture>>, command = "/审批") { return Number((await f.receive(command)).value.platformMessageId); }
async function done(p: PersonalHarness, ref: PersonalServiceOperationRef) { return p.harness.waitForTask(ref.taskId, context); }


test("反证：历史未知经人工核实后新建的授权应跨重启保留", async t => {
  const f = await fixture(t); let p = await f.open();
  const first = await f.request(); await f.receive("批准并长期授权", await menu(f)); await done(p, first);
  f.touch("fail-after-launch"); const unknown = await f.request();
  await until(async () => (await p.service!.status(unknown)).operation.result?.code === "result_unverified" && (await p.service!.status(unknown)).operation.launcherStopped);
  fs.rmSync(path.join(f.helper, "fail-after-launch"));
  await p.service!.resolve(unknown, "applied", "隔离反证已读取服务状态核实执行"); await done(p, unknown);
  const later = await f.request(); await f.receive("批准并长期授权", await menu(f)); await done(p, later);
  let grants = (await p.harness.snapshot(PersonalServiceGrantsDoc, context))!.grants;
  assert.equal(grants[1].active, true); assert.equal(f.starts(), 3);
  await p.close(); p = await f.open();
  grants = (await p.harness.snapshot(PersonalServiceGrantsDoc, context))!.grants;
  assert.equal(grants[1].active, true, "已核实历史未知不应撤销事后明确新建的授权");
});

test("反证：授权来源不能替换为已拒绝的旧菜单重批收件", async t => {
  const f = await fixture(t); let p = await f.open(); const first = await f.request();
  const originalMenu = await menu(f); await f.receive("批准并长期授权", originalMenu); await done(p, first);
  const stale = await f.receive("批准并长期授权", originalMenu);
  assert.match(stale.value.reply!, /失效|消费/);
  await p.harness.commit(async tx => { (await tx.doc(PersonalServiceGrantsDoc)).grants[0].controlRequestId = stale.key; }, context);
  await p.close();
  await assert.rejects(f.open(), code("service_grant_invalid"), "被拒绝的控制收件不应为长期授权提供恢复来源");
});

test("反证：原入口手工批准的未知操作仍能人工核实", async t => {
  const f = await fixture(t); const p = await f.open(); f.touch("fail-after-launch");
  const ref = await f.request(); await f.receive("批准本次", await menu(f));
  await until(async () => (await p.service!.status(ref)).operation.result?.code === "result_unverified" && (await p.service!.status(ref)).operation.launcherStopped);
  await p.service!.resolve(ref, "applied", "读取测试服务计数核实已经执行");
  await done(p, ref);
});

test("反证：单次批准与原已接受决定相反时拒绝恢复", async t => {
  const f = await fixture(t); const p = await f.open(); const ref = await f.request();
  const decision = await f.receive("批准本次", await menu(f)); await done(p, ref);
  await p.harness.commit(async tx => { (await tx.doc(PersonalTelegramReceiptDoc, decision.key, null)).receipt!.serviceDecision!.decision = "rejected"; }, context);
  await p.close(); await assert.rejects(f.open(), code("service_approval_invalid"));
});
