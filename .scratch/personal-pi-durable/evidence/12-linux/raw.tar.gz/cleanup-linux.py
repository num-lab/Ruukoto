import datetime
import json
import pathlib
import shlex
import subprocess
import sys

E = pathlib.Path(__file__).parent
ID = json.loads((E / 'session.json').read_text())['remoteId']
assert ID.startswith('ruukoto-work-notes-') and '/' not in ID
roots = ['/tmp/' + ID, '/dev/shm/' + ID]
script = """import pathlib,sys,os,signal,shutil,json,time
roots=[pathlib.Path(sys.argv[1]),pathlib.Path(sys.argv[2])]; marker=sys.argv[3]
for root in roots:
 if not root.is_dir() or (root/'.owner').read_text().strip()!=marker:raise RuntimeError('ownership mismatch: '+str(root))
def belongs(pid):
 try:return any((pathlib.Path('/proc')/str(pid)/'cwd').resolve().is_relative_to(root) for root in roots)
 except (FileNotFoundError,PermissionError,ProcessLookupError):return False
def owned():return [int(path.name) for path in pathlib.Path('/proc').iterdir() if path.name.isdigit() and int(path.name)!=os.getpid() and belongs(int(path.name))]
pids=owned()
for pid in pids:
 if belongs(pid):
  try:os.kill(pid,signal.SIGTERM)
  except ProcessLookupError:pass
if pids:time.sleep(1)
for pid in pids:
 if belongs(pid):
  try:os.kill(pid,signal.SIGKILL)
  except ProcessLookupError:pass
if pids:time.sleep(.1)
remaining=owned()
if remaining:raise RuntimeError('owned processes remain: '+repr(remaining))
for root in roots:shutil.rmtree(root)
print(json.dumps({'terminatedOwnedPids':pids,'remainingOwnedPids':owned(),'removed':[str(root) for root in roots],'remainingDirectories':[str(root) for root in roots if root.exists()]},indent=2))
"""
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
args = ['ssh', 'tx', 'python3 -c ' + shlex.quote(script) + ' ' + ' '.join(shlex.quote(root) for root in roots) + ' ' + shlex.quote(ID)]
result = subprocess.run(args, capture_output=True)
(E / 'cleanup.stdout').write_bytes(result.stdout)
(E / 'cleanup.stderr').write_bytes(result.stderr)
(E / 'cleanup.json').write_text(json.dumps({'command': args, 'exitCode': result.returncode, 'started': started, 'ended': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
print(result.stdout.decode(errors='replace'))
print(result.stderr.decode(errors='replace'))
print('cleanup: exit ' + str(result.returncode), flush=True)
raise SystemExit(result.returncode)
