import datetime,json,pathlib,subprocess,sys
E=pathlib.Path(__file__).parent;remote='/tmp/'+json.loads((E/'session.json').read_text())['remoteId']

def run(name,args):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(args,capture_output=True)
 (E/(name+'.stdout')).write_bytes(r.stdout);(E/(name+'.stderr')).write_bytes(r.stderr)
 (E/(name+'.json')).write_text(json.dumps({'command':args,'started':start,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode},indent=2)+'\n')
 print(name+': exit '+str(r.returncode),flush=True); print(r.stdout.decode(errors='replace'),flush=True)
 if r.returncode:print(r.stderr.decode(errors='replace')[-4000:],flush=True)
 return r.returncode
code=run('overlay-upload',['scp',str(E/'updated-personal-work-notes.test.ts'),str(E/'input-overlay.json'),str(E/'overlay-remote-runner.py'),'tx:'+remote+'/'])
if code:sys.exit(code)
code=run('overlay-validation',['ssh','tx','python3 '+remote+'/overlay-remote-runner.py '+remote])
(E/'remote-logs').rename(E/'initial-remote-logs')
collected=run('overlay-download',['scp','-r','tx:'+remote+'/logs',str(E/'remote-logs')])
sys.exit(code or collected)
