import datetime,hashlib,json,os,pathlib,shutil,signal,subprocess,sys
root=pathlib.Path(sys.argv[1]);repo=root/'repo';logs=root/'logs'
overlay=json.loads((root/'input-overlay.json').read_text())
source=root/'updated-personal-work-notes.test.ts';target=repo/overlay['after']['path']
if hashlib.sha256(source.read_bytes()).hexdigest()!=overlay['after']['sha256']:raise RuntimeError('overlay upload SHA-256 mismatch')
if hashlib.sha256(target.read_bytes()).hexdigest()!=overlay['before']['sha256']:raise RuntimeError('overlay prior input SHA-256 mismatch')
shutil.copyfile(source,target);target.chmod(int(overlay['after']['mode'],8))
(logs/'input-overlay.json').write_text(json.dumps(overlay,ensure_ascii=False,indent=2)+'\n')
shutil.copyfile(logs/'final-runtime-input-check.json',logs/'initial-runtime-input-check.json')
manifest=json.loads((root/'input-manifest.json').read_text())
manifest=[overlay['after'] if item['path']==overlay['after']['path'] else item for item in manifest]
(logs/'effective-input-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
env=os.environ.copy();env.update({'RUN_MODEL_CHECK':'0','TMPDIR':str(root/'tmp'),'npm_config_cache':str(root/'npm-cache'),'npm_config_update_notifier':'false','npm_config_audit':'false','npm_config_fund':'false'})
args=['npx','--no-install','tsx','--test','test/personal-work-notes.test.ts'];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (logs/'work-notes-final.stdout').open('wb') as out,(logs/'work-notes-final.stderr').open('wb') as err:
 p=subprocess.Popen(args,cwd=repo,env=env,stdout=out,stderr=err,start_new_session=True);timedout=False
 try:code=p.wait(timeout=900)
 except subprocess.TimeoutExpired:
  timedout=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 try:os.killpg(p.pid,signal.SIGTERM)
 except ProcessLookupError:pass
(logs/'work-notes-final.json').write_text(json.dumps({'command':args,'cwd':str(repo),'env':{key:env[key] for key in ['RUN_MODEL_CHECK','TMPDIR','npm_config_cache','npm_config_update_notifier','npm_config_audit','npm_config_fund']},'exitCode':code,'timedOut':timedout,'started':started,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
checked=[]
for item in manifest:
 name=item['path']
 if name.startswith('apps/ruukoto/src/personal-') and name.endswith('.ts') or name.startswith('test/personal-') and name.endswith('.test.ts'):
  observed=hashlib.sha256((repo/name).read_bytes()).hexdigest();checked.append({'path':name,'expected':item['sha256'],'observed':observed,'matches':observed==item['sha256']})
(logs/'final-runtime-input-check.json').write_text(json.dumps(checked,indent=2)+'\n')
if not all(item['matches'] for item in checked):raise RuntimeError('final runtime input mismatch')
print('work-notes-final: exit '+str(code));print((logs/'work-notes-final.stdout').read_text(errors='replace')[-2500:]);print((logs/'work-notes-final.stderr').read_text(errors='replace')[-2500:]);sys.exit(code)
