import datetime
import hashlib
import json
import os
import pathlib
import signal
import subprocess
import sys
import tarfile

root = pathlib.Path(sys.argv[1])
repo = root / 'repo'
logs = root / 'logs'
logs.mkdir(exist_ok=True)
(root / 'tmp').mkdir(exist_ok=True)
env = os.environ.copy()
env.update({'RUN_MODEL_CHECK': '0', 'TMPDIR': str(root / 'tmp'), 'npm_config_cache': str(root / 'npm-cache'), 'npm_config_update_notifier': 'false', 'npm_config_audit': 'false', 'npm_config_fund': 'false'})

def command(name, args, timeout=900):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (logs / (name + '.stdout')).open('wb') as out, (logs / (name + '.stderr')).open('wb') as err:
        process = subprocess.Popen(args, cwd=repo, env=env, stdout=out, stderr=err, start_new_session=True)
        timed_out = False
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                code = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait()
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    result = {'command': args, 'cwd': str(repo), 'env': {key: env[key] for key in ['RUN_MODEL_CHECK', 'TMPDIR', 'npm_config_cache', 'npm_config_update_notifier', 'npm_config_audit', 'npm_config_fund']}, 'exitCode': code, 'timedOut': timed_out, 'started': started, 'ended': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (logs / (name + '.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(name + ': exit ' + str(code), flush=True)
    if code:
        print((logs / (name + '.stderr')).read_text(errors='replace')[-4000:], flush=True)
    return code

expected_archive = (root / 'source.sha256').read_text().split()[0]
observed_archive = hashlib.sha256((root / 'source.tar.gz').read_bytes()).hexdigest()
if observed_archive != expected_archive:
    raise RuntimeError('archive SHA-256 mismatch')
def extract_filter(member, destination):
    filtered = tarfile.data_filter(member, destination)
    return filtered.replace(mode=member.mode) if member.isfile() else filtered

with tarfile.open(root / 'source.tar.gz') as archive:
    archive.extractall(repo, filter=extract_filter)
manifest = json.loads((root / 'input-manifest.json').read_text())
verified = []
for item in manifest:
    path = repo / item['path']
    content = os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes()
    observed = {'path': item['path'], 'kind': 'symlink' if path.is_symlink() else 'file', 'mode': oct(path.lstat().st_mode & 0o777), 'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)}
    expected = dict(item)
    if item['kind'] == 'symlink':
        expected['mode'] = observed['mode']
    if observed != expected:
        raise RuntimeError('input mismatch: ' + item['path'])
    verified.append(observed)
(logs / 'input-manifest.json').write_text(json.dumps(verified, ensure_ascii=False, indent=2) + '\n')
(logs / 'source.sha256').write_text(observed_archive + '  source.tar.gz\n')
command('environment', ['python3', '-c', "import subprocess; commands=[['uname','-a'],['cat','/etc/os-release'],['node','--version'],['npm','--version'],['python3','--version'],['git','--version'],['df','-h','/tmp','/dev/shm'],['free','-m']]; [subprocess.run(command,check=True) for command in commands]"], timeout=30)
command('git-init', ['git', 'init', '-q'], timeout=30)
setup = command('setup', ['npm', 'run', 'setup', '--', '--skip-hooks'], timeout=1200)
checks = [setup]
if setup == 0:
    checks.append(command('personal-tests', ['npx', '--no-install', 'tsx', '--test', 'test/personal-durable.test.ts', 'test/personal-cli.test.ts', 'test/personal-services.test.ts', 'test/personal-work.test.ts', 'test/personal-work-tools.test.ts', 'test/personal-work-controls.test.ts', 'test/personal-work-notes.test.ts', 'test/personal-service-operations.test.ts', 'test/personal-telegram.test.ts', 'test/personal-telegram-permissions.test.ts']))
    checks.append(command('build', ['npm', 'run', 'build']))
else:
    (logs / 'blocked.json').write_text(json.dumps({'blocked': 'setup failed; tests/build not started'}, indent=2) + '\n')
runtime = []
for item in manifest:
    name = item['path']
    if name.startswith('apps/ruukoto/src/personal-') and name.endswith('.ts') or name.startswith('test/personal-') and name.endswith('.test.ts'):
        observed = hashlib.sha256((repo / name).read_bytes()).hexdigest()
        runtime.append({'path': name, 'expected': item['sha256'], 'observed': observed, 'matches': observed == item['sha256']})
(logs / 'final-runtime-input-check.json').write_text(json.dumps(runtime, indent=2) + '\n')
if not all(item['matches'] for item in runtime):
    raise RuntimeError('runtime source changed during validation')
command('final-environment', ['python3', '-c', "import subprocess; [subprocess.run(command,check=True) for command in [['df','-h','/tmp','/dev/shm'],['free','-m']]]"], timeout=30)
sys.exit(0 if all(code == 0 for code in checks) else 1)
