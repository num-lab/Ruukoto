import datetime,json,pathlib,subprocess,sys
E=pathlib.Path(__file__).parent

def run(name,args):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(args,capture_output=True)
 (E/(name+'.stdout')).write_bytes(r.stdout);(E/(name+'.stderr')).write_bytes(r.stderr)
 (E/(name+'.json')).write_text(json.dumps({'command':args,'started':started,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode},indent=2)+'\n')
 print(name+': exit '+str(r.returncode),flush=True)
 print(r.stdout.decode(errors='replace'),flush=True)
 if r.returncode:print(r.stderr.decode(errors='replace')[-4000:],flush=True)
 return r.returncode
code=run('remote-validation',['ssh','tx','python3 /tmp/ruukoto-work-notes-20261017T043736Z-62zcy7u_/remote-runner.py /tmp/ruukoto-work-notes-20261017T043736Z-62zcy7u_'])
collected=run('download-logs',['scp','-r','tx:/tmp/ruukoto-work-notes-20261017T043736Z-62zcy7u_/logs',str(E/'remote-logs')])
sys.exit(code or collected)
