import datetime
import hashlib
import json
import io
import os
import pathlib
import shlex
import subprocess
import sys
import tarfile

E = pathlib.Path(__file__).parent
W = pathlib.Path('/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable')
ID = json.loads((E / 'session.json').read_text())['remoteId']
remote = '/tmp/' + ID
shm = '/dev/shm/' + ID

def run(name, args, cwd=None):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(args, capture_output=True, cwd=cwd)
    (E / (name + '.stdout')).write_bytes(result.stdout)
    (E / (name + '.stderr')).write_bytes(result.stderr)
    (E / (name + '.json')).write_text(json.dumps({'command': args, 'cwd': str(cwd) if cwd else None, 'exitCode': result.returncode, 'started': started, 'ended': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
    print(name + ': exit ' + str(result.returncode), flush=True)
    if result.returncode:
        print(result.stderr.decode(errors='replace')[-4000:], flush=True)
    return result.returncode

if run('local-git-status', ['git', 'status', '--short', '--branch'], W):
    raise SystemExit(1)
if run('local-base', ['git', 'rev-parse', 'HEAD'], W):
    raise SystemExit(1)
files = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=W).decode().split('\0')
files = sorted({name for name in files if name and os.path.lexists(W / name)})
(E / 'input-files.txt').write_text('\n'.join(files) + '\n')
manifest = []
with tarfile.open(E / 'source.tar.gz', 'w:gz', dereference=False) as archive:
    for name in files:
        path = W / name
        info = archive.gettarinfo(str(path), arcname=name)
        content = os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes()
        manifest.append({'path': name, 'kind': 'symlink' if path.is_symlink() else 'file', 'mode': oct(path.lstat().st_mode & 0o777), 'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)})
        if info.isfile():
            info.size = len(content)
            archive.addfile(info, io.BytesIO(content))
        else:
            archive.addfile(info)
(E / 'input-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
(E / 'source.sha256').write_text(hashlib.sha256((E / 'source.tar.gz').read_bytes()).hexdigest() + '  source.tar.gz\n')
script = """import pathlib,sys,os
root=pathlib.Path(sys.argv[1]); shm=pathlib.Path(sys.argv[2]); marker=sys.argv[3]
os.umask(0o077)
root.mkdir(); shm.mkdir(); (shm/'repo').mkdir(); (root/'repo').symlink_to(shm/'repo',target_is_directory=True)
(root/'.owner').write_text(marker+'\\n'); (shm/'.owner').write_text(marker+'\\n')
print(str(root)); print(str(shm))
"""
code = run('create-remote', ['ssh', 'tx', 'python3 -c ' + shlex.quote(script) + ' ' + shlex.quote(remote) + ' ' + shlex.quote(shm) + ' ' + shlex.quote(ID)])
if code:
    raise SystemExit(code)
code = run('upload', ['scp', str(E / 'source.tar.gz'), str(E / 'source.sha256'), str(E / 'input-manifest.json'), str(E / 'remote-runner.py'), 'tx:' + remote + '/'])
if code:
    raise SystemExit(code)
code = run('remote-validation', ['ssh', 'tx', 'python3 ' + shlex.quote(remote + '/remote-runner.py') + ' ' + shlex.quote(remote)])
collected = run('download-logs', ['scp', '-r', 'tx:' + remote + '/logs', str(E / 'remote-logs')])
print('EVIDENCE_DIRECTORY=' + str(E), flush=True)
print('REMOTE_DIRECTORY=' + remote, flush=True)
print('SHM_DIRECTORY=' + shm, flush=True)
raise SystemExit(code or collected)
