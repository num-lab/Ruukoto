import os,pathlib,signal,time,shutil,json,subprocess
root=pathlib.Path('/tmp/rk13-u6_eywbx');shm=pathlib.Path('/dev/shm/rk13-u6_eywbx')
assert root.name==shm.name and root.name.startswith('rk13-')
assert str(root.parent)=='/tmp' and str(shm.parent)=='/dev/shm'

def scoped_processes():
 result=[]
 for entry in pathlib.Path('/proc').iterdir():
  if not entry.name.isdigit() or int(entry.name)==os.getpid():continue
  try:
   if entry.stat().st_uid!=os.getuid():continue
   cwd=os.readlink(entry/'cwd')
   if any(cwd==str(base) or cwd.startswith(str(base)+'/') for base in [root,shm]):result.append({'pid':int(entry.name),'cwd':cwd,'comm':(entry/'comm').read_text().strip()})
  except (PermissionError,FileNotFoundError,ProcessLookupError):pass
 return result
before=scoped_processes()
for item in before:
 try:os.kill(item['pid'],signal.SIGTERM)
 except ProcessLookupError:pass
if before:time.sleep(2)
after_term=scoped_processes()
for item in after_term:
 try:os.kill(item['pid'],signal.SIGKILL)
 except ProcessLookupError:pass
if after_term:time.sleep(1)
after_kill=scoped_processes()
assert not after_kill,after_kill
removed=[]
for p in [root,shm]:
 assert not p.is_symlink(),str(p)
 if p.exists():shutil.rmtree(p);removed.append(str(p))
print(json.dumps({'before':before,'afterTerm':after_term,'afterKill':after_kill,'removed':removed,'remainingPaths':[str(p) for p in [root,shm] if p.exists()],'disk':subprocess.check_output(['df','-h','/tmp','/dev/shm'],text=True)},ensure_ascii=False,indent=2))
