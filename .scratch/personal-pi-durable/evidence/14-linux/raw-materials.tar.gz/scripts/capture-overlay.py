import hashlib
import io
import json
import os
import pathlib
import stat
import tarfile
import time

source = pathlib.Path("/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable")
destination = pathlib.Path(__file__).resolve().parent.parent
start = time.time()
runtime = json.loads((destination / "runtime-input-manifest.json").read_text())
names = ["apps/ruukoto/src/personal-report.ts", "test/personal-reports.test.ts"]
old = {item["path"]: item for item in runtime["files"]}
unchanged = []
for item in runtime["files"]:
    if item["path"] in names:
        continue
    data = (source / item["path"]).read_bytes()
    assert hashlib.sha256(data).hexdigest() == item["sha256"], item["path"]
    unchanged.append(item["path"])
new = []
with tarfile.open(destination / "overlay.tar.gz", "w:gz") as archive:
    for name in names:
        path = source / name
        metadata = path.lstat()
        assert stat.S_ISREG(metadata.st_mode)
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.mode = stat.S_IMODE(metadata.st_mode)
        info.mtime = int(metadata.st_mtime)
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
        item = {"path": name, "kind": "file", "mode": info.mode, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        new.append(item)
        target = destination / "overlay-source" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
overlay = {"start": start, "end": time.time(), "old": [old[name] for name in names], "new": new, "unchangedRuntimePaths": unchanged, "authorization": "根代理明确请求仅覆盖这两个当前文件，补跑 reports 与 service-operations 两份测试及 build。"}
(destination / "input-overlay.json").write_text(json.dumps(overlay, indent=2, ensure_ascii=False) + "\n")
replacement = {item["path"]: item for item in new}
for prefix in ["", "runtime-"]:
    manifest = json.loads((destination / f"{prefix}input-manifest.json").read_text())
    manifest["files"] = [replacement.get(item["path"], item) for item in manifest["files"]]
    manifest["overlayTime"] = overlay["end"]
    (destination / f"effective-{prefix}input-manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"start": start, "end": overlay["end"], "overlaid": new, "unchangedRuntimeFiles": len(unchanged)}, indent=2))
