import hashlib
import io
import json
import os
import pathlib
import stat
import subprocess
import tarfile
import time

source = pathlib.Path("/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable")
destination = pathlib.Path(__file__).resolve().parent.parent
start = time.time()
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip()
names = subprocess.check_output(["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"], cwd=source).decode().split("\0")
names = sorted({name for name in names if name and not (name.startswith(".scratch/") and "/evidence/" in name)})
manifest = []
with tarfile.open(destination / "source.tar.gz", "w:gz") as archive:
    for name in names:
        path = source / name
        if not path.exists() and not path.is_symlink():
            continue
        metadata = path.lstat()
        info = tarfile.TarInfo(name)
        info.mode = stat.S_IMODE(metadata.st_mode)
        info.mtime = int(metadata.st_mtime)
        if stat.S_ISLNK(metadata.st_mode):
            target = os.readlink(path)
            data = target.encode()
            info.type = tarfile.SYMTYPE
            info.linkname = target
            archive.addfile(info)
            kind = "symlink"
        else:
            assert stat.S_ISREG(metadata.st_mode), name
            data = path.read_bytes()
            info.size = len(data)
            archive.addfile(info, io.BytesIO(data))
            kind = "file"
        manifest.append({"path": name, "kind": kind, "mode": info.mode, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})
value = {"head": head, "start": start, "end": time.time(), "files": manifest}
(destination / "input-manifest.json").write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
runtime = [item for item in manifest if item["path"].startswith("apps/ruukoto/src/personal-") or item["path"].startswith("test/personal-")]
(destination / "runtime-input-manifest.json").write_text(json.dumps({"head": head, "files": runtime}, indent=2, ensure_ascii=False) + "\n")
archive = destination / "source.tar.gz"
(destination / "source.sha256").write_text(hashlib.sha256(archive.read_bytes()).hexdigest() + "  source.tar.gz\n")
(destination / "source-status.txt").write_text(subprocess.check_output(["git", "status", "--short", "--branch"], cwd=source, text=True))
print(json.dumps({"head": head, "files": len(manifest), "runtimeFiles": len(runtime), "inputBytes": sum(item["size"] for item in manifest), "archiveBytes": archive.stat().st_size, "start": start, "end": value["end"]}, indent=2))
