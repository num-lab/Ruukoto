import json
import os
import pathlib
import shutil
import sys
import time

root = pathlib.Path(sys.argv[1])
memory = pathlib.Path("/dev/shm") / root.name
assert root.parent == pathlib.Path("/tmp") and root.name.startswith("rk14-")
matches = []
for item in pathlib.Path("/proc").iterdir():
    if not item.name.isdecimal():
        continue
    try:
        cwd = os.readlink(item / "cwd")
        if cwd == str(root) or cwd.startswith(str(root) + "/") or cwd == str(memory) or cwd.startswith(str(memory) + "/"):
            matches.append({"pid": int(item.name), "cwd": cwd})
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        pass
if matches:
    print(json.dumps({"time": time.time(), "processes": matches, "removed": False}))
    sys.exit(1)
shutil.rmtree(root)
shutil.rmtree(memory)
print(json.dumps({"time": time.time(), "root": str(root), "memory": str(memory), "processes": matches, "rootExists": root.exists(), "memoryExists": memory.exists(), "removed": True}))
