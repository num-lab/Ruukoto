import json
import os
import pathlib
import platform
import subprocess
import tempfile
import time

start = time.time()
root = pathlib.Path(tempfile.mkdtemp(prefix="rk14-", dir="/tmp"))
memory = pathlib.Path("/dev/shm") / root.name
memory.mkdir(mode=0o700)
(memory / "repo").mkdir(mode=0o700)
(root / "repo").symlink_to(memory / "repo", target_is_directory=True)
for name in ["cache", "tmp", "logs"]:
    (root / name).mkdir(mode=0o700)
commands = [["uname", "-a"], ["node", "--version"], ["npm", "--version"], ["python3", "--version"], ["git", "--version"], ["df", "-h", "/", "/tmp", "/dev/shm"]]
environment = []
for command in commands:
    result = subprocess.run(command, text=True, capture_output=True)
    environment.append({"command": command, "exitCode": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
value = {"root": str(root), "memory": str(memory), "repo": str(root / "repo"), "start": start, "end": time.time(), "environment": environment, "platform": platform.platform(), "osRelease": pathlib.Path("/etc/os-release").read_text()}
(root / "logs" / "provision.json").write_text(json.dumps(value, indent=2) + "\n")
print(json.dumps(value, indent=2))
