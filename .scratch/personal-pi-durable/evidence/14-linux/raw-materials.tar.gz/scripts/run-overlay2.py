import json
import os
import pathlib
import subprocess
import sys
import time

root = pathlib.Path(sys.argv[1])
repo = root / "repo"
logs = root / "logs"
environment = dict(os.environ, RUN_MODEL_CHECK="0", npm_config_cache=str(root / "cache"), TMPDIR=str(root / "tmp"))
commands = [("overlay2-reports", ["npx", "--no-install", "tsx", "--test", "test/personal-reports.test.ts"])]
results = []
for name, command in commands:
    start = time.time()
    value = {"command": command, "cwd": str(repo), "environment": {key: environment[key] for key in ["RUN_MODEL_CHECK", "npm_config_cache", "TMPDIR"]}, "start": start}
    (logs / f"{name}.json").write_text(json.dumps(value, indent=2) + "\n")
    with (logs / f"{name}.stdout.log").open("w") as stdout, (logs / f"{name}.stderr.log").open("w") as stderr:
        process = subprocess.Popen(command, cwd=repo, env=environment, stdout=stdout, stderr=stderr)
        value["pid"] = process.pid
        value["exitCode"] = process.wait()
    value["end"] = time.time()
    value["durationSeconds"] = value["end"] - start
    (logs / f"{name}.json").write_text(json.dumps(value, indent=2) + "\n")
    results.append(value)
    print(json.dumps(value), flush=True)
    if value["exitCode"]:
        break
(logs / "overlay2-summary.json").write_text(json.dumps(results, indent=2) + "\n")
sys.exit(next((value["exitCode"] for value in results if value["exitCode"]), 0))
