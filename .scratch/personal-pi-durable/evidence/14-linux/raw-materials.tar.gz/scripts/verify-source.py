import hashlib
import json
import os
import pathlib
import stat
import sys
import time

repo, manifest, output = map(pathlib.Path, sys.argv[1:])
start = time.time()
items = json.loads(manifest.read_text())["files"]
errors = []
for item in items:
    path = repo / item["path"]
    try:
        metadata = path.lstat()
        kind = "symlink" if stat.S_ISLNK(metadata.st_mode) else "file" if stat.S_ISREG(metadata.st_mode) else "other"
        data = os.readlink(path).encode() if kind == "symlink" else path.read_bytes()
        if kind != item["kind"] or len(data) != item["size"] or hashlib.sha256(data).hexdigest() != item["sha256"] or (kind == "file" and stat.S_IMODE(metadata.st_mode) != item["mode"]):
            errors.append(item["path"])
    except Exception as error:
        errors.append({"path": item["path"], "error": str(error)})
result = {"start": start, "end": time.time(), "files": len(items), "errors": errors, "exitCode": 1 if errors else 0}
output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
sys.exit(result["exitCode"])
