// ../../../../../../private/tmp/ruukoto-command-24.93Sjb4/probe-entry.mjs
import assert from "node:assert/strict";
import * as fs6 from "node:fs";
import * as path6 from "node:path";
import { randomBytes as randomBytes2, createHash as createHash3 } from "node:crypto";
import { spawn as spawn2, execFileSync } from "node:child_process";

// apps/ruukoto/src/personal-command-execution.ts
import * as fs5 from "node:fs";
import * as path5 from "node:path";
import * as os2 from "node:os";
import { createHash as createHash2 } from "node:crypto";
import { Readable as Readable2, Transform } from "node:stream";
import { pipeline } from "node:stream/promises";
import { isDeepStrictEqual } from "node:util";

// packages/agent/src/execution/native-linux-identity.ts
import * as fs4 from "node:fs";
import * as path4 from "node:path";
import { randomBytes, createHash } from "node:crypto";
import { execFile as execFile3 } from "node:child_process";

// packages/agent/src/execution/native.ts
import * as fs3 from "node:fs";
import * as path3 from "node:path";
import * as os from "node:os";
import { execFile as execFile2 } from "node:child_process";
import { fileURLToPath } from "node:url";

// packages/agent/src/execution/approved-ops.ts
import * as fs from "node:fs";
import * as path from "node:path";
var MAX_HTTP_RESPONSE_BYTES = 1024 * 1024;
var MAX_FILE_CONTENT_BYTES = 8 * 1024 * 1024;
var ApprovedOpError = class extends Error {
};
function identityCovers(parent, target, descendants = false) {
  if (!fs.existsSync(parent)) return false;
  const pinned = fs.statSync(parent, { bigint: true });
  const targetIdentities = /* @__PURE__ */ new Set();
  let current = path.resolve(target);
  for (; ; ) {
    if (fs.existsSync(current)) {
      const stat = fs.statSync(current, { bigint: true });
      if (stat.dev === pinned.dev && stat.ino === pinned.ino) return true;
      if (descendants) targetIdentities.add(`${stat.dev}:${stat.ino}`);
    }
    const ancestor = path.dirname(current);
    if (ancestor === current) break;
    current = ancestor;
  }
  if (!descendants || !pinned.isDirectory()) return false;
  const pending = [fs.realpathSync(parent)], visited = /* @__PURE__ */ new Set();
  while (pending.length) {
    const entry = pending.pop();
    const stat = fs.lstatSync(entry, { bigint: true });
    if (stat.isSymbolicLink()) continue;
    const key = `${stat.dev}:${stat.ino}`;
    if (targetIdentities.has(key)) return true;
    if (!stat.isDirectory() || visited.has(key)) continue;
    visited.add(key);
    pending.push(...fs.readdirSync(entry).map((name) => path.join(entry, name)));
  }
  return false;
}
function isProtectedPath(resolved, protectedRoots) {
  for (const root of protectedRoots) {
    const realRoot = path.resolve(root);
    if (resolved === realRoot || resolved.startsWith(realRoot + path.sep) || identityCovers(realRoot, resolved, true)) {
      return true;
    }
  }
  return false;
}
function assertGrantNotProtected(resolved, protectedRoots) {
  if (isProtectedPath(resolved, protectedRoots)) {
    throw new ApprovedOpError(`\u8DEF\u5F84\u4F4D\u4E8E\u63A7\u5236\u9762/\u670D\u52A1\u6570\u636E\u76EE\u5F55\u5185\uFF0C\u59CB\u7EC8\u6392\u9664\uFF1A${resolved}`);
  }
  const prefix = resolved.endsWith(path.sep) ? resolved : resolved + path.sep;
  for (const root of protectedRoots) {
    const realRoot = path.resolve(root);
    if (realRoot === resolved || realRoot.startsWith(prefix) || identityCovers(resolved, realRoot)) {
      throw new ApprovedOpError(`\u8DEF\u5F84\u662F\u63A7\u5236\u9762/\u670D\u52A1\u6570\u636E\u76EE\u5F55\u7684\u7236\u7EA7\uFF0C\u59CB\u7EC8\u6392\u9664\uFF1A${resolved}`);
    }
  }
}

// packages/agent/src/execution/native-linux.ts
import * as fs2 from "node:fs";
import * as path2 from "node:path";
import { randomUUID } from "node:crypto";
import { execFile, spawn } from "node:child_process";
import { Readable } from "node:stream";
var BWRAP = "/usr/bin/bwrap";
var SYSTEMD_RUN = "/usr/bin/systemd-run";
var SYSTEMCTL = "/usr/bin/systemctl";
var hostEnv = () => ({
  PATH: "/usr/bin:/bin",
  XDG_RUNTIME_DIR: process.env.XDG_RUNTIME_DIR,
  DBUS_SESSION_BUS_ADDRESS: process.env.DBUS_SESSION_BUS_ADDRESS,
  LANG: "C.UTF-8"
});
function command(program, args) {
  return new Promise((resolve4) => execFile(
    program,
    args,
    { encoding: "utf8", timeout: 5e3, env: hostEnv() },
    (error, stdout) => resolve4({ code: error ? typeof error.code === "number" ? error.code : null : 0, stdout })
  ));
}
function linuxNativeScopeEmpty(cgroup) {
  if (cgroup === null) return false;
  try {
    return fs2.readFileSync(path2.join(cgroup, "cgroup.events"), "utf8").split("\n").includes("populated 0");
  } catch (error) {
    if (!(error instanceof Error && "code" in error && ["ENOENT", "ENODEV"].includes(String(error.code)))) return false;
    try {
      fs2.statSync(cgroup);
      return false;
    } catch (missing2) {
      return missing2 instanceof Error && "code" in missing2 && missing2.code === "ENOENT";
    }
  }
}
function nativeNetworkFilter(architecture) {
  const data = architecture === "x64" ? { arch: 3221225534, calls: [41, 42, 44, 46, 307, 425] } : architecture === "arm64" ? { arch: 3221225655, calls: [198, 203, 206, 211, 269, 425] } : null;
  if (!data) throw new ExecutionError("execution_unavailable", "\u539F\u751F\u7F51\u7EDC\u8FC7\u6EE4\u53EA\u652F\u6301 Linux x64 \u4E0E arm64", void 0, "sandbox_rejected");
  const instructions = [
    [32, 0, 0, 4],
    [21, 1, 0, data.arch],
    [6, 0, 0, 2147483648],
    [32, 0, 0, 0],
    [69, 0, 1, 1073741824],
    [6, 0, 0, 2147483648]
  ];
  for (const call of data.calls) instructions.push([21, 0, 1, call], [6, 0, 0, 327681]);
  instructions.push([6, 0, 0, 2147418112]);
  const buffer = Buffer.alloc(instructions.length * 8);
  instructions.forEach(([code, yes, no, value], i) => {
    buffer.writeUInt16LE(code, i * 8);
    buffer[i * 8 + 2] = yes;
    buffer[i * 8 + 3] = no;
    buffer.writeUInt32LE(value, i * 8 + 4);
  });
  return buffer;
}
function linuxNativeArgs(input) {
  const args = [
    "--unshare-all",
    "--die-with-parent",
    "--new-session",
    "--clearenv",
    "--cap-drop",
    "ALL",
    "--proc",
    "/proc",
    "--dev",
    "/dev",
    "--tmpfs",
    "/tmp"
  ];
  for (const root of [...input.runtimeReadRoots].sort((a, b) => a.length - b.length)) args.push("--ro-bind", root, root);
  for (const alias of ["/bin", "/sbin", "/lib", "/lib64"]) {
    if (fs2.existsSync(alias) && fs2.lstatSync(alias).isSymbolicLink()) args.push("--symlink", fs2.readlinkSync(alias), alias);
  }
  for (const alias of input.toolAliases) {
    if (!input.runtimeReadRoots.some((root) => alias.path === root || alias.path.startsWith(root + "/"))) {
      args.push("--symlink", alias.target, alias.path);
    }
  }
  args.push("--bind", input.tempDir, input.tempDir);
  for (const mount of input.mounts) args.push(mount.access === "read" ? "--ro-bind" : "--bind", mount.path, mount.path);
  for (const [key, value] of Object.entries(input.env)) args.push("--setenv", key, value);
  args.push(
    "--remount-ro",
    "/",
    "--remount-ro",
    "/tmp",
    "--remount-ro",
    "/dev",
    "--chdir",
    input.workspace,
    "--seccomp",
    "3",
    input.nodePath,
    "-e",
    "require('node:fs').writeSync(4,'started\\n');require('node:fs').closeSync(4);import(require('node:url').pathToFileURL(process.argv[1]).href)",
    input.workerPath
  );
  return args;
}
async function prerequisites() {
  for (const binary of [BWRAP, SYSTEMD_RUN, SYSTEMCTL]) {
    try {
      fs2.accessSync(binary, fs2.constants.X_OK);
    } catch {
      throw new ExecutionError("execution_unavailable", "Linux \u539F\u751F\u6267\u884C\u7F3A\u5C11 bubblewrap \u6216 user systemd\uFF1B\u89C1 deploy/native", void 0, "binary_missing");
    }
  }
  const restriction = "/proc/sys/kernel/apparmor_restrict_unprivileged_userns";
  if (fs2.existsSync(restriction) && fs2.readFileSync(restriction, "utf8").trim() === "1" && !fs2.existsSync("/etc/apparmor.d/ruukoto-bwrap")) {
    throw new ExecutionError("execution_unavailable", "Linux \u539F\u751F\u6267\u884C\u7F3A\u5C11 bwrap \u7684 AppArmor userns \u914D\u7F6E\uFF1B\u6309 deploy/native \u5B89\u88C5\u540E\u91CD\u8BD5", void 0, "policy_missing");
  }
  const manager = await command(SYSTEMCTL, ["--user", "is-system-running"]);
  if (!fs2.existsSync("/sys/fs/cgroup/cgroup.controllers") || !["running", "degraded"].includes(manager.stdout.trim())) {
    throw new ExecutionError("execution_unavailable", "Linux \u539F\u751F\u6267\u884C\u9700\u8981 cgroup v2 \u4E0E\u53EF\u7528\u7684 user systemd", void 0, "policy_missing");
  }
}
async function launchLinuxNative(input, spec, tracking) {
  await prerequisites();
  const scope = tracking?.scope ?? `ruukoto-native-${randomUUID()}.scope`;
  const filterPath = path2.join(input.tempDir, "network.bpf");
  fs2.writeFileSync(filterPath, nativeNetworkFilter(process.arch), { mode: 256 });
  const filter = fs2.openSync(filterPath, "r");
  let child;
  try {
    tracking?.beforeSpawn();
    child = spawn(
      SYSTEMD_RUN,
      [
        "--user",
        "--scope",
        "--quiet",
        "--unit",
        scope,
        "--property",
        "Delegate=yes",
        ...tracking ? ["--property", `Description=${tracking.description}`] : [],
        BWRAP,
        ...linuxNativeArgs(input)
      ],
      { stdio: ["pipe", "pipe", "pipe", filter, "pipe"], env: hostEnv(), ...tracking ? { detached: true } : {} }
    );
  } finally {
    fs2.closeSync(filter);
  }
  let exited = false;
  const exit = new Promise((resolve4, reject) => {
    child.on("exit", (code, signal) => {
      exited = true;
      resolve4({ code, signal });
    });
    child.on("error", () => {
      exited = true;
      reject(new ExecutionError("execution_unavailable", "Linux \u539F\u751F\u6267\u884C\u5165\u53E3\u542F\u52A8\u5931\u8D25", void 0, "sandbox_rejected"));
    });
  });
  void exit.catch(() => void 0);
  if (child.pid === void 0) {
    await exit;
    throw new ExecutionError("execution_unavailable", "Linux \u539F\u751F\u6267\u884C\u672A\u521B\u5EFA\u5355\u5143", void 0, "sandbox_rejected");
  }
  let cgroup = null;
  let groupChanged = false;
  let stopped = null;
  const query = async () => {
    const result = await command(SYSTEMCTL, [
      "--user",
      "show",
      scope,
      "--property",
      `LoadState,ActiveState,ControlGroup${tracking ? ",InvocationID,Description" : ""}`
    ]);
    if (result.code !== 0) return null;
    const fields = new Map(result.stdout.trim().split("\n").map((line) => {
      const index = line.indexOf("=");
      return [line.slice(0, index), line.slice(index + 1)];
    }));
    const group = fields.get("ControlGroup") ?? "";
    if (group) {
      if (!path2.isAbsolute(group) || path2.normalize(group) !== group || path2.basename(group) !== scope) {
        groupChanged = true;
        return null;
      }
      const current = path2.join("/sys/fs/cgroup", group);
      if (cgroup !== null && cgroup !== current) groupChanged = true;
      cgroup = current;
    }
    return {
      load: fields.get("LoadState") ?? "",
      active: fields.get("ActiveState") ?? "",
      group,
      invocationId: fields.get("InvocationID") ?? "",
      description: fields.get("Description") ?? ""
    };
  };
  const stop = () => stopped ??= (async () => {
    await query();
    if (cgroup && fs2.existsSync(cgroup)) {
      try {
        fs2.writeFileSync(path2.join(cgroup, "cgroup.kill"), "1");
      } catch {
      }
    }
    await command(SYSTEMCTL, ["--user", "kill", "--signal=SIGKILL", scope]);
    await command(SYSTEMCTL, ["--user", "stop", scope]);
    const deadline = Date.now() + 5e3;
    while (Date.now() < deadline) {
      const state = await query();
      const empty = !groupChanged && linuxNativeScopeEmpty(cgroup);
      if (state && exited && empty && (state.load === "not-found" || ["inactive", "failed"].includes(state.active))) return true;
      await new Promise((resolve4) => setTimeout(resolve4, 50));
    }
    return false;
  })();
  const unit = {
    entry: {
      kind: "systemd_unit",
      id: scope,
      label: `tool-worker native scope=${scope} task=${spec.taskId}`,
      stop
    },
    stdin: child.stdin,
    stdout: child.stdout,
    stderr: child.stderr,
    exit
  };
  try {
    tracking?.spawned(child.pid);
    const marker = child.stdio[4];
    if (!(marker instanceof Readable)) throw new ExecutionError("execution_unavailable", "\u539F\u751F\u542F\u52A8\u6838\u5B9E\u901A\u9053\u4E0D\u53EF\u7528", unit, "sandbox_rejected");
    const started = new Promise((resolve4) => {
      let buffer = "";
      const timer = setTimeout(() => resolve4(false), 1e4);
      marker.setEncoding("utf8");
      marker.on("data", (chunk) => {
        buffer += chunk;
        if (buffer.includes("started\n")) {
          clearTimeout(timer);
          resolve4(true);
        }
      });
      void exit.then(() => {
        clearTimeout(timer);
        resolve4(false);
      }, () => {
        clearTimeout(timer);
        resolve4(false);
      });
    });
    if (!await started) throw new ExecutionError("execution_unavailable", "bubblewrap \u7B56\u7565\u6216 namespace \u542F\u52A8\u88AB\u62D2\u7EDD\uFF1B\u6838\u5BF9 deploy/native \u524D\u7F6E", unit, "sandbox_rejected");
    const status = await query();
    if (!status?.group || path2.basename(status.group) !== scope) {
      throw new ExecutionError("execution_unavailable", "\u65E0\u6CD5\u6838\u5B9E\u539F\u751F\u6267\u884C\u7684 user scope \u8EAB\u4EFD", unit, exited ? "worker_failed" : "policy_missing");
    }
    tracking?.observed(status);
    fs2.accessSync(path2.join(cgroup, "cgroup.kill"), fs2.constants.W_OK);
    return unit;
  } catch (error) {
    if (error instanceof ExecutionError && error.unit) throw error;
    throw new ExecutionError("execution_unavailable", "\u539F\u751F\u6267\u884C\u65E0\u6CD5\u6838\u5B9E cgroup \u56DE\u6536\u80FD\u529B", unit, "policy_missing");
  }
}

// packages/agent/src/execution/native.ts
var NATIVE_WORKER_PATH = fileURLToPath(new URL("../../../../worker/worker.mjs", "file:///tmp/ruukoto-command-24.uPkbfF/source/packages/agent/src/execution/native.ts"));
var NATIVE_MACOS_HELPER_PATH = fileURLToPath(new URL("../../../../worker/native-macos-supervisor", "file:///tmp/ruukoto-command-24.uPkbfF/source/packages/agent/src/execution/native.ts"));
var covers = (root, target) => root === target || target.startsWith(root + path3.sep);
function assertNativeFileLinks(mounts) {
  const visited = /* @__PURE__ */ new Set();
  const directories = /* @__PURE__ */ new Map();
  const fileEntries = /* @__PURE__ */ new Map();
  const files = /* @__PURE__ */ new Map();
  const links = /* @__PURE__ */ new Map();
  const pending = mounts.map((mount) => ({ path: mount.path }));
  const reject = () => {
    throw new ExecutionError("execution_unavailable", "\u6388\u6743\u76EE\u5F55\u7684\u6587\u4EF6\u522B\u540D\u8D85\u51FA\u8303\u56F4\u6216\u6743\u9650\u51B2\u7A81\uFF1B\u79FB\u9664\u522B\u540D\u6216\u4F7F\u7528\u72EC\u7ACB\u6587\u4EF6\u526F\u672C\u540E\u91CD\u8BD5", void 0, "sandbox_rejected");
  };
  while (pending.length) {
    const { path: current, entryKey } = pending.pop();
    if (visited.has(current)) continue;
    visited.add(current);
    const stat = fs3.lstatSync(current, { bigint: true });
    const access = mounts.some((mount) => mount.access === "read" && covers(mount.path, current)) ? "read" : "read_write";
    if (stat.isDirectory()) {
      const directoryKey = `${stat.dev}:${stat.ino}`;
      const prior = directories.get(directoryKey);
      if (prior !== void 0) {
        if (prior !== access) reject();
        continue;
      }
      directories.set(directoryKey, access);
      pending.push(...fs3.readdirSync(current).map((name) => ({ path: path3.join(current, name), entryKey: `${directoryKey}:${name}` })));
    } else if (stat.isFile()) {
      let physicalEntry = entryKey;
      if (!physicalEntry) {
        const parent = path3.dirname(current), name = path3.basename(current);
        if (!fs3.readdirSync(parent).includes(name)) reject();
        const parentStat = fs3.statSync(parent, { bigint: true });
        physicalEntry = `${parentStat.dev}:${parentStat.ino}:${name}`;
      }
      const prior = fileEntries.get(physicalEntry);
      if (prior !== void 0) {
        if (prior !== access) reject();
        continue;
      }
      fileEntries.set(physicalEntry, access);
      const key = `${stat.dev}:${stat.ino}`;
      const fileAccess = files.get(key);
      if (fileAccess !== void 0 && fileAccess !== access) reject();
      files.set(key, access);
      if (stat.nlink > 1n) {
        const entries = links.get(key) ?? [];
        entries.push({ path: current, access });
        links.set(key, entries);
      }
    }
  }
  for (const [key, entries] of links) {
    const mixedAccess = entries.some((entry) => entry.access !== entries[0].access);
    for (const entry of entries) {
      const stat = fs3.lstatSync(entry.path, { bigint: true });
      if (!stat.isFile() || `${stat.dev}:${stat.ino}` !== key || stat.nlink !== BigInt(entries.length) || mixedAccess) {
        reject();
      }
    }
  }
}
function canonicalExisting(target) {
  const real = fs3.realpathSync(target);
  if (path3.resolve(target) !== real) {
    throw new ExecutionError("execution_unavailable", "\u539F\u751F\u6267\u884C\u7684\u6388\u6743\u8DEF\u5F84\u5FC5\u987B\u4F7F\u7528\u5DF2\u6838\u5B9E\u7684\u771F\u5B9E\u8DEF\u5F84", void 0, "sandbox_rejected");
  }
  return real;
}
function runFile(command2, args) {
  return new Promise((resolve4, reject) => execFile2(
    command2,
    args,
    { encoding: "utf8", timeout: 5e3 },
    (error, stdout) => error ? reject(error) : resolve4(stdout)
  ));
}
async function runtimePaths(workerPath, nodePath, dependencyRoots) {
  const roots = /* @__PURE__ */ new Set([workerPath, nodePath]);
  const aliases = [];
  const dirs = (process.env.PATH ?? "/usr/bin:/bin").split(path3.delimiter).filter((p) => path3.isAbsolute(p));
  const visibleDirs = /* @__PURE__ */ new Set([path3.dirname(nodePath)]);
  const systemRoots = process.platform === "darwin" ? ["/System/Library", "/usr/lib", "/usr/share", "/usr/bin", "/bin", "/usr/sbin", "/sbin", "/Library/Developer/CommandLineTools", "/private/var/select"] : ["/usr/bin", "/usr/sbin", "/usr/lib", "/usr/lib64", "/usr/libexec", "/usr/include", "/usr/share", "/bin", "/sbin", "/lib", "/lib64"];
  for (const root of systemRoots) if (fs3.existsSync(root)) roots.add(fs3.realpathSync(root));
  if (dependencyRoots !== void 0) {
    for (const root of dependencyRoots) roots.add(canonicalExisting(root));
  } else {
    let modulesParent = path3.dirname(workerPath);
    while (modulesParent !== path3.dirname(modulesParent)) {
      const modules = path3.join(modulesParent, "node_modules");
      if (fs3.existsSync(path3.join(modules, "@earendil-works/pi-coding-agent"))) {
        roots.add(fs3.realpathSync(modules));
        break;
      }
      modulesParent = path3.dirname(modulesParent);
    }
    if (![...roots].some((root) => path3.basename(root) === "node_modules")) {
      throw new ExecutionError("execution_unavailable", "\u5DE5\u5177\u5DE5\u4F5C\u8FDB\u7A0B\u7684\u8FD0\u884C\u4F9D\u8D56\u672A\u5B89\u88C5\uFF1A\u5148\u8FD0\u884C npm run setup \u548C npm run build", void 0, "binary_missing");
    }
  }
  const executables = /* @__PURE__ */ new Set([nodePath]);
  for (const name of ["node", "npm", "npx", "git", "python3", "cc", "c++", "clang", "make"]) {
    const requested = dirs.map((dir) => path3.join(dir, name)).find((candidate) => {
      try {
        fs3.accessSync(candidate, fs3.constants.X_OK);
        return fs3.statSync(candidate).isFile();
      } catch {
        return false;
      }
    });
    if (!requested) continue;
    visibleDirs.add(path3.dirname(requested));
    let current = requested;
    const seen = /* @__PURE__ */ new Set();
    while (fs3.lstatSync(current).isSymbolicLink()) {
      if (seen.has(current)) throw new ExecutionError("execution_unavailable", "\u5BBF\u4E3B\u5DE5\u5177\u94FE\u5305\u542B\u5FAA\u73AF\u7B26\u53F7\u94FE\u63A5", void 0, "binary_missing");
      seen.add(current);
      const target = path3.resolve(path3.dirname(current), fs3.readlinkSync(current));
      aliases.push({ path: current, target });
      current = target;
    }
    const real = fs3.realpathSync(requested);
    executables.add(real);
    const installation = real.match(/^(.*\/Cellar\/[^/]+\/[^/]+)(?:\/|$)/)?.[1] ?? real.match(/^(.*\/(?:\.nvm\/versions\/node|\.pyenv\/versions|mise\/installs\/(?:node|python))\/[^/]+)(?:\/|$)/)?.[1];
    roots.add(installation ?? real);
    const npm = real.match(/^(.*\/node_modules\/npm)(?:\/|$)/)?.[1];
    if (npm) roots.add(npm);
  }
  if (process.platform === "darwin") {
    const pending = [...executables];
    const inspected = /* @__PURE__ */ new Set();
    while (pending.length) {
      const binary = pending.pop();
      if (inspected.has(binary)) continue;
      inspected.add(binary);
      const header = fs3.openSync(binary, "r");
      const magic = Buffer.alloc(4);
      try {
        fs3.readSync(header, magic, 0, 4, 0);
      } finally {
        fs3.closeSync(header);
      }
      if (magic.subarray(0, 2).toString() === "#!") continue;
      const listing = await runFile("/usr/bin/otool", ["-L", binary]);
      for (const line of listing.split("\n").slice(1)) {
        const library = line.trim().split(" (")[0];
        if (!path3.isAbsolute(library) || !fs3.existsSync(library)) continue;
        const real = fs3.realpathSync(library);
        roots.add(real);
        if (library !== real) aliases.push({ path: library, target: real });
        pending.push(real);
      }
    }
    const selected = await runFile("/usr/bin/xcrun", ["--find", "clang"]).catch(() => "");
    if (selected.trim() && fs3.existsSync(selected.trim())) {
      const real = fs3.realpathSync(selected.trim());
      const developer = real.match(/^(.*\/(?:CommandLineTools|Xcode\.app))(?:\/|$)/)?.[1];
      if (developer) roots.add(developer);
    }
    for (const license of ["/Library/Preferences/com.apple.dt.Xcode.plist", "/Library/Preferences/com.apple.dt.CommandLineTools.plist"]) {
      if (fs3.existsSync(license)) roots.add(license);
    }
  }
  const canonical = [...roots].map((root) => fs3.realpathSync(root));
  for (const root of canonical) {
    if (root === "/" || root === os.homedir()) {
      throw new ExecutionError("execution_unavailable", "\u5BBF\u4E3B\u5DE5\u5177\u4F9D\u8D56\u9700\u8981\u5F00\u653E\u6574\u4E2A\u6587\u4EF6\u7CFB\u7EDF\u6216 HOME\uFF1B\u8BF7\u7F29\u5C0F\u5B89\u88C5\u4E0E\u6388\u6743\u8303\u56F4", void 0, "sandbox_rejected");
    }
  }
  for (const dir of ["/usr/bin", "/bin", "/usr/sbin", "/sbin"]) visibleDirs.add(dir);
  return { roots: [...new Set(canonical)], aliases, pathValue: [...visibleDirs].join(path3.delimiter) };
}
async function prepareNativeLaunch(config, spec) {
  if (spec.mode === "full_access") throw new ExecutionError("invalid_state", "\u539F\u751F\u6C99\u7BB1\u53EA\u7528\u4E8E\u53D7\u9650\u6267\u884C\u6A21\u5F0F");
  try {
    if (!spec.workspaceIdentity) {
      throw new ExecutionError("execution_unavailable", "\u539F\u751F\u542F\u52A8\u7F3A\u5C11\u5BBF\u4E3B\u9489\u5B9A\u7684\u5DE5\u4F5C\u533A\u76EE\u5F55\u8EAB\u4EFD", void 0, "sandbox_rejected");
    }
    const workspace = canonicalExisting(spec.workspace);
    const mounts = [{ path: workspace, access: "read_write" }];
    for (const grant of spec.grantedPaths) mounts.push({ path: canonicalExisting(grant.path), access: grant.access });
    for (const root of spec.readRoots ?? []) {
      const real = canonicalExisting(root.path);
      const stat = fs3.statSync(real);
      if (root.dev !== void 0 && stat.dev !== root.dev || root.ino !== void 0 && stat.ino !== root.ino) {
        throw new ExecutionError("execution_unavailable", "\u539F\u751F\u6267\u884C\u7684\u53EA\u8BFB\u6839\u8EAB\u4EFD\u5DF2\u53D8\u5316", void 0, "sandbox_rejected");
      }
      mounts.push({ path: real, access: "read" });
    }
    if (spec.workspaceIdentity) {
      const stat = fs3.statSync(workspace);
      if (stat.dev !== spec.workspaceIdentity.dev || stat.ino !== spec.workspaceIdentity.ino) {
        throw new ExecutionError("execution_unavailable", "\u539F\u751F\u6267\u884C\u7684\u5DE5\u4F5C\u533A\u8EAB\u4EFD\u5DF2\u53D8\u5316", void 0, "sandbox_rejected");
      }
    }
    for (const mount of mounts) assertGrantNotProtected(mount.path, config.protectedRoots ?? []);
    for (const read of mounts.filter((m) => m.access === "read")) {
      if (mounts.some((m) => m.access === "read_write" && covers(read.path, m.path))) {
        throw new ExecutionError("execution_unavailable", "\u53EA\u8BFB\u6839\u4E2D\u5B58\u5728\u8BFB\u5199\u6388\u6743\uFF1B\u8BF7\u6D88\u9664\u91CD\u53E0\u6388\u6743\u540E\u91CD\u8BD5", void 0, "sandbox_rejected");
      }
    }
    assertNativeFileLinks(mounts);
    const workerPath = fs3.realpathSync(config.workerPath ?? NATIVE_WORKER_PATH);
    const nodePath = fs3.realpathSync(process.execPath);
    const runtime = await runtimePaths(workerPath, nodePath, config.dependencyRoots);
    const codeRoot2 = fs3.realpathSync(fileURLToPath(new URL("../../../../", "file:///tmp/ruukoto-command-24.uPkbfF/source/packages/agent/src/execution/native.ts")));
    for (const root of runtime.roots) {
      for (const protectedRoot of config.protectedRoots ?? []) {
        const protectedReal = path3.resolve(protectedRoot);
        const codeAsset = protectedReal === codeRoot2 && (root === workerPath || config.dependencyRoots === void 0 && root === path3.join(codeRoot2, "node_modules"));
        if (!codeAsset) assertGrantNotProtected(root, [protectedReal]);
      }
    }
    const injected = spec.env ?? {};
    for (const key of Object.keys(injected)) {
      if (!/^GIT_CONFIG_(COUNT|KEY_\d+|VALUE_\d+)$/.test(key)) {
        throw new ExecutionError("execution_unavailable", "\u539F\u751F\u6267\u884C\u53EA\u63A5\u53D7\u5BBF\u4E3B\u56FA\u5B9A\u7684 Git \u73AF\u5883\u53C2\u6570", void 0, "sandbox_rejected");
      }
    }
    const tempDir = fs3.realpathSync(fs3.mkdtempSync(path3.join(os.tmpdir(), "ruukoto-native-")));
    fs3.mkdirSync(path3.join(tempDir, "home"), { mode: 448 });
    fs3.mkdirSync(path3.join(tempDir, "tmp"), { mode: 448 });
    return {
      workspace,
      mounts: mounts.sort((a, b) => a.path.length - b.path.length),
      runtimeReadRoots: runtime.roots,
      toolAliases: runtime.aliases,
      tempDir,
      nodePath,
      workerPath,
      env: {
        PATH: runtime.pathValue,
        HOME: path3.join(tempDir, "home"),
        TMPDIR: path3.join(tempDir, "tmp"),
        LANG: process.env.LANG ?? "C.UTF-8",
        GIT_CONFIG_NOSYSTEM: "1",
        ...injected
      }
    };
  } catch (error) {
    if (error instanceof ExecutionError) throw error;
    throw new ExecutionError(
      "execution_unavailable",
      "\u539F\u751F\u6267\u884C\u8DEF\u5F84\u6216\u8FD0\u884C\u4F9D\u8D56\u4E0D\u53EF\u7528\uFF1A\u8BF7\u68C0\u67E5\u6388\u6743\u76EE\u5F55\u5E76\u8FD0\u884C npm run build",
      void 0,
      error.code === "ENOENT" ? "binary_missing" : "sandbox_rejected"
    );
  }
}

// packages/agent/src/execution/launchers.ts
var ExecutionError = class extends Error {
  constructor(code, message, unit, reason, options) {
    super(message, options);
    this.unit = unit;
    this.reason = reason;
    this.code = code;
  }
  unit;
  reason;
  code;
};

// packages/agent/src/execution/native-linux-identity.ts
var UUID = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/;
var HEX32 = /^[0-9a-f]{32}$/;
var HEX64 = /^[0-9a-f]{64}$/;
var unavailable = (message) => new ExecutionError("execution_identity_invalid", message);
var isMissing = (error) => error instanceof Error && "code" in error && ["ENOENT", "ESRCH"].includes(String(error.code));
var covers2 = (root, target) => root === target || target.startsWith(root + path4.sep);
function privatePath(target, directory) {
  const stat = fs4.lstatSync(target);
  if (stat.isSymbolicLink() || stat.uid !== process.getuid?.() || stat.mode & 63 || (directory ? !stat.isDirectory() : !stat.isFile() || stat.nlink !== 1)) {
    throw unavailable("\u539F\u6267\u884C\u8BC1\u636E\u76EE\u5F55\u6216\u6587\u4EF6\u4E0D\u53EF\u4FE1\uFF1B\u4FDD\u7559\u5360\u7528\u5E76\u6838\u5B9E\u539F\u6863\u6848");
  }
  return stat;
}
function location(directory, ref) {
  if (!/^native_[0-9a-f]{24}$/.test(ref.executionId) || !HEX32.test(ref.machineId)) throw unavailable("\u539F\u6267\u884C\u5F15\u7528\u975E\u6CD5\uFF1B\u4FDD\u7559\u5360\u7528\u5E76\u6838\u5B9E\u539F\u6863\u6848");
  privatePath(directory, true);
  if (fs4.realpathSync(directory) !== directory) throw unavailable("\u6267\u884C\u8BC1\u636E\u76EE\u5F55\u987B\u4F7F\u7528\u771F\u5B9E\u8DEF\u5F84");
  if (fs4.readFileSync("/etc/machine-id", "utf8").trim() !== ref.machineId) throw unavailable("\u539F\u6267\u884C\u4E0D\u5C5E\u4E8E\u672C\u673A\uFF1B\u4FDD\u7559\u5360\u7528\u5E76\u6838\u5B9E\u539F\u673A\u5668");
  const bootId = fs4.readFileSync("/proc/sys/kernel/random/boot_id", "utf8").trim();
  if (!UUID.test(bootId)) throw unavailable("\u65E0\u6CD5\u6838\u5B9E\u672C\u673A\u542F\u52A8\u8EAB\u4EFD\uFF1B\u4FDD\u7559\u5360\u7528");
  return { claimDir: path4.join(directory, ref.executionId), bootId, scope: `ruukoto-${ref.executionId}.scope` };
}
function record(claimDir, name) {
  const target = path4.join(claimDir, name);
  privatePath(target, false);
  const value = JSON.parse(fs4.readFileSync(target, "utf8"));
  return typeof value === "object" && value !== null && !Array.isArray(value) ? value : null;
}
function writeRecord(claimDir, name, value) {
  fs4.writeFileSync(path4.join(claimDir, name), JSON.stringify(value) + "\n", { flag: "wx", mode: 384 });
}
function readClaim(claimDir, ref, scope) {
  privatePath(claimDir, true);
  const raw = record(claimDir, "claim.json");
  if (!raw || raw.version !== 1 || !raw.ref || typeof raw.ref !== "object") return null;
  const saved = raw.ref;
  if (saved.executionId !== ref.executionId || saved.machineId !== ref.machineId || raw.scope !== scope || typeof raw.bootId !== "string" || !UUID.test(raw.bootId) || typeof raw.token !== "string" || !HEX32.test(raw.token) || typeof raw.fingerprint !== "string" || !HEX64.test(raw.fingerprint) || !["launch", "stop"].includes(String(raw.claimedBy))) return null;
  return raw;
}
function processIdentity(pid) {
  const source = fs4.readFileSync(`/proc/${pid}/stat`, "utf8");
  const fields = source.slice(source.lastIndexOf(") ") + 2).trim().split(/\s+/);
  const processGroup = Number(fields[2]);
  if (!Number.isSafeInteger(processGroup) || processGroup !== pid || !/^\d+$/.test(fields[19] ?? "")) throw unavailable("\u65E0\u6CD5\u6838\u5B9E\u72EC\u7ACB\u542F\u52A8\u5668\u8EAB\u4EFD\uFF1B\u4FDD\u7559\u6267\u884C\u5360\u7528");
  return { pid, startTime: fields[19], processGroup };
}
function launcherExited(raw) {
  if (!raw || !Number.isSafeInteger(raw.pid) || Number(raw.pid) <= 0 || raw.processGroup !== raw.pid || typeof raw.startTime !== "string" || !/^\d+$/.test(raw.startTime)) return false;
  let current;
  try {
    current = processIdentity(Number(raw.pid));
  } catch (error) {
    if (!isMissing(error)) return false;
    current = { pid: 0, processGroup: 0, startTime: "" };
  }
  if (current.startTime === raw.startTime) return false;
  try {
    process.kill(-Number(raw.processGroup), 0);
    return false;
  } catch (error) {
    return error instanceof Error && "code" in error && error.code === "ESRCH";
  }
}
function observation(raw, scope) {
  if (!raw || typeof raw.group !== "string" || !path4.isAbsolute(raw.group) || path4.normalize(raw.group) !== raw.group || !raw.group.startsWith("/sys/fs/cgroup/") || path4.basename(raw.group) !== scope || typeof raw.invocationId !== "string" || !HEX32.test(raw.invocationId) || /^0+$/.test(raw.invocationId) || !Number.isSafeInteger(raw.dev) || !Number.isSafeInteger(raw.ino)) return null;
  return raw;
}
async function unitState(scope) {
  return new Promise((resolve4) => execFile3(
    "/usr/bin/systemctl",
    ["--user", "show", scope, "--property", "LoadState,ActiveState,ControlGroup,InvocationID,Description"],
    { encoding: "utf8", timeout: 5e3, maxBuffer: 1024 * 1024, env: {
      PATH: "/usr/bin:/bin",
      LANG: "C.UTF-8",
      XDG_RUNTIME_DIR: process.env.XDG_RUNTIME_DIR,
      DBUS_SESSION_BUS_ADDRESS: process.env.DBUS_SESSION_BUS_ADDRESS
    } },
    (error, stdout) => {
      if (error) {
        resolve4(null);
        return;
      }
      const fields = {};
      for (const line of stdout.trim().split("\n")) {
        const index = line.indexOf("=");
        if (index <= 0 || Object.hasOwn(fields, line.slice(0, index))) {
          resolve4(null);
          return;
        }
        fields[line.slice(0, index)] = line.slice(index + 1);
      }
      resolve4(fields);
    }
  ));
}
async function launchLinuxExecution(directory, ref, input, spec) {
  let claimDir;
  let claim;
  try {
    const locationInfo = location(directory, ref);
    claimDir = locationInfo.claimDir;
    if (spec.mode === "full_access") throw unavailable("\u6301\u4E45\u539F\u751F\u6267\u884C\u53EA\u652F\u6301\u53D7\u9650\u6A21\u5F0F");
    for (const root of [input.tempDir, ...input.mounts.map((mount) => mount.path), ...input.runtimeReadRoots, ...input.toolAliases.flatMap((alias) => [alias.path, alias.target])]) {
      if (covers2(root, directory) || covers2(directory, root)) throw unavailable("\u6267\u884C\u8BC1\u636E\u76EE\u5F55\u4E0E\u5DE5\u4F5C\u8FDB\u7A0B\u53EF\u89C1\u8303\u56F4\u91CD\u53E0\uFF1B\u8BF7\u4F7F\u7528\u72EC\u7ACB\u4FDD\u62A4\u76EE\u5F55");
    }
    claim = {
      version: 1,
      ref,
      bootId: locationInfo.bootId,
      scope: locationInfo.scope,
      claimedBy: "launch",
      token: randomBytes(16).toString("hex"),
      fingerprint: createHash("sha256").update(JSON.stringify({ input, spec })).digest("hex")
    };
    fs4.mkdirSync(claimDir, { mode: 448 });
    writeRecord(claimDir, "claim.json", claim);
  } catch (error) {
    if (error instanceof ExecutionError) throw error;
    throw new ExecutionError("execution_claim_failed", "\u6267\u884C\u8EAB\u4EFD\u8BA4\u9886\u5931\u8D25\u6216\u5DF2\u88AB\u8BA4\u9886\uFF1B\u672A\u542F\u52A8\u65B0\u6267\u884C", void 0, void 0, { cause: error });
  }
  let attempted = false;
  let launcher;
  const stop = async () => (await stopLinuxExecution(directory, ref)).exited;
  try {
    const unit = await launchLinuxNative(input, spec, {
      scope: claim.scope,
      description: `ruukoto-execution-${claim.token}`,
      beforeSpawn() {
        if (fs4.existsSync(path4.join(claimDir, "stop-requested"))) throw unavailable("\u539F\u6267\u884C\u5DF2\u8BF7\u6C42\u505C\u6B62\uFF1B\u672A\u542F\u52A8\u65B0\u6267\u884C");
        attempted = true;
      },
      spawned(pid) {
        launcher = processIdentity(pid);
        writeRecord(claimDir, "launcher.json", launcher);
      },
      observed(state) {
        if (!launcher || state.description !== `ruukoto-execution-${claim.token}` || !fs4.readFileSync(`/proc/${launcher.pid}/cgroup`, "utf8").split("\n").includes(`0::${state.group}`)) throw unavailable("\u539F\u6267\u884C\u7684\u5355\u5143\u5F52\u5C5E\u65E0\u6CD5\u6838\u5B9E\uFF1B\u4FDD\u7559\u5360\u7528");
        const group = path4.join("/sys/fs/cgroup", state.group);
        const stat = fs4.statSync(group);
        const saved = observation({ group, invocationId: state.invocationId, dev: stat.dev, ino: stat.ino }, claim.scope);
        if (!saved) throw unavailable("\u539F\u6267\u884C\u7684\u5355\u5143\u8EAB\u4EFD\u65E0\u6CD5\u6838\u5B9E\uFF1B\u4FDD\u7559\u5360\u7528");
        writeRecord(claimDir, "observation.json", saved);
      }
    });
    unit.entry.stop = stop;
    return unit;
  } catch (error) {
    if (error instanceof ExecutionError && error.unit) {
      error.unit.entry.stop = stop;
      throw error;
    }
    if (!attempted) {
      try {
        writeRecord(claimDir, "not-dispatched.json", { token: claim.token });
      } catch (proofError) {
        throw new ExecutionError(
          "execution_identity_invalid",
          "\u539F\u6267\u884C\u542F\u52A8\u5931\u8D25\u4E14\u672A\u6D3E\u53D1\u8BC1\u636E\u65E0\u6CD5\u4FDD\u5B58\uFF1B\u4FDD\u7559\u5360\u7528\u4E0E\u73B0\u573A",
          void 0,
          void 0,
          { cause: new AggregateError([error, proofError], "\u542F\u52A8\u4E0E\u8BC1\u636E\u5199\u5165\u5747\u5931\u8D25") }
        );
      }
    }
    if (error instanceof ExecutionError) throw error;
    throw new ExecutionError("execution_unavailable", "\u539F\u6267\u884C\u542F\u52A8\u5931\u8D25\uFF1B\u4FDD\u7559\u8BA4\u9886\u5E76\u6838\u5B9E\u505C\u6B62", void 0, void 0, { cause: error });
  }
}
async function stopLinuxExecution(directory, ref) {
  const result = (exited) => ({ ref, exited });
  try {
    const { claimDir, bootId, scope } = location(directory, ref);
    let created = false;
    try {
      fs4.mkdirSync(claimDir, { mode: 448 });
      created = true;
    } catch (error) {
      if (!(error instanceof Error && "code" in error && error.code === "EEXIST")) throw error;
    }
    if (created) writeRecord(claimDir, "claim.json", { version: 1, ref, bootId, scope, claimedBy: "stop", token: randomBytes(16).toString("hex"), fingerprint: "0".repeat(64) });
    privatePath(claimDir, true);
    try {
      fs4.mkdirSync(path4.join(claimDir, "stop-requested"), { mode: 448 });
    } catch (error) {
      if (!(error instanceof Error && "code" in error && error.code === "EEXIST")) throw error;
    }
    privatePath(path4.join(claimDir, "stop-requested"), true);
    const claim = readClaim(claimDir, ref, scope);
    if (!claim) return result(false);
    if (claim.claimedBy === "stop" || claim.bootId !== bootId) return result(true);
    const optionalRecord = (name) => {
      try {
        return record(claimDir, name);
      } catch (error) {
        if (isMissing(error)) return null;
        throw error;
      }
    };
    if (optionalRecord("not-dispatched.json")?.token === claim.token) return result(true);
    const deadline = Date.now() + 5e3;
    do {
      const saved = observation(optionalRecord("observation.json"), scope);
      if (!saved) return result(false);
      const state = await unitState(scope);
      if (!state) return result(false);
      const sameUnit = state.InvocationID === saved.invocationId && state.Description === `ruukoto-execution-${claim.token}`;
      const inactive = state.LoadState === "not-found" || sameUnit && state.LoadState === "loaded" && ["inactive", "failed"].includes(state.ActiveState);
      let directoryFd;
      try {
        directoryFd = fs4.openSync(saved.group, fs4.constants.O_RDONLY | fs4.constants.O_DIRECTORY | fs4.constants.O_NOFOLLOW);
      } catch (error) {
        if (!isMissing(error)) return result(false);
      }
      try {
        if (directoryFd === void 0) {
          if (inactive && launcherExited(optionalRecord("launcher.json"))) return result(true);
          return result(false);
        }
        const stat = fs4.fstatSync(directoryFd);
        if (stat.dev !== saved.dev || stat.ino !== saved.ino) return result(false);
        if (!inactive) {
          if (!sameUnit || path4.join("/sys/fs/cgroup", state.ControlGroup ?? "") !== saved.group) return result(false);
          const killFd = fs4.openSync(`/proc/self/fd/${directoryFd}/cgroup.kill`, fs4.constants.O_WRONLY | fs4.constants.O_NOFOLLOW);
          try {
            fs4.writeSync(killFd, "1");
          } finally {
            fs4.closeSync(killFd);
          }
        }
        if (linuxNativeScopeEmpty(`/proc/self/fd/${directoryFd}`) && inactive && launcherExited(optionalRecord("launcher.json"))) return result(true);
      } catch {
        return result(false);
      } finally {
        if (directoryFd !== void 0) fs4.closeSync(directoryFd);
      }
      await new Promise((resolve4) => setTimeout(resolve4, 50));
    } while (Date.now() < deadline);
    return result(false);
  } catch (error) {
    if (error instanceof ExecutionError) throw error;
    throw new ExecutionError("execution_identity_invalid", "\u539F\u6267\u884C\u8BC1\u636E\u65E0\u6CD5\u6838\u5B9E\uFF1B\u4FDD\u7559\u5360\u7528\u4E0E\u73B0\u573A", void 0, void 0, { cause: error });
  }
}

// apps/ruukoto/src/personal-error.ts
var PersonalError = class extends Error {
  constructor(code, message, options) {
    super(message, options);
    this.code = code;
    this.name = "PersonalError";
  }
  code;
};

// apps/ruukoto/src/personal-command-execution.ts
var digest = (value) => createHash2("sha256").update(value).digest("hex");
var missing = (error) => error instanceof Error && "code" in error && error.code === "ENOENT";
var invalid = () => new PersonalError("command_record_invalid", "\u539F\u547D\u4EE4\u8BC1\u636E\u65E0\u6CD5\u6838\u5B9E\uFF0C\u8BF7\u4FDD\u7559\u73B0\u573A\u5E76\u67E5\u8BE2\u539F\u5DE5\u4F5C\uFF0C\u52FF\u91CD\u65B0\u6267\u884C\u3002");
var object = (value) => !!value && typeof value === "object" && !Array.isArray(value);
var hex = (value) => typeof value === "string" && /^[0-9a-f]{64}$/.test(value);
var covers3 = (root, target) => root === target || target.startsWith(root + path5.sep);
function privateObject(target, directory) {
  const stat = fs5.lstatSync(target);
  if (stat.uid !== process.getuid?.() || stat.mode & 63 || stat.isSymbolicLink() || (directory ? !stat.isDirectory() : !stat.isFile() || stat.nlink !== 1)) throw invalid();
  return stat;
}
function location2(directory, ref) {
  if (!/^native_[0-9a-f]{24}$/.test(ref.executionId) || !/^[0-9a-f]{32}$/.test(ref.machineId)) throw invalid();
  privateObject(directory, true);
  if (fs5.realpathSync(directory) !== directory || fs5.readFileSync("/etc/machine-id", "utf8").trim() !== ref.machineId) throw invalid();
  return path5.join(directory, `command-${ref.executionId}`);
}
function readJson(target) {
  privateObject(target, false);
  return JSON.parse(fs5.readFileSync(target, "utf8"));
}
function writeJson(target, value) {
  fs5.writeFileSync(target, JSON.stringify(value) + "\n", { flag: "wx", mode: 384 });
}
function tempPath(target) {
  return path5.dirname(target) === fs5.realpathSync(os2.tmpdir()) && /^ruukoto-native-[a-zA-Z0-9]+$/.test(path5.basename(target));
}
function readBinding(record2, ref) {
  try {
    privateObject(record2, true);
  } catch (error) {
    if (missing(error)) return;
    throw error;
  }
  let raw;
  try {
    raw = readJson(path5.join(record2, "request.json"));
  } catch (error) {
    if (missing(error)) return;
    throw error;
  }
  if (!object(raw) || raw.version !== 1 || !isDeepStrictEqual(raw.ref, ref) || !hex(raw.fingerprint) || !object(raw.temp) || typeof raw.temp.path !== "string" || !tempPath(raw.temp.path) || !Number.isSafeInteger(raw.temp.dev) || !Number.isSafeInteger(raw.temp.ino) || !object(raw.request) || !object(raw.request.input) || raw.request.input.tempDir !== raw.temp.path || digest(JSON.stringify(raw.request)) !== raw.fingerprint) throw invalid();
  const owner = readJson(path5.join(path5.dirname(record2), `temp-${Number(raw.temp.dev)}-${Number(raw.temp.ino)}.json`));
  if (!isDeepStrictEqual(owner, { ref, temp: raw.temp })) throw invalid();
  return { version: 1, ref, fingerprint: raw.fingerprint, temp: { path: raw.temp.path, dev: Number(raw.temp.dev), ino: Number(raw.temp.ino) } };
}
async function outputDigest(target) {
  privateObject(target, false);
  const hash = createHash2("sha256");
  let bytes = 0;
  for await (const chunk of fs5.createReadStream(target)) {
    bytes += chunk.length;
    hash.update(chunk);
  }
  return { bytes, sha256: hash.digest("hex") };
}
async function readPersonalCommandReceipt(directory, ref) {
  try {
    const record2 = location2(directory, ref), binding = readBinding(record2, ref);
    let raw;
    try {
      raw = readJson(path5.join(record2, "receipt.json"));
    } catch (error) {
      if (missing(error)) return;
      throw error;
    }
    if (!binding || !object(raw) || raw.version !== 1 || !isDeepStrictEqual(raw.ref, ref) || raw.fingerprint !== binding.fingerprint || !object(raw.exit) || !Number.isInteger(raw.exit.code) || Number(raw.exit.code) < 0 || Number(raw.exit.code) > 255 || raw.exit.signal !== null) throw invalid();
    const stdout = await outputDigest(path5.join(record2, "stdout")), stderr = await outputDigest(path5.join(record2, "stderr"));
    if (!isDeepStrictEqual(raw.stdout, stdout) || !isDeepStrictEqual(raw.stderr, stderr)) throw invalid();
    return { version: 1, ref, fingerprint: binding.fingerprint, exit: { code: Number(raw.exit.code), signal: null }, stdout, stderr };
  } catch (error) {
    if (error instanceof PersonalError) throw error;
    throw new PersonalError("command_record_invalid", "\u539F\u547D\u4EE4\u8BC1\u636E\u65E0\u6CD5\u8BFB\u53D6\uFF0C\u8BF7\u4FDD\u7559\u73B0\u573A\u5E76\u67E5\u8BE2\u539F\u5DE5\u4F5C\uFF0C\u52FF\u91CD\u65B0\u6267\u884C\u3002", { cause: error });
  }
}
async function stopPersonalCommand(directory, ref) {
  try {
    const stopped = await stopLinuxExecution(directory, ref);
    if (!stopped.exited) return { ...stopped, cleaned: false };
    const binding = readBinding(location2(directory, ref), ref);
    if (!binding) return { ...stopped, cleaned: false };
    let stat;
    try {
      stat = fs5.lstatSync(binding.temp.path);
    } catch (error) {
      if (missing(error)) return { ...stopped, cleaned: true };
      throw error;
    }
    if (!stat.isDirectory() || stat.isSymbolicLink() || stat.uid !== process.getuid?.() || stat.dev !== binding.temp.dev || stat.ino !== binding.temp.ino) return { ...stopped, cleaned: false };
    fs5.rmSync(binding.temp.path, { recursive: true });
    return { ...stopped, cleaned: true };
  } catch (error) {
    if (error instanceof PersonalError) throw error;
    throw new PersonalError("command_stop_unverified", "\u539F\u547D\u4EE4\u505C\u6B62\u6216\u4E34\u65F6\u76EE\u5F55\u6E05\u7406\u65E0\u6CD5\u6838\u5B9E\uFF0C\u8BF7\u4FDD\u7559\u5360\u7528\u4E0E\u73B0\u573A\u3002", { cause: error });
  }
}
async function capture(source, target, signal) {
  const hash = createHash2("sha256");
  let bytes = 0;
  const counter = new Transform({ transform(chunk, _encoding, done) {
    bytes += chunk.length;
    hash.update(chunk);
    done(null, chunk);
  } });
  await pipeline(source, counter, fs5.createWriteStream(target, { flags: "wx", mode: 384 }), { signal });
  return { bytes, sha256: hash.digest("hex") };
}
async function runPersonalCommand(options) {
  const { directory, ref, command: command2, spec, input, timeoutMs } = structuredClone({ ...options, signal: void 0 });
  let record2;
  try {
    if (!command2.trim() || command2.includes("\0") || !Number.isInteger(timeoutMs) || timeoutMs <= 0 || timeoutMs > 2 ** 31 - 1 || !["confirm", "auto-review"].includes(spec.mode) || !spec.workspaceIdentity || input.workspace !== spec.workspace) throw invalid();
    const payload = JSON.stringify({ command: command2, workspace: { path: spec.workspace, ...spec.workspaceIdentity } });
    if (Buffer.byteLength(payload) > 4 * 1024 * 1024) throw invalid();
    record2 = location2(directory, ref);
    if (fs5.existsSync(record2)) throw new PersonalError("command_already_claimed", "\u539F\u547D\u4EE4\u5DF2\u767B\u8BB0\uFF0C\u8BF7\u67E5\u8BE2\u539F\u56DE\u6267\u4E0E\u505C\u6B62\u72B6\u6001\uFF0C\u52FF\u91CD\u65B0\u6267\u884C\u3002");
    for (const root of [input.tempDir, ...input.mounts.map((mount) => mount.path), ...input.runtimeReadRoots, ...input.toolAliases.flatMap((alias) => [alias.path, alias.target])]) {
      if (covers3(root, directory) || covers3(directory, root)) throw invalid();
    }
    if (!tempPath(input.tempDir) || fs5.realpathSync(input.tempDir) !== input.tempDir) throw invalid();
    const temp = privateObject(input.tempDir, true);
    options.signal?.throwIfAborted();
    try {
      fs5.mkdirSync(record2, { mode: 448 });
    } catch (error) {
      if (error instanceof Error && "code" in error && error.code === "EEXIST") throw new PersonalError("command_already_claimed", "\u539F\u547D\u4EE4\u5DF2\u767B\u8BB0\uFF0C\u8BF7\u67E5\u8BE2\u539F\u56DE\u6267\u4E0E\u505C\u6B62\u72B6\u6001\uFF0C\u52FF\u91CD\u65B0\u6267\u884C\u3002");
      throw error;
    }
    const request = { command: command2, spec, input };
    const identity = { path: input.tempDir, dev: temp.dev, ino: temp.ino };
    writeJson(path5.join(directory, `temp-${temp.dev}-${temp.ino}.json`), { ref, temp: identity });
    writeJson(path5.join(record2, "request.json"), { version: 1, ref, fingerprint: digest(JSON.stringify(request)), temp: identity, request });
  } catch (error) {
    if (error instanceof PersonalError) throw error;
    throw new PersonalError("command_admission_failed", "\u547D\u4EE4\u767B\u8BB0\u5931\u8D25\uFF0C\u672A\u8BF7\u6C42\u65B0\u6267\u884C\uFF1B\u8BF7\u67E5\u8BE2\u539F\u8BB0\u5F55\u3002", { cause: error });
  }
  const controller = new AbortController();
  let earlyStop;
  let earlyError;
  let unit;
  const interrupt = () => {
    controller.abort();
    earlyStop ??= stopLinuxExecution(directory, ref).catch((error) => {
      earlyError = error;
    });
  };
  const timer = setTimeout(interrupt, timeoutMs);
  options.signal?.addEventListener("abort", interrupt, { once: true });
  if (options.signal?.aborted) interrupt();
  let failure;
  let receipt;
  let captures = [];
  try {
    unit = await launchLinuxExecution(directory, ref, input, spec);
    const stdout = capture(unit.stdout, path5.join(record2, "stdout"), controller.signal);
    const stderr = capture(unit.stderr, path5.join(record2, "stderr"), controller.signal);
    captures = [stdout, stderr];
    const written = new Promise((resolve4, reject) => {
      unit.stdin.on("error", reject);
      if (controller.signal.aborted) {
        reject(controller.signal.reason);
        return;
      }
      unit.stdin.end(JSON.stringify({ command: command2, workspace: { path: spec.workspace, ...spec.workspaceIdentity } }), (error) => error ? reject(error) : resolve4());
    });
    const [out, err, exit] = await Promise.all([stdout, stderr, unit.exit, written]);
    controller.signal.throwIfAborted();
    if (exit.signal !== null || exit.code === null || fs5.existsSync(path5.join(directory, ref.executionId, "stop-requested"))) throw new PersonalError("command_interrupted", "\u539F\u547D\u4EE4\u672A\u6B63\u5E38\u8FD4\u56DE\u6216\u5DF2\u8BF7\u6C42\u505C\u6B62\uFF0C\u6548\u679C\u5F85\u6838\u5B9E\uFF1B\u8BF7\u67E5\u8BE2\u539F\u5DE5\u4F5C\uFF0C\u52FF\u91CD\u65B0\u6267\u884C\u3002");
    receipt = { version: 1, ref, fingerprint: digest(JSON.stringify({ command: command2, spec, input })), exit: { code: exit.code, signal: null }, stdout: out, stderr: err };
    writeJson(path5.join(record2, "receipt-pending.json"), receipt);
    fs5.renameSync(path5.join(record2, "receipt-pending.json"), path5.join(record2, "receipt.json"));
  } catch (error) {
    failure = error;
    if (error instanceof ExecutionError && error.unit) unit = error.unit;
    controller.abort();
  } finally {
    clearTimeout(timer);
    options.signal?.removeEventListener("abort", interrupt);
    unit?.stdin.destroy();
    if (unit?.stdout instanceof Readable2) unit.stdout.destroy();
    if (unit?.stderr instanceof Readable2) unit.stderr.destroy();
    await Promise.allSettled(captures);
  }
  await earlyStop;
  let stopped;
  try {
    stopped = await stopPersonalCommand(directory, ref);
  } catch (error) {
    throw new PersonalError("command_stop_unverified", "\u539F\u547D\u4EE4\u505C\u6B62\u6216\u6E05\u7406\u65E0\u6CD5\u6838\u5B9E\uFF0C\u8BF7\u4FDD\u7559\u5360\u7528\u5E76\u67E5\u8BE2\u539F\u56DE\u6267\u3002", { cause: new AggregateError([failure, earlyError, error].filter((value) => value !== void 0)) });
  }
  if (failure !== void 0 || !receipt) throw new PersonalError("command_result_unknown", "\u539F\u547D\u4EE4\u6CA1\u6709\u5B8C\u6574\u5BBF\u4E3B\u56DE\u6267\uFF0C\u6548\u679C\u5F85\u6838\u5B9E\uFF1B\u8BF7\u4FDD\u7559\u539F\u5DE5\u4F5C\uFF0C\u52FF\u91CD\u65B0\u6267\u884C\u3002", { cause: failure });
  return { receipt, ...stopped };
}

// ../../../../../../private/tmp/ruukoto-command-24.93Sjb4/probe-entry.mjs
var self = process.argv[1];
var base = process.argv[3];
var codeRoot = path6.resolve(path6.dirname(self), "../../..");
var evidence = path6.join(base, "evidence");
var sha = (value) => createHash3("sha256").update(value).digest("hex");
var sleep = (ms) => new Promise((resolve4) => setTimeout(resolve4, ms));
var quote = (value) => `'${value.replaceAll("'", "'\\''")}'`;
var write = (filename, value) => fs6.writeFileSync(filename, JSON.stringify(value, null, 2) + "\n");
var waitFor = async (test, description) => {
  const deadline = Date.now() + 2e4;
  while (!test()) {
    if (Date.now() >= deadline) throw new Error(`\u7B49\u5F85\u8D85\u65F6\uFF1A${description}`);
    await sleep(20);
  }
};
var fixtureData = (filename) => JSON.parse(fs6.readFileSync(filename, "utf8"));
if (process.argv[2] === "read") {
  const input = fixtureData(process.argv[4]);
  const receipt = await readPersonalCommandReceipt(input.directory, input.ref);
  process.stdout.write(JSON.stringify({ receipt }) + "\n");
} else if (process.argv[2] === "stop") {
  const input = fixtureData(process.argv[4]);
  process.stdout.write(JSON.stringify(await stopPersonalCommand(input.directory, input.ref)) + "\n");
} else if (process.argv[2] === "owner") {
  const input = fixtureData(process.argv[4]);
  write(path6.join(path6.dirname(process.argv[4]), "owner-started.json"), { pid: process.pid });
  const result = await runPersonalCommand(input);
  write(path6.join(path6.dirname(process.argv[4]), "owner-result.json"), result);
} else {
  fs6.mkdirSync(evidence, { recursive: true });
  const fixtureRoot = path6.join(base, "fixtures");
  fs6.mkdirSync(fixtureRoot, { mode: 448 });
  const machineId = fs6.readFileSync("/etc/machine-id", "utf8").trim();
  const results = [];
  const fixtures = [];
  write(path6.join(evidence, "environment.json"), {
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    node: process.version,
    platform: process.platform,
    arch: process.arch,
    uid: process.getuid(),
    kernel: execFileSync("uname", ["-a"], { encoding: "utf8" }).trim(),
    bwrap: execFileSync("bwrap", ["--version"], { encoding: "utf8" }).trim(),
    userManager: execFileSync("systemctl", ["--user", "is-system-running"], { encoding: "utf8" }).trim(),
    cgroupV2: fs6.existsSync("/sys/fs/cgroup/cgroup.controllers"),
    self,
    codeRoot,
    bundledProbeSha256: sha(fs6.readFileSync(self)),
    workerSha256: sha(fs6.readFileSync(path6.join(codeRoot, "worker/personal-command-worker.mjs"))),
    hasRepositoryNodeModules: fs6.existsSync(path6.join(codeRoot, "node_modules"))
  });
  const fixture = (name) => {
    const root = fs6.realpathSync(fs6.mkdtempSync(path6.join(fixtureRoot, name + "-")));
    const workspace = path6.join(root, "work");
    const directory = path6.join(root, "commands");
    fs6.mkdirSync(workspace, { mode: 448 });
    fs6.mkdirSync(directory, { mode: 448 });
    const { dev, ino } = fs6.statSync(workspace);
    const ref = { executionId: `native_${randomBytes2(12).toString("hex")}`, machineId };
    const input = { directory, ref, command: "exit 0", spec: { taskId: `personal-command-24-${name}`, mode: "confirm", workspace, workspaceIdentity: { dev, ino }, grantedPaths: [] }, timeoutMs: 15e3 };
    const value = { name, root, workspace, directory, input, inputFile: path6.join(root, "input.json") };
    fixtures.push(value);
    return value;
  };
  const fresh = (mode, f) => JSON.parse(execFileSync(process.execPath, [self, mode, base, f.inputFile], { encoding: "utf8", timeout: 2e4 }));
  const saveInput = async (f) => {
    f.input.input = await prepareNativeLaunch({ workerPath: path6.join(codeRoot, "worker/personal-command-worker.mjs"), dependencyRoots: [], protectedRoots: [codeRoot, f.directory] }, f.input.spec);
    assert.ok(!f.input.input.runtimeReadRoots.includes(codeRoot));
    assert.ok(!f.input.input.runtimeReadRoots.some((root) => root.endsWith("/node_modules")));
    write(f.inputFile, f.input);
    write(path6.join(evidence, `${f.name}-input.json`), f.input);
  };
  const sameRef = async (f) => {
    let result, failure;
    try {
      result = await runPersonalCommand(f.input);
    } catch (error) {
      failure = { name: error.name, code: error.code, message: error.message };
    }
    return { result, failure };
  };
  const finish = async (f) => {
    const stop = fresh("stop", f);
    assert.equal(stop.exited, true, `\u539F\u6267\u884C\u505C\u6B62\u5FC5\u987B\u6838\u5B9E\uFF1A${f.name}`);
    const repeated = fresh("stop", f);
    assert.equal(repeated.exited, true);
    fs6.cpSync(f.directory, path6.join(evidence, `${f.name}-records`), { recursive: true });
    write(path6.join(evidence, `${f.name}-stop.json`), { stop, repeated });
    fs6.rmSync(f.root, { recursive: true });
    return stop;
  };
  try {
    {
      const f = fixture("binary-nonzero");
      f.input.command = "printf x >> count; printf '\\000\\377A'; printf '\\200\\000Z' >&2; exit 37";
      await saveInput(f);
      const completed = await runPersonalCommand(f.input);
      assert.equal(completed.exited, true);
      assert.equal(completed.cleaned, true);
      assert.ok(completed.receipt, "\u6B63\u5E38\u975E\u96F6\u9000\u51FA\u4ECD\u987B\u6709\u5BBF\u4E3B\u5B8C\u6210\u56DE\u6267");
      assert.deepEqual(completed.receipt.exit, { code: 37, signal: null });
      assert.deepEqual(completed.receipt.stdout, { bytes: 3, sha256: sha(Buffer.from([0, 255, 65])) });
      assert.deepEqual(completed.receipt.stderr, { bytes: 3, sha256: sha(Buffer.from([128, 0, 90])) });
      assert.deepEqual(fresh("read", f).receipt, completed.receipt, "\u65B0\u8FDB\u7A0B\u8BFB\u53D6\u539F\u56DE\u6267");
      const repeated = await sameRef(f);
      assert.ok(repeated.failure);
      assert.equal(fs6.readFileSync(path6.join(f.workspace, "count"), "utf8"), "x", "\u540C ref \u4E0D\u80FD\u91CD\u653E\u547D\u4EE4");
      results.push({ name: f.name, completed, repeated });
      await finish(f);
    }
    {
      const f = fixture("large-output");
      f.input.command = "python3 -I -c 'import os; os.write(1,bytes(range(256))*8192); os.write(2,bytes(reversed(range(256)))*4096)'";
      await saveInput(f);
      const completed = await runPersonalCommand(f.input);
      assert.equal(completed.exited, true);
      assert.ok(completed.receipt);
      assert.deepEqual(completed.receipt.exit, { code: 0, signal: null });
      const stdout = Buffer.concat(Array(8192).fill(Buffer.from(Array.from({ length: 256 }, (_, i) => i))));
      const stderr = Buffer.concat(Array(4096).fill(Buffer.from(Array.from({ length: 256 }, (_, i) => 255 - i))));
      assert.deepEqual(completed.receipt.stdout, { bytes: stdout.length, sha256: sha(stdout) });
      assert.deepEqual(completed.receipt.stderr, { bytes: stderr.length, sha256: sha(stderr) });
      assert.deepEqual(fresh("read", f).receipt, completed.receipt);
      results.push({ name: f.name, completed });
      await finish(f);
    }
    for (const mode of ["timeout", "cancel", "independent-stop"]) {
      const f = fixture(`${mode}-descendant`);
      const heart = path6.join(f.workspace, "heart");
      const identity = path6.join(f.workspace, "identity.json");
      const python = `import os,time,json
os.setsid()
open(${JSON.stringify(identity)},'w').write(json.dumps({'pid':os.getpid(),'sid':os.getsid(0),'pgid':os.getpgid(0)}))
f=open(${JSON.stringify(heart)},'a',buffering=1)
while True:
 f.write('tick\\n');time.sleep(.02)
`;
      f.input.command = `python3 -I -c ${quote(python)} & wait`;
      if (mode === "timeout") f.input.timeoutMs = 1500;
      await saveInput(f);
      const controller = new AbortController();
      const running = runPersonalCommand({ ...f.input, ...mode === "cancel" ? { signal: controller.signal } : {} });
      const settled = running.then((value) => ({ result: value }), (error) => ({ failure: { name: error.name, code: error.code, message: error.message } }));
      await waitFor(() => fs6.existsSync(heart) && fs6.statSync(heart).size > 20, "setsid \u540E\u4EE3\u5FC3\u8DF3");
      const child = fixtureData(identity);
      assert.equal(child.sid, child.pid);
      assert.equal(child.pgid, child.pid);
      let independentStop;
      if (mode === "cancel") controller.abort();
      if (mode === "independent-stop") {
        independentStop = fresh("stop", f);
        assert.equal(independentStop.exited, true);
      }
      const outcome = await settled;
      assert.equal(outcome.failure?.code, "command_result_unknown");
      assert.equal(fresh("read", f).receipt, void 0, "\u4E2D\u65AD\u8FD0\u884C\u4E0D\u80FD\u53D1\u5E03\u5B8C\u6574\u56DE\u6267");
      const stop = fresh("stop", f);
      assert.equal(stop.exited, true);
      const bytes = fs6.statSync(heart).size;
      await sleep(250);
      assert.equal(fs6.statSync(heart).size, bytes, "\u505C\u6B62\u540E\u540E\u4EE3\u5FC3\u8DF3\u51BB\u7ED3");
      results.push({ name: f.name, child, outcome, independentStop, stop, heartbeatBytes: bytes, heartbeatFrozenForMs: 250 });
      await finish(f);
    }
    for (const replace of [false, true]) {
      const f = fixture(replace ? "owner-sigkill-temp-replaced" : "owner-sigkill");
      const heart = path6.join(f.workspace, "heart");
      const identity = path6.join(f.workspace, "identity.json");
      const python = `import os,time,json
os.setsid()
open(${JSON.stringify(identity)},'w').write(json.dumps({'pid':os.getpid(),'sid':os.getsid(0),'pgid':os.getpgid(0)}))
f=open(${JSON.stringify(heart)},'a',buffering=1)
while True:
 f.write('tick\\n');time.sleep(.02)
`;
      f.input.command = `printf x >> count; python3 -I -c ${quote(python)} & wait`;
      await saveInput(f);
      const owner = spawn2(process.execPath, [self, "owner", base, f.inputFile], { stdio: ["ignore", "pipe", "pipe"] });
      let stderr = "";
      owner.stderr.on("data", (bytes) => {
        stderr += bytes;
      });
      owner.stdout.resume();
      const exited = new Promise((resolve4) => owner.once("exit", (code, signal) => resolve4({ code, signal })));
      try {
        await waitFor(() => fs6.existsSync(heart) && fs6.statSync(heart).size > 20 || owner.exitCode !== null, "\u72EC\u7ACB owner \u6D3E\u53D1\u547D\u4EE4");
        assert.equal(owner.exitCode, null, stderr);
        const child = fixtureData(identity);
        assert.equal(child.sid, child.pid);
        assert.equal(child.pgid, child.pid);
        owner.kill("SIGKILL");
        const ownerExit = await exited;
        assert.deepEqual(ownerExit, { code: null, signal: "SIGKILL" });
        assert.equal(fresh("read", f).receipt, void 0, "owner \u5F3A\u6740\u540E\u6CA1\u6709\u5BBF\u4E3B\u5B8C\u6210\u56DE\u6267");
        const repeated = await sameRef(f);
        assert.equal(repeated.failure?.code, "command_already_claimed");
        assert.equal(fs6.readFileSync(path6.join(f.workspace, "count"), "utf8"), "x", "\u65E0\u56DE\u6267\u4E5F\u4E0D\u5F97\u91CD\u653E\u540C ref");
        const temp = fixtureData(path6.join(f.directory, `command-${f.input.ref.executionId}`, "request.json")).temp;
        const moved = temp.path + "-preserved";
        if (replace) {
          fs6.renameSync(temp.path, moved);
          fs6.mkdirSync(temp.path, { mode: 448 });
          fs6.writeFileSync(path6.join(temp.path, "replacement-marker"), "preserve replacement\n");
        }
        const stop = fresh("stop", f);
        assert.equal(stop.exited, true);
        assert.equal(stop.cleaned, !replace);
        if (replace) assert.equal(fs6.readFileSync(path6.join(temp.path, "replacement-marker"), "utf8"), "preserve replacement\n");
        else assert.equal(fs6.existsSync(temp.path), false);
        const bytes = fs6.statSync(heart).size;
        await sleep(250);
        assert.equal(fs6.statSync(heart).size, bytes);
        results.push({ name: f.name, ownerExit, child, repeated, stop, temp, replacementPreserved: replace, heartbeatBytes: bytes, heartbeatFrozenForMs: 250, stderr });
        if (replace) {
          fs6.rmSync(temp.path, { recursive: true });
          fs6.rmSync(moved, { recursive: true });
        }
      } finally {
        owner.kill("SIGKILL");
        await exited;
      }
      await finish(f);
    }
    fs6.rmdirSync(fixtureRoot);
    write(path6.join(evidence, "summary.json"), { passed: true, cases: results.length, results, limitations: ["\u4E0D\u8986\u76D6 durable \u5DE5\u5177\u3001\u6743\u9650\u3001\u5BA1\u6279\u3001\u5DE5\u4F5C\u6682\u505C\u6216\u5360\u7528", "\u4E0D\u8986\u76D6\u5B8C\u5168\u8BBF\u95EE\u3001MCP\u3001\u771F\u5B9E\u6A21\u578B\u3001IM \u6216\u751F\u4EA7\u90E8\u7F72"] });
    write(path6.join(evidence, "cleanup.json"), { fixturesRemoved: !fs6.existsSync(fixtureRoot), remainingCaseDirectories: [] });
    process.stdout.write(JSON.stringify({ passed: true, cases: results.length, evidence }) + "\n");
  } catch (error) {
    const cleanup = [];
    for (const f of fixtures) if (fs6.existsSync(f.root)) {
      try {
        cleanup.push({ name: f.name, stop: fresh("stop", f) });
      } catch (failure) {
        cleanup.push({ name: f.name, failure: { message: failure.message, code: failure.code } });
      }
    }
    write(path6.join(evidence, "failure.json"), { message: error.message, stack: error.stack, results, cleanup, remainingCaseDirectories: fs6.existsSync(fixtureRoot) ? fs6.readdirSync(fixtureRoot) : [] });
    throw error;
  }
}
