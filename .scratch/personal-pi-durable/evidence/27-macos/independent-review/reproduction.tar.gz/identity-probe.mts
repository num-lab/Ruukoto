import assert from "node:assert/strict";
import { connectMcpEndpoint, McpError } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/packages/agent/src/mcp/transport.ts";
import { McpError as LegacyMcpError } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/packages/agent/src/mcp/client.ts";
import { startMockMcp, MOCK_MCP_SECRET } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/test/helpers/mock-mcp.ts";
const service = await startMockMcp({ requireAuth: true, tools: [{ name: "read" }] });
const failure = new LegacyMcpError("source_revoked", "来源已撤销");
try {
  await assert.rejects(connectMcpEndpoint({ serviceId: "probe", endpoint: service.url }, { resolveToken: async () => { throw failure; } }), error => error === failure && error instanceof McpError);
  assert.equal(service.hits.length, 0);
  let revoked = false;
  const connection = await connectMcpEndpoint({ serviceId: "probe", endpoint: service.url }, { resolveToken: async () => { if (revoked) throw failure; return MOCK_MCP_SECRET; } });
  try {
    await connection.listTools();
    const sent = service.hits.length;
    revoked = true;
    await assert.rejects(connection.callTool({ name: "read", inputSchema: { type: "object" } }, {}), error => error === failure && error instanceof McpError);
    assert.equal(service.hits.length, sent);
  } finally { await connection.close(); }
  process.stdout.write("typed resolver error: same instance/code preserved; init and later requests send zero after rejection\n");
} finally { await service.close(); }
