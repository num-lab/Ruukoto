import assert from "node:assert/strict";
import { connectMcpService, MCP_LIMITS } from "./src/legacy-client.ts";
import { startMockMcp } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/test/helpers/mock-mcp.ts";
const mcp = await startMockMcp({ pageSize: 1, tools: Array.from({ length: MCP_LIMITS.maxListPages + 1 }, (_, i) => ({ name: `tool${i}` })) });
try {
  const connection = await connectMcpService({ id: "pagination-probe", endpoint: mcp.url, credential: null }, { projectId: "probe", credentials: undefined });
  try {
    const tools = await connection.listTools();
    assert.equal(tools.length, 17);
    const pages = mcp.hits.filter(hit => hit.rpcMethod === "tools/list").length;
    assert.equal(pages, 17);
    process.stdout.write(`configured maxListPages=${MCP_LIMITS.maxListPages}; actual tools/list requests=${pages}; returned tools=${tools.length}\n`);
  } finally { await connection.close(); }
} finally { await mcp.close(); }
