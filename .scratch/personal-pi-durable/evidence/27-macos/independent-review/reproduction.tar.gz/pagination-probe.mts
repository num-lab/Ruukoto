import assert from "node:assert/strict";
import { connectMcpEndpoint, MCP_LIMITS } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/packages/agent/src/mcp/transport.ts";
import { startMockMcp } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/test/helpers/mock-mcp.ts";
const mcp = await startMockMcp({ pageSize: 1, tools: Array.from({ length: MCP_LIMITS.maxListPages + 1 }, (_, i) => ({ name: `tool${i}` })) });
try {
  const connection = await connectMcpEndpoint({ serviceId: "pagination-probe", endpoint: mcp.url });
  try {
    const tools = await connection.listTools();
    assert.equal(tools.length, 17);
    const pages = mcp.hits.filter(hit => hit.rpcMethod === "tools/list").length;
    assert.equal(pages, 17);
    process.stdout.write(`configured maxListPages=${MCP_LIMITS.maxListPages}; actual tools/list requests=${pages}; returned tools=${tools.length}\n`);
  } finally { await connection.close(); }
} finally { await mcp.close(); }
