import {createRequire as probeCreateRequire} from 'node:module';const require=probeCreateRequire(import.meta.url);

// test/browser-lifecycle.test.ts
import assert from "node:assert/strict";
import * as fs3 from "node:fs";
import * as os from "node:os";
import * as path2 from "node:path";
import { createHash as createHash2, randomUUID as randomUUID2 } from "node:crypto";
import { execFileSync as execFileSync3, spawn as spawn2 } from "node:child_process";
import { createServer as createServer2 } from "node:http";
import { once } from "node:events";
import { test } from "node:test";

// packages/core/src/process-identity.ts
import * as fs from "node:fs";
import { execFileSync } from "node:child_process";
function validProcessIdentity(value) {
  if (typeof value !== "string") return false;
  if (/^linux:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}:\d+$/.test(value)) return true;
  if (!value.startsWith("darwin:")) return false;
  const date = /* @__PURE__ */ new Date(`${value.slice(7)} UTC`);
  if (!Number.isFinite(date.getTime())) return false;
  const [weekday, day, month, year, time] = date.toUTCString().split(" ");
  return value === `darwin:${weekday.slice(0, -1)} ${month} ${String(Number(day)).padStart(2, " ")} ${time} ${year}`;
}
function processIdentity(pid) {
  try {
    if (process.platform === "linux") {
      const bootId = fs.readFileSync("/proc/sys/kernel/random/boot_id", "utf8").trim();
      const stat = fs.readFileSync(`/proc/${pid}/stat`, "utf8");
      const end = stat.lastIndexOf(")");
      if (end < 0) return null;
      const ticks = stat.slice(end + 1).trim().split(/\s+/)[19];
      const identity = `linux:${bootId}:${ticks}`;
      return validProcessIdentity(identity) ? identity : null;
    }
    if (process.platform === "darwin") {
      const startedAt = execFileSync("ps", ["-p", String(pid), "-o", "lstart="], {
        encoding: "utf8",
        timeout: 3e3,
        env: { ...process.env, LC_ALL: "C", TZ: "UTC" }
      }).trim();
      const identity = `darwin:${startedAt}`;
      return validProcessIdentity(identity) ? identity : null;
    }
    return null;
  } catch {
    return null;
  }
}

// packages/agent/src/browser-manager.ts
import * as fs2 from "node:fs";
import * as path from "node:path";
import * as http from "node:http";
import * as https from "node:https";
import * as net from "node:net";
import { lookup } from "node:dns/promises";
import { createHash, randomUUID } from "node:crypto";
import { execFileSync as execFileSync2, spawn } from "node:child_process";
var BROWSER_META_KEY = "browser_bindings_v1";
var RELEASE = "0.39.1";
var RELEASE_HASHES = {
  "darwin-arm64": ["cc18fac41d9dc9821918340a136e643286ea05544c4dd35671b796f1a874cdef"],
  "darwin-x64": ["339cb9aa6dfd404856cf938df34cd3b4779c61dfd57fc257be11b14fd1a885f9"],
  "linux-arm64": ["9d8fdc586056df65747927ae166157c83af91b52cea287175e5544afd2591d33", "c4959f3e193c5bc8f333613363f25f2eaceecafe25a0821843b271906474a20f"],
  "linux-x64": ["6906d3a2a67b05809932a93d99e53d1132373f0a52a617b2d6032dbb954df6fc", "74507cdab98aa91bdc14346c545aff974640a225e43f8c3d6c23164f8c0f9bb9"]
};
var BrowserError = class extends Error {
  constructor(code, message, effectUnknown = false) {
    super(message);
    this.code = code;
    this.effectUnknown = effectUnknown;
  }
  code;
  effectUnknown;
};
function object(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function errno(error2) {
  return error2 instanceof Error && "code" in error2 && typeof error2.code === "string" ? error2.code : void 0;
}
function delay(ms) {
  return new Promise((resolve2) => setTimeout(resolve2, ms));
}
function digest(value) {
  return createHash("sha256").update(value).digest("hex");
}
function processState(unit) {
  try {
    process.kill(unit.pid, 0);
  } catch (error2) {
    return errno(error2) === "ESRCH" ? "gone" : "unknown";
  }
  const actual = processIdentity(unit.pid);
  if (!actual) {
    try {
      process.kill(unit.pid, 0);
    } catch (error2) {
      return errno(error2) === "ESRCH" ? "gone" : "unknown";
    }
    return "unknown";
  }
  if (actual !== unit.processIdentity) return "unknown";
  try {
    const state = execFileSync2("ps", ["-p", String(unit.pid), "-o", "stat=,pgid="], { encoding: "utf8", timeout: 3e3 }).trim().split(/\s+/);
    if (Number(state[1]) !== unit.pgid) return "unknown";
    return state[0]?.startsWith("Z") ? "gone" : "alive";
  } catch {
    try {
      process.kill(unit.pid, 0);
    } catch (error2) {
      return errno(error2) === "ESRCH" ? "gone" : "unknown";
    }
    return "unknown";
  }
}
function captureProcess(pid) {
  const identity = processIdentity(pid);
  if (!identity) throw new BrowserError("browser_identity_unverified", "\u65E0\u6CD5\u6838\u5B9E\u6D4F\u89C8\u5668\u8FDB\u7A0B\u542F\u52A8\u6807\u8BC6\uFF0C\u8BF7\u68C0\u67E5\u539F\u8FDB\u7A0B\u540E\u518D\u7EE7\u7EED");
  let pgid;
  try {
    pgid = Number(execFileSync2("ps", ["-p", String(pid), "-o", "pgid="], { encoding: "utf8", timeout: 3e3 }).trim());
  } catch {
    throw new BrowserError("browser_identity_unverified", "\u65E0\u6CD5\u6838\u5B9E\u6D4F\u89C8\u5668\u8FDB\u7A0B\u7EC4\uFF0C\u8BF7\u68C0\u67E5\u539F\u8FDB\u7A0B\u540E\u518D\u7EE7\u7EED");
  }
  if (!Number.isSafeInteger(pgid) || pgid <= 0) throw new BrowserError("browser_identity_unverified", "\u6D4F\u89C8\u5668\u8FDB\u7A0B\u7EC4\u4E0D\u5408\u6CD5");
  return { pid, pgid, processIdentity: identity };
}
function validProcess(value) {
  return value === null || object(value) && Number.isSafeInteger(value.pid) && Number(value.pid) > 0 && Number.isSafeInteger(value.pgid) && Number(value.pgid) > 0 && validProcessIdentity(value.processIdentity);
}
function isReadOnly(args) {
  return args[0] === "snapshot" || args[0] === "screenshot" || args[0] === "tab" && (args.length === 1 || args[1] === "list") || args[0] === "get" && ["url", "title"].includes(args[1]);
}
function responseError(value, args) {
  const code = typeof value.code === "string" ? value.code : null;
  if (code === "tab_gone") return new BrowserError(code, "\u6D4F\u89C8\u5668\u6807\u7B7E\u5DF2\u5173\u95ED\uFF0C\u8BF7\u5148\u67E5\u770B\u6807\u7B7E\u5217\u8868\u6216\u663E\u5F0F\u65B0\u5EFA\u6807\u7B7E");
  const unknown = code !== null || !isReadOnly(args);
  return new BrowserError(unknown ? "outcome_unknown" : "browser_action_failed", unknown ? "\u6D4F\u89C8\u5668\u52A8\u4F5C\u7ED3\u679C\u672A\u77E5\uFF1B\u5DF2\u6682\u505C\u81EA\u52A8\u5316\uFF0C\u8BF7\u6838\u5B9E\u5F53\u524D\u9875\u9762\uFF0C\u4E0D\u80FD\u91CD\u590D\u65E7\u52A8\u4F5C" : "\u6D4F\u89C8\u5668\u8BFB\u53D6\u5931\u8D25\uFF0C\u8BF7\u6838\u5B9E\u5F53\u524D\u6D4F\u89C8\u5668\u8FDE\u63A5", unknown && !isReadOnly(args));
}
function parseBrowserCommand(stdout, args, exitCode) {
  let parsed;
  try {
    parsed = JSON.parse(stdout);
  } catch {
    throw new BrowserError("outcome_unknown", "\u6D4F\u89C8\u5668\u5E94\u7B54\u4E0D\u5B8C\u6574\uFF0C\u5DF2\u6682\u505C\u81EA\u52A8\u5316\uFF0C\u8BF7\u6838\u5B9E\u5F53\u524D\u9875\u9762", !isReadOnly(args));
  }
  if (object(parsed) && parsed.success === false) throw responseError(parsed, args);
  if (!Array.isArray(parsed) || parsed.length !== 1 || !object(parsed[0])) throw new BrowserError("outcome_unknown", "\u6D4F\u89C8\u5668 batch \u5E94\u7B54\u4E0D\u5408\u6CD5\uFF0C\u8BF7\u6838\u5B9E\u5F53\u524D\u9875\u9762", !isReadOnly(args));
  const row = parsed[0];
  if (!Array.isArray(row.command) || row.command.length !== args.length || row.command.some((value, index) => value !== args[index]) || typeof row.success !== "boolean" || row.result !== null && !object(row.result) || row.code !== void 0 && typeof row.code !== "string") {
    throw new BrowserError("outcome_unknown", "\u6D4F\u89C8\u5668\u5E94\u7B54\u4E0E\u5F53\u524D\u52A8\u4F5C\u4E0D\u5339\u914D\uFF0C\u8BF7\u6838\u5B9E\u5F53\u524D\u9875\u9762", !isReadOnly(args));
  }
  if (!row.success) throw responseError(row, args);
  if (row.code !== void 0) throw new BrowserError("outcome_unknown", "\u6D4F\u89C8\u5668\u6210\u529F\u5E94\u7B54\u542B\u672A\u77E5\u72B6\u6001\u7801\uFF0C\u8BF7\u6838\u5B9E\u5F53\u524D\u9875\u9762", !isReadOnly(args));
  if (exitCode !== 0) throw new BrowserError("outcome_unknown", "\u6D4F\u89C8\u5668\u8FDB\u7A0B\u9000\u51FA\u4E0E\u5E94\u7B54\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u6838\u5B9E\u5F53\u524D\u9875\u9762", !isReadOnly(args));
  return { data: row.result, ...typeof row.code === "string" ? { code: row.code } : {} };
}
async function runProcess(binary, argv, options) {
  if (options.signal?.aborted) throw new BrowserError("browser_not_sent", "\u52A8\u4F5C\u5DF2\u53D6\u6D88\uFF0C\u5C1A\u672A\u542F\u52A8\u6D4F\u89C8\u5668\u547D\u4EE4");
  return await new Promise((resolve2, reject) => {
    const child = spawn(binary, argv, { cwd: options.cwd, env: options.env, stdio: ["pipe", "pipe", "pipe"] });
    let stdout = "", stderr = "", failed = null;
    let killTimer;
    const stop = (error2) => {
      failed ??= error2;
      if (child.exitCode !== null || child.signalCode !== null) return;
      child.kill("SIGTERM");
      killTimer ??= setTimeout(() => {
        if (child.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
      }, 1e3);
    };
    const abort = () => stop(new BrowserError("outcome_unknown", "\u6D4F\u89C8\u5668\u547D\u4EE4\u5DF2\u53D6\u6D88\uFF0C\u5E94\u7B54\u672A\u6838\u5B9E"));
    options.signal?.addEventListener("abort", abort, { once: true });
    const timer = setTimeout(() => stop(new BrowserError("outcome_unknown", "\u6D4F\u89C8\u5668\u547D\u4EE4\u8D85\u65F6\uFF0C\u5E94\u7B54\u672A\u6838\u5B9E")), options.timeout ?? 12e4);
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk) => {
      if (failed) return;
      stdout += chunk;
      if (Buffer.byteLength(stdout) > 8 * 1024 * 1024) stop(new BrowserError("outcome_unknown", "\u6D4F\u89C8\u5668\u5E94\u7B54\u8D85\u8FC7\u4E0A\u9650\uFF0C\u5E94\u7B54\u672A\u6838\u5B9E"));
    });
    child.stderr.on("data", (chunk) => {
      if (stderr.length < 65536) stderr += chunk;
    });
    child.on("error", () => {
      failed = new BrowserError("browser_not_sent", "\u65E0\u6CD5\u542F\u52A8\u6D4F\u89C8\u5668\u7A0B\u5E8F\uFF0C\u8BF7\u6838\u5B9E\u53EF\u6267\u884C\u6587\u4EF6\u4E0E\u6743\u9650");
    });
    child.stdin.on("error", () => stop(new BrowserError("outcome_unknown", "\u6D4F\u89C8\u5668\u547D\u4EE4\u8F93\u5165\u672A\u786E\u8BA4")));
    child.on("close", (code) => {
      clearTimeout(timer);
      clearTimeout(killTimer);
      options.signal?.removeEventListener("abort", abort);
      if (failed) reject(failed);
      else resolve2({ stdout, stderr, code });
    });
    child.stdin.end(options.input);
    if (options.signal?.aborted) abort();
  });
}
async function runBrowserCommand(binary, argv, args, options) {
  if (args.length === 0 || args.some((arg) => typeof arg !== "string")) throw new BrowserError("browser_invalid_action", "\u6D4F\u89C8\u5668\u52A8\u4F5C\u53C2\u6570\u4E0D\u5408\u6CD5");
  let result;
  try {
    result = await runProcess(binary, [...argv, "batch", "--bail"], { ...options, input: JSON.stringify([args]) });
  } catch (error2) {
    if (error2 instanceof BrowserError && error2.code === "browser_not_sent") throw error2;
    throw new BrowserError("outcome_unknown", "\u6D4F\u89C8\u5668\u547D\u4EE4\u5E94\u7B54\u4E22\u5931\uFF0C\u5DF2\u6682\u505C\u81EA\u52A8\u5316\uFF0C\u8BF7\u6838\u5B9E\u5F53\u524D\u9875\u9762", !isReadOnly(args));
  }
  return parseBrowserCommand(result.stdout, args, result.code);
}
function loopback(address) {
  return address === "::1" || net.isIP(address) === 4 && address.startsWith("127.");
}
async function pinLoopback(input) {
  let url;
  try {
    url = new URL(input);
  } catch {
    throw new BrowserError("browser_invalid_target", "\u9644\u63A5\u9700\u8981\u663E\u5F0F\u672C\u673A loopback HTTP \u6216 WebSocket CDP \u5730\u5740");
  }
  if (!["http:", "https:", "ws:", "wss:"].includes(url.protocol) || url.username || url.password || url.hash || url.search || !url.port) throw new BrowserError("browser_invalid_target", "CDP \u5730\u5740\u534F\u8BAE\u3001\u7AEF\u53E3\u6216\u6388\u6743\u5B57\u6BB5\u4E0D\u5408\u6CD5");
  const host = url.hostname.replace(/^\[|\]$/g, "");
  let address = host;
  if (host === "localhost") {
    let addresses;
    try {
      addresses = await lookup(host, { all: true });
    } catch {
      throw new BrowserError("browser_invalid_target", "\u65E0\u6CD5\u6838\u5B9E localhost \u7684\u672C\u673A\u5730\u5740");
    }
    if (!Array.isArray(addresses) || addresses.length === 0 || addresses.some((entry) => !loopback(entry.address))) throw new BrowserError("browser_invalid_target", "localhost \u89E3\u6790\u5305\u542B\u975E loopback \u5730\u5740\uFF0C\u62D2\u7EDD\u9644\u63A5");
    address = addresses.find((entry) => entry.family === 4)?.address ?? addresses[0].address;
  }
  if (!loopback(address)) throw new BrowserError("browser_invalid_target", "\u9996\u7248\u53EA\u5141\u8BB8\u672C\u673A loopback CDP\uFF0C\u4E0D\u80FD\u63A7\u5236\u8FDC\u7A0B\u6D4F\u89C8\u5668");
  url.hostname = address.includes(":") ? `[${address}]` : address;
  return url;
}
function readVersion(url, signal) {
  return new Promise((resolve2, reject) => {
    const get3 = url.protocol === "https:" ? https.get : http.get;
    const request = get3({ hostname: url.hostname.replace(/^\[|\]$/g, ""), port: url.port, path: "/json/version", signal }, (response) => {
      if (response.statusCode !== 200) {
        response.destroy();
        reject(new BrowserError("browser_invalid_target", "CDP discovery \u8FD4\u56DE\u975E\u6210\u529F\u5E94\u7B54\uFF1B\u4E0D\u8DDF\u968F\u91CD\u5B9A\u5411"));
        return;
      }
      let body = "";
      response.setEncoding("utf8");
      response.on("data", (chunk) => {
        body += chunk;
        if (body.length > 65536) request.destroy();
      });
      response.on("error", () => reject(new BrowserError("browser_invalid_target", "CDP discovery \u5E94\u7B54\u4E2D\u65AD")));
      response.on("end", () => {
        let parsed;
        try {
          parsed = JSON.parse(body);
        } catch {
          reject(new BrowserError("browser_invalid_target", "CDP discovery \u5E94\u7B54\u4E0D\u5408\u6CD5"));
          return;
        }
        resolve2(parsed);
      });
    });
    request.on("error", () => reject(signal.aborted ? signal.reason : new BrowserError("browser_invalid_target", "\u65E0\u6CD5\u8FDE\u63A5\u672C\u673A CDP discovery")));
  });
}
async function resolveBrowserEndpoint(input, signal) {
  const controller = new AbortController();
  const abort = () => controller.abort(new BrowserError("browser_not_sent", "CDP discovery \u5DF2\u53D6\u6D88\uFF0C\u672C\u6B21\u9644\u63A5\u672A\u53D1\u9001"));
  signal?.addEventListener("abort", abort, { once: true });
  if (signal?.aborted) abort();
  const timer = setTimeout(() => controller.abort(new BrowserError("browser_invalid_target", "CDP discovery \u8D85\u8FC7\u603B\u671F\u9650")), 3e3);
  let rejectAbort;
  const canceled = new Promise((_resolve, reject) => {
    rejectAbort = () => reject(controller.signal.reason);
    controller.signal.addEventListener("abort", rejectAbort, { once: true });
    if (controller.signal.aborted) rejectAbort();
  });
  try {
    return await Promise.race([resolveEndpoint(input, controller.signal), canceled]);
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", abort);
    controller.signal.removeEventListener("abort", rejectAbort);
  }
}
async function resolveEndpoint(input, signal) {
  if (signal.aborted) throw signal.reason;
  let url = await pinLoopback(input);
  if (signal.aborted) throw signal.reason;
  if (url.protocol === "http:" || url.protocol === "https:") {
    const version = await readVersion(url, signal);
    if (!object(version) || typeof version.webSocketDebuggerUrl !== "string") throw new BrowserError("browser_invalid_target", "CDP discovery \u7F3A\u5C11\u6D4F\u89C8\u5668 WebSocket \u5730\u5740");
    const ws = await pinLoopback(version.webSocketDebuggerUrl);
    if (ws.port !== url.port || ws.hostname !== url.hostname) throw new BrowserError("browser_invalid_target", "CDP discovery \u6307\u5411\u4E0D\u540C\u76EE\u6807\uFF0C\u62D2\u7EDD\u9644\u63A5");
    url = ws;
  }
  if (url.protocol !== "ws:" && url.protocol !== "wss:") throw new BrowserError("browser_invalid_target", "CDP discovery \u672A\u8FD4\u56DE WebSocket \u5730\u5740");
  const match = /^\/devtools\/browser\/([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})$/i.exec(url.pathname);
  if (!match) throw new BrowserError("browser_invalid_target", "CDP \u5730\u5740\u5FC5\u987B\u6307\u5411\u5E26 UUID \u7684\u6D4F\u89C8\u5668\u7AEF\u70B9");
  const targetId = match[1].toLowerCase();
  url.pathname = `/devtools/browser/${targetId}`;
  return { url: url.toString(), targetId };
}
async function freePort() {
  const server = net.createServer();
  return await new Promise((resolve2, reject) => {
    server.on("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      if (!address || typeof address === "string") {
        server.close();
        reject(new BrowserError("browser_unavailable", "\u65E0\u6CD5\u5206\u914D\u672C\u673A dashboard \u7AEF\u53E3"));
        return;
      }
      server.close((error2) => error2 ? reject(error2) : resolve2(address.port));
    });
  });
}
async function browserClose(url) {
  await new Promise((resolve2, reject) => {
    const ws = new WebSocket(url);
    const timer = setTimeout(() => {
      ws.close();
      reject(new BrowserError("browser_stop_unverified", "\u6D4F\u89C8\u5668\u5173\u95ED\u5E94\u7B54\u8D85\u65F6"));
    }, 3e3);
    const finish = () => {
      clearTimeout(timer);
      ws.close();
      resolve2();
    };
    ws.onopen = () => ws.send(JSON.stringify({ id: 1, method: "Browser.close" }));
    ws.onmessage = (event) => {
      let value;
      try {
        value = JSON.parse(String(event.data));
      } catch {
        return;
      }
      if (object(value) && value.id === 1 && !value.error) finish();
    };
    ws.onclose = finish;
    ws.onerror = finish;
  });
}
function rows() {
  let output;
  try {
    output = execFileSync2("ps", ["-axo", "pid=,pgid=,stat=,command="], { encoding: "utf8", timeout: 3e3 });
  } catch {
    throw new BrowserError("browser_stop_unverified", "\u65E0\u6CD5\u6838\u5B9E\u6D4F\u89C8\u5668\u76F8\u5173\u8FDB\u7A0B\u662F\u5426\u9000\u51FA");
  }
  return output.split("\n").flatMap((line) => {
    const match = /^\s*(\d+)\s+(\d+)\s+(\S+)\s+(.*)$/.exec(line);
    return match ? [{ pid: Number(match[1]), pgid: Number(match[2]), state: match[3], command: match[4] }] : [];
  });
}
function secureDirectory(directory) {
  fs2.mkdirSync(directory, { recursive: true, mode: 448 });
  const stat = fs2.lstatSync(directory);
  if (!stat.isDirectory() || stat.isSymbolicLink() || stat.uid !== process.getuid?.() || (stat.mode & 63) !== 0) throw new BrowserError("browser_binding_invalid", "\u6D4F\u89C8\u5668\u63A7\u5236\u76EE\u5F55\u5F52\u5C5E\u6216\u6743\u9650\u4E0D\u5B89\u5168\uFF0C\u8BF7\u6838\u5B9E\u76EE\u5F55\u540E\u7EE7\u7EED");
}
var BrowserManager = class {
  constructor(options) {
    this.options = options;
    this.options = {
      ...options,
      binaryPath: options.binaryPath ? path.resolve(options.binaryPath) : void 0,
      chromePath: options.chromePath ? path.resolve(options.chromePath) : void 0
    };
    this.dataDir = path.resolve(options.dataDir);
    this.root = path.join(this.dataDir, "browser");
    this.locks = `/tmp/ruukoto-browser-locks-${process.getuid?.() ?? "unknown"}`;
    this.env = Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith("AGENT_BROWSER_") && !key.startsWith("AI_GATEWAY_") && !["HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY"].includes(key.toUpperCase())));
    for (const key of ["RUUKOTO_OWNER_TOKEN", "RUUKOTO_OWNER_TOKEN_FILE", "RUUKOTO_CONTROL_DIR", "RUUKOTO_CODE_CONTROL_DIR"]) delete this.env[key];
    this.env.AGENT_BROWSER_IDLE_TIMEOUT_MS = "3600000";
    const stored = options.initialState ?? options.store?.getMetaValue(BROWSER_META_KEY) ?? null;
    if (stored !== null) {
      try {
        this.load(stored);
      } catch {
        this.loadError = new BrowserError("browser_binding_invalid", "\u6D4F\u89C8\u5668\u7ED1\u5B9A\u8BB0\u5F55\u4E0D\u5408\u6CD5\uFF0C\u4FDD\u7559\u539F\u8FDB\u7A0B\u4E0E\u8D44\u6599\uFF0C\u8BF7\u4EBA\u5DE5\u6838\u5B9E");
      }
    }
    this.timer = setInterval(() => {
      void this.supervise();
    }, 2e3);
    this.timer.unref();
  }
  options;
  bindings = /* @__PURE__ */ new Map();
  fingerprints = /* @__PURE__ */ new Map();
  active = /* @__PURE__ */ new Map();
  closing = /* @__PURE__ */ new Map();
  dataDir;
  root;
  locks;
  env;
  loadError = null;
  shuttingDown = false;
  supervising = false;
  timer;
  load(raw) {
    const parsed = JSON.parse(raw);
    if (!object(parsed) || parsed.version !== 1 || !Array.isArray(parsed.bindings)) throw new Error("invalid browser state");
    const pending = /* @__PURE__ */ new Map();
    for (const value of parsed.bindings) {
      if (!object(value) || typeof value.sessionId !== "string" || typeof value.generation !== "string" || !["owned", "attached"].includes(String(value.kind)) || !["starting", "ready", "paused", "unavailable", "closed"].includes(String(value.state))) throw new Error("invalid binding");
      for (const key of ["socketDir", "cliSession"]) if (typeof value[key] !== "string") throw new Error("invalid paths");
      for (const key of ["profileDir", "cdpUrl", "targetId", "lockDir", "pauseTaskId", "failureCode", "dashboardUrl"]) if (value[key] !== null && typeof value[key] !== "string") throw new Error("invalid fields");
      for (const key of ["chromePending", "daemonPending", "dashboardPending", "outcomeUnknown", "headed"]) if (typeof value[key] !== "boolean") throw new Error("invalid flags");
      if (value.pauseAfterSeq === void 0) value.pauseAfterSeq = null;
      if (value.pauseAfterSeq !== null && (!Number.isSafeInteger(value.pauseAfterSeq) || Number(value.pauseAfterSeq) < 0)) throw new Error("invalid pause barrier");
      if (!validProcess(value.chrome) || !validProcess(value.daemon) || !validProcess(value.dashboard)) throw new Error("invalid process identity");
      const binding = value;
      const expected = this.paths(binding.sessionId);
      if (pending.has(binding.sessionId) || binding.socketDir !== expected.socketDir || binding.cliSession !== expected.cliSession || binding.profileDir !== null && binding.profileDir !== expected.profileDir || binding.lockDir !== null && binding.lockDir !== path.join(this.locks, digest(binding.targetId ?? ""))) throw new Error("invalid binding ownership");
      pending.set(binding.sessionId, binding);
    }
    for (const [key, value] of pending) this.bindings.set(key, value);
    if (parsed.fingerprints !== void 0) {
      if (!object(parsed.fingerprints)) throw new Error("invalid fingerprints");
      for (const [key, value] of Object.entries(parsed.fingerprints)) {
        if (!pending.has(key) || !object(value) || typeof value.config !== "string" || value.version !== RELEASE || !/^[a-f0-9]{16}$/.test(value.config)) throw new Error("invalid fingerprint");
        this.fingerprints.set(key, { config: value.config, version: value.version });
      }
    }
  }
  paths(sessionId) {
    const id = digest(`${this.dataDir}\0${sessionId}`).slice(0, 24);
    return { socketDir: `/tmp/ruukoto-browser-${process.getuid?.() ?? "unknown"}-${id}`, cliSession: `rk-${id}`, profileDir: path.join(this.root, id, "profile") };
  }
  async save(binding, previousGeneration) {
    try {
      await this.options.persist(JSON.stringify({ version: 1, bindings: [...this.bindings.values()], fingerprints: Object.fromEntries(this.fingerprints) }), structuredClone(binding));
    } catch {
      this.loadError = new BrowserError("browser_state_unavailable", "\u6D4F\u89C8\u5668\u72B6\u6001\u65E0\u6CD5\u6301\u4E45\u5316\uFF0C\u5DF2\u505C\u6B62\u7EE7\u7EED\u81EA\u52A8\u5316\uFF0C\u8BF7\u6838\u5B9E\u539F\u6267\u884C");
      throw this.loadError;
    }
    if (binding.lockDir && binding.state !== "closed" && this.lockMatches(binding, previousGeneration)) {
      const file = path.join(binding.lockDir, "owner.json"), temporary = `${file}.${randomUUID()}`;
      try {
        fs2.writeFileSync(temporary, JSON.stringify({ dataDir: this.dataDir, sessionId: binding.sessionId, generation: binding.generation, daemon: binding.daemon, daemonPending: binding.daemonPending }), { flag: "wx", mode: 384 });
      } catch {
        this.loadError = new BrowserError("browser_state_unavailable", "\u6D4F\u89C8\u5668\u5360\u7528\u8BB0\u5F55\u65E0\u6CD5\u5199\u5165\uFF0C\u505C\u6B62\u81EA\u52A8\u5316\u5E76\u4FDD\u7559\u539F\u8FDB\u7A0B");
        throw this.loadError;
      }
      try {
        fs2.renameSync(temporary, file);
      } catch {
        this.loadError = new BrowserError("browser_state_unavailable", "\u6D4F\u89C8\u5668\u5360\u7528\u8BB0\u5F55\u65E0\u6CD5\u63D0\u4EA4\uFF0C\u505C\u6B62\u81EA\u52A8\u5316\u5E76\u4FDD\u7559\u539F\u8FDB\u7A0B");
        throw this.loadError;
      }
    }
  }
  async unavailable(binding, error2) {
    binding.state = "unavailable";
    binding.failureCode = error2.code;
    binding.outcomeUnknown ||= error2.effectUnknown;
    await this.save(binding);
  }
  status(sessionId) {
    const binding = this.bindings.get(sessionId);
    return binding ? structuredClone(binding) : null;
  }
  require(sessionId) {
    if (this.loadError) throw this.loadError;
    const binding = this.bindings.get(sessionId);
    if (!binding || binding.state === "closed") throw new BrowserError("browser_not_ready", "\u6D4F\u89C8\u5668\u5C1A\u672A\u542F\u52A8\u6216\u5DF2\u56DE\u6536\uFF0C\u8BF7\u5148\u663E\u5F0F\u542F\u52A8\u6216\u9644\u63A5");
    return binding;
  }
  async prepare(owned) {
    if (this.loadError) throw this.loadError;
    if (this.shuttingDown) throw new BrowserError("browser_unavailable", "\u540E\u53F0\u6B63\u5728\u505C\u6B62\uFF0C\u4E0D\u80FD\u542F\u52A8\u6D4F\u89C8\u5668");
    {
      const binary = this.options.binaryPath;
      if (!binary || !RELEASE_HASHES[`${process.platform}-${process.arch}`]) throw new BrowserError("browser_unavailable", "\u8BF7\u51C6\u5907\u5F53\u524D\u5E73\u53F0 agent-browser v0.39.1 \u5B98\u65B9\u539F\u751F\u7A0B\u5E8F\u5E76\u914D\u7F6E\u5BBF\u4E3B\u8DEF\u5F84");
      let hash;
      try {
        hash = createHash("sha256").update(fs2.readFileSync(binary)).digest("hex");
      } catch {
        throw new BrowserError("browser_unavailable", "\u65E0\u6CD5\u8BFB\u53D6 agent-browser \u539F\u751F\u7A0B\u5E8F\uFF0C\u8BF7\u51C6\u5907\u5B98\u65B9\u7248\u672C\u5E76\u6838\u5B9E\u6743\u9650");
      }
      if (!RELEASE_HASHES[`${process.platform}-${process.arch}`].includes(hash)) throw new BrowserError("browser_unavailable", "agent-browser \u7A0B\u5E8F\u6821\u9A8C\u503C\u4E0D\u5C5E\u4E8E\u56FA\u5B9A\u5B98\u65B9 v0.39.1 release\uFF0C\u8BF7\u91CD\u65B0\u51C6\u5907\u5B98\u65B9\u8D44\u4EA7");
      const version = await runProcess(binary, ["--version"], { cwd: this.dataDir, env: this.env, timeout: 5e3 });
      if (version.code !== 0 || version.stdout.trim() !== `agent-browser ${RELEASE}`) throw new BrowserError("browser_unavailable", "agent-browser \u7248\u672C\u4E0D\u6EE1\u8DB3\u56FA\u5B9A release \u8981\u6C42");
      secureDirectory(this.root);
      secureDirectory(this.locks);
    }
    if (owned) {
      if (!this.options.chromePath) throw new BrowserError("browser_unavailable", "\u8BF7\u5148\u51C6\u5907 Chromium \u5E76\u914D\u7F6E\u5BBF\u4E3B\u53EF\u6267\u884C\u6587\u4EF6\u8DEF\u5F84\uFF1B\u6A21\u578B\u4EFB\u52A1\u4E0D\u4F1A\u81EA\u52A8\u5B89\u88C5\u6216\u63D0\u6743");
      try {
        fs2.accessSync(this.options.chromePath, fs2.constants.X_OK);
      } catch {
        throw new BrowserError("browser_unavailable", "Chromium \u4E0D\u53EF\u6267\u884C\uFF0C\u8BF7\u6838\u5B9E\u5BBF\u4E3B\u51C6\u5907\u6B65\u9AA4\u4E0E\u6743\u9650");
      }
    }
  }
  async binding(sessionId, kind, headed) {
    const old = this.bindings.get(sessionId);
    if (old && old.state !== "closed") throw new BrowserError("browser_not_ready", "\u539F\u6D4F\u89C8\u5668\u672A\u6838\u5B9E\u5173\u95ED\uFF0C\u4E0D\u80FD\u65B0\u5F00\u5B9E\u4F8B\uFF1B\u8BF7\u5148\u67E5\u770B\u72B6\u6001\u5E76\u663E\u5F0F\u5173\u95ED");
    const paths = this.paths(sessionId);
    secureDirectory(paths.socketDir);
    if (fs2.readdirSync(paths.socketDir).some((name) => name.endsWith(".pid") || name.endsWith(".sock"))) throw new BrowserError("browser_stop_unverified", "\u6D4F\u89C8\u5668\u63A7\u5236\u76EE\u5F55\u6B8B\u7559\u6267\u884C\u8BB0\u5F55\uFF0C\u8BF7\u6838\u5B9E\u539F\u6267\u884C\u540E\u518D\u542F\u52A8");
    fs2.writeFileSync(path.join(paths.socketDir, "config.json"), "{}\n", { mode: 384 });
    const binding = { sessionId, generation: randomUUID(), kind, state: "starting", profileDir: kind === "owned" ? paths.profileDir : null, socketDir: paths.socketDir, cliSession: paths.cliSession, cdpUrl: null, targetId: null, chrome: null, daemon: null, dashboard: null, chromePending: false, daemonPending: false, dashboardPending: false, lockDir: null, pauseTaskId: null, pauseAfterSeq: null, outcomeUnknown: false, failureCode: null, dashboardUrl: null, headed };
    this.bindings.set(sessionId, binding);
    await this.save(binding);
    return binding;
  }
  envFor(binding) {
    return { ...this.env, AGENT_BROWSER_SOCKET_DIR: binding.socketDir };
  }
  argv(binding) {
    return ["--config", path.join(binding.socketDir, "config.json"), "--session", binding.cliSession, "--cdp", binding.cdpUrl, "--json"];
  }
  sidecar(binding, name) {
    const file = path.join(binding.socketDir, `${name}.pid`);
    let text;
    try {
      text = fs2.readFileSync(file, "utf8");
    } catch (error2) {
      if (errno(error2) === "ENOENT") return null;
      throw new BrowserError("browser_identity_unverified", "\u65E0\u6CD5\u8BFB\u53D6\u6D4F\u89C8\u5668\u8FDB\u7A0B\u8BB0\u5F55");
    }
    const pid = Number(text.trim());
    if (!Number.isSafeInteger(pid) || pid <= 0) throw new BrowserError("browser_identity_unverified", "\u6D4F\u89C8\u5668\u8FDB\u7A0B\u8BB0\u5F55\u4E0D\u5408\u6CD5");
    const unit = captureProcess(pid);
    let command;
    try {
      command = execFileSync2("ps", ["-ww", "-p", String(pid), "-o", "command="], { encoding: "utf8", timeout: 3e3 }).trim();
    } catch {
      throw new BrowserError("browser_identity_unverified", "\u65E0\u6CD5\u6838\u5B9E\u6D4F\u89C8\u5668 daemon \u7A0B\u5E8F\u5F52\u5C5E");
    }
    const binary = fs2.realpathSync(this.options.binaryPath);
    if (command !== binary && !command.startsWith(`${binary} `)) throw new BrowserError("browser_identity_unverified", "\u6D4F\u89C8\u5668\u8FDB\u7A0B\u8BB0\u5F55\u6307\u5411\u5176\u4ED6\u7A0B\u5E8F\uFF0C\u62D2\u7EDD\u63A7\u5236");
    return unit;
  }
  async captureDaemon(binding) {
    const daemon = this.sidecar(binding, binding.cliSession);
    if (!daemon) throw new BrowserError("browser_identity_unverified", "\u6D4F\u89C8\u5668 daemon \u672A\u767B\u8BB0\u8FDB\u7A0B\u8EAB\u4EFD\uFF0C\u4FDD\u7559\u4E0D\u53EF\u7528\u72B6\u6001");
    if (binding.daemon && (binding.daemon.pid !== daemon.pid || binding.daemon.processIdentity !== daemon.processIdentity)) throw new BrowserError("browser_identity_unverified", "\u6D4F\u89C8\u5668 daemon \u5DF2\u6362\u4EE3\uFF0C\u539F\u6267\u884C\u72B6\u6001\u4E0D\u80FD\u6838\u5B9E");
    const fingerprint = this.fingerprint(binding);
    const previous = this.fingerprints.get(binding.sessionId);
    if (previous && (previous.config !== fingerprint.config || previous.version !== fingerprint.version)) throw new BrowserError("browser_identity_unverified", "\u6D4F\u89C8\u5668 daemon \u914D\u7F6E\u5DF2\u53D8\u5316\uFF0C\u62D2\u7EDD\u7EE7\u7EED\u81EA\u52A8\u5316");
    this.fingerprints.set(binding.sessionId, fingerprint);
    binding.daemon = daemon;
    binding.daemonPending = false;
    await this.save(binding);
  }
  fingerprint(binding) {
    let config, version, source;
    try {
      config = fs2.readFileSync(path.join(binding.socketDir, `${binding.cliSession}.config`), "utf8").trim();
      version = fs2.readFileSync(path.join(binding.socketDir, `${binding.cliSession}.version`), "utf8").trim();
      source = fs2.readFileSync(path.join(binding.socketDir, "config.json"), "utf8");
    } catch {
      throw new BrowserError("browser_identity_unverified", "\u6D4F\u89C8\u5668\u914D\u7F6E\u6216\u7248\u672C\u8BB0\u5F55\u7F3A\u5931\uFF0C\u62D2\u7EDD\u9690\u5F0F\u91CD\u542F daemon");
    }
    if (!/^[a-f0-9]{16}$/.test(config) || version !== RELEASE || source !== "{}\n") throw new BrowserError("browser_identity_unverified", "\u6D4F\u89C8\u5668\u914D\u7F6E\u6216\u7248\u672C\u8BB0\u5F55\u4E0D\u7B26\u5408\u56FA\u5B9A\u5BBF\u4E3B\u53C2\u6570");
    return { config, version };
  }
  async dashboard(binding, signal) {
    const port = await freePort();
    if (signal?.aborted) throw new BrowserError("browser_not_sent", "dashboard \u542F\u52A8\u5DF2\u53D6\u6D88");
    binding.dashboardPending = true;
    await this.save(binding);
    if (signal?.aborted) {
      binding.dashboardPending = false;
      await this.save(binding);
      throw new BrowserError("browser_not_sent", "dashboard \u542F\u52A8\u5DF2\u53D6\u6D88");
    }
    const result = await runProcess(this.options.binaryPath, ["--config", path.join(binding.socketDir, "config.json"), "--json", "dashboard", "start", "--port", String(port)], { cwd: binding.socketDir, env: this.envFor(binding), timeout: 1e4, signal });
    let response;
    try {
      response = JSON.parse(result.stdout);
    } catch {
      throw new BrowserError("browser_identity_unverified", "dashboard \u542F\u52A8\u5E94\u7B54\u4E22\u5931\uFF0C\u8BF7\u6838\u5B9E\u539F\u8FDB\u7A0B");
    }
    if (result.code !== 0 || !object(response) || response.success !== true || !object(response.data) || response.data.port !== port) throw new BrowserError("browser_unavailable", "\u5B98\u65B9 dashboard \u672A\u80FD\u542F\u52A8\uFF0C\u8BF7\u6838\u5B9E\u672C\u673A\u7AEF\u53E3\u548C\u8FDB\u7A0B");
    binding.dashboard = this.sidecar(binding, "dashboard");
    if (!binding.dashboard || binding.dashboard.pid !== response.data.pid) throw new BrowserError("browser_identity_unverified", "dashboard \u8FDB\u7A0B\u5F52\u5C5E\u4E0D\u4E00\u81F4");
    binding.dashboardPending = false;
    binding.dashboardUrl = `http://127.0.0.1:${port}/?port=${this.streamPort(binding)}`;
    await this.save(binding);
  }
  streamPort(binding) {
    const port = Number(fs2.readFileSync(path.join(binding.socketDir, `${binding.cliSession}.stream`), "utf8").trim());
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new BrowserError("browser_unavailable", "\u6D4F\u89C8\u5668\u4EBA\u5DE5\u8F93\u5165\u7AEF\u53E3\u4E0D\u5408\u6CD5");
    return port;
  }
  async initialize(binding, signal) {
    if (signal?.aborted) throw new BrowserError("browser_not_sent", "\u6D4F\u89C8\u5668\u8FDE\u63A5\u5DF2\u53D6\u6D88");
    binding.daemonPending = true;
    await this.save(binding);
    if (signal?.aborted) {
      binding.daemonPending = false;
      await this.save(binding);
      throw new BrowserError("browser_not_sent", "\u6D4F\u89C8\u5668\u8FDE\u63A5\u5DF2\u53D6\u6D88");
    }
    await runBrowserCommand(this.options.binaryPath, this.argv(binding), ["snapshot"], { cwd: binding.socketDir, env: this.envFor(binding), signal });
    await this.captureDaemon(binding);
    await this.dashboard(binding, signal);
    if (signal?.aborted) throw new BrowserError("browser_not_sent", "\u6D4F\u89C8\u5668\u542F\u52A8\u5DF2\u53D6\u6D88\uFF0C\u8BF7\u5173\u95ED\u5DF2\u767B\u8BB0\u6D4F\u89C8\u5668");
    binding.state = "ready";
    await this.save(binding);
    return structuredClone(binding);
  }
  async operation(sessionId, signal, action) {
    if (this.active.has(sessionId) || this.closing.has(sessionId)) throw new BrowserError("browser_busy", "\u540C\u4E00\u6D4F\u89C8\u5668\u4E00\u6B21\u53EA\u6267\u884C\u4E00\u4E2A\u64CD\u4F5C");
    const controller = new AbortController();
    const abort = () => controller.abort();
    signal?.addEventListener("abort", abort, { once: true });
    if (signal?.aborted) abort();
    const done = Promise.resolve().then(() => action(controller.signal));
    this.active.set(sessionId, { controller, done });
    try {
      return await done;
    } finally {
      this.active.delete(sessionId);
      signal?.removeEventListener("abort", abort);
    }
  }
  async start(sessionId, options = {}, signal) {
    return await this.operation(sessionId, signal, (current) => this.startOwned(sessionId, options, current));
  }
  async startOwned(sessionId, options, signal) {
    const current = this.bindings.get(sessionId);
    if (current && (current.state === "ready" || current.state === "paused") && current.kind === "owned") return structuredClone(current);
    if (signal?.aborted) throw new BrowserError("browser_not_sent", "\u6D4F\u89C8\u5668\u542F\u52A8\u5DF2\u53D6\u6D88");
    await this.prepare(true);
    if (signal.aborted) throw new BrowserError("browser_not_sent", "\u6D4F\u89C8\u5668\u542F\u52A8\u5DF2\u53D6\u6D88");
    const binding = await this.binding(sessionId, "owned", options.headed ?? this.options.headed ?? process.platform === "darwin");
    try {
      if (signal.aborted) throw new BrowserError("browser_not_sent", "\u6D4F\u89C8\u5668\u542F\u52A8\u5DF2\u53D6\u6D88");
      secureDirectory(binding.profileDir);
      if (rows().some((row) => row.command.includes(`--user-data-dir=${binding.profileDir}`) && !row.state.startsWith("Z"))) throw new BrowserError("browser_stop_unverified", "\u8BE5\u8D44\u6599\u76EE\u5F55\u4ECD\u6709\u6D4F\u89C8\u5668\u8FDB\u7A0B\uFF0C\u62D2\u7EDD\u65B0\u5F00\u5B9E\u4F8B");
      fs2.rmSync(path.join(binding.profileDir, "DevToolsActivePort"), { force: true });
      binding.chromePending = true;
      await this.save(binding);
      if (signal.aborted) {
        binding.chromePending = false;
        await this.save(binding);
        throw new BrowserError("browser_not_sent", "\u6D4F\u89C8\u5668\u542F\u52A8\u5DF2\u53D6\u6D88");
      }
      const args = ["--no-first-run", "--no-default-browser-check", "--remote-debugging-address=127.0.0.1", "--remote-debugging-port=0", `--user-data-dir=${binding.profileDir}`, ...binding.headed ? [] : ["--headless=new"], ...this.options.noSandbox ? ["--no-sandbox"] : [], "about:blank"];
      const child = spawn(this.options.chromePath, args, { cwd: binding.profileDir, env: this.env, detached: true, stdio: "ignore" });
      let spawnError = null;
      child.on("error", (error2) => {
        spawnError = error2;
      });
      child.unref();
      await delay(20);
      if (!child.pid || spawnError) {
        binding.chromePending = false;
        throw new BrowserError("browser_unavailable", "Chromium \u542F\u52A8\u5931\u8D25\uFF0C\u8BF7\u6838\u5B9E\u6C99\u7BB1\u4E0E\u7CFB\u7EDF\u524D\u63D0");
      }
      binding.chrome = captureProcess(child.pid);
      if (binding.chrome.pgid !== binding.chrome.pid) throw new BrowserError("browser_identity_unverified", "Chromium \u672A\u53D6\u5F97\u72EC\u7ACB\u8FDB\u7A0B\u7EC4");
      binding.chromePending = false;
      await this.save(binding);
      const deadline = Date.now() + 15e3;
      let endpoint = null;
      while (!endpoint) {
        if (signal?.aborted) throw new BrowserError("browser_not_sent", "\u6D4F\u89C8\u5668\u542F\u52A8\u5DF2\u53D6\u6D88\uFF0C\u8BF7\u5173\u95ED\u5DF2\u767B\u8BB0\u6D4F\u89C8\u5668");
        if (processState(binding.chrome) !== "alive" || Date.now() > deadline) throw new BrowserError("browser_unavailable", "Chromium \u672A\u63D0\u4F9B\u53EF\u7528 CDP\uFF1B\u8BF7\u6838\u5B9E\u7CFB\u7EDF\u6C99\u7BB1\u4E0E\u65E5\u5FD7\u51C6\u5907");
        let portText = null;
        try {
          portText = fs2.readFileSync(path.join(binding.profileDir, "DevToolsActivePort"), "utf8");
        } catch (error2) {
          if (errno(error2) !== "ENOENT") throw error2;
        }
        if (portText) {
          const [port, target] = portText.trim().split("\n");
          if (!/^\d+$/.test(port) || Number(port) < 1 || Number(port) > 65535) throw new BrowserError("browser_invalid_target", "Chromium CDP \u7AEF\u53E3\u8BB0\u5F55\u4E0D\u5408\u6CD5");
          endpoint = await resolveBrowserEndpoint(`ws://127.0.0.1:${port}${target}`, signal);
        } else await delay(50);
      }
      binding.cdpUrl = endpoint.url;
      binding.targetId = endpoint.targetId;
      await this.claim(binding);
      return await this.initialize(binding, signal);
    } catch (error2) {
      await this.unavailable(binding, error2 instanceof BrowserError ? error2 : new BrowserError("browser_unavailable", "\u6D4F\u89C8\u5668\u542F\u52A8\u5931\u8D25\uFF0C\u8BF7\u6838\u5B9E\u539F\u8FDB\u7A0B\u548C\u8D44\u6599\u76EE\u5F55"));
      throw error2 instanceof BrowserError ? error2 : new BrowserError("browser_unavailable", "\u6D4F\u89C8\u5668\u542F\u52A8\u5931\u8D25\uFF0C\u8BF7\u6838\u5B9E\u539F\u8FDB\u7A0B\u548C\u8D44\u6599\u76EE\u5F55");
    }
  }
  async attach(sessionId, target, signal) {
    return await this.operation(sessionId, signal, (current) => this.attachTarget(sessionId, target, current));
  }
  async claim(binding) {
    const lockDir = path.join(this.locks, digest(binding.targetId));
    try {
      fs2.mkdirSync(lockDir, { mode: 448 });
    } catch (error2) {
      if (errno(error2) === "EEXIST") throw new BrowserError("browser_target_in_use", "\u8BE5\u6D4F\u89C8\u5668\u5DF2\u88AB Ruukoto \u4F1A\u8BDD\u5360\u7528\uFF1B\u672A\u6838\u5B9E\u539F\u81EA\u52A8\u5316\u505C\u6B62\u524D\u4E0D\u80FD\u63A5\u7BA1");
      throw error2;
    }
    binding.lockDir = lockDir;
    fs2.writeFileSync(path.join(lockDir, "owner.json"), JSON.stringify({ dataDir: this.dataDir, sessionId: binding.sessionId, generation: binding.generation, daemon: null, daemonPending: false }), { flag: "wx", mode: 384 });
    await this.save(binding);
  }
  async attachTarget(sessionId, target, signal) {
    if (signal?.aborted) throw new BrowserError("browser_not_sent", "\u6D4F\u89C8\u5668\u9644\u63A5\u5DF2\u53D6\u6D88");
    await this.prepare(false);
    const endpoint = await resolveBrowserEndpoint(target, signal);
    const current = this.bindings.get(sessionId);
    if (current && (current.state === "ready" || current.state === "paused") && current.kind === "attached" && current.targetId === endpoint.targetId) return structuredClone(current);
    if (signal.aborted) throw new BrowserError("browser_not_sent", "\u6D4F\u89C8\u5668\u9644\u63A5\u5DF2\u53D6\u6D88");
    const binding = await this.binding(sessionId, "attached", false);
    binding.cdpUrl = endpoint.url;
    binding.targetId = endpoint.targetId;
    try {
      await this.claim(binding);
      return await this.initialize(binding, signal);
    } catch (error2) {
      const typed = error2 instanceof BrowserError ? error2 : new BrowserError("browser_unavailable", "\u9644\u63A5\u5931\u8D25\uFF0C\u8BF7\u6838\u5B9E\u539F\u81EA\u52A8\u5316\u8FDE\u63A5");
      await this.unavailable(binding, typed);
      throw typed;
    }
  }
  async pause(sessionId, taskId, afterSeq = 0) {
    const binding = this.require(sessionId);
    if (!["ready", "unavailable"].includes(binding.state) || this.active.has(sessionId)) throw new BrowserError("browser_busy", "\u8BF7\u7B49\u5F85\u5F53\u524D\u6D4F\u89C8\u5668\u52A8\u4F5C\u7ED3\u675F\u540E\u8FDB\u5165\u4EBA\u5DE5\u64CD\u4F5C");
    if (binding.state === "ready") binding.state = "paused";
    binding.pauseTaskId = taskId;
    binding.pauseAfterSeq = afterSeq;
    await this.save(binding);
    return structuredClone(binding);
  }
  async resume(sessionId, newTaskId) {
    return await this.operation(sessionId, void 0, async (signal) => {
      const binding = this.require(sessionId);
      if (!["paused", "unavailable"].includes(binding.state) || !binding.pauseTaskId || !newTaskId || newTaskId === binding.pauseTaskId) throw new BrowserError("browser_paused", "\u4EBA\u5DE5\u64CD\u4F5C\u540E\u9700\u62E5\u6709\u8005\u7684\u65B0\u6D88\u606F\u7EE7\u7EED\uFF0C\u4E0D\u80FD\u7531\u539F\u4EFB\u52A1\u81EA\u884C\u6062\u590D");
      if (!this.live(binding)) throw new BrowserError("browser_identity_unverified", "\u539F\u6D4F\u89C8\u5668\u8EAB\u4EFD\u6216\u5360\u7528\u65E0\u6CD5\u6838\u5B9E\uFF0C\u4E0D\u80FD\u6062\u590D\u81EA\u52A8\u5316");
      await this.prepare(false);
      try {
        await runBrowserCommand(this.options.binaryPath, this.argv(binding), ["snapshot"], { cwd: binding.socketDir, env: this.envFor(binding), signal });
        await this.captureDaemon(binding);
      } catch (error2) {
        const typed = error2 instanceof BrowserError ? error2 : new BrowserError("outcome_unknown", "\u6062\u590D\u65F6\u6D4F\u89C8\u5668\u8BFB\u53D6\u5E94\u7B54\u672A\u6838\u5B9E");
        await this.unavailable(binding, typed);
        throw typed;
      }
      const previousGeneration = binding.generation;
      binding.generation = randomUUID();
      binding.state = "ready";
      binding.pauseTaskId = null;
      binding.pauseAfterSeq = null;
      binding.failureCode = null;
      binding.outcomeUnknown = false;
      await this.save(binding, previousGeneration);
      return structuredClone(binding);
    });
  }
  async command(sessionId, args, signal) {
    return await this.operation(sessionId, signal, (current) => this.execute(sessionId, args, current));
  }
  async execute(sessionId, args, signal) {
    const binding = this.require(sessionId);
    if (binding.state === "paused") throw new BrowserError("browser_paused", "\u6D4F\u89C8\u5668\u6B63\u5728\u4EBA\u5DE5\u64CD\u4F5C\uFF0C\u7B49\u5F85\u62E5\u6709\u8005\u7684\u65B0\u6D88\u606F\u7EE7\u7EED");
    if (binding.state !== "ready") throw new BrowserError("browser_not_ready", "\u6D4F\u89C8\u5668\u8FDE\u63A5\u4E0D\u53EF\u7528\uFF0C\u672C\u6B21\u52A8\u4F5C\u672A\u53D1\u9001\uFF1B\u8BF7\u5148\u6838\u5B9E\u539F\u6267\u884C\u5E76\u663E\u5F0F\u5173\u95ED");
    if (!this.live(binding)) {
      const error2 = new BrowserError("browser_identity_unverified", "\u6D4F\u89C8\u5668\u8FDB\u7A0B\u5DF2\u9000\u51FA\u6216\u8EAB\u4EFD\u53D8\u5316\uFF0C\u8BF7\u5148\u6838\u5B9E\u505C\u6B62\uFF1B\u4E0D\u4F1A\u81EA\u52A8\u91CD\u5EFA\u5B9E\u4F8B");
      await this.unavailable(binding, error2);
      throw error2;
    }
    if (!["open", "snapshot", "click", "fill", "select", "check", "uncheck", "press", "scroll", "wait", "tab", "screenshot", "get"].includes(args[0])) throw new BrowserError("browser_invalid_action", "\u5BBF\u4E3B\u6D4F\u89C8\u5668\u52A8\u4F5C\u4E0D\u5728\u9996\u7248\u547D\u4EE4\u96C6\u5185");
    await this.prepare(false);
    try {
      const result = await runBrowserCommand(this.options.binaryPath, this.argv(binding), args, { cwd: binding.socketDir, env: this.envFor(binding), signal });
      await this.captureDaemon(binding);
      return result;
    } catch (error2) {
      const typed = error2 instanceof BrowserError && !["browser_identity_unverified", "browser_state_unavailable"].includes(error2.code) ? error2 : new BrowserError("outcome_unknown", "\u6D4F\u89C8\u5668\u52A8\u4F5C\u5E94\u7B54\u6216 daemon \u72B6\u6001\u672A\u6838\u5B9E", !isReadOnly(args));
      if (!["tab_gone", "browser_action_failed", "browser_not_sent"].includes(typed.code)) {
        try {
          await this.unavailable(binding, typed);
        } catch {
          process.stderr.write("[ruukoto:browser] \u6D4F\u89C8\u5668\u5931\u8D25\u72B6\u6001\u65E0\u6CD5\u4FDD\u5B58\uFF1B\u4FDD\u7559\u672C\u6B21\u7ED3\u679C\u672A\u77E5\u5E76\u505C\u6B62\u81EA\u52A8\u5316\n");
        }
      }
      throw typed;
    }
  }
  async stopUnit(unit) {
    if (!unit) return true;
    const state = processState(unit);
    if (state === "unknown") return false;
    if (state === "gone") return true;
    try {
      process.kill(unit.pid, "SIGTERM");
    } catch (error2) {
      return errno(error2) === "ESRCH";
    }
    const deadline = Date.now() + 3e3;
    while (Date.now() < deadline) {
      const current = processState(unit);
      if (current === "gone") return true;
      if (current === "unknown") return false;
      await delay(50);
    }
    if (processState(unit) !== "alive") return false;
    try {
      process.kill(unit.pid, "SIGKILL");
    } catch (error2) {
      return errno(error2) === "ESRCH";
    }
    const hardDeadline = Date.now() + 3e3;
    while (Date.now() < hardDeadline) {
      const current = processState(unit);
      if (current === "gone") return true;
      if (current === "unknown") return false;
      await delay(50);
    }
    return false;
  }
  lockMatches(binding, generation = binding.generation) {
    if (!binding.lockDir) return true;
    let owner;
    try {
      owner = JSON.parse(fs2.readFileSync(path.join(binding.lockDir, "owner.json"), "utf8"));
    } catch {
      return false;
    }
    return object(owner) && owner.dataDir === this.dataDir && owner.sessionId === binding.sessionId && owner.generation === generation;
  }
  sidecarsMatch(binding) {
    for (const [name, unit] of [[binding.cliSession, binding.daemon], ["dashboard", binding.dashboard]]) {
      let pid;
      try {
        pid = fs2.readFileSync(path.join(binding.socketDir, `${name}.pid`), "utf8");
      } catch (error2) {
        if (errno(error2) === "ENOENT") continue;
        return false;
      }
      if (!unit || Number(pid.trim()) !== unit.pid) return false;
    }
    let names;
    try {
      names = fs2.readdirSync(binding.socketDir);
    } catch {
      return false;
    }
    return !names.some((name) => name.endsWith(".pid") && ![`${binding.cliSession}.pid`, "dashboard.pid"].includes(name));
  }
  live(binding) {
    const previous = this.fingerprints.get(binding.sessionId);
    if (!previous) return false;
    let current;
    try {
      current = this.fingerprint(binding);
    } catch {
      return false;
    }
    return previous.config === current.config && previous.version === current.version && this.lockMatches(binding) && this.sidecarsMatch(binding) && !!binding.daemon && processState(binding.daemon) === "alive" && (!binding.chrome || processState(binding.chrome) === "alive") && (!binding.dashboard || processState(binding.dashboard) === "alive");
  }
  async closeOwned(binding) {
    if (binding.chromePending && !binding.chrome) return false;
    if (!binding.chrome) return !binding.chromePending;
    const state = processState(binding.chrome);
    if (state === "unknown") return false;
    if (state === "alive") {
      if (binding.cdpUrl) {
        try {
          await browserClose(binding.cdpUrl);
        } catch {
        }
      } else if (!await this.stopUnit(binding.chrome)) return false;
    }
    const deadline = Date.now() + 1e4;
    while (Date.now() < deadline) {
      if (processState(binding.chrome) === "unknown") return false;
      const remaining = rows().filter((row) => !row.state.startsWith("Z") && (row.pgid === binding.chrome.pgid || row.command.includes(`--user-data-dir=${binding.profileDir}`)));
      if (remaining.length === 0 && processState(binding.chrome) === "gone") return true;
      await delay(100);
    }
    return false;
  }
  async doClose(binding) {
    const active = this.active.get(binding.sessionId);
    active?.controller.abort();
    if (active) {
      try {
        await active.done;
      } catch {
      }
    }
    try {
      if (!this.lockMatches(binding)) throw new BrowserError("browser_stop_unverified", "\u9644\u63A5\u9501\u5F52\u5C5E\u65E0\u6CD5\u6838\u5B9E\uFF0C\u4FDD\u7559\u5360\u7528");
      if (binding.daemonPending) {
        if (!binding.daemon) binding.daemon = this.sidecar(binding, binding.cliSession);
        if (!binding.daemon) throw new BrowserError("browser_stop_unverified", "daemon \u542F\u52A8\u7A97\u53E3\u672A\u8BB0\u5F55\u8EAB\u4EFD\uFF0C\u4E0D\u80FD\u58F0\u79F0\u5DF2\u505C\u6B62");
        binding.daemonPending = false;
        try {
          await this.save(binding);
        } catch {
          process.stderr.write("[ruukoto:browser] daemon \u8EAB\u4EFD\u65E0\u6CD5\u4FDD\u5B58\uFF1B\u7EE7\u7EED\u505C\u6B62\u5DF2\u6838\u5B9E\u7684\u672C\u6B21\u8FDB\u7A0B\n");
        }
      }
      if (binding.dashboardPending) {
        if (!binding.dashboard) binding.dashboard = this.sidecar(binding, "dashboard");
        if (!binding.dashboard) throw new BrowserError("browser_stop_unverified", "dashboard \u542F\u52A8\u7A97\u53E3\u672A\u8BB0\u5F55\u8EAB\u4EFD");
        binding.dashboardPending = false;
        try {
          await this.save(binding);
        } catch {
          process.stderr.write("[ruukoto:browser] dashboard \u8EAB\u4EFD\u65E0\u6CD5\u4FDD\u5B58\uFF1B\u7EE7\u7EED\u505C\u6B62\u5DF2\u6838\u5B9E\u7684\u672C\u6B21\u8FDB\u7A0B\n");
        }
      }
      if (!this.sidecarsMatch(binding)) throw new BrowserError("browser_stop_unverified", "\u63A7\u5236\u76EE\u5F55\u51FA\u73B0\u672A\u767B\u8BB0\u8FDB\u7A0B\uFF0C\u4FDD\u7559\u539F\u7ED1\u5B9A\u4E0E\u5360\u7528");
      const daemonStopped = await this.stopUnit(binding.daemon), dashboardStopped = await this.stopUnit(binding.dashboard);
      const chromeStopped = binding.kind === "owned" ? await this.closeOwned(binding) : true;
      if (!daemonStopped || !dashboardStopped || !chromeStopped) throw new BrowserError("browser_stop_unverified", "\u6D4F\u89C8\u5668\u76F8\u5173\u8FDB\u7A0B\u672A\u6838\u5B9E\u505C\u6B62\uFF0C\u4FDD\u7559\u7ED1\u5B9A\u4E0E\u9644\u63A5\u5360\u7528");
      if (!this.lockMatches(binding) || !this.sidecarsMatch(binding)) throw new BrowserError("browser_stop_unverified", "\u505C\u6B62\u671F\u95F4\u5360\u7528\u6216\u8FDB\u7A0B\u8BB0\u5F55\u53D8\u5316\uFF0C\u4FDD\u7559\u63A7\u5236\u76EE\u5F55");
      binding.state = "closed";
      binding.pauseTaskId = null;
      binding.pauseAfterSeq = null;
      binding.failureCode = null;
      await this.save(binding);
      if (binding.lockDir) fs2.rmSync(binding.lockDir, { recursive: true });
      for (const name of fs2.readdirSync(binding.socketDir)) if (/\.(pid|sock|stream|config|version|target)$/.test(name)) fs2.rmSync(path.join(binding.socketDir, name), { force: true });
      return true;
    } catch (error2) {
      const typed = error2 instanceof BrowserError ? error2 : new BrowserError("browser_stop_unverified", "\u6D4F\u89C8\u5668\u505C\u6B62\u6838\u5B9E\u5931\u8D25\uFF0C\u4FDD\u7559\u7ED1\u5B9A\u4E0E\u5360\u7528");
      try {
        await this.unavailable(binding, typed);
      } catch {
        process.stderr.write("[ruukoto:browser] \u6D4F\u89C8\u5668\u505C\u6B62\u72B6\u6001\u65E0\u6CD5\u4FDD\u5B58\uFF1B\u4FDD\u7559\u7ED1\u5B9A\u4E0E\u5360\u7528\u5F85\u6838\u5B9E\n");
      }
      process.stderr.write(`[ruukoto:browser] ${typed.message}
`);
      return false;
    }
  }
  async close(sessionId) {
    const old = this.closing.get(sessionId);
    if (old) return await old;
    const pending = this.closeSession(sessionId);
    this.closing.set(sessionId, pending);
    try {
      return await pending;
    } finally {
      this.closing.delete(sessionId);
    }
  }
  async closeSession(sessionId) {
    const active = this.active.get(sessionId);
    active?.controller.abort();
    let binding = this.bindings.get(sessionId);
    if (!binding && active) {
      try {
        await active.done;
      } catch {
      }
      binding = this.bindings.get(sessionId);
    }
    if (!binding || binding.state === "closed") return true;
    binding.state = "unavailable";
    binding.failureCode = "browser_closing";
    let recorded = true;
    try {
      await this.save(binding);
    } catch {
      recorded = false;
      process.stderr.write("[ruukoto:browser] \u5173\u95ED\u610F\u56FE\u65E0\u6CD5\u4FDD\u5B58\uFF1B\u7EE7\u7EED\u56DE\u6536\u5DF2\u767B\u8BB0\u8FDB\u7A0B\uFF0C\u505C\u6B62\u7ED3\u8BBA\u4FDD\u6301\u5F85\u6838\u5B9E\n");
    }
    return await this.doClose(binding) && recorded;
  }
  assertState() {
    if (this.loadError) throw this.loadError;
  }
  async recover() {
    if (this.loadError) {
      process.stderr.write(`[ruukoto:browser] ${this.loadError.message}
`);
      return;
    }
    for (const binding of this.bindings.values()) if (binding.state !== "closed") await this.close(binding.sessionId);
  }
  async supervise() {
    if (this.supervising || this.shuttingDown || this.loadError) return;
    this.supervising = true;
    try {
      for (const binding of this.bindings.values()) {
        if (!["ready", "paused"].includes(binding.state) || this.active.has(binding.sessionId) || this.closing.has(binding.sessionId)) continue;
        if (!this.lockMatches(binding)) {
          await this.unavailable(binding, new BrowserError("browser_identity_unverified", "\u9644\u63A5\u5360\u7528\u8BB0\u5F55\u53D8\u5316\uFF0C\u8BF7\u6838\u5B9E\u539F\u6267\u884C"));
          continue;
        }
        if (binding.daemon && processState(binding.daemon) === "gone") await this.close(binding.sessionId);
        else if (binding.daemon && processState(binding.daemon) !== "alive" || binding.chrome && processState(binding.chrome) !== "alive" || binding.dashboard && processState(binding.dashboard) !== "alive") await this.unavailable(binding, new BrowserError("browser_identity_unverified", "\u6D4F\u89C8\u5668\u8FDB\u7A0B\u8EAB\u4EFD\u6216\u5B58\u6D3B\u72B6\u6001\u65E0\u6CD5\u6838\u5B9E"));
      }
    } catch (error2) {
      process.stderr.write(`[ruukoto:browser] \u751F\u547D\u5468\u671F\u76D1\u7763\u5931\u8D25\uFF1A${error2 instanceof Error ? error2.message : String(error2)}
`);
    } finally {
      this.supervising = false;
    }
  }
  async shutdown() {
    this.shuttingDown = true;
    clearInterval(this.timer);
    for (const sessionId of /* @__PURE__ */ new Set([...this.bindings.keys(), ...this.active.keys()])) await this.close(sessionId);
  }
};

// test/browser-lifecycle.test.ts
async function waitFor(condition) {
  const deadline = Date.now() + 5e3;
  while (!condition()) {
    if (Date.now() > deadline) throw new Error("\u5B50\u8FDB\u7A0B\u672A\u5728\u9884\u7B97\u5185\u5B8C\u6210");
    await new Promise((resolve2) => setTimeout(resolve2, 20));
  }
}
function error(code, effectUnknown) {
  return (value) => value instanceof BrowserError && value.code === code && value.effectUnknown === effectUnknown;
}
function wire(args, fields) {
  return JSON.stringify([{ command: args, success: true, result: {}, ...fields }]);
}
test("\u6D4F\u89C8\u5668 wire \u6309\u7ED3\u6784\u5316 code \u5224\u5B9A\uFF0C\u8BFB\u53D6\u5E94\u7B54\u4E22\u5931\u4E0D\u58F0\u79F0\u5916\u90E8\u5199\u5165\uFF0C\u6807\u7B7E\u5173\u95ED\u4E0D\u91CD\u5EFA", () => {
  const write = ["click", "#pay"];
  assert.throws(() => parseBrowserCommand(wire(write, { success: false, error: "\u4EFB\u610F\u8BCA\u65AD" }), write, 1), error("outcome_unknown", true));
  assert.throws(() => parseBrowserCommand(wire(write, { success: false, code: "new_code" }), write, 1), error("outcome_unknown", true));
  assert.throws(() => parseBrowserCommand(wire(write, { code: "new_code" }), write, 0), error("outcome_unknown", true));
  assert.throws(() => parseBrowserCommand(wire(write, { success: false, code: "tab_gone" }), write, 1), error("tab_gone", false));
  for (const read of [["snapshot"], ["screenshot", "out.png"], ["tab", "list"]]) {
    assert.throws(() => parseBrowserCommand("", read, 0), error("outcome_unknown", false));
    assert.throws(() => parseBrowserCommand(wire(read, { success: false, code: "outcome_unknown" }), read, 1), error("outcome_unknown", false));
    assert.throws(() => parseBrowserCommand(wire(read, { success: false }), read, 1), error("browser_action_failed", false));
  }
  assert.throws(() => parseBrowserCommand(wire(["click", "#other"], {}), write, 0), error("outcome_unknown", true));
  assert.throws(() => parseBrowserCommand(wire(write, {}), write, 1), error("outcome_unknown", true));
});
function cliFixture() {
  const root = fs3.mkdtempSync(path2.join(os.tmpdir(), "rk-browser-cli-"));
  const script = path2.join(root, "cli.mjs"), log = path2.join(root, "calls.jsonl");
  fs3.writeFileSync(script, `import fs from 'node:fs';let text='';for await(const chunk of process.stdin)text+=chunk;const batch=JSON.parse(text);fs.appendFileSync(process.env.CALL_LOG,JSON.stringify({argv:process.argv.slice(2),batch,pid:process.pid})+'\\n');if(process.env.MODE==='hang')setInterval(()=>{},1000);else if(process.env.MODE==='empty')process.exit(1);else if(process.env.MODE==='bad')process.stdout.write('{');else process.stdout.write(JSON.stringify([{command:batch[0],success:true,result:{text:'\u5BC6\u94A5'}}]));`);
  return { root, script, log, env: { ...process.env, CALL_LOG: log }, cleanup: () => fs3.rmSync(root, { recursive: true, force: true }) };
}
test("\u5355\u52A8\u4F5C\u4F7F\u7528 stdin batch \u4FDD\u7559 flag \u5F62\u6587\u672C\uFF0CEOF \u4E0E\u574F\u5E94\u7B54\u4ECE\u4E0D\u91CD\u53D1", async () => {
  const f = cliFixture(), args = ["fill", "#name", "--config"];
  try {
    assert.deepEqual(await runBrowserCommand(process.execPath, [f.script], args, { cwd: f.root, env: f.env }), { data: { text: "\u5BC6\u94A5" } });
    for (const mode of ["empty", "bad"]) await assert.rejects(runBrowserCommand(process.execPath, [f.script], args, { cwd: f.root, env: { ...f.env, MODE: mode } }), error("outcome_unknown", true));
    const calls = fs3.readFileSync(f.log, "utf8").trim().split("\n").map((line) => JSON.parse(line));
    assert.equal(calls.length, 3);
    for (const call of calls) {
      assert.deepEqual(call.argv, ["batch", "--bail"]);
      assert.deepEqual(call.batch, [args]);
    }
  } finally {
    f.cleanup();
  }
});
test("\u53D6\u6D88\u5728\u9014\u547D\u4EE4\u53EA\u505C\u6B62\u672C\u6B21 CLI \u5B50\u8FDB\u7A0B\uFF0C\u5199\u5165\u7ED3\u679C\u672A\u77E5\u4E14\u4E0D\u91CD\u53D1", async () => {
  const f = cliFixture(), controller = new AbortController();
  const pending = runBrowserCommand(process.execPath, [f.script], ["click", "#submit"], { cwd: f.root, env: { ...f.env, MODE: "hang" }, signal: controller.signal });
  const assertion = assert.rejects(pending, error("outcome_unknown", true));
  try {
    await waitFor(() => fs3.existsSync(f.log));
    const call = JSON.parse(fs3.readFileSync(f.log, "utf8").trim());
    controller.abort();
    await assertion;
    await waitFor(() => processIdentity(call.pid) === null);
    assert.equal(fs3.readFileSync(f.log, "utf8").trim().split("\n").length, 1);
  } finally {
    controller.abort();
    await assertion;
    f.cleanup();
  }
});
test("CDP discovery \u56FA\u5B9A literal loopback \u548C\u540C\u4E00\u6D4F\u89C8\u5668 UUID\uFF0C\u62D2\u7EDD\u91CD\u5B9A\u5411\u53CA\u8FDC\u7A0B\u76EE\u6807", async () => {
  const targetId = randomUUID2();
  let mode = "ok";
  const server = createServer2((_request, response) => {
    if (mode === "redirect") {
      response.writeHead(302, { Location: "http://example.com/json/version" });
      response.end();
      return;
    }
    const address2 = server.address();
    assert.ok(address2 && typeof address2 === "object");
    response.end(JSON.stringify({ webSocketDebuggerUrl: `ws://${mode === "remote" ? "example.com" : "localhost"}:${address2.port}/devtools/browser/${targetId}` }));
  });
  await new Promise((resolve2) => server.listen(0, "127.0.0.1", resolve2));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  try {
    const expected = { url: `ws://127.0.0.1:${address.port}/devtools/browser/${targetId}`, targetId };
    assert.deepEqual(await resolveBrowserEndpoint(`http://localhost:${address.port}`), expected);
    assert.deepEqual(await resolveBrowserEndpoint(`ws://127.0.0.1:${address.port}/devtools/browser/${targetId.toUpperCase()}`), expected);
    mode = "redirect";
    await assert.rejects(resolveBrowserEndpoint(`http://127.0.0.1:${address.port}`), error("browser_invalid_target", false));
    mode = "remote";
    await assert.rejects(resolveBrowserEndpoint(`http://localhost:${address.port}`), error("browser_invalid_target", false));
    for (const url of ["ws://example.com:9222/devtools/browser/" + targetId, "ws://127.0.0.1:9222/devtools/page/" + targetId, "ws://user@localhost:9222/devtools/browser/" + targetId]) await assert.rejects(resolveBrowserEndpoint(url), error("browser_invalid_target", false));
  } finally {
    await new Promise((resolve2) => server.close(() => resolve2()));
  }
});
async function childUnit() {
  const child = spawn2(process.execPath, ["-e", "process.stdout.write('ready');setInterval(()=>{},1000)"], { detached: true, stdio: ["ignore", "pipe", "ignore"] });
  const exited = once(child, "exit");
  await once(child.stdout, "data");
  assert.ok(child.pid);
  const identity = processIdentity(child.pid);
  assert.ok(identity);
  return { child, exited, unit: { pid: child.pid, pgid: Number(execFileSync3("ps", ["-p", String(child.pid), "-o", "pgid="], { encoding: "utf8" }).trim()), processIdentity: identity } };
}
function persistedFixture(unit) {
  const root = fs3.mkdtempSync(path2.join(os.tmpdir(), "rk-browser-state-")), dataDir = path2.join(root, "data");
  fs3.mkdirSync(dataDir);
  const sessionId = "session", generation = randomUUID2(), targetId = randomUUID2();
  const id = createHash2("sha256").update(`${dataDir}\0${sessionId}`).digest("hex").slice(0, 24);
  const socketDir = `/tmp/ruukoto-browser-${process.getuid?.() ?? "unknown"}-${id}`;
  const lockDir = `/tmp/ruukoto-browser-locks-${process.getuid?.() ?? "unknown"}/${createHash2("sha256").update(targetId).digest("hex")}`;
  fs3.mkdirSync(socketDir, { recursive: true, mode: 448 });
  fs3.mkdirSync(lockDir, { recursive: true, mode: 448 });
  const binding = { sessionId, generation, kind: "attached", state: "ready", profileDir: null, socketDir, cliSession: `rk-${id}`, cdpUrl: `ws://127.0.0.1:9222/devtools/browser/${targetId}`, targetId, chrome: null, daemon: unit, dashboard: null, chromePending: false, daemonPending: false, dashboardPending: false, lockDir, pauseTaskId: null, pauseAfterSeq: null, outcomeUnknown: false, failureCode: null, dashboardUrl: null, headed: false };
  const ownerFile = path2.join(lockDir, "owner.json");
  fs3.writeFileSync(ownerFile, JSON.stringify({ dataDir, sessionId, generation, daemon: unit }));
  if (unit) fs3.writeFileSync(path2.join(socketDir, `${binding.cliSession}.pid`), String(unit.pid));
  fs3.writeFileSync(path2.join(socketDir, "config.json"), "{}\n");
  fs3.writeFileSync(path2.join(socketDir, `${binding.cliSession}.config`), "0123456789abcdef");
  fs3.writeFileSync(path2.join(socketDir, `${binding.cliSession}.version`), "0.39.1");
  let state = JSON.stringify({ version: 1, bindings: [binding], fingerprints: { [sessionId]: { config: "0123456789abcdef", version: "0.39.1" } } });
  const make = (beforePersist) => new BrowserManager({ dataDir, binaryPath: process.execPath, store: { getMetaValue: () => state }, persist: async (value) => {
    await beforePersist?.();
    state = value;
  } });
  return { root, binding, ownerFile, make, setState: (value) => {
    state = JSON.stringify({ version: 1, bindings: [value] });
  }, cleanup: () => {
    fs3.rmSync(root, { recursive: true, force: true });
    fs3.rmSync(socketDir, { recursive: true, force: true });
    fs3.rmSync(lockDir, { recursive: true, force: true });
  } };
}
test("\u51B7\u6062\u590D\u505C\u6B62\u5DF2\u77E5\u9644\u63A5 daemon\uFF0C\u91CA\u653E\u9501\u4F46\u4E0D\u89E6\u78B0\u7528\u6237 Chrome CDP", async () => {
  const c = await childUnit(), f = persistedFixture(c.unit), manager = f.make();
  try {
    await manager.recover();
    await c.exited;
    assert.equal(manager.status("session")?.state, "closed");
    assert.equal(fs3.existsSync(f.ownerFile), false);
    assert.equal(await manager.close("session"), true);
  } finally {
    await manager.shutdown();
    if (c.child.exitCode === null && c.child.signalCode === null) c.child.kill();
    await c.exited;
    f.cleanup();
  }
});
test("\u8FDB\u7A0B\u542F\u52A8\u8EAB\u4EFD\u4E0D\u5339\u914D\u4E0D\u53D1\u4FE1\u53F7\u3001\u4E0D\u653E\u9501\u3001\u4E0D\u5141\u8BB8\u65B0\u5F00\uFF1B\u7ED3\u679C\u672A\u77E5\u53EA\u767B\u8BB0\u4EBA\u5DE5\u7B49\u5F85", async () => {
  const c = await childUnit(), f = persistedFixture(c.unit);
  f.binding.daemon = { ...c.unit, processIdentity: process.platform === "linux" ? c.unit.processIdentity.replace(/:\d+$/, ":0") : "darwin:Thu Jan  1 00:00:00 1970" };
  f.binding.state = "unavailable";
  f.binding.outcomeUnknown = true;
  f.setState(f.binding);
  const manager = f.make();
  try {
    for (const args of [["snapshot"], ["click", "@e1"]]) await assert.rejects(manager.command("session", args), error("browser_not_ready", false));
    assert.equal(manager.status("session")?.outcomeUnknown, true);
    assert.equal(await manager.close("session"), false);
    assert.equal(processIdentity(c.unit.pid), c.unit.processIdentity);
    assert.equal(fs3.existsSync(f.ownerFile), true);
    await manager.pause("session", "old");
    assert.equal(manager.status("session")?.state, "unavailable");
    await assert.rejects(manager.resume("session", "old"), error("browser_paused", false));
    await assert.rejects(manager.resume("session", "new"), error("browser_identity_unverified", false));
    await assert.rejects(manager.start("session"), BrowserError);
    assert.equal(processIdentity(c.unit.pid), c.unit.processIdentity);
  } finally {
    await manager.shutdown();
    c.child.kill();
    await c.exited;
    f.cleanup();
  }
});
test("\u4ED6\u4EBA\u7684 UUID \u9501\u548C\u672A\u767B\u8BB0 PID sidecar \u4E0D\u88AB\u8986\u76D6\u3001\u505C\u6B62\u6216\u6E05\u9664", async () => {
  const c = await childUnit(), f = persistedFixture(c.unit), manager = f.make();
  try {
    const foreign = JSON.stringify({ dataDir: "/other", sessionId: "other", generation: randomUUID2() });
    fs3.writeFileSync(f.ownerFile, foreign);
    assert.equal(await manager.close("session"), false);
    assert.equal(fs3.readFileSync(f.ownerFile, "utf8"), foreign);
    assert.equal(processIdentity(c.unit.pid), c.unit.processIdentity);
  } finally {
    await manager.shutdown();
    c.child.kill();
    await c.exited;
    f.cleanup();
  }
  const c2 = await childUnit(), f2 = persistedFixture(c2.unit), manager2 = f2.make();
  try {
    fs3.writeFileSync(path2.join(f2.binding.socketDir, "unknown.pid"), String(c2.unit.pid));
    assert.equal(await manager2.close("session"), false);
    assert.equal(fs3.existsSync(path2.join(f2.binding.socketDir, "unknown.pid")), true);
    assert.equal(processIdentity(c2.unit.pid), c2.unit.processIdentity);
  } finally {
    await manager2.shutdown();
    c2.child.kill();
    await c2.exited;
    f2.cleanup();
  }
});
test("\u9996\u6B21\u53D1\u9001\u7A97\u53E3\u7F3A\u8EAB\u4EFD\u65F6\u4FDD\u7559 unavailable \u4E0E\u9501\uFF1B\u7F3A\u7248\u672C\u6216 fingerprint \u53D8\u5316\u5148\u62D2\u7EDD CLI", async () => {
  const f = persistedFixture(null);
  f.binding.daemonPending = true;
  f.setState(f.binding);
  const manager = f.make();
  try {
    assert.equal(await manager.close("session"), false);
    assert.equal(fs3.existsSync(f.ownerFile), true);
  } finally {
    await manager.shutdown();
    f.cleanup();
  }
  for (const mode of ["missing", "changed"]) {
    const c = await childUnit(), current = persistedFixture(c.unit), m = current.make();
    try {
      const file = path2.join(current.binding.socketDir, `${current.binding.cliSession}.${mode === "missing" ? "version" : "config"}`);
      if (mode === "missing") fs3.rmSync(file);
      else fs3.writeFileSync(file, "ffffffffffffffff");
      await assert.rejects(m.command("session", ["click", "#submit"]), error("browser_identity_unverified", false));
      assert.equal(m.status("session")?.state, "unavailable");
      assert.equal(processIdentity(c.unit.pid), c.unit.processIdentity);
      assert.equal(await m.close("session"), true);
      await c.exited;
    } finally {
      await m.shutdown();
      if (c.child.exitCode === null && c.child.signalCode === null) c.child.kill();
      await c.exited;
      current.cleanup();
    }
  }
});
test("\u5BBF\u4E3B\u672A\u51C6\u5907\u56FA\u5B9A\u5B98\u65B9\u7A0B\u5E8F\u65F6\u4E0D\u521B\u5EFA profile \u6216\u65B0\u5B9E\u4F8B", async () => {
  const root = fs3.mkdtempSync(path2.join(os.tmpdir(), "rk-browser-prepare-")), binary = path2.join(root, "fake");
  fs3.writeFileSync(binary, "fake");
  const manager = new BrowserManager({ dataDir: root, binaryPath: binary, store: { getMetaValue: () => null }, persist: () => assert.fail("\u62D2\u7EDD\u7A0B\u5E8F\u65F6\u4E0D\u5F97\u767B\u8BB0\u7ED1\u5B9A") });
  try {
    await assert.rejects(manager.start("session"), error("browser_unavailable", false));
    assert.equal(manager.status("session"), null);
    assert.equal(fs3.existsSync(path2.join(root, "browser")), false);
  } finally {
    await manager.shutdown();
    fs3.rmSync(root, { recursive: true, force: true });
  }
});
for (const pending of [false, true]) test(`\u6D4F\u89C8\u5668\u5173\u95ED\u6301\u4E45\u5316\u5931\u8D25\u4ECD\u505C\u6B62${pending ? "\u542F\u52A8\u7A97\u53E3\u4E2D" : "\u5DF2\u767B\u8BB0"}\u7684\u672C\u6B21 daemon\uFF0C\u4FDD\u7559\u672A\u6838\u5B9E\u7ED3\u8BBA`, async () => {
  const c = await childUnit(), f = persistedFixture(c.unit);
  if (pending) {
    f.binding.daemonPending = true;
    f.binding.daemon = null;
    f.setState(f.binding);
  }
  let fail = true;
  const manager = f.make(() => {
    if (fail) throw new Error("\u6D4B\u8BD5\u5B58\u50A8\u5931\u8D25");
  });
  try {
    assert.equal(await manager.close("session"), false);
    await waitFor(() => processIdentity(c.unit.pid) === null);
    await c.exited;
    assert.equal(manager.status("session")?.state, "unavailable");
    assert.equal(fs3.existsSync(f.ownerFile), true);
  } finally {
    fail = false;
    await manager.shutdown();
    if (c.child.exitCode === null && c.child.signalCode === null) c.child.kill();
    await c.exited;
    f.cleanup();
  }
});
for (const failedWire of [false, true]) test(`\u6D4F\u89C8\u5668${failedWire ? "\u5DF2\u4E22\u54CD\u5E94" : "\u6210\u529F\u5199\u5165\u540E"}\u6301\u4E45\u5316\u5931\u8D25\u4FDD\u7559\u672C\u6B21\u672A\u77E5\u6548\u679C`, async () => {
  const c = await childUnit(), f = persistedFixture(c.unit), cli = cliFixture();
  let failPersist = false, writes = 0;
  const manager = f.make(() => {
    if (failPersist) throw new Error("\u6D4B\u8BD5\u5B58\u50A8\u5931\u8D25");
  });
  const server = createServer2((_req, response) => {
    writes++;
    failPersist = true;
    response.end("ok");
  });
  await new Promise((resolve2) => server.listen(0, "127.0.0.1", resolve2));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  fs3.writeFileSync(cli.script, `let input='';for await(const part of process.stdin)input+=part;const [command]=JSON.parse(input);await fetch(process.env.POST_URL,{method:'POST'});process.stdout.write(JSON.stringify([{command,success:${!failedWire},result:${failedWire ? "null" : "{}"}${failedWire ? ",code:'outcome_unknown'" : ""}}]));process.exit(${failedWire ? 1 : 0});`);
  Object.assign(manager, { prepare: async () => {
  }, argv: () => [cli.script], envFor: () => ({ ...process.env, POST_URL: `http://127.0.0.1:${address.port}/` }) });
  try {
    await assert.rejects(manager.command("session", ["click", "@e1"]), error("outcome_unknown", true));
    assert.equal(writes, 1);
    assert.equal(manager.status("session")?.outcomeUnknown, true);
    assert.equal(manager.status("session")?.state, "unavailable");
  } finally {
    failPersist = false;
    await manager.shutdown();
    if (c.child.exitCode === null && c.child.signalCode === null) c.child.kill();
    await c.exited;
    server.closeAllConnections();
    await new Promise((resolve2) => server.close(() => resolve2()));
    f.cleanup();
    cli.cleanup();
  }
});
for (const canceled of [true, false]) test(`CDP discovery \u6301\u7EED\u6162\u6D41\u4ECD\u54CD\u5E94${canceled ? "\u53D6\u6D88" : "\u603B\u671F\u9650"}`, async () => {
  let ready;
  const seen = new Promise((resolve2) => {
    ready = resolve2;
  });
  const server = createServer2((_req, response) => {
    response.writeHead(200);
    response.write(" ");
    ready();
    const timer = setInterval(() => response.write(" "), 20);
    response.on("close", () => clearInterval(timer));
  });
  await new Promise((resolve2) => server.listen(0, "127.0.0.1", resolve2));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  const controller = new AbortController(), start = Date.now();
  const pending = resolveBrowserEndpoint(`http://127.0.0.1:${address.port}`, controller.signal);
  const assertion = assert.rejects(pending, error(canceled ? "browser_not_sent" : "browser_invalid_target", false));
  let deadline;
  try {
    await seen;
    if (canceled) controller.abort();
    await Promise.race([assertion, new Promise((_resolve, reject) => {
      deadline = setTimeout(() => reject(new Error("discovery \u672A\u5728\u603B\u9884\u7B97\u5185\u7ED3\u675F")), 5e3);
    })]);
    assert.ok(Date.now() - start < (canceled ? 1e3 : 4500));
  } finally {
    clearTimeout(deadline);
    controller.abort();
    server.closeAllConnections();
    await new Promise((resolve2) => server.close(() => resolve2()));
    await assertion;
  }
});
test("\u6D4F\u89C8\u5668\u5F02\u6B65\u6301\u4E45\u8FB9\u754C\u5B8C\u6210\u524D\u4E0D\u53D1\u9001\u505C\u6B62\u4FE1\u53F7", async () => {
  const c = await childUnit(), f = persistedFixture(c.unit);
  let entered = false, release;
  const hold = new Promise((resolve2) => {
    release = resolve2;
  });
  const manager = f.make(async () => {
    entered = true;
    await hold;
  });
  const closing = manager.close("session");
  try {
    await waitFor(() => entered);
    await new Promise((resolve2) => setTimeout(resolve2, 50));
    assert.equal(processIdentity(c.unit.pid), c.unit.processIdentity);
    release();
    assert.equal(await closing, true);
    await c.exited;
  } finally {
    release();
    await closing;
    await manager.shutdown();
    if (c.child.exitCode === null && c.child.signalCode === null) c.child.kill();
    await c.exited;
    f.cleanup();
  }
});
test("\u6D4F\u89C8\u5668\u542F\u52A8\u610F\u56FE\u63D0\u4EA4\u671F\u95F4\u53D6\u6D88\u4E0D\u542F\u52A8Chrome\uFF0C\u4E0D\u7559\u4E0B\u5F85\u6838\u5B9E\u542F\u52A8\u7A97\u53E3", async () => {
  const root = fs3.mkdtempSync(path2.join(os.tmpdir(), "rk-browser-cancel-persist-")), chrome = path2.join(root, "chrome"), marker = path2.join(root, "spawned");
  fs3.writeFileSync(chrome, `#!${process.execPath}
import fs from 'node:fs';fs.writeFileSync(${JSON.stringify(marker)},'started');setInterval(()=>{},1000);`, { mode: 448 });
  let entered = false, release;
  const hold = new Promise((resolve2) => {
    release = resolve2;
  }), controller = new AbortController();
  const manager = new BrowserManager({ dataDir: root, binaryPath: process.execPath, chromePath: chrome, initialState: null, persist: async (_state, binding) => {
    if (binding.chromePending && !entered) {
      entered = true;
      await hold;
    }
  } });
  Object.assign(manager, { prepare: async () => {
  } });
  const pending = manager.start("session", {}, controller.signal), assertion = assert.rejects(pending, error("browser_not_sent", false));
  try {
    await waitFor(() => entered);
    controller.abort();
    release();
    await assertion;
    assert.equal(fs3.existsSync(marker), false);
    assert.equal(manager.status("session")?.chromePending, false);
  } finally {
    release();
    await assertion;
    await manager.shutdown();
    fs3.rmSync(root, { recursive: true, force: true });
    const id = createHash2("sha256").update(`${root}\0session`).digest("hex").slice(0, 24);
    fs3.rmSync(`/tmp/ruukoto-browser-${process.getuid?.() ?? "unknown"}-${id}`, { recursive: true, force: true });
  }
});
