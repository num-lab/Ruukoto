import {createRequire as probeCreateRequire} from 'node:module';const require=probeCreateRequire(import.meta.url);

// test/personal-media.test.ts
import assert from "node:assert/strict";
import * as fs4 from "node:fs";
import * as path4 from "node:path";
import { test } from "node:test";
import { randomUUID as randomUUID3 } from "node:crypto";
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT14 } from "@earendil-works/chord/context";
import { createRegistry, defineExtension as defineExtension16, defineTool as defineTool7, Harness, ProviderDoc as ProviderDoc2, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID15 } from "@earendil-works/pi-durable";
import { Type as Type7 } from "typebox";

// apps/ruukoto/src/personal-media.ts
import * as fs2 from "node:fs";
import * as path2 from "node:path";
import { isDeepStrictEqual } from "node:util";
import { setTimeout as delay } from "node:timers/promises";
import { BACKGROUND_CONTEXT } from "@earendil-works/chord/context";
import { copyJson } from "@earendil-works/chord";
import { defineDoc as defineDoc2, defineDocFamily as defineDocFamily2, defineExtension, ProviderDoc, ROOT_CONVERSATION_ID } from "@earendil-works/pi-durable";

// packages/agent/src/artifacts.ts
function imageMime(bytes) {
  if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return "image/jpeg";
  if (bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return "image/png";
  if (bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP") return "image/webp";
  return null;
}

// apps/ruukoto/src/personal-artifacts.ts
import * as fs from "node:fs";
import * as path from "node:path";
import { createHash, randomUUID } from "node:crypto";

// apps/ruukoto/src/personal-error.ts
var PersonalError = class extends Error {
  constructor(code, message, options) {
    super(message, options);
    this.code = code;
    this.name = "PersonalError";
  }
  code;
};

// apps/ruukoto/src/personal-artifacts.ts
var CAP_BYTES = 8 * 1024 * 1024;
var unavailable = () => new PersonalError("artifact_unavailable", "\u539F\u4EA7\u7269\u7F3A\u5931\u3001\u635F\u574F\u6216\u6743\u9650\u65E0\u6CD5\u6838\u5B9E\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u62A5\u544A\u62E5\u6709\u8005\u3002");
function privateObject(filename, directory) {
  const stat = fs.lstatSync(filename);
  if ((directory ? !stat.isDirectory() : !stat.isFile() || stat.nlink !== 1) || stat.uid !== process.getuid?.() || (stat.mode & 63) !== 0) throw unavailable();
  return stat;
}
function artifactDirectory(profile, create = false) {
  const directory = typeof profile === "string" ? profile : profile.directory;
  if (!path.isAbsolute(directory) || fs.realpathSync(directory) !== directory) throw unavailable();
  privateObject(directory, true);
  const root = path.join(directory, "artifacts");
  if (create) fs.mkdirSync(root, { recursive: true, mode: 448 });
  privateObject(root, true);
  return root;
}
function writeExclusive(filename, bytes) {
  const fd = fs.openSync(filename, "wx", 384);
  try {
    fs.writeFileSync(fd, bytes);
    fs.fsyncSync(fd);
    const { dev, ino } = fs.fstatSync(fd);
    return { dev, ino };
  } finally {
    fs.closeSync(fd);
  }
}
function syncDirectory(directory) {
  const fd = fs.openSync(directory, fs.constants.O_RDONLY | fs.constants.O_DIRECTORY);
  try {
    fs.fsyncSync(fd);
  } finally {
    fs.closeSync(fd);
  }
}
async function savePersonalArtifact(profile, bytes, options = {}) {
  try {
    const root = artifactDirectory(profile, true), id2 = randomUUID(), temporary = path.join(root, `.tmp-${randomUUID()}`), target = path.join(root, `${id2}.bin`);
    const content = Buffer.from(bytes.subarray(0, CAP_BYTES)), mime2 = options.mime ?? "application/octet-stream";
    if (!mime2 || mime2.length > 256 || /[\x00-\x1f\x7f]/.test(mime2)) throw new PersonalError("artifact_input_invalid", "\u4EA7\u7269 MIME \u65E0\u6CD5\u6838\u5B9E\uFF0C\u8BF7\u4FEE\u6B63\u6765\u6E90\u7C7B\u578B\u540E\u518D\u4FDD\u5B58\u3002");
    const identity = writeExclusive(temporary, content);
    fs.linkSync(temporary, target);
    fs.unlinkSync(temporary);
    syncDirectory(root);
    const stat = privateObject(target, false);
    if (stat.dev !== identity.dev || stat.ino !== identity.ino || stat.size !== content.length) throw unavailable();
    return { id: id2, bytes: content.length, sha256: createHash("sha256").update(content).digest("hex"), partial: !!options.partial || bytes.length > CAP_BYTES, mime: mime2, identity };
  } catch (error) {
    if (error instanceof PersonalError && error.code === "artifact_input_invalid") throw error;
    throw new PersonalError("artifact_write_failed", "\u4EA7\u7269\u672A\u80FD\u5B8C\u6574\u767B\u8BB0\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u68C0\u67E5\u78C1\u76D8\uFF1B\u5DF2\u5199\u6587\u4EF6\u4ECD\u4FDD\u7559\u3002", { cause: error });
  }
}
function loadPersonalArtifact(profile, ref) {
  try {
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(ref.id) || !Number.isSafeInteger(ref.bytes) || ref.bytes < 0 || ref.bytes > CAP_BYTES || !/^[0-9a-f]{64}$/.test(ref.sha256) || typeof ref.partial !== "boolean" || typeof ref.mime !== "string" || !ref.mime || ref.mime.length > 256 || /[\x00-\x1f\x7f]/.test(ref.mime) || !Number.isSafeInteger(ref.identity.dev) || !Number.isSafeInteger(ref.identity.ino)) throw unavailable();
    const target = path.join(artifactDirectory(profile), `${ref.id}.bin`), before = privateObject(target, false);
    if (before.dev !== ref.identity.dev || before.ino !== ref.identity.ino || before.size !== ref.bytes) throw unavailable();
    const fd = fs.openSync(target, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW | fs.constants.O_NONBLOCK);
    try {
      const stat = fs.fstatSync(fd);
      if (!stat.isFile() || stat.nlink !== 1 || stat.uid !== process.getuid?.() || (stat.mode & 63) !== 0 || stat.dev !== before.dev || stat.ino !== before.ino || stat.size !== ref.bytes) throw unavailable();
      const bytes = Buffer.alloc(ref.bytes);
      let offset = 0;
      while (offset < bytes.length) {
        const count = fs.readSync(fd, bytes, offset, bytes.length - offset, offset);
        if (!count) throw unavailable();
        offset += count;
      }
      if (fs.fstatSync(fd).size !== ref.bytes || createHash("sha256").update(bytes).digest("hex") !== ref.sha256) throw unavailable();
      return bytes;
    } finally {
      fs.closeSync(fd);
    }
  } catch (error) {
    throw new PersonalError("artifact_unavailable", "\u539F\u4EA7\u7269\u7F3A\u5931\u3001\u635F\u574F\u6216\u6743\u9650\u65E0\u6CD5\u6838\u5B9E\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u62A5\u544A\u62E5\u6709\u8005\u3002", { cause: error });
  }
}

// apps/ruukoto/src/personal-telegram-records.ts
import { defineDoc, defineDocFamily } from "@earendil-works/pi-durable";
var PersonalTelegramDoc = defineDoc({ kind: "ruukoto.telegram", scope: "session", version: 1, initial: () => ({ rejected: 0 }) });
var PersonalTelegramReceiptDoc = defineDocFamily({ kind: "ruukoto.telegram-receipt", scope: "session", version: 1, family: true, initial: () => ({}) });

// apps/ruukoto/src/personal-media.ts
var PERSONAL_MEDIA = "personal-media";
var context = BACKGROUND_CONTEXT;
var MAX_IMAGES = 4;
var MAX_BYTES = 8 * 1024 * 1024;
var TTL_MS = 24 * 60 * 60 * 1e3;
var PersonalMediaError = class extends PersonalError {
  constructor(reason) {
    super(reason, "\u56FE\u7247\u672A\u88AB\u63A5\u7EB3\uFF0C\u8BF7\u68C0\u67E5\u56FE\u7247\u5927\u5C0F\u3001\u683C\u5F0F\u548C\u5165\u53E3\uFF1B\u672C\u6761\u6587\u5B57\u672A\u5355\u72EC\u4EA4\u7ED9\u6A21\u578B\u3002");
    this.reason = reason;
  }
  reason;
};
var PersonalMediaDoc = defineDoc2({ kind: "ruukoto.media", scope: "session", version: 1, initial: () => ({ keys: [], images: [] }) });
var PersonalMediaMessageDoc = defineDocFamily2({ kind: "ruukoto.media-message", scope: "session", version: 1, family: true, initial: () => ({}) });
var PersonalImageDoc = defineDocFamily2({ kind: "ruukoto.image", scope: "session", version: 1, family: true, initial: () => ({}) });
var validMime = (value) => value === "image/jpeg" || value === "image/png" || value === "image/webp";
var mime = (value) => value?.split(";", 1)[0]?.trim().toLowerCase();
var invalid = () => new PersonalError("image_reference_invalid", "\u539F\u56FE\u7247\u7684\u6765\u6E90\u3001\u5B57\u8282\u6216\u5F52\u5C5E\u65E0\u6CD5\u6838\u5B9E\uFF0C\u5DF2\u505C\u6B62\u6A21\u578B\u8BF7\u6C42\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u62A5\u544A\u62E5\u6709\u8005\u3002");
var block = (ref) => ({ type: "image", mimeType: ref.artifact.mime, data: JSON.stringify({ ruukotoImage: ref }) });
function reference(part) {
  let value;
  try {
    value = JSON.parse(part.data);
  } catch {
    throw invalid();
  }
  if (!value || typeof value !== "object" || !("ruukotoImage" in value)) throw invalid();
  const ref = value.ruukotoImage;
  if (!ref || ref.version !== 1 || !ref.artifact || ref.artifact.mime !== part.mimeType || ref.artifact.partial || !validMime(ref.artifact.mime) || !ref.source || !["inbound", "tool"].includes(ref.source.kind)) throw invalid();
  return ref;
}
var contains = (messages, image) => messages?.some((message) => message.role !== "assistant" && Array.isArray(message.content) && message.content.some((part) => part.type === "image" && isDeepStrictEqual(part, image))) === true;
async function downloadImage(input, parent) {
  if (input.sizeBytes !== void 0 && (!Number.isSafeInteger(input.sizeBytes) || input.sizeBytes < 1 || input.sizeBytes > MAX_BYTES)) throw new PersonalMediaError("image_too_large");
  if (input.declaredMime && !validMime(mime(input.declaredMime))) throw new PersonalMediaError("mime_unsupported");
  for (let attempt = 0; attempt < 3; attempt++) {
    parent?.throwIfAborted();
    const signal = AbortSignal.any([...parent ? [parent] : [], AbortSignal.timeout(15e3)]);
    let onAbort;
    try {
      const canceled2 = new Promise((_, reject) => {
        onAbort = () => reject(signal.reason);
        signal.addEventListener("abort", onAbort, { once: true });
      });
      return await Promise.race([canceled2, (async () => {
        const response = await input.download(signal);
        signal.throwIfAborted();
        if (!response.ok) {
          if (response.status >= 400 && response.status < 500 && response.status !== 429) throw new PersonalMediaError("download_unavailable");
          throw new PersonalError("media_retry", "\u56FE\u7247\u4E0B\u8F7D\u6682\u65F6\u4E0D\u53EF\u7528\u3002");
        }
        const declared = mime(input.declaredMime), returned = mime(response.headers.get("content-type")), expected = declared ?? returned;
        const reader = response.body?.getReader();
        if (!reader) throw new PersonalMediaError("mime_mismatch");
        const cancel = () => {
          void reader.cancel().catch(() => {
          });
        };
        signal.addEventListener("abort", cancel, { once: true });
        try {
          if (!validMime(expected)) throw new PersonalMediaError("mime_unsupported");
          if (returned && returned !== "application/octet-stream" && returned !== expected) throw new PersonalMediaError("mime_mismatch");
          if (Number(response.headers.get("content-length") ?? 0) > MAX_BYTES) throw new PersonalMediaError("image_too_large");
          const chunks = [];
          let count = 0;
          while (true) {
            signal.throwIfAborted();
            const next = await reader.read();
            if (next.done) break;
            count += next.value.byteLength;
            if (count > MAX_BYTES) throw new PersonalMediaError("image_too_large");
            chunks.push(Buffer.from(next.value));
          }
          signal.throwIfAborted();
          const bytes = Buffer.concat(chunks, count);
          if (imageMime(bytes) !== expected) throw new PersonalMediaError("mime_mismatch");
          return { bytes, mimeType: expected };
        } finally {
          signal.removeEventListener("abort", cancel);
          try {
            await reader.cancel();
          } catch {
          }
        }
      })()]);
    } catch (error) {
      if (parent?.aborted || error instanceof PersonalMediaError) throw error;
      if (attempt === 2) throw new PersonalMediaError("download_failed");
      await delay(250 * (attempt + 1), void 0, { signal: parent });
    } finally {
      if (onAbort) signal.removeEventListener("abort", onAbort);
    }
  }
  throw new PersonalMediaError("download_failed");
}
function personalMedia(profile, getHarness, supportsImages = () => true, artifactReader) {
  const staging = /* @__PURE__ */ new Map();
  const harness = () => getHarness();
  async function register(tx, ref) {
    if (ref.artifact.partial || !validMime(ref.artifact.mime) || imageMime(loadPersonalArtifact(profile, ref.artifact)) !== ref.artifact.mime) throw invalid();
    const doc = await tx.doc(PersonalImageDoc, ref.artifact.id, null);
    if (doc.image) {
      if (!isDeepStrictEqual(doc.image.ref, ref)) throw invalid();
      return block(ref);
    }
    const index = await tx.doc(PersonalMediaDoc);
    const entry = await tx.appendEntry(ref.conversationId, { kind: "ruukoto.image-reference", data: ref });
    doc.image = { ref, entry: entry.id };
    index.images.push(ref.artifact.id);
    return block(ref);
  }
  async function verifyMessage(tx, message) {
    const accepted = await tx.entry(message.accepted);
    if (!accepted || accepted.kind !== "ruukoto.media-received" || accepted.conversationId !== ROOT_CONVERSATION_ID || !isDeepStrictEqual(accepted.data, { key: message.key, source: message.source, body: message.body, identities: message.identities })) throw invalid();
  }
  async function verify(tx, ref, sessionId) {
    const saved = (await tx.doc(PersonalImageDoc, ref.artifact.id, null)).image;
    if (!saved || !isDeepStrictEqual(saved.ref, ref)) throw invalid();
    const anchor = await tx.entry(saved.entry);
    if (!anchor || anchor.conversationId !== ref.conversationId || anchor.kind !== "ruukoto.image-reference" || !isDeepStrictEqual(anchor.data, ref)) throw invalid();
    if (sessionId !== void 0 && (await tx.doc(ProviderDoc, ref.conversationId)).sessionId !== sessionId) throw invalid();
    const image = block(ref);
    if (ref.source.kind === "inbound") {
      const message = (await tx.doc(PersonalMediaMessageDoc, ref.source.requestId, null)).message;
      const submission = await tx.submissionByRequest(ref.conversationId, ref.source.requestId);
      const entry = submission?.entry === void 0 ? void 0 : await tx.entry(submission.entry);
      if (!message || message.key !== ref.source.requestId || !["ready", "bound"].includes(message.state) || !message.artifacts.some((artifact) => isDeepStrictEqual(artifact, ref.artifact)) || ref.conversationId !== ROOT_CONVERSATION_ID || !submission || submission.type !== "input" || message.submissionId !== void 0 && message.submissionId !== submission.id || !entry || entry.kind !== "pi.user" || entry.conversationId !== ref.conversationId || !contains(entry.model, image)) throw invalid();
      await verifyMessage(tx, message);
      if (message.source.platform === "telegram") {
        const receipt3 = (await tx.doc(PersonalTelegramReceiptDoc, message.key, null)).receipt;
        const task = receipt3 && await tx.task(receipt3.taskId);
        if (!receipt3 || receipt3.requestId !== message.key || receipt3.media?.key !== message.key || !isDeepStrictEqual(receipt3.media.identities, message.identities) || receipt3.mediaRejected || receipt3.control || receipt3.generation !== message.source.generation || receipt3.botId !== message.source.accountId || receipt3.ownerId !== message.source.ownerId || receipt3.content !== message.body || receipt3.accepted !== message.accepted || !task || task.kind !== "ruukoto.telegram-input" || task.conversationId !== ROOT_CONVERSATION_ID || receipt3.submissionId !== void 0 && receipt3.submissionId !== submission.id) throw invalid();
      }
    } else {
      const task = await tx.task(ref.source.taskId), input = task?.input;
      if (!task || task.kind !== "pi.tool" || task.conversationId !== ref.conversationId || !input || typeof input !== "object" || Array.isArray(input) || input.kind !== "model" || task.state.status !== "terminal") throw invalid();
      const result = task.state.outcome.result;
      const entry = result && typeof result === "object" && !Array.isArray(result) && typeof result.entryId === "number" ? await tx.entry(result.entryId) : void 0;
      if (!entry || entry.kind !== "pi.tool-result" || entry.conversationId !== ref.conversationId || !contains(entry.model, image) || !entry.model?.some((message) => message.role === "toolResult" && message.toolCallId === input.callId)) throw invalid();
    }
    if (ref.artifact.partial || !validMime(ref.artifact.mime)) throw invalid();
    const bytes = loadPersonalArtifact(profile, ref.artifact);
    if (imageMime(bytes) !== ref.artifact.mime) throw invalid();
    return bytes;
  }
  async function reject(key, reason) {
    return harness().commit(async (tx) => {
      const message = (await tx.doc(PersonalMediaMessageDoc, key, null)).message;
      if (!message || message.state === "bound") throw invalid();
      message.state = reason === "orphan_expired" ? "expired" : "rejected";
      message.reason = reason;
      return copyJson(message);
    }, context);
  }
  async function stage(input, signal) {
    const active2 = staging.get(input.key);
    if (active2) {
      if (!isDeepStrictEqual(active2.source, input.source) || active2.body !== input.body || !isDeepStrictEqual(active2.identities, input.media.map((value) => value.identity))) throw new PersonalError("media_input_conflict", "\u5728\u9014\u56FE\u7247\u6D88\u606F\u7684\u6765\u6E90\u6216\u5185\u5BB9\u4E0D\u7B26\uFF0C\u672A\u5408\u5E76\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
      return active2.pending;
    }
    const work = async () => {
      let message = await harness().commit(async (tx) => {
        const doc = await tx.doc(PersonalMediaMessageDoc, input.key, null);
        if (doc.message) {
          if (!isDeepStrictEqual(doc.message.source, input.source) || doc.message.body !== input.body || !isDeepStrictEqual(doc.message.identities, input.media.map((value) => value.identity))) throw new PersonalError("media_input_conflict", "\u539F\u56FE\u7247\u6D88\u606F\u7684\u6765\u6E90\u6216\u5185\u5BB9\u4E0D\u7B26\uFF0C\u672A\u91CD\u65B0\u63A5\u7EB3\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
          return copyJson(doc.message);
        }
        const accepted = (await tx.appendEntry(ROOT_CONVERSATION_ID, { kind: "ruukoto.media-received", data: { key: input.key, source: input.source, body: input.body, identities: input.media.map((value) => value.identity) } })).id;
        doc.message = { key: input.key, source: input.source, body: input.body, receivedAt: Date.now(), accepted, identities: input.media.map((value) => value.identity), artifacts: [], state: "staging" };
        (await tx.doc(PersonalMediaDoc)).keys.push(input.key);
        return copyJson(doc.message);
      }, context);
      if (message.state !== "staging") return message;
      if (!input.media.length || input.media.length > MAX_IMAGES) return reject(input.key, "too_many_images");
      if (!supportsImages()) return reject(input.key, "image_input_unsupported");
      try {
        for (const [index, download2] of input.media.entries()) {
          if (message.artifacts[index]) {
            loadPersonalArtifact(profile, message.artifacts[index]);
            continue;
          }
          const value = await downloadImage(download2, signal);
          signal?.throwIfAborted();
          const artifact = await savePersonalArtifact(profile, value.bytes, { mime: value.mimeType });
          message = await harness().commit(async (tx) => {
            const doc = (await tx.doc(PersonalMediaMessageDoc, input.key, null)).message;
            if (doc.state !== "staging" || doc.artifacts.length !== index) throw invalid();
            doc.artifacts.push(artifact);
            await register(tx, { version: 1, artifact, conversationId: ROOT_CONVERSATION_ID, source: { kind: "inbound", requestId: input.key } });
            return copyJson(doc);
          }, context);
        }
        return harness().commit(async (tx) => {
          const message2 = (await tx.doc(PersonalMediaMessageDoc, input.key, null)).message;
          message2.state = "ready";
          return copyJson(message2);
        }, context);
      } catch (error) {
        if (signal?.aborted || !(error instanceof PersonalMediaError)) throw error;
        return reject(input.key, error.reason);
      }
    };
    const pending = work().finally(() => {
      staging.delete(input.key);
    });
    staging.set(input.key, { source: copyJson(input.source), body: input.body, identities: input.media.map((value) => value.identity), pending });
    return pending;
  }
  const modelMedia = { async prepare(input, sessionId) {
    const replacements = /* @__PURE__ */ new Map(), placeholders = /* @__PURE__ */ new Map(), expected = /* @__PURE__ */ new Map(), expectedMime = /* @__PURE__ */ new Map(), mappings = /* @__PURE__ */ new Map();
    const messages = [];
    for (const message of input.messages) {
      if (message.role === "assistant" || message.role === "system" || typeof message.content === "string") {
        messages.push(message);
        continue;
      }
      const content = [];
      for (const part of message.content) {
        if (part.type !== "image") {
          content.push(part);
          continue;
        }
        const ref = reference(part), bytes = await harness().commit((tx) => verify(tx, ref, sessionId), context), data = bytes.toString("base64");
        expectedMime.set(data, part.mimeType);
        placeholders.set(part.data, data);
        expected.set(data, (expected.get(data) ?? 0) + 1);
        const mapping = mappings.get(data);
        if (mapping) mapping.references.push(ref);
        else {
          mappings.set(data, { sha256: ref.artifact.sha256, references: [ref], payloadReference: ref });
          replacements.set(data, part.data);
          replacements.set(`data:${part.mimeType};base64,${data}`, `ruukoto-image:${part.data}`);
        }
        content.push({ ...part, data });
      }
      messages.push({ ...message, content });
    }
    const snapshot = (value, actualPayload = false) => {
      const result = JSON.parse(JSON.stringify(value)), seen = /* @__PURE__ */ new Map();
      const object2 = (part) => !!part && typeof part === "object" && !Array.isArray(part);
      const imageData = (value2, mimeType, placeholder) => {
        if (typeof value2 !== "string") throw invalid();
        const data = placeholder ? placeholders.get(value2) : expected.has(value2) ? value2 : void 0;
        if (!data || mimeType !== expectedMime.get(data)) throw invalid();
        seen.set(data, (seen.get(data) ?? 0) + 1);
        return replacements.get(value2) ?? value2;
      };
      const imageUrl = (value2) => {
        if (typeof value2 !== "string") throw invalid();
        const replacement = replacements.get(value2), data = value2.slice(value2.indexOf(",") + 1);
        if (!replacement || !value2.startsWith("data:image/") || !expected.has(data)) throw invalid();
        seen.set(data, (seen.get(data) ?? 0) + 1);
        return replacement;
      };
      const content = (parts, payload) => {
        if (!Array.isArray(parts)) return;
        for (const part of parts) {
          if (!object2(part)) continue;
          if (part.type === "image") {
            if (!payload) part.data = imageData(part.data, part.mimeType, true);
            else {
              if (!object2(part.source) || part.source.type !== "base64") throw invalid();
              part.source.data = imageData(part.source.data, part.source.media_type, false);
            }
          } else if (payload && part.type === "image_url") {
            if (!object2(part.image_url)) throw invalid();
            part.image_url.url = imageUrl(part.image_url.url);
          } else if (payload && part.type === "input_image") part.image_url = imageUrl(part.image_url);
          else if (payload && part.type === "tool_result") content(part.content, true);
        }
      };
      if (object2(result)) {
        const messages2 = actualPayload && Array.isArray(result.input) ? result.input : result.messages;
        if (Array.isArray(messages2)) for (const message of messages2) {
          if (!object2(message)) continue;
          if (actualPayload || message.role === "user" || message.role === "toolResult") content(message.content, actualPayload);
        }
      }
      if (!isDeepStrictEqual(seen, expected)) throw invalid();
      return result;
    };
    return { input: { ...input, messages }, snapshot, ...mappings.size ? { imageMappings: JSON.parse(JSON.stringify([...mappings.values()])) } : {} };
  } };
  return {
    extension: defineExtension({ name: PERSONAL_MEDIA, ...artifactReader ? { tools: [artifactReader] } : {} }),
    modelMedia,
    stage,
    supportsImages,
    reject,
    async message(key) {
      return (await harness().snapshot(PersonalMediaMessageDoc, key, context))?.message;
    },
    async input(key) {
      const message = (await harness().snapshot(PersonalMediaMessageDoc, key, context))?.message;
      if (!message || !["ready", "bound"].includes(message.state) || message.artifacts.length !== message.identities.length) throw invalid();
      return [{ type: "text", text: message.body || "\u8BF7\u67E5\u770B\u8FD9\u6761\u6D88\u606F\u4E2D\u7684\u56FE\u7247\u3002" }, ...message.artifacts.flatMap((artifact) => [{ type: "text", text: `[\u56FE\u7247\u4EA7\u7269\uFF1A${artifact.id}\uFF1B${artifact.mime}\uFF1B${artifact.bytes}\u5B57\u8282\u3002\u5BBF\u4E3B\u6062\u590D\u539F\u56FE\u4E3A\u89C6\u89C9\u8F93\u5165\uFF1B\u538B\u7F29\u6458\u8981\u4E0D\u5305\u542B\u56FE\u7247\u7684\u89C6\u89C9\u7EC6\u8282\u3002]` }, block({ version: 1, artifact, conversationId: ROOT_CONVERSATION_ID, source: { kind: "inbound", requestId: key } })])];
    },
    async bind(tx, key, submissionId) {
      const message = (await tx.doc(PersonalMediaMessageDoc, key, null)).message, submission = await tx.submissionByRequest(ROOT_CONVERSATION_ID, key);
      if (!message || !["ready", "bound"].includes(message.state) || submission?.id !== submissionId || submission.type !== "input" || message.submissionId !== void 0 && message.submissionId !== submissionId) throw invalid();
      message.state = "bound";
      message.submissionId = submissionId;
    },
    mediaArtifacts,
    async registerImage(tx, artifact, source3) {
      const task = await tx.task(source3.taskId);
      if (!task || task.kind !== "pi.tool" || task.conversationId !== source3.conversationId) throw invalid();
      return register(tx, { version: 1, artifact, conversationId: source3.conversationId, source: { kind: "tool", taskId: source3.taskId } });
    },
    async recover() {
      const index = await harness().snapshot(PersonalMediaDoc, context);
      if (!index) return;
      for (const key of index.keys) {
        const message = (await harness().snapshot(PersonalMediaMessageDoc, key, context))?.message;
        if (!message || message.key !== key || !Number.isSafeInteger(message.receivedAt) || message.receivedAt < 0) throw invalid();
        await harness().commit((tx) => verifyMessage(tx, message), context);
        if (message.state === "bound") {
          await harness().commit(async (tx) => {
            for (const artifact of message.artifacts) await verify(tx, { version: 1, artifact, conversationId: ROOT_CONVERSATION_ID, source: { kind: "inbound", requestId: key } });
          }, context);
          continue;
        }
        const submission = await harness().commit((tx) => tx.submissionByRequest(ROOT_CONVERSATION_ID, key), context);
        if (submission) {
          await harness().commit((tx) => this.bind(tx, key, submission.id), context);
          continue;
        }
        if (message.state === "staging") {
          if (message.artifacts.length > 0 && message.artifacts.length === message.identities.length && message.artifacts.length <= MAX_IMAGES) {
            for (const artifact of message.artifacts) {
              if (artifact.partial || !validMime(artifact.mime) || imageMime(loadPersonalArtifact(profile, artifact)) !== artifact.mime) throw invalid();
            }
            await harness().commit(async (tx) => {
              for (const artifact of message.artifacts) {
                const saved = (await tx.doc(PersonalImageDoc, artifact.id, null)).image;
                if (!saved || !isDeepStrictEqual(saved.ref, { version: 1, artifact, conversationId: ROOT_CONVERSATION_ID, source: { kind: "inbound", requestId: key } })) throw invalid();
              }
              (await tx.doc(PersonalMediaMessageDoc, key, null)).message.state = "ready";
            }, context);
          } else await reject(key, "download_interrupted");
        }
        if (Date.now() - message.receivedAt >= TTL_MS) {
          if (message.state !== "expired") await reject(key, "orphan_expired");
          for (const artifact of message.artifacts) {
            const filename = path2.join(profile, "artifacts", `${artifact.id}.bin`);
            if (!fs2.existsSync(filename)) continue;
            loadPersonalArtifact(profile, artifact);
            fs2.unlinkSync(filename);
          }
        }
      }
    }
  };
}
function personalMediaRejection(reason) {
  return reason === "image_input_unsupported" ? "\u5F53\u524D\u6A21\u578B\u4E0D\u652F\u6301\u56FE\u7247\uFF0C\u672C\u6761\u6D88\u606F\u672A\u4EA4\u7ED9\u6A21\u578B\u3002\u8BF7\u901A\u8FC7\u672C\u673A\u5411\u5BFC\u914D\u7F6E\u652F\u6301\u56FE\u7247\u7684\u6A21\u578B\u540E\u91CD\u65B0\u53D1\u9001\u3002" : ["download_unavailable", "download_failed", "download_interrupted"].includes(reason) ? "\u56FE\u7247\u4E0B\u8F7D\u672A\u5B8C\u6210\uFF0C\u672C\u6761\u6D88\u606F\u672A\u4EA4\u7ED9\u6A21\u578B\u3002\u8BF7\u68C0\u67E5\u5165\u53E3\u540E\u91CD\u65B0\u53D1\u9001\u56FE\u7247\u3002" : "\u56FE\u7247\u683C\u5F0F\u3001\u5927\u5C0F\u6216\u4FDD\u7559\u72B6\u6001\u4E0D\u7B26\u5408\u8981\u6C42\uFF0C\u672C\u6761\u6D88\u606F\u672A\u4EA4\u7ED9\u6A21\u578B\u3002\u4EC5\u652F\u6301JPEG\u3001PNG\u3001WebP\uFF0C\u6BCF\u6761\u6700\u591A4\u5F20\u3001\u5355\u56FE\u6700\u591A8MiB\uFF1B\u8BF7\u8C03\u6574\u540E\u91CD\u65B0\u53D1\u9001\u3002";
}
async function mediaArtifacts(tx, conversationId = ROOT_CONVERSATION_ID) {
  const result = [];
  for (const id2 of (await tx.doc(PersonalMediaDoc)).images) {
    const saved = (await tx.doc(PersonalImageDoc, id2, null)).image;
    if (!saved) throw invalid();
    const ref = saved.ref;
    if (conversationId !== ROOT_CONVERSATION_ID && ref.conversationId !== conversationId) continue;
    const anchor = await tx.entry(saved.entry);
    if (!anchor || anchor.conversationId !== ref.conversationId || anchor.kind !== "ruukoto.image-reference" || !isDeepStrictEqual(anchor.data, ref)) throw invalid();
    if (ref.source.kind === "inbound") {
      const message = (await tx.doc(PersonalMediaMessageDoc, ref.source.requestId, null)).message;
      if (!message || !message.artifacts.some((artifact) => isDeepStrictEqual(artifact, ref.artifact))) throw invalid();
      if (message.state !== "bound") continue;
      if ((await tx.submissionByRequest(ref.conversationId, ref.source.requestId))?.id !== message.submissionId) throw invalid();
    } else {
      const task = await tx.task(ref.source.taskId);
      if (!task || task.kind !== "pi.tool" || task.conversationId !== ref.conversationId) throw invalid();
    }
    result.push({ artifact: copyJson(ref.artifact), conversationId: ref.conversationId, source: copyJson(ref.source) });
  }
  return result;
}

// apps/ruukoto/src/personal-model.ts
import { createModels, createProvider, lazyStream, normalizeContext } from "@earendil-works/pi-ai";
import { openAICompletionsApi } from "@earendil-works/pi-ai/api/openai-completions.lazy";
import { openAIResponsesApi } from "@earendil-works/pi-ai/api/openai-responses.lazy";
import { anthropicMessagesApi } from "@earendil-works/pi-ai/api/anthropic-messages.lazy";
import { randomUUID as randomUUID2 } from "node:crypto";
function personalProvider(config) {
  const model = {
    id: config.modelId,
    name: config.modelId,
    api: config.api,
    provider: "personal",
    baseUrl: config.baseUrl,
    reasoning: false,
    input: config.imageInput ? ["text", "image"] : ["text"],
    contextWindow: config.contextWindow,
    maxTokens: config.maxTokens,
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }
  };
  return createProvider({
    id: "personal",
    name: "\u4E2A\u4EBA\u6A21\u578B",
    models: [model],
    auth: { apiKey: { name: "\u4E2A\u4EBA\u6A21\u578B\u51ED\u636E", resolve: async () => {
      const apiKey = process.env[config.apiKeyEnv];
      if (!apiKey) throw new PersonalError("model_credentials_missing", "\u6A21\u578B\u51ED\u636E\u672A\u914D\u7F6E\uFF0C\u8BF7\u8BBE\u7F6E\u5411\u5BFC\u4E2D\u6307\u5B9A\u7684\u73AF\u5883\u53D8\u91CF\u540E\u91CD\u542F\u3002");
      return { auth: { apiKey } };
    } } },
    api: { "openai-completions": openAICompletionsApi(), "openai-responses": openAIResponsesApi(), "anthropic-messages": anthropicMessagesApi() }
  });
}
function json(value) {
  return JSON.parse(JSON.stringify(value));
}
function recordedModels(provider, record, media, prepareInput) {
  const models = createModels();
  const prepare = async (model, original, options) => {
    if (!options?.sessionId) throw new PersonalError("model_source_missing", "\u6A21\u578B\u8BF7\u6C42\u7F3A\u5C11\u6301\u4E45\u4F1A\u8BDD\u6765\u6E90\uFF0C\u5DF2\u505C\u6B62\u8BF7\u6C42\u3002");
    const input = prepareInput ? await prepareInput(normalizeContext(original), options) : original;
    const images = input.messages.some((message) => message.role !== "assistant" && Array.isArray(message.content) && message.content.some((part) => part.type === "image"));
    if (images && !model.input.includes("image")) throw new PersonalError("image_input_unsupported", "\u5F53\u524D\u6A21\u578B\u4E0D\u652F\u6301\u56FE\u7247\uFF0C\u672A\u53D1\u9001\u7F3A\u56FE\u8BF7\u6C42\uFF1B\u8BF7\u7531\u62E5\u6709\u8005\u9009\u62E9\u652F\u6301\u56FE\u7247\u7684\u6A21\u578B\u3002");
    if (images && !media) throw new PersonalError("image_reference_invalid", "\u539F\u56FE\u7247\u7684\u6301\u4E45\u6765\u6E90\u65E0\u6CD5\u6838\u5B9E\uFF0C\u5DF2\u505C\u6B62\u6A21\u578B\u8BF7\u6C42\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
    const prepared = media ? await media.prepare(input, options.sessionId) : { input, snapshot: json, imageMappings: void 0 };
    const evidence = { requestId: randomUUID2(), sessionId: options.sessionId, provider: model.provider, modelId: model.id, input: prepared.snapshot(input), ...prepared.imageMappings ? { imageMappings: prepared.imageMappings } : {}, reasoning: "reasoning" in options && typeof options.reasoning === "string" ? options.reasoning : "off" };
    await record(evidence);
    options.signal?.throwIfAborted();
    return { input: prepared.input, options: {
      onPayload: async (payload) => {
        const changed = await options.onPayload?.(payload, model);
        await record({ ...evidence, payload: prepared.snapshot(changed ?? payload, true) });
        options.signal?.throwIfAborted();
        return changed;
      }
    } };
  };
  models.setProvider({
    ...provider,
    stream: (model, input, options) => lazyStream(model, async () => {
      const prepared = await prepare(model, input, options);
      return provider.stream(model, normalizeContext(prepared.input), Object.assign({}, options, prepared.options));
    }),
    streamSimple: (model, input, options) => lazyStream(model, async () => {
      const prepared = await prepare(model, input, options);
      return provider.streamSimple(model, normalizeContext(prepared.input), { ...options, ...prepared.options });
    })
  });
  return models;
}

// apps/ruukoto/src/personal-telegram.ts
import { isDeepStrictEqual as isDeepStrictEqual7 } from "node:util";
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT13 } from "@earendil-works/chord/context";
import { AssistantEntry as AssistantEntry3, defineExtension as defineExtension15, defineTask as defineTask7, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID14 } from "@earendil-works/pi-durable";

// apps/ruukoto/src/personal-telegram-api.ts
function object(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}
function id(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value > 0;
}
async function readReply(response) {
  const reader = response.body?.getReader();
  if (!reader) throw new PersonalTelegramApiError("effect_unknown");
  const chunks = [];
  let bytes = 0;
  try {
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      bytes += next.value.length;
      if (bytes > 1024 * 1024) throw new PersonalTelegramApiError("effect_unknown");
      chunks.push(next.value);
    }
  } finally {
    await reader.cancel();
  }
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}
function telegramMessage(update, allowImages = true) {
  const m = update.message;
  if (!object(m) || !id(m.message_id) || !object(m.chat) || m.chat.type !== "private" || !id(m.chat.id) || !object(m.from) || !id(m.from.id) || m.from.is_bot !== false || m.chat.id !== m.from.id) return;
  const hasImages = allowImages && Array.isArray(m.photo) && m.photo.length > 0;
  const text = hasImages ? typeof m.caption === "string" ? m.caption : "" : m.text;
  if (typeof text !== "string" || !hasImages && !text.trim() || Buffer.byteLength(text) > 16384) return;
  let media;
  if (hasImages) {
    const photos = m.photo.filter(object);
    const photo2 = photos.reduce((largest, candidate) => !largest || Number(candidate.width) * Number(candidate.height) > Number(largest.width) * Number(largest.height) ? candidate : largest, void 0);
    media = [{ identity: typeof photo2?.file_unique_id === "string" ? photo2.file_unique_id : typeof photo2?.file_id === "string" ? photo2.file_id : "invalid-photo", fileId: typeof photo2?.file_id === "string" ? photo2.file_id : "", ...typeof photo2?.file_size === "number" ? { sizeBytes: photo2.file_size } : {} }];
  }
  const reply = object(m.reply_to_message) ? m.reply_to_message : void 0;
  return { id: m.message_id, ownerId: String(m.from.id), text, ...media ? { media } : {}, name: typeof m.from.first_name === "string" ? m.from.first_name.slice(0, 128) : "Telegram \u7528\u6237", direct: !["forward_origin", "forward_from", "forward_from_chat", "forward_sender_name", "via_bot", "sender_chat", "external_reply", "quote"].some((key) => key in m), ...reply && id(reply.message_id) ? { replyTo: reply.message_id } : {}, ...reply && object(reply.from) && reply.from.is_bot === true && id(reply.from.id) ? { replyBotId: String(reply.from.id) } : {} };
}
function telegramOffset(ack, now = performance.now()) {
  return ack && now >= ack.receivedAt && now - ack.receivedAt < 6e4 ? ack.offset : void 0;
}
var PersonalTelegramApiError = class extends PersonalError {
  constructor(effect, retryAfterMs) {
    super(retryAfterMs ? "telegram_rate_limited" : effect === "not_sent" ? "telegram_refused" : "telegram_unverified", retryAfterMs ? "Telegram \u660E\u786E\u9650\u6D41\uFF0C\u539F\u53D1\u9001\u5C06\u5EF6\u540E\u5904\u7406\u3002" : effect === "not_sent" ? "Telegram \u660E\u786E\u62D2\u7EDD\u8BF7\u6C42\uFF0C\u8BF7\u68C0\u67E5\u5165\u53E3\u914D\u7F6E\u4E0E\u6743\u9650\u3002" : "Telegram \u8BF7\u6C42\u7ED3\u679C\u672A\u80FD\u6838\u5B9E\uFF0C\u8BF7\u67E5\u770B\u6536\u53D1\u72B6\u6001\uFF1B\u672A\u77E5\u53D1\u9001\u4E0D\u4F1A\u81EA\u52A8\u91CD\u53D1\u3002");
    this.effect = effect;
    this.retryAfterMs = retryAfterMs;
  }
  effect;
  retryAfterMs;
};
function personalTelegramApi(apiBase, token) {
  async function call(method, body, signal, timeoutMs = 35e3) {
    let response;
    try {
      response = await fetch(`${apiBase}/bot${token}/${method}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body), signal: AbortSignal.any([signal, AbortSignal.timeout(timeoutMs)]), redirect: "error" });
    } catch {
      throw new PersonalTelegramApiError("effect_unknown");
    }
    let value;
    try {
      value = await readReply(response);
    } catch {
      throw new PersonalTelegramApiError("effect_unknown");
    }
    if (response.ok && object(value) && value.ok === true && "result" in value) return value.result;
    if (object(value) && value.ok === false && value.error_code === response.status && response.status >= 400 && response.status < 500) {
      if (response.status === 429) {
        const seconds = object(value.parameters) && value.parameters.retry_after;
        if (typeof seconds === "number" && Number.isSafeInteger(seconds) && seconds > 0 && seconds <= 86400) throw new PersonalTelegramApiError("not_sent", seconds * 1e3);
        throw new PersonalTelegramApiError("effect_unknown");
      }
      throw new PersonalTelegramApiError("not_sent");
    }
    throw new PersonalTelegramApiError("effect_unknown");
  }
  return {
    async me(signal) {
      const result = await call("getMe", {}, signal, 1e4);
      if (!object(result) || !id(result.id) || result.is_bot !== true || typeof result.username !== "string") throw new PersonalTelegramApiError("effect_unknown");
      return { id: String(result.id), username: result.username };
    },
    async updates(signal, offset, timeout = 25) {
      const result = await call("getUpdates", { ...offset === void 0 ? {} : { offset }, timeout, limit: 16, allowed_updates: ["message"] }, signal, (timeout + 10) * 1e3);
      if (!Array.isArray(result) || result.length > 16 || result.some((item, i) => !object(item) || typeof item.update_id !== "number" || !Number.isSafeInteger(item.update_id) || item.update_id < 0 || i > 0 && item.update_id <= result[i - 1].update_id)) throw new PersonalTelegramApiError("effect_unknown");
      return result;
    },
    photo(input) {
      return { identity: input.identity, ...input.sizeBytes === void 0 ? {} : { sizeBytes: input.sizeBytes }, async download(signal) {
        if (!input.fileId || input.fileId.length > 4096) throw new PersonalMediaError("download_unavailable");
        let result;
        try {
          result = await call("getFile", { file_id: input.fileId }, signal, 15e3);
        } catch (error) {
          if (error instanceof PersonalTelegramApiError && error.effect === "not_sent" && !error.retryAfterMs) throw new PersonalMediaError("download_unavailable");
          throw new PersonalError("media_retry", "\u56FE\u7247\u4E0B\u8F7D\u6682\u65F6\u4E0D\u53EF\u7528\u3002");
        }
        const filename = object(result) ? result.file_path : void 0;
        if (typeof filename !== "string" || !/^[A-Za-z0-9_./-]+$/.test(filename) || filename.startsWith("/") || filename.split("/").some((part) => !part || part === "." || part === "..")) throw new PersonalMediaError("download_unavailable");
        let response;
        try {
          response = await fetch(`${apiBase}/file/bot${token}/${filename}`, { signal, redirect: "error" });
        } catch {
          throw new PersonalError("media_retry", "\u56FE\u7247\u4E0B\u8F7D\u6682\u65F6\u4E0D\u53EF\u7528\u3002");
        }
        const headers = new Headers(response.headers), returned = headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase();
        if (!returned || returned === "application/octet-stream") headers.set("content-type", { jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp" }[filename.split(".").at(-1).toLowerCase()] ?? "application/octet-stream");
        return new Response(response.body, { status: response.status, headers });
      } };
    },
    async send(ownerId, messageId, text, signal) {
      const result = await call("sendMessage", { chat_id: ownerId, text, reply_parameters: { message_id: messageId, allow_sending_without_reply: true } }, signal, 1e4);
      if (!object(result) || !id(result.message_id) || !object(result.chat) || String(result.chat.id) !== ownerId || result.chat.type !== "private") throw new PersonalTelegramApiError("effect_unknown");
      return String(result.message_id);
    }
  };
}

// apps/ruukoto/src/personal-permissions.ts
import { defineDoc as defineDoc3, defineExtension as defineExtension2 } from "@earendil-works/pi-durable";
var PersonalPermissionsDoc = defineDoc3({ kind: "ruukoto.permissions", scope: "session", version: 1, initial: () => ({ mode: "auto-review", version: 1 }) });
var personalPermissions = defineExtension2({ name: "personal-telegram-permissions" });
var MODES = { "\u81EA\u52A8\u5BA1\u67E5": "auto-review", "\u8BF7\u6C42\u786E\u8BA4": "confirm", "\u5B8C\u5168\u8BBF\u95EE": "full_access" };
var TELEGRAM_SERVICE_ACTIONS = ["/\u5BA1\u6279", "/\u6388\u6743", "/\u670D\u52A1\u72B6\u6001", "\u6279\u51C6\u672C\u6B21", "\u6279\u51C6\u5E76\u957F\u671F\u6388\u6743", "\u62D2\u7EDD", "\u64A4\u9500\u6388\u6743", "\u4E0B\u4E00\u9879"];
function permissionSnapshot(value) {
  return value.direct && !value.control && value.permission ? { generation: value.generation, botId: value.botId, ownerId: value.ownerId, ...value.permission } : void 0;
}
async function telegramSourceActive(tx, source3) {
  const current = (await tx.doc(PersonalTelegramDoc)).config;
  return current?.enabled === true && current.generation === source3.generation && current.botId === source3.botId && current.ownerId === source3.ownerId;
}
async function telegramSelection(tx, value) {
  if (!value.direct || value.replyBotId !== value.botId || value.replyTo === void 0) return;
  let selected;
  let cursor;
  do {
    const page = await tx.scanTasks({ kind: "ruukoto.telegram-input" }, 256, cursor);
    for (const task of page.items) {
      const key = task.input && typeof task.input === "object" && !Array.isArray(task.input) && task.input.requestId;
      if (typeof key !== "string") throw new PersonalError("telegram_receipt_invalid", "\u5BBF\u4E3B\u6D88\u606F\u7684\u539F\u6536\u4EF6\u65E0\u6CD5\u6838\u5B9E\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
      const other = (await tx.doc(PersonalTelegramReceiptDoc, key, null)).receipt;
      if (!other || other.taskId !== task.id) throw new PersonalError("telegram_receipt_invalid", "\u5BBF\u4E3B\u6D88\u606F\u7684\u539F\u6536\u4EF6\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
      if (other.platformMessageId !== String(value.replyTo) || other.generation !== value.generation || other.botId !== value.botId || other.ownerId !== value.ownerId || other.delivery !== "sent" || !other.control || !other.selection) continue;
      if (selected) throw new PersonalError("telegram_menu_ambiguous", "\u539F\u5BBF\u4E3B\u6D88\u606F\u4E0D\u552F\u4E00\uFF0C\u5DF2\u505C\u6B62\u51B3\u5B9A\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
      selected = other;
    }
    cursor = page.next;
  } while (cursor);
  return selected;
}
async function telegramPermissionControl(tx, value) {
  const mode = Object.hasOwn(MODES, value.content) ? MODES[value.content] : void 0;
  if (value.content !== "/\u6743\u9650" && !mode) {
    if (TELEGRAM_SERVICE_ACTIONS.includes(value.content)) {
      if (!value.direct) {
        value.reply = "\u8BF7\u7531\u7ED1\u5B9A\u62E5\u6709\u8005\u76F4\u63A5\u53D1\u9001\u63A7\u5236\u547D\u4EE4\uFF1B\u8F6C\u53D1\u548C\u5F15\u7528\u6458\u5F55\u4E0D\u80FD\u63D0\u4F9B\u51B3\u5B9A\u3002";
        return true;
      }
      return false;
    }
    return false;
  }
  if (!value.direct) {
    value.reply = "\u8BF7\u76F4\u63A5\u53D1\u9001 /\u6743\u9650\uFF0C\u518D\u56DE\u590D\u5BBF\u4E3B\u83DC\u5355\u9009\u62E9\uFF1B\u8F6C\u53D1\u548C\u5F15\u7528\u6458\u5F55\u4E0D\u80FD\u6539\u53D8\u6743\u9650\u3002";
    return true;
  }
  const permission = await tx.doc(PersonalPermissionsDoc);
  if (value.content === "/\u6743\u9650") {
    value.selection = { kind: "mode" };
    value.reply = `\u65B0 Telegram \u8F93\u5165\u9ED8\u8BA4\u6A21\u5F0F\uFF1A${Object.entries(MODES).find(([, mode2]) => mode2 === permission.mode)[0]}\u3002\u56DE\u590D\u8FD9\u6761\u6D88\u606F\u9009\u62E9\uFF1A\u81EA\u52A8\u5BA1\u67E5\u3001\u8BF7\u6C42\u786E\u8BA4\u3001\u5B8C\u5168\u8BBF\u95EE\u3002\u5B8C\u5168\u8BBF\u95EE\u4F7F\u7528\u540E\u53F0\u8D26\u6237\u6743\u9650\u5E76\u514D\u9010\u6B21\u5BA1\u6279\uFF1B\u672A\u77E5\u64CD\u4F5C\u4ECD\u6682\u505C\u3002\u53D8\u66F4\u53EA\u5F71\u54CD\u4EE5\u540E\u6536\u5230\u7684\u65B0 Telegram \u8F93\u5165\u3002`;
  } else if ((await telegramSelection(tx, value))?.selection?.kind !== "mode") value.reply = "\u6743\u9650\u672A\u6539\u53D8\u3002\u8BF7\u76F4\u63A5\u53D1\u9001 /\u6743\u9650\uFF0C\u518D\u56DE\u590D\u8BE5\u6761\u5BBF\u4E3B\u83DC\u5355\u9009\u62E9\u6A21\u5F0F\u3002";
  else {
    if (permission.mode !== mode) {
      permission.mode = mode;
      permission.version++;
    }
    value.reply = `\u65B0 Telegram \u8F93\u5165\u9ED8\u8BA4\u6A21\u5F0F\u5DF2\u8BBE\u4E3A${value.content}\uFF1B\u5DF2\u6709\u5DE5\u4F5C\u4FDD\u6301\u539F\u6743\u9650\u3002`;
  }
  return true;
}

// apps/ruukoto/src/personal-work-controls.ts
import { defineExtension as defineExtension14 } from "@earendil-works/pi-durable";

// apps/ruukoto/src/personal-local-records.ts
import { defineDocFamily as defineDocFamily3, defineEntry, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID2 } from "@earendil-works/pi-durable";
var LocalInputDoc = defineDocFamily3({ kind: "ruukoto.local-input", scope: "session", version: 1, family: true, initial: (digest) => ({ digest }) });
var LocalInputAdmission = defineEntry("ruukoto.local-input-admission");

// apps/ruukoto/src/personal-browser.ts
import { copyJson as copyJson5 } from "@earendil-works/chord";
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT9 } from "@earendil-works/chord/context";
import { AgentDoc as AgentDoc2, InboxDoc as InboxDoc2, LiveDoc as LiveDoc7, defineDoc as defineDoc8, defineDocFamily as defineDocFamily9, defineEntry as defineEntry8, defineExtension as defineExtension10, defineTask as defineTask5, defineTool as defineTool4, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID11 } from "@earendil-works/pi-durable";
import { validateToolArguments } from "@earendil-works/pi-ai/utils/validation";
import { Type as Type4 } from "typebox";

// apps/ruukoto/src/personal-browser-config.ts
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT2 } from "@earendil-works/chord/context";
import { openNodeSqliteStorage } from "@earendil-works/pi-durable/storage/sqlite/node";

// apps/ruukoto/src/personal-profile.ts
import * as fs3 from "node:fs";
import * as path3 from "node:path";
import { isDeepStrictEqual as isDeepStrictEqual2 } from "node:util";
import { DatabaseSync } from "node:sqlite";
var PERSONAL_FORMAT = { product: "ruukoto", format: 1, pi: "1.3.0", extensions: { personal: 1 } };
var PERSONAL_PENDING_FILE = /^pending-(?:work-)?([0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})\.json$/;
function lockPersonalProfile(directory) {
  fs3.mkdirSync(directory, { recursive: true, mode: 448 });
  if (!fs3.lstatSync(directory).isDirectory() || fs3.lstatSync(directory).isSymbolicLink()) throw new PersonalError("profile_unrecognized", "\u4E2A\u4EBA\u6863\u6848\u5FC5\u987B\u662F\u666E\u901A\u76EE\u5F55\uFF0C\u8BF7\u53E6\u9009\u7A7A\u76EE\u5F55\u3002");
  const names = fs3.readdirSync(directory);
  const allowed = /* @__PURE__ */ new Set(["profile.json", "owner.sqlite", "owner.sqlite-journal", "personal.sqlite", "personal.sqlite-wal", "personal.sqlite-shm", "model.json", "model.json.tmp", "telegram.json", "telegram.json.tmp", "service.json", "service.json.tmp", "command.json", "command.json.tmp", "mcp.json", "mcp.json.tmp", "tools.json", "tools.json.tmp", "browser.json", "browser.json.tmp", "control.token", "backend.log"]);
  if (names.some((name) => {
    const stat = fs3.lstatSync(path3.join(directory, name), { throwIfNoEntry: false });
    return stat && (name === "control.sock" ? !stat.isSocket() : ["commands", "artifacts", "browser"].includes(name) ? !stat.isDirectory() || stat.isSymbolicLink() || stat.uid !== process.getuid?.() || (stat.mode & 63) !== 0 : !allowed.has(name) && !PERSONAL_PENDING_FILE.test(name) || !stat.isFile());
  }) || !names.includes("profile.json") && names.some((name) => !name.startsWith("owner.sqlite"))) {
    throw new PersonalError("profile_unrecognized", "\u6240\u9009\u76EE\u5F55\u4E0D\u662F\u65B0\u7684\u4E2A\u4EBA\u6863\u6848\u3002\u8BF7\u4FDD\u7559\u539F\u8D44\u6599\uFF0C\u53E6\u9009\u7A7A\u76EE\u5F55\u3002");
  }
  fs3.chmodSync(directory, 448);
  const ownerFile = path3.join(directory, "owner.sqlite");
  fs3.closeSync(fs3.openSync(ownerFile, "a", 384));
  const owner = new DatabaseSync(ownerFile);
  try {
    owner.exec("PRAGMA busy_timeout=0; BEGIN EXCLUSIVE");
  } catch (error) {
    owner.close();
    if (error instanceof Error && "errcode" in error && error.errcode === 5) {
      throw new PersonalError("profile_busy", "\u4E2A\u4EBA\u5B9E\u4F8B\u6216\u914D\u7F6E\u5411\u5BFC\u6B63\u5728\u4F7F\u7528\u6B64\u6863\u6848\uFF0C\u8BF7\u8FDE\u63A5\u8FD0\u884C\u4E2D\u5B9E\u4F8B\u6216\u7B49\u5F85\u5B83\u505C\u6B62\u3002", { cause: error });
    }
    throw new PersonalError("profile_lock_failed", "\u65E0\u6CD5\u9501\u5B9A\u4E2A\u4EBA\u6863\u6848\uFF0C\u8BF7\u68C0\u67E5\u76EE\u5F55\u4E0E\u78C1\u76D8\u72B6\u6001\u3002", { cause: error });
  }
  let released = false;
  const release2 = () => {
    if (released) return;
    released = true;
    owner.close();
  };
  try {
    for (const name of fs3.readdirSync(directory)) if (name !== "control.sock" && !PERSONAL_PENDING_FILE.test(name)) fs3.chmodSync(path3.join(directory, name), ["commands", "artifacts", "browser"].includes(name) ? 448 : 384);
    const manifest = path3.join(directory, "profile.json");
    if (fs3.existsSync(manifest)) {
      const saved = JSON.parse(fs3.readFileSync(manifest, "utf8"));
      if (!isDeepStrictEqual2(saved, PERSONAL_FORMAT)) {
        throw new PersonalError("profile_version", "\u4E2A\u4EBA\u6863\u6848\u7248\u672C\u4E0D\u53D7\u5F53\u524D\u7A0B\u5E8F\u652F\u6301\uFF0C\u8BF7\u4F7F\u7528\u5BF9\u5E94\u7248\u672C\u5E76\u5728\u505C\u6B62\u5B9E\u4F8B\u540E\u5B89\u6392\u5347\u7EA7\u3002");
      }
    } else {
      fs3.writeFileSync(manifest, JSON.stringify(PERSONAL_FORMAT) + "\n", { flag: "wx", mode: 384 });
    }
    return { directory, release: release2 };
  } catch (error) {
    release2();
    if (error instanceof PersonalError) throw error;
    throw new PersonalError("profile_invalid", "\u65E0\u6CD5\u6838\u5B9E\u4E2A\u4EBA\u6863\u6848\uFF0C\u8BF7\u4FDD\u7559\u73B0\u573A\u5E76\u68C0\u67E5\u6863\u6848\u6807\u8BB0\u3002", { cause: error });
  }
}

// apps/ruukoto/src/personal-tool-source.ts
import { LiveDoc as LiveDoc6, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID10 } from "@earendil-works/pi-durable";

// apps/ruukoto/src/personal-work-tools.ts
import { AgentDoc, defineExtension as defineExtension9, defineTool as defineTool3, LiveDoc as LiveDoc5, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID9 } from "@earendil-works/pi-durable";
import { Type as Type3 } from "typebox";

// apps/ruukoto/src/personal-delegation.ts
import { isDeepStrictEqual as isDeepStrictEqual4 } from "node:util";
import { defineDocFamily as defineDocFamily8, defineEntry as defineEntry6, defineExtension as defineExtension7, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID7 } from "@earendil-works/pi-durable";

// apps/ruukoto/src/personal-service-operations.ts
import { copyJson as copyJson4 } from "@earendil-works/chord";
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT8 } from "@earendil-works/chord/context";
import { defineDoc as defineDoc7, defineDocFamily as defineDocFamily7, defineEntry as defineEntry5, defineExtension as defineExtension6, defineTask as defineTask3, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID6 } from "@earendil-works/pi-durable";

// apps/ruukoto/src/personal-service-inspection.ts
import { copyJson as copyJson3 } from "@earendil-works/chord";
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT5 } from "@earendil-works/chord/context";
import { defineDoc as defineDoc5, defineDocFamily as defineDocFamily5, defineEntry as defineEntry3, defineExtension as defineExtension4, LiveDoc as LiveDoc2, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID4 } from "@earendil-works/pi-durable";

// apps/ruukoto/src/personal-command-work.ts
import { isDeepStrictEqual as isDeepStrictEqual3 } from "node:util";
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT4 } from "@earendil-works/chord/context";
import { copyJson as copyJson2 } from "@earendil-works/chord";
import { defineDoc as defineDoc4, defineDocFamily as defineDocFamily4, defineEntry as defineEntry2, defineExtension as defineExtension3, defineTask, defineTool, section, LiveDoc, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID3 } from "@earendil-works/pi-durable";
import { Type } from "typebox";

// packages/agent/src/execution/native.ts
import { fileURLToPath } from "node:url";

// packages/agent/src/execution/approved-ops.ts
var MAX_HTTP_RESPONSE_BYTES = 1024 * 1024;
var MAX_FILE_CONTENT_BYTES = 8 * 1024 * 1024;

// packages/agent/src/execution/native.ts
var NATIVE_WORKER_PATH = fileURLToPath(new URL("../../../../worker/worker.mjs", "file:///tmp/ruukoto-30-independent.QDMBbM/source/packages/agent/src/execution/native.ts"));
var NATIVE_MACOS_HELPER_PATH = fileURLToPath(new URL("../../../../worker/native-macos-supervisor", "file:///tmp/ruukoto-30-independent.QDMBbM/source/packages/agent/src/execution/native.ts"));

// apps/ruukoto/src/personal-command-config.ts
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT3 } from "@earendil-works/chord/context";
import { openNodeSqliteStorage as openNodeSqliteStorage2 } from "@earendil-works/pi-durable/storage/sqlite/node";

// apps/ruukoto/src/personal-command-work.ts
var PersonalCommandsDoc = defineDoc4({ kind: "ruukoto.commands", scope: "session", version: 1, initial: () => ({ fingerprint: "" }) });
var PersonalCommandDoc = defineDocFamily4({ kind: "ruukoto.command", scope: "session", version: 1, family: true, initial: () => ({}) });
var CommandAdmission = defineEntry2("ruukoto.command-admission");
var CommandResolution = defineEntry2("ruukoto.command-resolution");
var CommandStart = defineEntry2("ruukoto.command-start");
var CommandObservation = defineEntry2("ruukoto.command-observation");
async function personalCommand(tx, ref) {
  const value = (await tx.doc(PersonalCommandDoc, ref.requestId, null)).command;
  if (!value || !isDeepStrictEqual3(value.ref, ref)) throw new PersonalError("command_missing", "\u539F\u547D\u4EE4\u8BB0\u5F55\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u67E5\u8BE2\u539F\u5DE5\u4F5C\u3002");
  if (value.started && value.result?.code === "started" && (await tx.task(ref.taskId))?.state.status === "terminal") value.result = { effect: "effect_unknown", code: "interrupted" };
  return value;
}
function personalCommandUnresolved(value) {
  return value.started && (!value.stopped || !value.result || value.result.code === "started" || value.result.effect === "effect_unknown" && !value.resolution);
}
async function personalCommandsIn(tx) {
  const commands = [];
  let cursor;
  do {
    const page = await tx.scanTasks({ kind: "ruukoto.command" }, 256, cursor);
    for (const task of page.items) {
      const key = task.input && typeof task.input === "object" && !Array.isArray(task.input) && task.input.requestId;
      if (typeof key !== "string") throw new PersonalError("command_record_invalid", "\u547D\u4EE4\u4EFB\u52A1\u7F3A\u5C11\u539F\u8BF7\u6C42\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
      commands.push(await personalCommand(tx, { requestId: key, taskId: task.id }));
    }
    cursor = page.next;
  } while (cursor);
  return commands;
}
async function personalCommandSourceBlocker(tx, requestId) {
  const source3 = await tx.submissionByRequest(ROOT_CONVERSATION_ID3, requestId);
  if (!source3) return;
  for (const op of await personalCommandsIn(tx)) if (op.work.sources.includes(source3.id) && personalCommandUnresolved(op)) return { command: op.ref.requestId, admission: op.admission };
}
async function personalWorkCommands(tx, taskId) {
  return (await personalCommandsIn(tx)).filter((op) => op.work.ref.taskId === taskId);
}
async function requirePersonalCommandsStopped(tx, taskId) {
  for (const op of await personalWorkCommands(tx, taskId)) if ((await tx.task(op.ref.taskId))?.state.status !== "terminal" || personalCommandUnresolved(op)) throw new PersonalError("work_stop_unverified", "\u539F\u547D\u4EE4\u6548\u679C\u6216\u505C\u6B62\u4ECD\u5F85\u6838\u5B9E\uFF0C\u5360\u7528\u4FDD\u7559\uFF1B\u8BF7\u5728\u672C\u673A\u547D\u4EE4\u7BA1\u7406\u4E2D\u6838\u5B9E\u539F\u64CD\u4F5C\u3002");
}
async function waitPersonalCommand(reader, ref, context4) {
  const watch = await reader.watchDoc(PersonalCommandDoc, ref.requestId, context4);
  if (!watch) throw new PersonalError("command_missing", "\u539F\u547D\u4EE4\u8BB0\u5F55\u7F3A\u5931\uFF0C\u5360\u7528\u4FDD\u7559\uFF1B\u8BF7\u68C0\u67E5\u6863\u6848\u3002");
  try {
    await new Promise((resolve3, reject) => {
      const check = (value) => {
        if (!value?.command) reject(new PersonalError("command_missing", "\u539F\u547D\u4EE4\u8BB0\u5F55\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002"));
        else if (!personalCommandUnresolved(value.command)) resolve3();
      };
      watch.start(async (value) => {
        check(value);
      });
      check(watch.value);
      void watch.closed.then(() => reject(new PersonalError("command_wait_stopped", "\u547D\u4EE4\u7B49\u5F85\u5DF2\u505C\u6B62\uFF0C\u8BF7\u67E5\u8BE2\u539F\u5DE5\u4F5C\uFF1B\u5360\u7528\u4ECD\u4FDD\u7559\u3002")));
    });
  } finally {
    await watch.stop();
  }
}

// apps/ruukoto/src/personal-service-inspection.ts
var PersonalInspectionDoc = defineDocFamily5({ kind: "ruukoto.service-execution", scope: "session", version: 1, family: true, initial: () => ({}) });
var PersonalPendingInspectionsDoc = defineDoc5({ kind: "ruukoto.service-executions", scope: "session", version: 1, initial: () => ({ tasks: [] }) });
var ServiceInspectionAdmission = defineEntry3("ruukoto.service-inspection-admission");
var ServiceInspectionEntry = defineEntry3("ruukoto.service-inspection");
var ServiceInspectionStopEntry = defineEntry3("ruukoto.service-inspection-stop");
var personalInspectionExtension = defineExtension4({ name: "personal-service-executions" });
var MAX_CAPTURE = 1024 * 1024;
async function pendingServiceInspection(tx, unit, sources = []) {
  for (const taskId of (await tx.doc(PersonalPendingInspectionsDoc)).tasks) {
    const value = (await tx.doc(PersonalInspectionDoc, String(taskId), null)).inspection;
    if (!value || value.stopped) throw new PersonalError("service_inspection_invalid", "\u68C0\u67E5\u5360\u7528\u8BB0\u5F55\u65E0\u6CD5\u6838\u5B9E\uFF0C\u5DF2\u505C\u6B62\u670D\u52A1\u64CD\u4F5C\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
    if (unit !== void 0 && value.unit === unit || value.sources.some((id2) => sources.includes(id2))) return copyJson3(value);
  }
}
async function pendingWorkInspection(tx, taskId) {
  for (const id2 of (await tx.doc(PersonalPendingInspectionsDoc)).tasks) {
    const value = (await tx.doc(PersonalInspectionDoc, String(id2), null)).inspection;
    if (!value || value.stopped) throw new PersonalError("service_inspection_invalid", "\u68C0\u67E5\u5360\u7528\u8BB0\u5F55\u65E0\u6CD5\u6838\u5B9E\uFF0C\u5DF2\u4FDD\u7559\u5DE5\u4F5C\u5360\u7528\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
    if (value.work?.ref.taskId === taskId || value.taskKind === "ruukoto.service-operation" && (await tx.task(value.taskId))?.owner === taskId) return true;
  }
  return false;
}

// apps/ruukoto/src/personal-mcp.ts
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT7 } from "@earendil-works/chord/context";
import { defineDoc as defineDoc6, defineDocFamily as defineDocFamily6, defineEntry as defineEntry4, defineExtension as defineExtension5, defineTask as defineTask2, defineTool as defineTool2, LiveDoc as LiveDoc3, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID5 } from "@earendil-works/pi-durable";
import { Type as Type2 } from "typebox";

// packages/agent/src/mcp/transport.ts
import {
  Client,
  StreamableHTTPClientTransport,
  UnauthorizedError,
  ProtocolError,
  SdkError,
  SdkErrorCode,
  SdkHttpError,
  isCallToolResult
} from "@modelcontextprotocol/client";
var MCP_LIMITS = {
  maxToolsPerService: 64,
  maxListPages: 16,
  maxToolDescriptionChars: 4e3,
  maxToolSchemaBytes: 16 * 1024,
  connectTimeoutMs: 15e3,
  listTimeoutMs: 15e3,
  callTimeoutMs: 6e4,
  /** 结果内联上限：超过则正文入 ArtifactStore，模型只收预览与引用。 */
  resultInlineCapChars: 32 * 1024,
  /** 产物正文硬上限：超过截断并明确标记。 */
  resultHardCapBytes: 1024 * 1024
};

// packages/agent/src/mcp/schema.ts
import { Compile } from "typebox/compile";

// apps/ruukoto/src/personal-mcp-config.ts
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT6 } from "@earendil-works/chord/context";
import { openNodeSqliteStorage as openNodeSqliteStorage3 } from "@earendil-works/pi-durable/storage/sqlite/node";

// apps/ruukoto/src/personal-mcp.ts
var PersonalMcpConfigDoc = defineDoc6({ kind: "ruukoto.mcp-config", scope: "session", version: 1, initial: () => ({ generations: [], operations: [] }) });
var PersonalMcpDoc = defineDocFamily6({ kind: "ruukoto.mcp", scope: "session", version: 1, family: true, initial: () => ({}) });
var McpAdmission = defineEntry4("ruukoto.mcp-admission");
var McpRequest = defineEntry4("ruukoto.mcp-request");
var McpObservation = defineEntry4("ruukoto.mcp-observation");
var McpDecision = defineEntry4("ruukoto.mcp-decision");
var McpResolution = defineEntry4("ruukoto.mcp-resolution");
var McpConfiguration = defineEntry4("ruukoto.mcp-configuration");
async function mcpOperation(tx, operation) {
  const value = (await tx.doc(PersonalMcpDoc, String(operation), null)).operation;
  if (!value || value.operation !== operation) throw new PersonalError("mcp_missing", "\u539F MCP \u8C03\u7528\u7F3A\u5931\uFF0C\u8BF7\u5237\u65B0\u539F\u8C03\u7528\u5217\u8868\u5E76\u4FDD\u7559\u6863\u6848\u3002");
  return value;
}
function mcpUnresolved(value) {
  return value.started && (!value.remoteEnded || value.effect === "effect_unknown" && !value.resolution);
}
async function mcpOperations(tx) {
  const values = [];
  for (const operation of (await tx.doc(PersonalMcpConfigDoc)).operations) values.push(await mcpOperation(tx, operation));
  return values;
}
async function mcpSourceBlocker(tx, requestId) {
  const source3 = await tx.submissionByRequest(ROOT_CONVERSATION_ID5, requestId);
  if (!source3) return;
  for (const value of await mcpOperations(tx)) if (value.origin.sources.includes(source3.id) && mcpUnresolved(value)) return { mcp: String(value.operation), admission: value.admission };
}
async function requireWorkMcpStopped(tx, taskId) {
  if ((await mcpOperations(tx)).some((value) => value.origin.work?.ref.taskId === taskId && mcpUnresolved(value))) throw new PersonalError("work_stop_unverified", "\u539F MCP \u8C03\u7528\u6548\u679C\u6216\u8FDC\u7AEF\u8BF7\u6C42\u7ED3\u675F\u672A\u6838\u5B9E\uFF0C\u5360\u7528\u4FDD\u7559\uFF1B\u8BF7\u67E5\u8BE2\u539F MCP \u8BC1\u636E\u3002");
}
async function waitWorkMcp(reader, pending, context4) {
  for (const operation of pending) await waitMcp(reader, operation, (value) => !mcpUnresolved(value), context4);
}
async function waitMcp(reader, operation, ready, context4) {
  const watch = await reader.watchDoc(PersonalMcpDoc, String(operation), context4);
  if (!watch) throw new PersonalError("mcp_missing", "\u539F MCP \u7B49\u5F85\u8BB0\u5F55\u7F3A\u5931\uFF0C\u5DF2\u4FDD\u7559\u5360\u7528\uFF1B\u8BF7\u68C0\u67E5\u6863\u6848\u3002");
  try {
    await new Promise((resolve3, reject) => {
      const check = (value) => {
        if (!value?.operation) reject(new PersonalError("mcp_missing", "\u539F MCP \u8BB0\u5F55\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002"));
        else if (ready(value.operation)) resolve3();
      };
      watch.start(async (value) => {
        check(value);
      });
      check(watch.value);
      void watch.closed.then(() => reject(new PersonalError("mcp_wait_stopped", "MCP \u7B49\u5F85\u5DF2\u505C\u6B62\uFF0C\u8BF7\u67E5\u8BE2\u539F\u8C03\u7528\uFF1B\u5360\u7528\u4ECD\u4FDD\u7559\u3002")));
    });
  } finally {
    await watch.stop();
  }
}

// apps/ruukoto/src/personal-service-operations.ts
var ServiceWorkAdmission = defineEntry5("ruukoto.service-work-admission");
var PersonalServiceGrantsDoc = defineDoc7({ kind: "ruukoto.service-grants", scope: "session", version: 1, initial: () => ({ grants: [] }) });
var PersonalServiceOperationsDoc = defineDoc7({ kind: "ruukoto.service-operations-config", scope: "session", version: 1, initial: () => ({ enabled: true }) });
var PersonalServiceOperationDoc = defineDocFamily7({ kind: "ruukoto.service-operation", scope: "session", version: 1, family: true, initial: () => ({}) });
var ServiceOperationEvidence = defineEntry5("ruukoto.service-operation-evidence");
async function personalServiceOperation(tx, ref) {
  const value = (await tx.doc(PersonalServiceOperationDoc, ref.requestId, null)).operation;
  if (!value || value.ref.taskId !== ref.taskId) throw new PersonalError("service_operation_missing", "\u627E\u4E0D\u5230\u539F\u670D\u52A1\u64CD\u4F5C\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u67E5\u8BE2\u539F\u5DE5\u4F5C\u3002");
  return value;
}
async function waitForChange(reader, key, ready, context4) {
  const watch = await reader.watchDoc(PersonalServiceOperationDoc, key, context4);
  if (!watch) throw new PersonalError("service_operation_missing", "\u670D\u52A1\u64CD\u4F5C\u8BB0\u5F55\u7F3A\u5931\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
  try {
    await new Promise((resolve3, reject) => {
      const check = (value) => {
        if (!value?.operation) reject(new PersonalError("service_operation_missing", "\u670D\u52A1\u64CD\u4F5C\u8BB0\u5F55\u5DF2\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002"));
        else if (ready(value.operation)) resolve3();
      };
      watch.start(async (value) => {
        check(value);
      });
      check(watch.value);
      void watch.closed.then(() => reject(new PersonalError("service_wait_stopped", "\u670D\u52A1\u64CD\u4F5C\u7B49\u5F85\u5DF2\u505C\u6B62\uFF0C\u8BF7\u67E5\u8BE2\u6301\u4E45\u5DE5\u4F5C\u72B6\u6001\u3002")));
    });
  } finally {
    await watch.stop();
  }
}
function unresolved(op) {
  return op.consumed && (!op.result || op.result.effect === "effect_unknown" && (!op.resolution || !op.launcherStopped));
}
async function interruptedPersonalService(tx, op) {
  if (op.consumed && (!op.result || op.result.code === "started") && (await tx.task(op.ref.taskId))?.state.status === "terminal") {
    op.result = { effect: "effect_unknown", code: "interrupted" };
    await invalidateServiceGrants(tx, op);
  }
}
async function personalWorkServices(tx, taskId) {
  return (await personalServiceOperationsIn(tx)).filter((op) => op.work?.ref.taskId === taskId);
}
async function requirePersonalWorkServicesStopped(tx, taskId) {
  for (const op of await personalWorkServices(tx, taskId)) if ((await tx.task(op.ref.taskId))?.state.status !== "terminal" || unresolved(op)) throw new PersonalError("work_stop_unverified", "\u5B50\u5DE5\u4F5C\u7684\u670D\u52A1\u64CD\u4F5C\u6216\u6548\u679C\u5C1A\u672A\u6838\u5B9E\uFF0C\u5360\u7528\u4FDD\u7559\uFF1B\u8BF7\u4ECE\u539F\u670D\u52A1\u83DC\u5355\u6838\u5B9E\u6548\u679C\u4E0E\u505C\u6B62\u3002");
}
async function waitPersonalServiceEffect(reader, ref, context4) {
  await waitForChange(reader, ref.requestId, (op) => !unresolved(op), context4);
}
async function personalServiceSourceBlocker(tx, sourceRequestId) {
  const browser = await browserSourceBlocker(tx, sourceRequestId);
  if (browser) return browser;
  const tool = await toolSourceBlocker(tx, sourceRequestId);
  if (tool) return tool;
  const mcp = await mcpSourceBlocker(tx, sourceRequestId);
  if (mcp) return mcp;
  const command = await personalCommandSourceBlocker(tx, sourceRequestId);
  if (command) return command;
  const source3 = await tx.submissionByRequest(ROOT_CONVERSATION_ID6, sourceRequestId);
  const inspection = source3 && await pendingServiceInspection(tx, void 0, [source3.id]);
  if (inspection) return { inspection: inspection.taskId, admission: inspection.admission };
  let cursor;
  do {
    const page = await tx.scanTasks({ kind: "ruukoto.service-operation" }, 256, cursor);
    for (const task of page.items) {
      const key = task.input && typeof task.input === "object" && !Array.isArray(task.input) && task.input.requestId;
      if (typeof key !== "string") throw new PersonalError("service_operation_missing", "\u670D\u52A1\u64CD\u4F5C\u7F3A\u5C11\u6765\u6E90\u8BB0\u5F55\uFF0C\u5DF2\u505C\u6B62\u59D4\u6D3E\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
      const value = await personalServiceOperation(tx, { requestId: key, taskId: task.id });
      if (value.source.requestId === sourceRequestId && unresolved(value)) return key;
    }
    cursor = page.next;
  } while (cursor);
}
async function requirePersonalServiceSourceReady(tx, sourceRequestId) {
  if (await personalServiceSourceBlocker(tx, sourceRequestId)) throw new PersonalError("work_source_paused", "\u539F\u5DE5\u4F5C\u6709\u5C1A\u672A\u6838\u5B9E\u7684\u5916\u90E8\u6548\u679C\u6216\u505C\u6B62\u72B6\u6001\uFF0C\u5DF2\u6682\u505C\u59D4\u6D3E\u548C\u5B50\u6A21\u578B\u8BF7\u6C42\uFF1B\u8BF7\u5411\u62E5\u6709\u8005\u62A5\u544A\u5E76\u6838\u5B9E\u539F\u64CD\u4F5C\uFF0C\u4E0D\u8981\u6362\u5DE5\u4F5C\u91CD\u8BD5\u3002");
}
function invalidateGrant(grant, reason) {
  if (grant.active) {
    grant.active = false;
    grant.version++;
    grant.reason = reason;
  }
}
async function invalidateServiceGrants(tx, value) {
  for (const grant of (await tx.doc(PersonalServiceGrantsDoc)).grants) {
    if (grant.snapshot.machineId === value.snapshot?.machineId && grant.unit === value.unit) invalidateGrant(grant, "effect_unknown");
  }
}
async function personalServiceOperationsIn(tx) {
  const values = [];
  let cursor;
  do {
    const page = await tx.scanTasks({ kind: "ruukoto.service-operation" }, 256, cursor);
    for (const task of page.items) {
      const key = task.input && typeof task.input === "object" && !Array.isArray(task.input) && task.input.requestId;
      if (typeof key !== "string") throw new PersonalError("service_operation_invalid", "\u670D\u52A1\u5DE5\u4F5C\u7F3A\u5C11\u64CD\u4F5C\u5F15\u7528\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
      values.push(await personalServiceOperation(tx, { requestId: key, taskId: task.id }));
    }
    cursor = page.next;
  } while (cursor);
  return values;
}

// apps/ruukoto/src/personal-delegation.ts
var PersonalDelegationDoc = defineDocFamily8({ kind: "ruukoto.analysis-delegation", scope: "session", version: 1, family: true, initial: () => ({}) });
var personalAnalysisDelegations = defineExtension7({ name: "personal-analysis-delegations" });
var PersonalAnalysisAdmission = defineEntry6("ruukoto.analysis-admission");
async function source(tx, requestId) {
  const input = await tx.submissionByRequest(ROOT_CONVERSATION_ID7, requestId);
  const entry = input?.entry && await tx.entry(input.entry);
  if (input?.type !== "input" || !entry || entry.kind !== "pi.user" || entry.conversationId !== ROOT_CONVERSATION_ID7) throw new PersonalError("delegation_source_invalid", "\u59D4\u6258\u8BF4\u660E\u7F3A\u5C11\u539F\u62E5\u6709\u8005\u8F93\u5165\uFF0C\u8BF7\u505C\u6B62\u64CD\u4F5C\u5E76\u67E5\u8BE2\u539F\u59D4\u6258\u3002");
  return { requestId, submissionId: input.id, entryId: entry.id };
}
async function personalDelegation(tx, ref) {
  const value = (await tx.doc(PersonalDelegationDoc, String(ref.entryId), null)).delegation;
  if (!value || value.ref.entryId !== ref.entryId) throw new PersonalError("delegation_missing", "\u627E\u4E0D\u5230\u539F\u5206\u6790\u59D4\u6258\uFF0C\u8BF7\u67E5\u8BE2\u59D4\u6258\u5217\u8868\uFF1B\u6CA1\u6709\u6539\u53D8\u5DE5\u4F5C\u3002");
  return value;
}
async function originalEntry(tx, value, requestId) {
  const receipt3 = requestId.startsWith("telegram:") ? (await tx.doc(PersonalTelegramReceiptDoc, requestId, null)).receipt : void 0;
  const telegram = receipt3 && permissionSnapshot(receipt3);
  if (value.telegram ? !telegram || receipt3?.submissionId !== (await source(tx, requestId)).submissionId || value.telegram.botId !== telegram.botId || value.telegram.ownerId !== telegram.ownerId || value.telegram.generation !== telegram.generation : requestId.startsWith("telegram:")) throw new PersonalError("delegation_original_entry", "\u6B64\u8BF4\u660E\u4E0D\u5C5E\u4E8E\u59D4\u6258\u7684\u539F\u5165\u53E3\uFF0C\u672A\u6539\u53D8\u5DE5\u4F5C\uFF1B\u8BF7\u4ECE\u539F\u5165\u53E3\u67E5\u8BE2\u3002");
}
async function requirePersonalDelegationInput(tx, ref, requestId) {
  await source(tx, requestId);
  await originalEntry(tx, await personalDelegation(tx, ref), requestId);
}
async function personalDelegationSources(tx, value) {
  const sources = /* @__PURE__ */ new Set([value.source.requestId]);
  if (value.report) sources.add(value.report.source.requestId);
  for (const ref of value.members) {
    const work = await tx.doc(PersonalWorkDoc, ref.requestId, null);
    if (!isDeepStrictEqual4(work.ref, ref) || work.delegation?.entryId !== value.ref.entryId || !work.instructionSource) throw new PersonalError("delegation_member_invalid", "\u59D4\u6258\u6210\u5458\u5F52\u5C5E\u65E0\u6CD5\u6838\u5B9E\uFF0C\u5DF2\u505C\u6B62\u6267\u884C\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u68C0\u67E5\u539F\u8BB0\u5F55\u3002");
    sources.add(work.instructionSource.requestId);
    if (work.source) sources.add(work.source.requestId);
    for (const note of work.notes ?? []) if (note.source.kind === "input") sources.add(note.source.requestId);
  }
  return sources;
}
async function personalDelegationBlocker(tx, value) {
  for (const requestId of await personalDelegationSources(tx, value)) {
    const blocker = await personalServiceSourceBlocker(tx, requestId);
    if (blocker) return blocker;
  }
}
async function sourcesReady(tx, value) {
  if (await personalDelegationBlocker(tx, value)) throw new PersonalError("work_source_paused", "\u59D4\u6258\u6709\u5C1A\u672A\u6838\u5B9E\u7684\u670D\u52A1\u6548\u679C\u6216\u505C\u6B62\u72B6\u6001\uFF0C\u5DF2\u6682\u505C\u5206\u6790\u548C\u6C47\u603B\uFF1B\u8BF7\u67E5\u8BE2\u539F\u64CD\u4F5C\u5E76\u6838\u5B9E\uFF0C\u4E0D\u8981\u6362\u59D4\u6258\u91CD\u8BD5\u3002");
}
async function requirePersonalDelegationOpen(tx, ref) {
  if ((await personalDelegation(tx, ref)).report) throw new PersonalError("delegation_sealed", "\u59D4\u6258\u5DF2\u5B89\u6392\u6700\u7EC8\u6C47\u603B\uFF0C\u672A\u63A5\u7EB3\u65B0\u5206\u6790\u6216\u8BF4\u660E\uFF1B\u8BF7\u67E5\u8BE2\u539F\u59D4\u6258\u62A5\u544A\uFF0C\u65B0\u5DE5\u4F5C\u7531\u62E5\u6709\u8005\u53E6\u884C\u63D0\u4EA4\u3002");
}
async function requirePersonalDelegationReady(tx, ref) {
  const value = await personalDelegation(tx, ref);
  if (value.cancelRequested) throw new PersonalError("delegation_canceled", "\u6574\u9879\u5206\u6790\u59D4\u6258\u5DF2\u53D6\u6D88\uFF0C\u8BF7\u67E5\u8BE2\u539F\u7ED3\u679C\u5E76\u5411\u62E5\u6709\u8005\u62A5\u544A\uFF1B\u4E0D\u80FD\u7EED\u6D3E\u6216\u8FFD\u52A0\u3002");
  if (value.telegram && !await telegramSourceActive(tx, value.telegram)) throw new PersonalError("delegation_source_inactive", "\u59D4\u6258\u539F\u5165\u53E3\u5DF2\u5931\u6548\uFF0C\u8BF7\u67E5\u8BE2\u539F\u59D4\u6258\uFF1B\u672A\u7EE7\u7EED\u6267\u884C\u6216\u6539\u53D1\u5176\u4ED6\u5165\u53E3\u3002");
  await sourcesReady(tx, value);
}
async function cancelPersonalDelegation(tx, ref, sourceRequestId) {
  const value = await personalDelegation(tx, ref);
  if (sourceRequestId) await originalEntry(tx, value, sourceRequestId);
  for (const member of value.members) {
    if (!isDeepStrictEqual4(await personalWorkRef(tx, member.taskId), member)) throw new PersonalError("delegation_member_invalid", "\u59D4\u6258\u6210\u5458\u65E0\u6CD5\u6838\u5B9E\uFF0C\u672A\u8BF7\u6C42\u53D6\u6D88\uFF1B\u8BF7\u68C0\u67E5\u539F\u8BB0\u5F55\u3002");
    await personalWorkStatus(tx, member);
  }
  value.cancelRequested = true;
  for (const member of value.members) await requestPersonalWorkCancel(tx, member);
}
async function personalDelegationProgress(tx, ref, offset = 0) {
  const value = await personalDelegation(tx, ref);
  let active2 = 0;
  let unverified = 0;
  const members = [];
  for (const [index, member] of value.members.entries()) {
    const status = await personalWorkStatus(tx, member);
    if (status.task.state.status !== "terminal") active2++;
    else if (!status.stopVerified) unverified++;
    if (index >= offset && members.length < 8) members.push(await personalWorkSummary(tx, { ...member }));
  }
  let paused = false;
  try {
    await sourcesReady(tx, value);
  } catch (error) {
    if (!(error instanceof PersonalError) || error.code !== "work_source_paused") throw error;
    paused = true;
  }
  const entry = await tx.entry(value.source.entryId);
  const message = entry?.model?.[0];
  if (message?.role !== "user") throw new PersonalError("delegation_source_invalid", "\u59D4\u6258\u539F\u8BF4\u660E\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u68C0\u67E5\u8BB0\u5F55\u3002");
  const content = typeof message.content === "string" ? message.content : message.content.filter((part) => part.type === "text").map((part) => part.text).join("");
  const reportTask = value.report && await tx.task(value.report.taskId);
  if (value.report && !reportTask) throw new PersonalError("report_missing", "\u59D4\u6258\u62A5\u544A\u6267\u884C\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
  const report = value.report && reportTask ? { delivery: value.report.delivery, state: reportTask.state.status === "terminal" ? reportTask.state.outcome.status : reportTask.state.status } : void 0;
  return { ref: { ...value.ref }, content: content.slice(0, 160), cancelRequested: value.cancelRequested, total: value.members.length, active: active2, unverified, paused, ...report ? { report } : {}, state: unverified ? "stop_unverified" : value.cancelRequested ? active2 ? "canceling" : "canceled" : paused ? "paused" : report ? reportTask.state.status === "terminal" ? reportTask.state.outcome.status === "completed" ? "reported" : "report_failed" : "reporting" : active2 ? "active" : "idle", members, ...offset + 8 < value.members.length ? { nextOffset: offset + 8 } : {} };
}
async function listPersonalDelegations(tx, offset = 0, telegram) {
  const seen = /* @__PURE__ */ new Set();
  const items = [];
  let cursor;
  do {
    const page = await tx.scanTasks({ kind: PersonalWorkTask.definition.name, order: "descending" }, 64, cursor);
    for (const task of page.items) {
      const ref = await personalWorkRef(tx, task.id);
      const group = (await tx.doc(PersonalWorkDoc, ref.requestId, null)).delegation;
      if (!group || seen.has(group.entryId)) continue;
      seen.add(group.entryId);
      const value = await personalDelegation(tx, group);
      if (telegram && (telegram.botId !== value.telegram?.botId || telegram.ownerId !== value.telegram.ownerId || telegram.generation !== value.telegram.generation)) continue;
      if (offset-- > 0) continue;
      if (items.length === 8) return { items, more: true };
      const progress = await personalDelegationProgress(tx, group);
      const { members: _members, nextOffset: _next, ...summary } = progress;
      items.push(summary);
    }
    cursor = page.next;
  } while (cursor);
  return { items, more: false };
}

// apps/ruukoto/src/personal-report.ts
import { isDeepStrictEqual as isDeepStrictEqual5 } from "node:util";
import { AssistantEntry, defineEntry as defineEntry7, defineExtension as defineExtension8, defineTask as defineTask4, InboxDoc, LiveDoc as LiveDoc4, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID8 } from "@earendil-works/pi-durable";

// apps/ruukoto/src/personal-telegram-config.ts
import { createHash as createHash2 } from "node:crypto";
function telegramToken(config) {
  const token = process.env[config.tokenEnv];
  if (!token || !/^[1-9][0-9]*:[\w-]+$/.test(token) || token.split(":")[0] !== config.botId || createHash2("sha256").update(token).digest("hex") !== config.tokenDigest) throw new PersonalError("telegram_credentials_changed", "Telegram \u51ED\u636E\u7F3A\u5931\u6216\u5DF2\u53D8\u5316\uFF0C\u8BF7\u8BBE\u7F6E\u539F\u73AF\u5883\u53D8\u91CF\u6216\u505C\u6B62\u5B9E\u4F8B\u540E\u91CD\u65B0\u914D\u5BF9\uFF1B\u672A\u8FDE\u63A5\u5E73\u53F0\u3002");
  return token;
}

// apps/ruukoto/src/personal-report.ts
var ReportAdmission = defineEntry7("ruukoto.report-admission");
var ReportPause = defineEntry7("ruukoto.report-pause");
var INPUT_KIND = "ruukoto.delegation-report";
var submissionKey = (taskId, attempt) => `personal-report:${taskId}:${attempt}`;
var inputData = (ref, report, attempt = report.attempt) => ({ delegation: ref.entryId, taskId: report.taskId, attempt });
var platformText = (text) => Array.from(text).length > 3900 ? Array.from(text).slice(0, 3900).join("") + "\u2026\uFF08\u663E\u793A\u5DF2\u622A\u65AD\uFF0C\u5B8C\u6574\u62A5\u544A\u53EF\u4ECE\u59D4\u6258\u83DC\u5355\u8BFB\u53D6\uFF09" : text || "\u672C\u6B21\u62A5\u544A\u6CA1\u6709\u6587\u672C\u5185\u5BB9\uFF0C\u8BF7\u67E5\u8BE2\u539F\u59D4\u6258\u3002";
async function reportFacts(tx, ref, taskId) {
  const value = await personalDelegation(tx, ref);
  if (!value.report || taskId !== void 0 && value.report.taskId !== taskId) throw new PersonalError("report_missing", "\u59D4\u6258\u62A5\u544A\u5F52\u5C5E\u7F3A\u5931\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u67E5\u8BE2\u539F\u59D4\u6258\u5E76\u4FDD\u7559\u6863\u6848\u3002");
  return { value, report: value.report };
}
async function verifyInput(tx, ref, report, attempt = report.attempt) {
  const submission = await tx.submissionByRequest(ROOT_CONVERSATION_ID8, submissionKey(report.taskId, attempt));
  if (!submission) return;
  if (submission.type !== "input") throw new PersonalError("report_input_invalid", "\u62A5\u544A\u8F93\u5165\u7C7B\u578B\u4E0D\u7B26\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
  if (submission.entry) {
    const entry = await tx.entry(submission.entry);
    const message = entry?.model?.[0];
    if (entry?.kind !== INPUT_KIND || entry.conversationId !== ROOT_CONVERSATION_ID8 || !isDeepStrictEqual5(entry.data, inputData(ref, report, attempt)) || message?.role !== "user" || message.content !== report.content) throw new PersonalError("report_input_invalid", "\u62A5\u544A\u539F\u8F93\u5165\u6216\u6765\u6E90\u65E0\u6CD5\u6838\u5B9E\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
  } else if (submission.status === "queued") {
    const queued = (await tx.doc(InboxDoc, ROOT_CONVERSATION_ID8)).items.find((item) => item.id === submission.id);
    if (!queued || queued.mode !== "followUp" || queued.content !== report.content || !isDeepStrictEqual5(queued.entry, { kind: INPUT_KIND, data: inputData(ref, report, attempt) })) throw new PersonalError("report_input_invalid", "\u62A5\u544A\u6392\u961F\u539F\u6587\u6216\u6765\u6E90\u4E0D\u7B26\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
  }
  return submission;
}
async function membersStopped(tx, ref) {
  for (const member of (await personalDelegation(tx, ref)).members) if (!(await personalWorkStatus(tx, member)).stopVerified) throw new PersonalError("report_stop_unverified", "\u59D4\u6258\u6210\u5458\u505C\u6B62\u5C1A\u672A\u6838\u5B9E\uFF0C\u672A\u751F\u6210\u62A5\u544A\uFF1B\u8BF7\u67E5\u8BE2\u539F\u5206\u6790\u5E76\u6838\u5B9E\u505C\u6B62\u3002");
}
async function requireReportReady(tx, ref) {
  await membersStopped(tx, ref);
  await requirePersonalDelegationReady(tx, ref);
}
function canceled(reader, ref, context4) {
  return reader.watchDoc(PersonalDelegationDoc, String(ref.entryId), context4).then((watch) => {
    if (!watch) throw new PersonalError("report_missing", "\u62A5\u544A\u59D4\u6258\u8BB0\u5F55\u7F3A\u5931\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
    const promise = new Promise((resolve3) => {
      const check = (value) => {
        if (!value?.delegation || value.delegation.cancelRequested) resolve3();
      };
      watch.start(async (value) => {
        check(value);
      });
      check(watch.value);
      void watch.closed.then(() => resolve3());
    });
    return { watch, promise };
  });
}
var PersonalReportTask = defineTask4({
  name: "ruukoto.delegation-report",
  version: 1,
  initial: () => ({ phase: "wait" }),
  phases: {
    async wait(current, runtime, context4) {
      await runtime.commit(async (tx) => {
        const { value, report } = await reportFacts(tx, current.input.delegation, current.id);
        if (value.cancelRequested) {
          report.delivery = "canceled";
          return { status: "terminal", outcome: { status: "completed", result: { delivery: "canceled" } } };
        }
        return { status: "waiting", checkpoint: { phase: "summarize", attempt: report.attempt }, on: value.members.map((ref) => ref.taskId), policy: "allSettled" };
      }, context4);
    },
    async summarize(current, runtime, context4) {
      const ref = current.input.delegation;
      const cancel = await canceled(runtime, ref, context4);
      try {
        while (true) {
          let blocker;
          let stop = false;
          await runtime.commit(async (tx) => {
            const { value, report } = await reportFacts(tx, ref, current.id);
            if (value.cancelRequested) {
              report.delivery = "canceled";
              stop = true;
              return { status: "terminal", outcome: { status: "completed", result: { delivery: "canceled" } } };
            }
            blocker = await personalDelegationBlocker(tx, value);
            if (!blocker) {
              try {
                await requireReportReady(tx, ref);
              } catch (error) {
                if (!(error instanceof PersonalError) || !["report_stop_unverified", "delegation_source_inactive", "delegation_canceled"].includes(error.code)) throw error;
                stop = true;
                report.delivery = error.code === "report_stop_unverified" ? "blocked" : "canceled";
                return { status: "terminal", outcome: { status: "failed", error: { message: error.message, detail: { code: error.code } }, result: { delivery: report.delivery } } };
              }
              await verifyInput(tx, ref, report);
            }
            return void 0;
          }, context4);
          if (stop) return;
          if (!blocker) break;
          const watch = typeof blocker === "string" ? await runtime.watchDoc(PersonalServiceOperationDoc, blocker, context4) : "browser" in blocker ? await runtime.watchDoc(PersonalBrowserOperationDoc, blocker.browser, context4) : "tool" in blocker ? await runtime.watchDoc(PersonalToolDoc, blocker.tool, context4) : "mcp" in blocker ? await runtime.watchDoc(PersonalMcpDoc, blocker.mcp, context4) : "command" in blocker ? await runtime.watchDoc(PersonalCommandDoc, blocker.command, context4) : await runtime.watchDoc(PersonalInspectionDoc, String(blocker.inspection), context4);
          if (!watch) throw new PersonalError("service_operation_missing", "\u6682\u505C\u62A5\u544A\u7684\u670D\u52A1\u8BB0\u5F55\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
          try {
            const changed = new Promise((resolve3) => {
              watch.start(async () => {
                resolve3();
              });
              void watch.closed.then(() => resolve3());
            });
            let stillBlocked = false;
            await runtime.commit(async (tx) => {
              stillBlocked = isDeepStrictEqual5(await personalDelegationBlocker(tx, await personalDelegation(tx, ref)), blocker);
              return void 0;
            }, context4);
            if (stillBlocked) await Promise.race([changed, cancel.promise]);
          } finally {
            await watch.stop();
          }
        }
        const saved = (await runtime.snapshot(PersonalDelegationDoc, String(ref.entryId), context4)).delegation.report;
        const main = await runtime.conversation(ROOT_CONVERSATION_ID8, context4);
        if (!main) throw new PersonalError("report_main_missing", "\u62A5\u544A\u4E3B\u4F1A\u8BDD\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
        const submission = await main.submit({ type: "input", requestId: submissionKey(current.id, saved.attempt), content: saved.content, entry: { kind: INPUT_KIND, data: inputData(ref, saved) }, whenBusy: "followUp" }, context4);
        let cancelNow = false;
        await runtime.commit(async (tx) => {
          const { value, report } = await reportFacts(tx, ref, current.id);
          await verifyInput(tx, ref, report);
          report.submissionId = submission.id;
          cancelNow = value.cancelRequested;
          return void 0;
        }, context4);
        if (cancelNow) await submission.abort(context4);
        const settled = await Promise.race([submission.wait(context4), cancel.promise.then(() => void 0)]);
        if (!settled) await submission.abort(context4);
        await runtime.commit(async (tx) => {
          const { value, report } = await reportFacts(tx, ref, current.id);
          if (value.cancelRequested) {
            report.delivery = "canceled";
            return { status: "terminal", outcome: { status: "completed", result: { delivery: "canceled" } } };
          }
          if (settled?.status !== "done" || settled.type !== "input") {
            if (report.pauses[report.attempt]) {
              report.attempt++;
              delete report.submissionId;
              return { status: "running", checkpoint: { phase: "summarize", attempt: report.attempt } };
            }
            report.delivery = "unanswered";
            return { status: "terminal", outcome: { status: "failed", error: { message: "\u4E3B\u4F1A\u8BDD\u672A\u5B8C\u6210\u672C\u62A5\u544A\uFF0C\u672A\u5916\u53D1\uFF1B\u8BF7\u67E5\u8BE2\u539F\u59D4\u6258\u3002" }, result: { delivery: report.delivery } } };
          }
          const entry = await tx.entry(AssistantEntry, settled.answer);
          const message = entry?.model?.[0];
          if (message?.role !== "assistant") throw new PersonalError("report_answer_missing", "\u62A5\u544A\u5B8C\u6574\u56DE\u7B54\u7F3A\u5931\uFF0C\u672A\u5916\u53D1\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
          report.answer = settled.answer;
          const text = message.content.filter((part) => part.type === "text").map((part) => part.text).join("");
          report.reply = platformText(text);
          report.delivery = "pending";
          return { status: "running", checkpoint: { phase: "send" } };
        }, context4);
      } finally {
        await cancel.watch.stop();
      }
    },
    async send(current, runtime, context4) {
      if (current.state.checkpoint.retryAt) await runtime.sleep(current.state.checkpoint.retryAt, context4);
      const ref = current.input.delegation;
      const config = (await runtime.snapshot(PersonalTelegramDoc, context4))?.config;
      const api = config?.enabled ? personalTelegramApi(config.apiBase, telegramToken(config)) : void 0;
      let owner = "", message = 0, reply = "";
      await runtime.commit(async (tx) => {
        const { value, report } = await reportFacts(tx, ref, current.id);
        const currentConfig = (await tx.doc(PersonalTelegramDoc)).config;
        if (value.cancelRequested || value.telegram && (!isDeepStrictEqual5(config, currentConfig) || !config?.enabled || config.generation !== value.telegram.generation || config.botId !== value.telegram.botId || config.ownerId !== value.telegram.ownerId)) {
          report.delivery = "canceled";
          return { status: "terminal", outcome: { status: "completed", result: { delivery: "canceled" } } };
        }
        if (await personalDelegationBlocker(tx, value)) return { status: "running", checkpoint: { phase: "summarize", attempt: report.attempt } };
        if (!value.telegram) {
          report.delivery = "local";
          return { status: "terminal", outcome: { status: "completed", result: { delivery: "local" } } };
        }
        const receipt3 = (await tx.doc(PersonalTelegramReceiptDoc, value.source.requestId, null)).receipt;
        if (!receipt3 || !report.reply || report.delivery !== "pending" || !api) throw new PersonalError("report_send_invalid", "\u62A5\u544A\u56FA\u5B9A\u76EE\u6807\u6216\u6B63\u6587\u7F3A\u5931\uFF0C\u5DF2\u505C\u6B62\u53D1\u9001\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
        owner = value.telegram.ownerId;
        message = receipt3.messageId;
        reply = report.reply;
        report.delivery = "sending";
        return { status: "running", checkpoint: { phase: "verify" } };
      }, context4);
      if (!owner) return;
      let platformMessageId;
      let failure;
      try {
        platformMessageId = await api.send(owner, message, reply, runtime.signal);
      } catch (error) {
        if (!(error instanceof PersonalTelegramApiError)) throw error;
        failure = error;
      }
      await runtime.commit(async (tx) => {
        const { report } = await reportFacts(tx, ref, current.id);
        if (failure?.retryAfterMs) {
          report.delivery = "pending";
          return { status: "running", checkpoint: { phase: "send", retryAt: runtime.now() + failure.retryAfterMs } };
        }
        report.delivery = platformMessageId ? "sent" : failure?.effect === "not_sent" ? "failed" : "effect_unknown";
        if (platformMessageId) report.platformMessageId = platformMessageId;
        return { status: "terminal", outcome: { status: "completed", result: { delivery: report.delivery } } };
      }, context4);
    },
    async verify(current, runtime, context4) {
      await runtime.commit(async (tx) => {
        const { report } = await reportFacts(tx, current.input.delegation, current.id);
        report.delivery = "effect_unknown";
        return { status: "terminal", outcome: { status: "completed", result: { delivery: "effect_unknown" } } };
      }, context4);
    }
  },
  async abort(current, runtime, context4) {
    const saved = (await runtime.snapshot(PersonalDelegationDoc, String(current.input.delegation.entryId), context4))?.delegation?.report;
    const main = await runtime.conversation(ROOT_CONVERSATION_ID8, context4);
    let admitted = false;
    if (saved) await runtime.commit(async (tx) => {
      admitted = !!await verifyInput(tx, current.input.delegation, saved);
      return void 0;
    }, context4);
    if (saved && main && admitted) {
      const submission = await main.submit({ type: "input", requestId: submissionKey(current.id, saved.attempt), content: saved.content, entry: { kind: INPUT_KIND, data: inputData(current.input.delegation, saved) }, whenBusy: "followUp" }, context4);
      await submission.abort(context4);
    }
    await runtime.commit(async (tx) => {
      const { report } = await reportFacts(tx, current.input.delegation, current.id);
      report.delivery = report.delivery === "sending" ? "effect_unknown" : "canceled";
      return { status: "terminal", outcome: { status: "aborted", result: { delivery: report.delivery } } };
    }, context4);
  }
});
var personalDelegationReports = defineExtension8({ name: "personal-delegation-reports", tasks: [PersonalReportTask] });
async function personalReportResult(tx, ref, offset = 0, size = 4096) {
  const value = await personalDelegation(tx, ref);
  if (!value.report) return { delivery: "not_requested" };
  const { report } = await reportFacts(tx, ref);
  const task = await tx.task(report.taskId);
  if (!task) throw new PersonalError("report_missing", "\u62A5\u544A\u6267\u884C\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
  const state = task.state.status === "terminal" ? task.state.outcome.status : task.state.status;
  if (!report.answer) return { delivery: report.delivery, state };
  const entry = await tx.entry(AssistantEntry, report.answer);
  const message = entry?.model?.[0];
  if (message?.role !== "assistant") throw new PersonalError("report_answer_missing", "\u62A5\u544A\u539F\u56DE\u7B54\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
  const text = message.content.filter((part) => part.type === "text").map((part) => part.text).join("");
  let end = Math.min(offset + size, text.length);
  if (end < text.length && /[\ud800-\udbff]/.test(text[end - 1]) && /[\udc00-\udfff]/.test(text[end])) end--;
  return { delivery: report.delivery, state, text: text.slice(offset, end), ...end < text.length ? { nextOffset: end } : {} };
}

// apps/ruukoto/src/personal-browser.ts
var PersonalBrowserDoc = defineDoc8({ kind: "ruukoto.browser", scope: "session", version: 1, initial: () => ({ operations: [] }) });
var PersonalBrowserOperationDoc = defineDocFamily9({ kind: "ruukoto.browser-operation", scope: "session", version: 1, family: true, initial: () => ({}) });
var BrowserConfiguration = defineEntry8("ruukoto.browser-configuration");
var BrowserBindingChanged = defineEntry8("ruukoto.browser-binding-changed");
var BrowserAdmission = defineEntry8("ruukoto.browser-admission");
var BrowserStart = defineEntry8("ruukoto.browser-start");
var BrowserObservation = defineEntry8("ruukoto.browser-observation");
var BrowserPause = defineEntry8("ruukoto.browser-pause");
var BrowserResolution = defineEntry8("ruukoto.browser-resolution");
var browserUnresolved = (value) => value.started && (!value.stopped || value.effect === "effect_unknown" && !value.resolution);
async function browserOperation(tx, operation) {
  const value = (await tx.doc(PersonalBrowserOperationDoc, String(operation), null)).operation;
  if (!value || value.operation !== operation) throw new PersonalError("browser_operation_missing", "\u539F\u6D4F\u89C8\u5668\u64CD\u4F5C\u7F3A\u5931\uFF0C\u8BF7\u5237\u65B0\u539F\u8BB0\u5F55\u5E76\u4FDD\u7559\u6863\u6848\u3002");
  return value;
}
async function browserOperations(tx) {
  const values = [];
  for (const id2 of (await tx.doc(PersonalBrowserDoc)).operations) values.push(await browserOperation(tx, id2));
  return values;
}
async function browserSourceBlocker(tx, requestId) {
  const source3 = await tx.submissionByRequest(ROOT_CONVERSATION_ID11, requestId);
  if (!source3) return;
  for (const value of await browserOperations(tx)) if (value.origin.sources.includes(source3.id) && browserUnresolved(value)) return { browser: String(value.operation), admission: value.admission };
}

// apps/ruukoto/src/personal-tools.ts
import { copyJson as copyJson6 } from "@earendil-works/chord";
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT11 } from "@earendil-works/chord/context";
import { AgentDoc as AgentDoc3, defineDoc as defineDoc9, defineDocFamily as defineDocFamily10, defineEntry as defineEntry9, defineExtension as defineExtension11, defineTool as defineTool5, LiveDoc as LiveDoc8, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID12 } from "@earendil-works/pi-durable";
import { createModels as createModels2 } from "@earendil-works/pi-ai";
import { validateToolArguments as validateToolArguments2 } from "@earendil-works/pi-ai/utils/validation";
import { Type as Type5 } from "typebox";

// packages/agent/src/review.ts
var REVIEW_INPUT_CAP_BYTES = 8 * 1024;

// apps/ruukoto/src/personal-tools-config.ts
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT10 } from "@earendil-works/chord/context";
import { openNodeSqliteStorage as openNodeSqliteStorage4 } from "@earendil-works/pi-durable/storage/sqlite/node";

// apps/ruukoto/src/personal-tool-io.ts
var PERSONAL_TOOL_CAPTURE_BYTES = 8 * 1024 * 1024;

// packages/agent/src/web-search-transport.ts
var RESPONSE_CAP_BYTES = 256 * 1024;

// apps/ruukoto/src/personal-tools.ts
var PersonalToolsDoc = defineDoc9({ kind: "ruukoto.tools", scope: "session", version: 1, initial: () => ({ operations: [], grants: [], grantVersion: 1 }) });
var PersonalToolDoc = defineDocFamily10({ kind: "ruukoto.tool-operation", scope: "session", version: 1, family: true, initial: () => ({}) });
var ToolAdmission = defineEntry9("ruukoto.tool-admission");
var ToolStart = defineEntry9("ruukoto.tool-start");
var ToolObservation = defineEntry9("ruukoto.tool-observation");
var ToolDecision = defineEntry9("ruukoto.tool-decision");
var ToolReview = defineEntry9("ruukoto.tool-review");
var ToolGrant = defineEntry9("ruukoto.tool-grant");
var ToolResolution = defineEntry9("ruukoto.tool-resolution");
async function toolOperation(tx, operation) {
  const value = (await tx.doc(PersonalToolDoc, String(operation), null)).operation;
  if (!value || value.operation !== operation) throw new PersonalError("tool_missing", "\u539F\u5DE5\u5177\u8C03\u7528\u7F3A\u5931\uFF0C\u8BF7\u5237\u65B0\u539F\u64CD\u4F5C\u5E76\u4FDD\u7559\u6863\u6848\u3002");
  return value;
}
async function toolOperations(tx) {
  const values = [];
  for (const id2 of (await tx.doc(PersonalToolsDoc)).operations) values.push(await toolOperation(tx, id2));
  return values;
}
var toolUnresolved = (value) => value.started && (!value.stopped || value.effect === "effect_unknown" && !value.resolution);
async function toolSourceBlocker(tx, requestId) {
  const source3 = await tx.submissionByRequest(ROOT_CONVERSATION_ID12, requestId);
  if (!source3) return;
  for (const value of await toolOperations(tx)) if (value.origin.sources.includes(source3.id) && toolUnresolved(value)) return { tool: String(value.operation), admission: value.admission };
}
async function requireWorkToolsStopped(tx, taskId) {
  if ((await toolOperations(tx)).some((value) => value.origin.work?.ref.taskId === taskId && toolUnresolved(value))) throw new PersonalError("work_stop_unverified", "\u539F\u5DE5\u5177\u6548\u679C\u6216\u5916\u90E8\u8BF7\u6C42\u7ED3\u675F\u672A\u6838\u5B9E\uFF0C\u4FDD\u7559\u5360\u7528\uFF1B\u8BF7\u7531\u62E5\u6709\u8005\u67E5\u8BE2\u539F\u64CD\u4F5C\u3002");
}
async function waitWorkTools(reader, ids, context4) {
  for (const id2 of ids) await waitTool(reader, id2, (value) => !toolUnresolved(value), context4);
}
async function waitTool(reader, id2, ready, context4) {
  const watch = await reader.watchDoc(PersonalToolDoc, String(id2), context4);
  if (!watch) throw new PersonalError("tool_missing", "\u539F\u5DE5\u5177\u7B49\u5F85\u8BB0\u5F55\u7F3A\u5931\uFF0C\u5DF2\u4FDD\u7559\u5360\u7528\uFF1B\u8BF7\u68C0\u67E5\u6863\u6848\u3002");
  try {
    await new Promise((resolve3, reject) => {
      const check = (value) => {
        if (!value?.operation) reject(new PersonalError("tool_missing", "\u539F\u5DE5\u5177\u8BB0\u5F55\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002"));
        else if (ready(value.operation)) resolve3();
      };
      watch.start(async (value) => check(value));
      check(watch.value);
      void watch.closed.then(() => reject(new PersonalError("tool_wait_stopped", "\u539F\u5DE5\u5177\u7B49\u5F85\u5DF2\u505C\u6B62\uFF0C\u8BF7\u67E5\u8BE2\u539F\u64CD\u4F5C\u3002")));
    });
  } finally {
    await watch.stop();
  }
}
var ToolConfiguration = defineEntry9("ruukoto.tools-configuration");

// apps/ruukoto/src/personal-work.ts
import { isDeepStrictEqual as isDeepStrictEqual6 } from "node:util";
import { BACKGROUND_CONTEXT as BACKGROUND_CONTEXT12 } from "@earendil-works/chord/context";
import { AgentDoc as AgentDoc4, AssistantEntry as AssistantEntry2, configure, defineDoc as defineDoc11, defineDocFamily as defineDocFamily11, defineEntry as defineEntry10, defineExtension as defineExtension13, defineTask as defineTask6, ROOT_CONVERSATION_ID as ROOT_CONVERSATION_ID13, section as section2 } from "@earendil-works/pi-durable";

// apps/ruukoto/src/personal-services.ts
import { defineDoc as defineDoc10, defineExtension as defineExtension12, defineTool as defineTool6 } from "@earendil-works/pi-durable";
import { Type as Type6 } from "typebox";
var PersonalServiceDoc = defineDoc10({ kind: "ruukoto.service-config", scope: "session", version: 2, initial: () => ({ fingerprint: "" }) });
var personalSubAgentServices = defineExtension12({ name: "personal-subagent-service-inspect" });

// apps/ruukoto/src/personal-work.ts
var PersonalWorkNoteAdmission = defineEntry10("ruukoto.work-note-admission");
var PersonalAgentsDoc = defineDoc11({ kind: "ruukoto.subagents", scope: "session", version: 1, initial: () => ({ agents: [] }) });
var PersonalWorkDoc = defineDocFamily11({ kind: "ruukoto.work", scope: "session", version: 1, family: true, initial: () => ({ fingerprint: "", cancelRequested: false }) });
async function facts(tx, ref) {
  const work = await tx.doc(PersonalWorkDoc, ref.requestId, null);
  if (!work.ref || work.ref.taskId !== ref.taskId || work.ref.agentId !== ref.agentId) throw new PersonalError("work_missing", "\u627E\u4E0D\u5230\u6B64\u540E\u53F0\u5DE5\u4F5C\uFF0C\u8BF7\u67E5\u8BE2\u539F\u5DE5\u4F5C\u8BB0\u5F55\u3002");
  return work;
}
async function occupancy(tx, input, taskId) {
  const agent = (await tx.doc(PersonalAgentsDoc)).agents.find((agent2) => agent2.id === input.agentId);
  if (!agent || agent.closed || agent.work?.taskId !== taskId) throw new PersonalError("work_ownership", "\u540E\u53F0\u5DE5\u4F5C\u7684\u5360\u7528\u8BB0\u5F55\u4E0D\u7B26\uFF0C\u5DF2\u4FDD\u7559\u73B0\u573A\uFF1B\u8BF7\u68C0\u67E5\u6863\u6848\u3002");
  return agent;
}
async function release(tx, input, taskId) {
  const agent = await occupancy(tx, input, taskId);
  await requirePersonalWorkServicesStopped(tx, taskId);
  await requirePersonalCommandsStopped(tx, taskId);
  await requireWorkMcpStopped(tx, taskId);
  await requireWorkToolsStopped(tx, taskId);
  if (await pendingWorkInspection(tx, taskId)) throw new PersonalError("work_stop_unverified", "\u5B50\u5DE5\u4F5C\u4ECD\u6709\u672A\u6838\u5B9E\u7684\u68C0\u67E5\uFF0C\u5360\u7528\u4FDD\u7559\uFF1B\u8BF7\u6838\u5B9E\u539F\u68C0\u67E5\u505C\u6B62\u3002");
  delete agent.work;
}
async function settleServices(runtime, taskId, context4, cancel) {
  let refs = [];
  await runtime.commit(async (tx) => {
    refs = (await personalWorkServices(tx, taskId)).map((op) => ({ ...op.ref }));
    return void 0;
  }, context4);
  for (const ref of refs) {
    if (cancel) await runtime.abortOwned(ref.taskId, context4);
    else await runtime.waitForTask(ref.taskId, context4);
    await runtime.commit(async (tx) => {
      for (const value of await personalWorkServices(tx, taskId)) await interruptedPersonalService(tx, value);
      return void 0;
    }, context4);
    await waitPersonalServiceEffect(runtime, ref, context4);
  }
}
async function settleCommands(runtime, taskId, context4, cancel) {
  let refs = [];
  await runtime.commit(async (tx) => {
    refs = (await personalWorkCommands(tx, taskId)).map((op) => ({ ...op.ref }));
    return void 0;
  }, context4);
  for (const ref of refs) {
    if (cancel) await runtime.abortOwned(ref.taskId, context4);
    else await runtime.waitForTask(ref.taskId, context4);
    await waitPersonalCommand(runtime, ref, context4);
  }
}
async function settleMcp(runtime, taskId, context4) {
  let pending = [];
  await runtime.commit(async (tx) => {
    pending = (await mcpOperations(tx)).filter((value) => value.origin.work?.ref.taskId === taskId && mcpUnresolved(value)).map((value) => value.operation);
    return void 0;
  }, context4);
  await waitWorkMcp(runtime, pending, context4);
}
async function settleTools(runtime, taskId, context4) {
  let ids = [];
  await runtime.commit(async (tx) => {
    ids = (await toolOperations(tx)).filter((value) => value.origin.work?.ref.taskId === taskId && toolUnresolved(value)).map((value) => value.operation);
    return void 0;
  }, context4);
  await waitWorkTools(runtime, ids, context4);
}
async function waitForInspections(runtime, taskId, context4) {
  while (true) {
    const watch = await runtime.watchDoc(PersonalPendingInspectionsDoc, context4);
    if (!watch) return;
    try {
      const changed = new Promise((resolve3) => {
        watch.start(async () => {
          resolve3();
        });
        void watch.closed.then(() => resolve3());
      });
      let pending = false;
      await runtime.commit(async (tx) => {
        pending = await pendingWorkInspection(tx, taskId);
        return void 0;
      }, context4);
      if (!pending) return;
      await changed;
    } finally {
      await watch.stop();
    }
  }
}
var PersonalWorkTask = defineTask6({
  name: "ruukoto.background-work",
  version: 1,
  initial: () => ({ phase: "run" }),
  phases: {
    async run(task, runtime, context4) {
      const work = await runtime.snapshot(PersonalWorkDoc, task.input.requestId, context4);
      const ref = work?.ref;
      if (!ref || ref.taskId !== task.id || ref.agentId !== task.input.agentId) throw new PersonalError("work_missing", "\u540E\u53F0\u5DE5\u4F5C\u7F3A\u5C11\u5F52\u5C5E\u8BB0\u5F55\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u68C0\u67E5\u6863\u6848\u3002");
      await runtime.commit(async (tx) => {
        await occupancy(tx, task.input, task.id);
        return void 0;
      }, context4);
      const child = await runtime.conversation(task.input.agentId, context4);
      if (!child) throw new PersonalError("work_agent_missing", "\u540E\u53F0\u5DE5\u4F5C\u7684\u5B50\u4F1A\u8BDD\u7F3A\u5931\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
      if (work.cancelRequested) {
        await child.abort(context4, { background: true });
        await Promise.all([settleCommands(runtime, task.id, context4, true), settleServices(runtime, task.id, context4, true), settleMcp(runtime, task.id, context4), settleTools(runtime, task.id, context4)]);
        await waitForInspections(runtime, task.id, context4);
        await runtime.commit(async (tx) => {
          await release(tx, task.input, task.id);
          return { status: "terminal", outcome: { status: "aborted" } };
        }, context4);
        return;
      }
      let start = -1;
      await runtime.commit(async (tx) => {
        const work2 = await facts(tx, ref);
        for (const [i, note] of (work2.notes ?? []).entries()) if (await tx.submissionByRequest(ref.agentId, noteSubmissionKey(ref, note))) start = i;
        return void 0;
      }, context4);
      for (let index = start; ; index++) {
        const latest = await runtime.snapshot(PersonalWorkDoc, task.input.requestId, context4);
        const note = index < 0 ? void 0 : latest?.notes?.[index];
        if (index >= 0 && !note) throw new PersonalError("work_note_missing", "\u540E\u53F0\u5206\u6790\u7684\u8FFD\u52A0\u8BB0\u5F55\u7F3A\u5931\uFF0C\u5DF2\u4FDD\u7559\u5360\u7528\uFF1B\u8BF7\u68C0\u67E5\u6863\u6848\u3002");
        const submission = await child.submit({ type: "input", content: note?.content ?? task.input.content, requestId: note ? noteSubmissionKey(ref, note) : `personal-work:${task.id}`, whenBusy: "reject" }, context4);
        await runtime.commit(async (tx) => {
          const work2 = await facts(tx, ref);
          if (index < 0) work2.submissionId = submission.id;
          else work2.notes[index].submissionId = submission.id;
          return void 0;
        }, context4);
        const watch = await runtime.watchDoc(PersonalWorkDoc, task.input.requestId, context4);
        if (!watch) throw new PersonalError("work_missing", "\u540E\u53F0\u5DE5\u4F5C\u7684\u53D6\u6D88\u8BB0\u5F55\u7F3A\u5931\uFF0C\u5DF2\u4FDD\u7559\u5360\u7528\uFF1B\u8BF7\u68C0\u67E5\u6863\u6848\u3002");
        let settled;
        try {
          const canceled2 = new Promise((resolve3, reject) => {
            const check = (value) => {
              if (!value?.ref || value.ref.taskId !== task.id) reject(new PersonalError("work_missing", "\u540E\u53F0\u5DE5\u4F5C\u7684\u53D6\u6D88\u5F52\u5C5E\u65E0\u6CD5\u6838\u5B9E\uFF0C\u5DF2\u4FDD\u7559\u5360\u7528\uFF1B\u8BF7\u68C0\u67E5\u6863\u6848\u3002"));
              else if (value.cancelRequested) resolve3(void 0);
            };
            watch.start(async (value) => {
              check(value);
            });
            check(watch.value);
            void watch.closed.then(() => reject(new PersonalError("work_wait_stopped", "\u540E\u53F0\u5DE5\u4F5C\u7B49\u5F85\u5DF2\u505C\u6B62\uFF0C\u8BF7\u67E5\u8BE2\u539F\u5DE5\u4F5C\uFF1B\u5360\u7528\u672A\u6838\u5B9E\u524D\u4E0D\u80FD\u590D\u7528\u3002")));
          });
          settled = await Promise.race([submission.wait(context4), canceled2]);
        } finally {
          await watch.stop();
        }
        await child.abort(context4, { background: true });
        const cancel = !settled || !!(await runtime.snapshot(PersonalWorkDoc, task.input.requestId, context4))?.cancelRequested;
        await Promise.all([settleCommands(runtime, task.id, context4, cancel), settleServices(runtime, task.id, context4, cancel), settleMcp(runtime, task.id, context4), settleTools(runtime, task.id, context4)]);
        await waitForInspections(runtime, task.id, context4);
        let next = false;
        await runtime.commit(async (tx) => {
          const work2 = await facts(tx, ref);
          if (work2.cancelRequested) {
            await release(tx, task.input, task.id);
            return { status: "terminal", outcome: { status: "aborted" } };
          }
          if (settled?.status === "done" && (work2.notes?.length ?? 0) > index + 1) {
            next = true;
            return void 0;
          }
          await release(tx, task.input, task.id);
          return { status: "terminal", outcome: settled?.status === "done" ? { status: "completed", result: { submissionId: submission.id } } : { status: "failed", error: { message: "\u5B50\u4F1A\u8BDD\u672A\u5B8C\u6210\u56DE\u7B54\uFF0C\u540E\u7EED\u8BF4\u660E\u672A\u6267\u884C\uFF1B\u8BF7\u67E5\u8BE2\u539F\u8F93\u5165\u8BB0\u5F55\u3002" }, result: { submissionId: submission.id } } };
        }, context4);
        if (!next) return;
      }
    }
  },
  async abort(task, runtime, context4) {
    await runtime.commit(async (tx) => {
      await occupancy(tx, task.input, task.id);
      (await facts(tx, { ...task.input, taskId: task.id })).cancelRequested = true;
      return void 0;
    }, context4);
    const child = await runtime.conversation(task.input.agentId, context4);
    if (!child) throw new PersonalError("work_agent_missing", "\u53D6\u6D88\u65F6\u627E\u4E0D\u5230\u5B50\u4F1A\u8BDD\uFF0C\u5360\u7528\u4ECD\u4FDD\u7559\uFF1B\u8BF7\u68C0\u67E5\u6863\u6848\u3002");
    await child.abort(context4, { background: true });
    await Promise.all([settleCommands(runtime, task.id, context4, true), settleServices(runtime, task.id, context4, true), settleMcp(runtime, task.id, context4), settleTools(runtime, task.id, context4)]);
    await waitForInspections(runtime, task.id, context4);
    await runtime.commit(async (tx) => {
      await release(tx, task.input, task.id);
      return { status: "terminal", outcome: { status: "aborted" } };
    }, context4);
  }
});
var personalBackgroundWork = defineExtension13({ name: "personal-background-work", tasks: [PersonalWorkTask] });
var personalSubAgent = defineExtension13({ name: "personal-subagent", sections: [section2("subagent", () => "\u4F60\u662F\u4E2A\u4EBA\u52A9\u624B\u7684\u5B50 Agent\uFF0C\u53EA\u5904\u7406\u5F53\u524D\u59D4\u6D3E\u7684\u5DE5\u4F5C\u5E76\u5411\u4E3B Agent \u8FD4\u56DE\u7ED3\u679C\u3002\u5386\u53F2\u4E0A\u4E0B\u6587\u53EF\u4F9B\u53C2\u8003\uFF0C\u4E0D\u4EE3\u8868\u65B0\u5DE5\u4F5C\u7684\u6388\u6743\u3002\u4EC5\u4F7F\u7528\u672C\u8F6E\u63D0\u4F9B\u7684\u5DE5\u5177\uFF0C\u65E0\u6CD5\u518D\u59D4\u6D3E\u6216\u8054\u7CFB\u62E5\u6709\u8005\uFF1B\u9700\u8981\u4E0D\u53EF\u7528\u7684\u5916\u90E8\u64CD\u4F5C\u65F6\u5728\u7ED3\u679C\u4E2D\u8BF4\u660E\u3002\u5916\u90E8\u64CD\u4F5C\u6548\u679C\u6216\u505C\u6B62\u672A\u6838\u5B9E\u65F6\uFF0C\u5BBF\u4E3B\u6682\u505C\u6574\u9879\u59D4\u6258\u7684\u540E\u7EED\u64CD\u4F5C\u5E76\u4FDD\u7559\u5360\u7528\uFF1B\u7531\u62E5\u6709\u8005\u6838\u5B9E\u540E\u6536\u5C3E\uFF0C\u4E0D\u8981\u6362\u65B9\u5F0F\u91CD\u8BD5\u3002", { tag: false })] });
var personalWorkNotes = defineExtension13({ name: "personal-work-notes" });
var noteSubmissionKey = (ref, note) => `personal-work:${ref.taskId}:note:${note.requestId}`;
async function appendPersonalWork(tx, ref, input) {
  if (!input.requestId || input.requestId.length > 256 || !input.content.trim() || Buffer.byteLength(input.content) > 16384) throw new PersonalError("work_input_invalid", "\u8BF7\u8F93\u5165\u975E\u7A7A\u8FFD\u52A0\u8BF4\u660E\uFF0C\u6BCF\u6761\u6700\u591A 16 KiB\u3002\u8BF4\u660E\u53EA\u8865\u5145\u5F53\u524D\u5206\u6790\uFF0C\u4E0D\u6539\u53D8\u6743\u9650\u3002");
  const work = await facts(tx, ref);
  const existing = work.notes?.find((note) => note.requestId === input.requestId);
  if (existing) {
    if (existing.content !== input.content || !isDeepStrictEqual6(existing.source, input.source)) throw new PersonalError("work_request_conflict", "\u540C\u4E00\u8FFD\u52A0\u8BF7\u6C42\u7684\u5185\u5BB9\u6216\u6765\u6E90\u4E0D\u540C\uFF0C\u8BF7\u67E5\u8BE2\u539F\u5DE5\u4F5C\uFF1B\u4E0D\u8981\u6362\u952E\u81EA\u52A8\u91CD\u8BD5\u3002");
    return;
  }
  const task = await tx.task(ref.taskId);
  if (work.cancelRequested || !task || task.state.status === "terminal" || task.state.status === "completing" || task.abortRequested) throw new PersonalError("work_inactive", "\u539F\u5206\u6790\u5DF2\u7ED3\u675F\u6216\u6B63\u5728\u53D6\u6D88\uFF0C\u672A\u63A5\u7EB3\u8BF4\u660E\uFF1B\u8BF7\u67E5\u8BE2\u539F\u5DE5\u4F5C\u540E\u51B3\u5B9A\u4E0B\u4E00\u6B65\u3002");
  await occupancy(tx, { ...ref, content: "" }, ref.taskId);
  if (work.delegation) await requirePersonalDelegationReady(tx, work.delegation);
  if (work.delegation) await requirePersonalDelegationOpen(tx, work.delegation);
  if (work.delegation && input.source.kind === "input") await requirePersonalDelegationInput(tx, work.delegation, input.source.requestId);
  if (input.source.kind === "input") await requirePersonalServiceSourceReady(tx, input.source.requestId);
  if (input.source.kind === "input" && input.source.requestId.startsWith("telegram:")) {
    const receipt3 = (await tx.doc(PersonalTelegramReceiptDoc, input.source.requestId, null)).receipt;
    const source3 = receipt3 && permissionSnapshot(receipt3);
    if (!source3 || !await telegramSourceActive(tx, source3) || receipt3?.submissionId !== input.source.submissionId || source3.botId !== work.telegram?.botId || source3.ownerId !== work.telegram.ownerId || source3.generation !== work.telegram.generation) throw new PersonalError("work_original_entry_required", "\u6B64\u8BF4\u660E\u4E0D\u5C5E\u4E8E\u539F\u62E5\u6709\u8005\u5165\u53E3\uFF0C\u672A\u6539\u53D8\u5DE5\u4F5C\uFF1B\u8BF7\u4ECE\u539F\u5165\u53E3\u67E5\u8BE2\u3002");
  }
  if (work.telegram && !await telegramSourceActive(tx, work.telegram)) throw new PersonalError("work_source_inactive", "\u539F\u62E5\u6709\u8005\u5165\u53E3\u5DF2\u505C\u7528\u6216\u53D8\u66F4\uFF0C\u672A\u63A5\u7EB3\u8BF4\u660E\uFF1B\u8BF7\u67E5\u8BE2\u539F\u5DE5\u4F5C\u3002");
  if (work.source) await requirePersonalServiceSourceReady(tx, work.source.requestId);
  work.notes ??= [];
  const admission = (await tx.appendEntry(PersonalWorkNoteAdmission, ROOT_CONVERSATION_ID13, { data: { ref: { ...ref }, ...input } })).id;
  work.notes.push({ ...input, admission });
}
async function requestPersonalWorkCancel(tx, ref) {
  const work = await facts(tx, ref);
  const task = await tx.task(ref.taskId);
  if (!task) throw new PersonalError("work_task_missing", "\u540E\u53F0\u5DE5\u4F5C\u7684\u6267\u884C\u8BB0\u5F55\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u68C0\u67E5\u5B58\u50A8\u3002");
  if (task.state.status !== "terminal") {
    work.cancelRequested = true;
    for (const op of await personalWorkServices(tx, ref.taskId)) if ((await tx.task(op.ref.taskId))?.state.status !== "terminal") op.cancelRequested = true;
    for (const op of await personalWorkCommands(tx, ref.taskId)) if ((await tx.task(op.ref.taskId))?.state.status !== "terminal") op.cancelRequested = true;
  }
}
async function closePersonalAgent(tx, id2) {
  const agent = (await tx.doc(PersonalAgentsDoc)).agents.find((agent2) => agent2.id === id2);
  if (!agent) throw new PersonalError("subagent_missing", "\u627E\u4E0D\u5230\u6B64\u5B50 Agent\uFF0C\u8BF7\u67E5\u8BE2\u5DF2\u6709\u8EAB\u4EFD\u3002");
  if (agent.work) throw new PersonalError("subagent_busy", "\u5B50 Agent \u4ECD\u88AB\u5DE5\u4F5C\u5360\u7528\uFF0C\u8BF7\u7B49\u5F85\u5B8C\u6210\u6216\u53D6\u6D88\u6838\u5B9E\u540E\u518D\u5173\u95ED\u3002");
  agent.closed = true;
}
async function personalWorkRef(tx, id2) {
  const task = await tx.task(id2);
  const input = task?.input;
  if (task?.kind !== PersonalWorkTask.definition.name || task.conversationId !== ROOT_CONVERSATION_ID13 || !task.background || !input || typeof input !== "object" || Array.isArray(input) || typeof input.requestId !== "string") throw new PersonalError("work_missing", "\u627E\u4E0D\u5230\u6B64\u540E\u53F0\u5DE5\u4F5C\uFF0C\u8BF7\u67E5\u8BE2\u539F\u5DE5\u4F5C\u5217\u8868\u3002");
  const work = await tx.doc(PersonalWorkDoc, input.requestId, null);
  if (work.ref?.requestId !== input.requestId || work.ref.taskId !== id2 || work.ref.agentId !== input.agentId) throw new PersonalError("work_missing", "\u540E\u53F0\u5DE5\u4F5C\u5F52\u5C5E\u7F3A\u5931\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u62A5\u544A\u62E5\u6709\u8005\u68C0\u67E5\u6863\u6848\u3002");
  return { ...work.ref };
}
async function personalWorkStatus(tx, ref) {
  const work = await facts(tx, ref);
  const task = await tx.task(ref.taskId);
  if (!task || task.kind !== PersonalWorkTask.definition.name) throw new PersonalError("work_task_missing", "\u540E\u53F0\u5DE5\u4F5C\u7684\u6267\u884C\u8BB0\u5F55\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u68C0\u67E5\u5B58\u50A8\u3002");
  const agent = (await tx.doc(PersonalAgentsDoc)).agents.find((agent2) => agent2.id === ref.agentId);
  if (!agent) throw new PersonalError("work_agent_missing", "\u540E\u53F0\u5DE5\u4F5C\u7684\u8EAB\u4EFD\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u68C0\u67E5\u5B58\u50A8\u3002");
  const last = work.notes?.at(-1);
  const submission = await tx.submissionByRequest(ref.agentId, last ? noteSubmissionKey(ref, last) : `personal-work:${ref.taskId}`);
  const stopVerified = task.state.status === "terminal" && ["completed", "failed", "aborted"].includes(task.state.outcome.status) && agent.work?.taskId !== ref.taskId;
  return { task, submission, cancelRequested: work.cancelRequested, stopVerified, notes: work.notes?.length ?? 0 };
}
async function personalWorkResult(tx, ref, offset = 0, size = 4096) {
  const { task, submission, cancelRequested } = await personalWorkStatus(tx, ref);
  const state = task.state.status === "terminal" ? task.state.outcome.status : task.state.status;
  if (state !== "completed") return { work: ref.taskId, state, cancelRequested, next: task.state.status === "terminal" ? "\u5DE5\u4F5C\u672A\u6210\u529F\u5B8C\u6210\uFF0C\u540E\u7EED\u5DF2\u63A5\u7EB3\u8BF4\u660E\u672A\u7EE7\u7EED\u6267\u884C\uFF1B\u8BF7\u5411\u62E5\u6709\u8005\u62A5\u544A\uFF0C\u8EAB\u4EFD\u4ECD\u6709\u5360\u7528\u65F6\u4E0D\u8981\u91CD\u8BD5\u6216\u590D\u7528\u3002" : "\u5DE5\u4F5C\u5C1A\u672A\u7ED3\u675F\uFF0C\u8BF7\u7ED3\u675F\u672C\u8F6E\uFF0C\u540E\u7EED\u62E5\u6709\u8005\u8BE2\u95EE\u65F6\u518D\u67E5\u8BE2\u3002" };
  const entry = submission?.status === "done" && submission.type === "input" ? await tx.entry(AssistantEntry2, submission.answer) : void 0;
  const message = entry?.model?.[0];
  if (message?.role !== "assistant") throw new PersonalError("work_answer_missing", "\u539F\u5DE5\u4F5C\u7684\u5B8C\u6574\u56DE\u7B54\u7F3A\u5931\uFF0C\u8BF7\u505C\u6B62\u5F15\u7528\u7ED3\u679C\u5E76\u62A5\u544A\u62E5\u6709\u8005\u68C0\u67E5\u6863\u6848\u3002");
  const text = message.content.filter((part) => part.type === "text").map((part) => part.text).join("");
  let end = Math.min(text.length, offset + size);
  if (end < text.length && /[\ud800-\udbff]/.test(text[end - 1]) && /[\udc00-\udfff]/.test(text[end])) end--;
  return { work: ref.taskId, state, text: text.slice(offset, end), ...end < text.length ? { nextOffset: end } : {} };
}
async function personalWorkSummary(tx, ref) {
  const status = await personalWorkStatus(tx, ref);
  const agent = (await tx.doc(PersonalAgentsDoc)).agents.find((agent2) => agent2.id === ref.agentId);
  const input = status.task.input;
  const content = input && typeof input === "object" && !Array.isArray(input) && input.content;
  if (typeof content !== "string") throw new PersonalError("work_missing", "\u540E\u53F0\u5DE5\u4F5C\u8BF4\u660E\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u68C0\u67E5\u5B58\u50A8\u3002");
  return { ref, label: agent.label, content: content.slice(0, 160), state: status.task.state.status === "terminal" ? status.task.state.outcome.status : status.task.state.status, cancelRequested: status.cancelRequested, stopVerified: status.stopVerified, closed: agent.closed, notes: status.notes };
}
async function listPersonalWorks(tx, offset = 0, source3) {
  const items = [];
  let cursor;
  let skipped = 0;
  do {
    const page = await tx.scanTasks({ kind: PersonalWorkTask.definition.name, order: "descending" }, 64, cursor);
    for (const task of page.items) {
      const ref = await personalWorkRef(tx, task.id);
      const work = await facts(tx, ref);
      if (source3 && (work.telegram?.botId !== source3.botId || work.telegram.ownerId !== source3.ownerId || work.telegram.generation !== source3.generation)) continue;
      if (skipped++ < offset) continue;
      if (items.length === 8) return { items, nextOffset: offset + 8 };
      items.push(await personalWorkSummary(tx, ref));
    }
    cursor = page.next;
  } while (cursor);
  return { items };
}
async function closePersonalWorkAgent(tx, ref) {
  await facts(tx, ref);
  let cursor;
  do {
    const page = await tx.scanTasks({ kind: PersonalWorkTask.definition.name, order: "descending" }, 64, cursor);
    for (const task of page.items) {
      const other = await personalWorkRef(tx, task.id);
      if (other.agentId !== ref.agentId) continue;
      if (other.taskId !== ref.taskId) throw new PersonalError("work_menu_stale", "\u6B64\u8EAB\u4EFD\u5DF2\u627F\u63A5\u540E\u7EED\u5DE5\u4F5C\uFF0C\u8BF7\u91CD\u65B0\u67E5\u8BE2\u5E76\u9009\u62E9\uFF1B\u65E7\u83DC\u5355\u6CA1\u6709\u5173\u95ED\u8EAB\u4EFD\u3002");
      await closePersonalAgent(tx, ref.agentId);
      return;
    }
    cursor = page.next;
  } while (cursor);
  throw new PersonalError("work_missing", "\u540E\u53F0\u5DE5\u4F5C\u8BB0\u5F55\u7F3A\u5931\uFF0C\u672A\u5173\u95ED\u8EAB\u4EFD\uFF1B\u8BF7\u68C0\u67E5\u6863\u6848\u3002");
}

// apps/ruukoto/src/personal-work-controls.ts
var personalWorkControls = defineExtension14({ name: "personal-work-controls" });
var ACTIONS = ["/\u5DE5\u4F5C", "\u66F4\u591A\u5206\u6790", "\u5237\u65B0\u5206\u6790", "\u67E5\u770B\u7ED3\u679C", "\u4E0B\u4E00\u9875\u7ED3\u679C", "\u53D6\u6D88\u8FD9\u9879\u5206\u6790", "\u5173\u95ED\u6B64\u8EAB\u4EFD"];
function personalWorkDescription(value) {
  const states = { pending: "\u7B49\u5F85\u6267\u884C", running: "\u6267\u884C\u4E2D", waiting: "\u7B49\u5F85\u5904\u7406", completing: "\u6B63\u5728\u6536\u5C3E", completed: "\u5DF2\u5B8C\u6210", failed: "\u672A\u6210\u529F\u5B8C\u6210", aborted: "\u5DF2\u53D6\u6D88", faulted: "\u5F02\u5E38\u505C\u6B62\uFF0C\u505C\u6B62\u5C1A\u672A\u6838\u5B9E", orphaned: "\u6267\u884C\u5F52\u5C5E\u5F02\u5E38\uFF0C\u505C\u6B62\u5C1A\u672A\u6838\u5B9E" };
  return `${value.label}\uFF1A${value.content}\uFF1B${states[value.state] ?? "\u72B6\u6001\u65E0\u6CD5\u6838\u5B9E"}${value.cancelRequested && !value.stopVerified ? "\uFF1B\u5DF2\u8BF7\u6C42\u53D6\u6D88\uFF0C\u505C\u6B62\u5F85\u6838\u5B9E" : ""}${value.stopVerified ? "\uFF1B\u505C\u6B62\u5DF2\u6838\u5B9E" : ""}${value.notes ? `\uFF1B\u5DF2\u63A5\u7EB3 ${value.notes} \u6761\u8FFD\u52A0\u8BF4\u660E` : ""}${value.closed ? "\uFF1B\u8EAB\u4EFD\u5DF2\u5173\u95ED" : ""}`;
}
async function originalWork(tx, ref, value) {
  const actual = await personalWorkRef(tx, ref.taskId);
  const source3 = (await tx.doc(PersonalWorkDoc, actual.requestId, null)).telegram;
  if (actual.requestId !== ref.requestId || actual.agentId !== ref.agentId || source3?.botId !== value.botId || source3.ownerId !== value.ownerId || source3.generation !== value.generation) throw new PersonalError("work_original_entry_required", "\u6B64\u5206\u6790\u4E0D\u5C5E\u4E8E\u539F\u62E5\u6709\u8005\u5165\u53E3\uFF0C\u8BF7\u91CD\u65B0\u53D1\u9001 /\u5DE5\u4F5C \u67E5\u8BE2\uFF1B\u6CA1\u6709\u6539\u53D8\u5DE5\u4F5C\u3002");
}
async function telegramWorkControl(tx, value) {
  const choice = /^分析([1-8])$/.exec(value.content);
  if (!choice && !ACTIONS.includes(value.content) && !value.content.startsWith("\u8865\u5145\uFF1A")) return false;
  if (!value.direct) {
    value.reply = "\u8BF7\u7531\u7ED1\u5B9A\u62E5\u6709\u8005\u76F4\u63A5\u53D1\u9001 /\u5DE5\u4F5C\uFF0C\u518D\u56DE\u590D\u5BBF\u4E3B\u83DC\u5355\u9009\u62E9\uFF1B\u8F6C\u53D1\u548C\u5F15\u7528\u6458\u5F55\u4E0D\u80FD\u63A7\u5236\u5DE5\u4F5C\u3002";
    return true;
  }
  try {
    const menu = value.content === "/\u5DE5\u4F5C" ? void 0 : (await telegramSelection(tx, value))?.selection;
    if (value.content === "/\u5DE5\u4F5C" || value.content === "\u66F4\u591A\u5206\u6790" && menu?.kind === "work-list" && menu.nextOffset !== void 0) {
      const page = await listPersonalWorks(tx, menu?.kind === "work-list" ? menu.nextOffset : 0, value);
      value.selection = { kind: "work-list", refs: page.items.map((item) => item.ref), ...page.nextOffset === void 0 ? {} : { nextOffset: page.nextOffset } };
      value.reply = page.items.length ? `\u540E\u53F0\u5206\u6790\uFF08\u5355\u9879\u5DE5\u4F5C\uFF09\uFF1A
${page.items.map((item, index) => `\u5206\u6790${index + 1}\uFF1A${personalWorkDescription(item)}`).join("\n")}
\u56DE\u590D\u672C\u6D88\u606F\u9009\u62E9\u5206\u67901\u81F3\u5206\u6790${page.items.length}${page.nextOffset === void 0 ? "\u3002" : "\uFF0C\u6216\u9009\u62E9\u300C\u66F4\u591A\u5206\u6790\u300D\u3002"}` : "\u539F\u5165\u53E3\u6682\u65E0\u540E\u53F0\u5206\u6790\uFF1B\u4E3B\u804A\u5929\u4ECD\u53EF\u7EE7\u7EED\u3002";
      return true;
    }
    const ref = choice && menu?.kind === "work-list" ? menu.refs[Number(choice[1]) - 1] : menu?.kind === "work" ? menu.ref : void 0;
    if (!ref) {
      value.reply = "\u6CA1\u6709\u6539\u53D8\u5DE5\u4F5C\u3002\u8BF7\u53D1\u9001 /\u5DE5\u4F5C\uFF0C\u518D\u56DE\u590D\u5DF2\u9001\u8FBE\u7684\u5BBF\u4E3B\u83DC\u5355\u9009\u62E9\u5217\u51FA\u7684\u5B8C\u6574\u52A8\u4F5C\u3002";
      return true;
    }
    await originalWork(tx, ref, value);
    value.selection = { kind: "work", ref: { ...ref } };
    if (value.content.startsWith("\u8865\u5145\uFF1A")) {
      await appendPersonalWork(tx, ref, { requestId: value.requestId, content: value.content.slice(3), source: { kind: "telegram" } });
      value.reply = "\u539F\u5206\u6790\u5DF2\u63A5\u7EB3\u8BF4\u660E\uFF0C\u5C06\u5728\u5F53\u524D\u56DE\u7B54\u7ED3\u675F\u540E\u6309\u987A\u5E8F\u5904\u7406\uFF1B\u539F\u6743\u9650\u4FDD\u6301\u3002\u56DE\u590D\u300C\u5237\u65B0\u5206\u6790\u300D\u67E5\u8BE2\u72B6\u6001\u3002";
    } else if (value.content === "\u53D6\u6D88\u8FD9\u9879\u5206\u6790") {
      await requestPersonalWorkCancel(tx, ref);
      value.reply = "\u5DF2\u767B\u8BB0\u6B64\u5206\u6790\u7684\u53D6\u6D88\u8BF7\u6C42\uFF1B\u505C\u6B62\u4ECD\u987B\u6838\u5B9E\u3002\u56DE\u590D\u300C\u5237\u65B0\u5206\u6790\u300D\u67E5\u8BE2\u539F\u5DE5\u4F5C\uFF0C\u8EAB\u4EFD\u548C\u5386\u53F2\u4FDD\u7559\u3002";
    } else if (value.content === "\u5173\u95ED\u6B64\u8EAB\u4EFD") {
      await closePersonalWorkAgent(tx, ref);
      value.reply = "\u6B64\u7A7A\u95F2\u8EAB\u4EFD\u5DF2\u5173\u95ED\uFF0C\u539F\u5DE5\u4F5C\u5386\u53F2\u4ECD\u4FDD\u7559\u3002";
    } else if (value.content === "\u67E5\u770B\u7ED3\u679C" || value.content === "\u4E0B\u4E00\u9875\u7ED3\u679C") {
      if (value.content === "\u4E0B\u4E00\u9875\u7ED3\u679C" && (menu?.kind !== "work" || menu.nextOffset === void 0)) {
        value.reply = "\u6B64\u83DC\u5355\u6CA1\u6709\u4E0B\u4E00\u9875\u7ED3\u679C\uFF0C\u8BF7\u56DE\u590D\u300C\u67E5\u770B\u7ED3\u679C\u300D\u4ECE\u539F\u56DE\u7B54\u5F00\u59CB\u8BFB\u53D6\u3002";
        return true;
      }
      const offset = value.content === "\u4E0B\u4E00\u9875\u7ED3\u679C" && menu?.kind === "work" ? menu.nextOffset : 0;
      const result = await personalWorkResult(tx, ref, offset, 2400);
      if (result.text === void 0) value.reply = `${personalWorkDescription(await personalWorkSummary(tx, ref))}\u3002\u539F\u5DE5\u4F5C\u6CA1\u6709\u6210\u529F\u5B8C\u6210\u7684\u56DE\u7B54\uFF0C\u8BF7\u7A0D\u540E\u5237\u65B0\u72B6\u6001\uFF1B\u505C\u6B62\u672A\u6838\u5B9E\u524D\u4E0D\u8981\u590D\u7528\u8EAB\u4EFD\u3002`;
      else {
        if (result.nextOffset !== void 0) value.selection.nextOffset = result.nextOffset;
        value.reply = `\u539F\u5206\u6790\u7ED3\u679C\uFF1A
${result.text || "\uFF08\u65E0\u6587\u672C\u5185\u5BB9\uFF09"}${result.nextOffset === void 0 ? "\n\u539F\u56DE\u7B54\u5DF2\u8BFB\u5B8C\u3002" : "\n\u56DE\u590D\u672C\u6D88\u606F\u9009\u62E9\u300C\u4E0B\u4E00\u9875\u7ED3\u679C\u300D\u7EE7\u7EED\u3002"}`;
      }
    } else value.reply = `${personalWorkDescription(await personalWorkSummary(tx, ref))}\u3002\u56DE\u590D\u672C\u6D88\u606F\u9009\u62E9\uFF1A\u5237\u65B0\u5206\u6790\u3001\u67E5\u770B\u7ED3\u679C\u3001\u53D6\u6D88\u8FD9\u9879\u5206\u6790\u3001\u5173\u95ED\u6B64\u8EAB\u4EFD\uFF1B\u8FFD\u52A0\u8BF4\u660E\u8BF7\u56DE\u590D\u300C\u8865\u5145\uFF1A\u6B63\u6587\u300D\uFF0C\u5728\u5F53\u524D\u56DE\u7B54\u7ED3\u675F\u540E\u5904\u7406\u3002\u5173\u95ED\u53EA\u9002\u7528\u672A\u518D\u590D\u7528\u4E14\u7A7A\u95F2\u7684\u8EAB\u4EFD\u3002`;
  } catch (error) {
    if (!(error instanceof PersonalError)) throw error;
    delete value.selection;
    value.reply = `${error.message} \u8BF7\u53D1\u9001 /\u5DE5\u4F5C \u67E5\u8BE2\u5F53\u524D\u8BB0\u5F55\u3002`;
  }
  return true;
}
function personalDelegationDescription(value) {
  const states = { active: "\u5206\u6790\u4E2D", idle: "\u5206\u6790\u7A7A\u95F2\uFF0C\u53EF\u7EE7\u7EED\u539F\u59D4\u6258\uFF1B\u5C1A\u672A\u5B89\u6392\u6C47\u603B", reporting: "\u5DF2\u5C01\u7EC4\uFF0C\u7B49\u5F85\u6210\u5458\u6216\u4E3B Agent \u6C47\u603B", reported: "\u62A5\u544A\u5904\u7406\u5DF2\u7ED3\u675F\uFF0C\u8BF7\u6838\u5BF9\u9001\u8FBE\u72B6\u6001", report_failed: "\u62A5\u544A\u672A\u5B8C\u6210\uFF0C\u8BF7\u67E5\u770B\u539F\u62A5\u544A\u72B6\u6001", canceling: "\u53D6\u6D88\u5DF2\u767B\u8BB0\uFF0C\u6B63\u5728\u6838\u5B9E\u505C\u6B62", canceled: "\u6574\u9879\u5206\u6790\u5DF2\u53D6\u6D88\uFF0C\u505C\u6B62\u5DF2\u6838\u5B9E", stop_unverified: "\u505C\u6B62\u5C1A\u672A\u6838\u5B9E\uFF0C\u8BF7\u68C0\u67E5\u539F\u5DE5\u4F5C", paused: "\u670D\u52A1\u6548\u679C\u5F85\u6838\u5B9E\uFF0C\u5206\u6790\u59D4\u6258\u6682\u505C" };
  return `${value.content}\uFF1B${states[value.state] ?? "\u72B6\u6001\u65E0\u6CD5\u6838\u5B9E"}\uFF1B\u5171 ${value.total} \u9879\uFF0C\u6D3B\u52A8 ${value.active} \u9879\uFF0C\u505C\u6B62\u672A\u6838\u5B9E ${value.unverified} \u9879${value.paused && value.state !== "paused" ? "\uFF1B\u539F\u670D\u52A1\u6548\u679C\u5F85\u6838\u5B9E" : ""}${value.report ? `\uFF1B${personalReportDelivery(value.report.delivery)}` : ""}`;
}
function personalReportDelivery(delivery) {
  return { not_requested: "\u5C1A\u672A\u5B89\u6392\u6700\u7EC8\u6C47\u603B", waiting: "\u62A5\u544A\u7B49\u5F85\u4E2D", local: "\u5B8C\u6574\u62A5\u544A\u5DF2\u4FDD\u5B58\u672C\u673A", pending: "\u62A5\u544A\u7B49\u5F85\u53D1\u9001", sending: "\u62A5\u544A\u53D1\u9001\u5DF2\u5F00\u59CB\uFF0C\u7ED3\u679C\u5F85\u6838\u5B9E", sent: "\u62A5\u544A\u5DF2\u9001\u8FBE\u539F\u5165\u53E3", failed: "\u62A5\u544A\u660E\u786E\u672A\u53D1\u9001\uFF0C\u8BF7\u67E5\u8BE2\u539F\u62A5\u544A", effect_unknown: "\u62A5\u544A\u53D1\u9001\u6548\u679C\u672A\u77E5\uFF0C\u672A\u81EA\u52A8\u91CD\u53D1\uFF1B\u8BF7\u5728\u539F\u5E73\u53F0\u6838\u5B9E", canceled: "\u62A5\u544A\u5DF2\u53D6\u6D88\uFF1B\u5DF2\u5F00\u59CB\u7684\u53D1\u9001\u53E6\u6309\u539F\u6548\u679C\u8BB0\u5F55", blocked: "\u505C\u6B62\u672A\u6838\u5B9E\uFF0C\u62A5\u544A\u672A\u751F\u6210", unanswered: "\u4E3B Agent \u672A\u5B8C\u6210\u62A5\u544A\uFF0C\u672A\u5916\u53D1\uFF1B\u8BF7\u67E5\u770B\u539F\u59D4\u6258" }[delivery] ?? "\u62A5\u544A\u72B6\u6001\u65E0\u6CD5\u6838\u5B9E\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848";
}
async function originalDelegation(tx, ref, input) {
  const source3 = (await personalDelegation(tx, ref)).telegram;
  if (source3?.botId !== input.botId || source3.ownerId !== input.ownerId || source3.generation !== input.generation) throw new PersonalError("delegation_original_entry", "\u59D4\u6258\u4E0D\u5C5E\u4E8E\u539F\u62E5\u6709\u8005\u5165\u53E3\uFF0C\u672A\u6539\u53D8\u5DE5\u4F5C\uFF1B\u8BF7\u53D1\u9001 /\u59D4\u6258 \u67E5\u8BE2\u3002");
}
async function telegramDelegationControl(tx, value) {
  const choice = /^委托([1-8])$/.exec(value.content);
  if (!choice && !["/\u59D4\u6258", "\u66F4\u591A\u59D4\u6258", "\u5237\u65B0\u59D4\u6258", "\u4E0B\u4E00\u9875\u5206\u6790", "\u53D6\u6D88\u6574\u9879\u5206\u6790", "\u67E5\u770B\u62A5\u544A", "\u4E0B\u4E00\u9875\u62A5\u544A"].includes(value.content)) return false;
  if (!value.direct) {
    value.reply = "\u8BF7\u76F4\u63A5\u53D1\u9001 /\u59D4\u6258\uFF0C\u518D\u56DE\u590D\u5DF2\u9001\u8FBE\u5BBF\u4E3B\u83DC\u5355\uFF1B\u8F6C\u53D1\u548C\u5F15\u7528\u6458\u5F55\u4E0D\u80FD\u63A7\u5236\u59D4\u6258\u3002";
    return true;
  }
  try {
    const menu = value.content === "/\u59D4\u6258" ? void 0 : (await telegramSelection(tx, value))?.selection;
    if (value.content === "/\u59D4\u6258" || value.content === "\u66F4\u591A\u59D4\u6258" && menu?.kind === "delegation-list" && menu.nextOffset !== void 0) {
      const offset2 = menu?.kind === "delegation-list" ? menu.nextOffset : 0;
      const page = await listPersonalDelegations(tx, offset2, value);
      value.selection = { kind: "delegation-list", refs: page.items.map((item) => item.ref), ...page.more ? { nextOffset: offset2 + 8 } : {} };
      value.reply = page.items.length ? `\u5206\u6790\u59D4\u6258\uFF1A
${page.items.map((item, i) => `\u59D4\u6258${i + 1}\uFF1A${personalDelegationDescription(item)}`).join("\n")}
\u56DE\u590D\u672C\u6D88\u606F\u9009\u62E9\u59D4\u62581\u81F3\u59D4\u6258${page.items.length}${page.more ? "\uFF0C\u6216\u9009\u62E9\u300C\u66F4\u591A\u59D4\u6258\u300D\u3002" : "\u3002"}` : "\u539F\u5165\u53E3\u6682\u65E0\u5206\u6790\u59D4\u6258\uFF1B\u5386\u53F2\u5355\u9879\u5206\u6790\u4ECD\u53EF\u901A\u8FC7 /\u5DE5\u4F5C \u67E5\u8BE2\u3002";
      return true;
    }
    const ref = choice && menu?.kind === "delegation-list" ? menu.refs[Number(choice[1]) - 1] : menu?.kind === "delegation" ? menu.ref : void 0;
    if (!ref || value.content === "\u4E0B\u4E00\u9875\u5206\u6790" && (menu?.kind !== "delegation" || menu.nextOffset === void 0)) {
      value.reply = "\u6CA1\u6709\u6539\u53D8\u59D4\u6258\u3002\u8BF7\u53D1\u9001 /\u59D4\u6258\uFF0C\u518D\u56DE\u590D\u5DF2\u9001\u8FBE\u5BBF\u4E3B\u83DC\u5355\u9009\u62E9\u5217\u51FA\u7684\u52A8\u4F5C\u3002";
      return true;
    }
    await originalDelegation(tx, ref, value);
    if (value.content === "\u67E5\u770B\u62A5\u544A" || value.content === "\u4E0B\u4E00\u9875\u62A5\u544A") {
      if (value.content === "\u4E0B\u4E00\u9875\u62A5\u544A" && (menu?.kind !== "delegation" || menu.reportNextOffset === void 0)) {
        value.reply = "\u5F53\u524D\u83DC\u5355\u6CA1\u6709\u4E0B\u4E00\u9875\u62A5\u544A\uFF0C\u8BF7\u56DE\u590D\u300C\u67E5\u770B\u62A5\u544A\u300D\u4ECE\u5934\u8BFB\u53D6\u3002";
        return true;
      }
      const report = await personalReportResult(tx, ref, value.content === "\u4E0B\u4E00\u9875\u62A5\u544A" && menu?.kind === "delegation" ? menu.reportNextOffset : 0, 2400);
      value.selection = { kind: "delegation", ref, ...report.nextOffset === void 0 ? {} : { reportNextOffset: report.nextOffset } };
      value.reply = `${personalReportDelivery(report.delivery)}\u3002${report.text === void 0 ? "" : `
${report.text || "\uFF08\u65E0\u6587\u672C\u5185\u5BB9\uFF09"}`}${report.nextOffset === void 0 ? "\n\u56DE\u590D\u300C\u5237\u65B0\u59D4\u6258\u300D\u67E5\u8BE2\u6210\u5458\u3002" : "\n\u56DE\u590D\u300C\u4E0B\u4E00\u9875\u62A5\u544A\u300D\u7EE7\u7EED\u3002"}`;
      return true;
    }
    const offset = value.content === "\u4E0B\u4E00\u9875\u5206\u6790" && menu?.kind === "delegation" ? menu.nextOffset : 0;
    const progress = await personalDelegationProgress(tx, ref, offset);
    if (value.content === "\u53D6\u6D88\u6574\u9879\u5206\u6790") {
      await cancelPersonalDelegation(tx, ref);
      progress.cancelRequested = true;
      progress.state = progress.unverified ? "stop_unverified" : progress.active ? "canceling" : "canceled";
    }
    value.selection = { kind: "delegation", ref, ...progress.nextOffset === void 0 ? {} : { nextOffset: progress.nextOffset } };
    value.reply = `${personalDelegationDescription(progress)}\u3002
${progress.members.map(personalWorkDescription).join("\n")}
\u56DE\u590D\u672C\u6D88\u606F\u9009\u62E9\uFF1A\u5237\u65B0\u59D4\u6258\u3001\u67E5\u770B\u62A5\u544A\u3001\u53D6\u6D88\u6574\u9879\u5206\u6790${progress.nextOffset === void 0 ? "" : "\u3001\u4E0B\u4E00\u9875\u5206\u6790"}\u3002\u53D6\u6D88\u8986\u76D6\u6240\u5C5E\u5206\u6790\u6210\u5458\u3001\u5176\u56FA\u5B9A\u670D\u52A1\u68C0\u67E5\u3001\u670D\u52A1\u91CD\u542F\u53CA\u5C1A\u672A\u5F00\u59CB\u7684\u6700\u7EC8\u56DE\u62A5\uFF0C\u4E0D\u5173\u95ED\u8EAB\u4EFD\uFF0C\u4E0D\u5305\u542B\u72EC\u7ACB\u5BBF\u4E3B\u670D\u52A1\u5199\u64CD\u4F5C\u3002\u5C01\u7EC4\u540E\u4E0D\u80FD\u7EED\u6D3E\u6216\u8FFD\u52A0\uFF1B\u672A\u5C01\u7EC4\u65F6\u5355\u9879\u7ED3\u679C\u4E0E\u8FFD\u52A0\u8BF4\u660E\u8BF7\u53D1\u9001 /\u5DE5\u4F5C \u9009\u62E9\u3002`;
  } catch (error) {
    if (!(error instanceof PersonalError)) throw error;
    delete value.selection;
    value.reply = `${error.message} \u8BF7\u53D1\u9001 /\u59D4\u6258 \u67E5\u8BE2\u3002`;
  }
  return true;
}

// apps/ruukoto/src/personal-telegram.ts
var context2 = BACKGROUND_CONTEXT13;
var TASK = "ruukoto.telegram-input";
async function receipt(tx, requestId, taskId) {
  const value = (await tx.doc(PersonalTelegramReceiptDoc, requestId, null)).receipt;
  if (!value || value.taskId !== taskId || value.requestId !== requestId) throw new PersonalError("telegram_receipt_missing", "Telegram \u6536\u4EF6\u4E0E\u6267\u884C\u8BB0\u5F55\u4E0D\u7B26\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u68C0\u67E5\u3002");
  return value;
}
function active(config, value) {
  return config?.enabled === true && config.generation === value.generation && config.botId === value.botId && config.ownerId === value.ownerId;
}
function personalTelegram(config, api, control, media) {
  const task = defineTask7({
    name: TASK,
    version: 1,
    initial: () => ({ phase: "run" }),
    phases: {
      async run(current, runtime, context4) {
        const value = await runtime.snapshot(PersonalTelegramReceiptDoc, current.input.requestId, context4);
        if (!value?.receipt || value.receipt.taskId !== current.id) throw new PersonalError("telegram_receipt_missing", "Telegram \u6536\u4EF6\u6765\u6E90\u7F3A\u5931\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u68C0\u67E5\u6863\u6848\u3002");
        let allowed = false;
        await runtime.commit(async (tx) => {
          const value2 = await receipt(tx, current.input.requestId, current.id);
          allowed = active((await tx.doc(PersonalTelegramDoc)).config, value2);
          if (!allowed) {
            value2.delivery = "canceled";
            return { status: "terminal", outcome: { status: "completed", result: { delivery: value2.delivery } } };
          }
          return void 0;
        }, context4);
        if (!allowed) return;
        if (value.receipt.media && !media) throw new PersonalError("media_config_missing", "\u539F\u56FE\u7247\u5904\u7406\u6A21\u5757\u4E0D\u53EF\u7528\uFF0C\u672A\u53D1\u9001\u7F3A\u56FE\u8BF7\u6C42\uFF1B\u8BF7\u6062\u590D\u5BF9\u5E94\u7A0B\u5E8F\u3002");
        const currentMedia = value.receipt.media ? await media.message(value.receipt.media.key) : void 0;
        if (value.receipt.media && !currentMedia) throw new PersonalError("image_reference_invalid", "\u539F\u56FE\u7247\u63A5\u6536\u8BB0\u5F55\u7F3A\u5931\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
        if (value.receipt.mediaRejected || currentMedia && ["rejected", "expired"].includes(currentMedia.state) || value.receipt.media && !media.supportsImages()) {
          const reason = currentMedia?.reason ?? "image_input_unsupported";
          if (value.receipt.media && currentMedia?.state === "ready") await media.reject(value.receipt.media.key, reason);
          await runtime.commit(async (tx) => {
            const value2 = await receipt(tx, current.input.requestId, current.id);
            value2.reply = personalMediaRejection(reason);
            value2.mediaRejected = true;
            delete value2.permission;
            value2.delivery = "pending";
            return { status: "running", checkpoint: { phase: "send" } };
          }, context4);
          return;
        }
        if (value.receipt.control) {
          await runtime.commit(async (tx) => {
            (await receipt(tx, current.input.requestId, current.id)).delivery = "pending";
            return { status: "running", checkpoint: { phase: "send" } };
          }, context4);
          return;
        }
        const main = await runtime.conversation(ROOT_CONVERSATION_ID14, context4);
        if (!main) throw new PersonalError("telegram_main_missing", "Telegram \u4E3B\u4F1A\u8BDD\u7F3A\u5931\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
        const submission = await main.submit({ type: "input", content: value.receipt.media ? await media.input(value.receipt.media.key) : value.receipt.content, requestId: current.input.requestId, whenBusy: "followUp" }, context4);
        await runtime.commit(async (tx) => {
          const receipt3 = (await tx.doc(PersonalTelegramReceiptDoc, current.input.requestId, null)).receipt;
          if (!receipt3 || receipt3.taskId !== current.id) throw new PersonalError("telegram_receipt_missing", "\u539F\u6536\u4EF6\u8BB0\u5F55\u7F3A\u5931\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
          receipt3.submissionId = submission.id;
          if (receipt3.media) await media.bind(tx, receipt3.media.key, submission.id);
          return void 0;
        }, context4);
        const settled = await submission.wait(context4);
        const entry = settled.status === "done" && settled.type === "input" ? await runtime.entry(AssistantEntry3, settled.answer, context4) : void 0;
        const message = entry?.model?.[0];
        if (settled.status === "done" && message?.role !== "assistant") throw new PersonalError("telegram_answer_missing", "Telegram \u539F\u8F93\u5165\u7684\u5B8C\u6574\u56DE\u7B54\u7F3A\u5931\uFF0C\u672A\u53D1\u9001\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
        const answer = message?.role === "assistant" ? message.content.filter((part) => part.type === "text").map((part) => part.text).join("") : void 0;
        await runtime.commit(async (tx) => {
          const value2 = await receipt(tx, current.input.requestId, current.id);
          if (!active((await tx.doc(PersonalTelegramDoc)).config, value2) || answer === void 0) {
            value2.delivery = answer === void 0 ? "unanswered" : "canceled";
            return { status: "terminal", outcome: { status: "completed", result: { delivery: value2.delivery } } };
          }
          const characters = Array.from(answer);
          value2.reply = characters.length > 3900 ? characters.slice(0, 3900).join("") + "\u2026\uFF08\u663E\u793A\u5DF2\u622A\u65AD\uFF0C\u5B8C\u6574\u56DE\u7B54\u4FDD\u7559\u5728\u4E2A\u4EBA\u4F1A\u8BDD\u4E2D\uFF09" : answer || "\u672C\u6B21\u56DE\u7B54\u6CA1\u6709\u6587\u672C\u5185\u5BB9\uFF0C\u8BF7\u4ECE\u672C\u673A\u5411\u5BFC\u67E5\u770B\u4F1A\u8BDD\u72B6\u6001\u3002";
          value2.delivery = "pending";
          return { status: "running", checkpoint: { phase: "send" } };
        }, context4);
      },
      async send(current, runtime, context4) {
        if (current.state.checkpoint.retryAt) await runtime.sleep(current.state.checkpoint.retryAt, context4);
        let target;
        await runtime.commit(async (tx) => {
          const value = await receipt(tx, current.input.requestId, current.id);
          if (!active((await tx.doc(PersonalTelegramDoc)).config, value)) {
            value.delivery = "canceled";
            return { status: "terminal", outcome: { status: "completed", result: { delivery: value.delivery } } };
          }
          if (value.delivery !== "pending" || !value.reply || !active(config, value) || !api) throw new PersonalError("telegram_send_invalid", "Telegram \u56FA\u5B9A\u53D1\u9001\u8BB0\u5F55\u6216\u5165\u53E3\u65E0\u6CD5\u6838\u5B9E\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
          value.delivery = "sending";
          target = { ...value };
          return { status: "running", checkpoint: { phase: "verify" } };
        }, context4);
        if (!target) return;
        let platformMessageId;
        let failure;
        try {
          platformMessageId = await api.send(target.ownerId, target.messageId, target.reply, runtime.signal);
        } catch (error) {
          if (!(error instanceof PersonalTelegramApiError)) throw error;
          failure = error;
        }
        await runtime.commit(async (tx) => {
          const value = await receipt(tx, current.input.requestId, current.id);
          if (failure?.retryAfterMs) {
            value.delivery = "pending";
            return { status: "running", checkpoint: { phase: "send", retryAt: runtime.now() + failure.retryAfterMs } };
          }
          value.delivery = platformMessageId ? "sent" : failure?.effect === "not_sent" ? "failed" : "effect_unknown";
          if (platformMessageId) value.platformMessageId = platformMessageId;
          return { status: "terminal", outcome: { status: "completed", result: { delivery: value.delivery } } };
        }, context4);
      },
      async verify(current, runtime, context4) {
        await runtime.commit(async (tx) => {
          const value = await receipt(tx, current.input.requestId, current.id);
          value.delivery = "effect_unknown";
          return { status: "terminal", outcome: { status: "completed", result: { delivery: value.delivery } } };
        }, context4);
      }
    },
    async abort(current, runtime, context4) {
      await runtime.commit(async (tx) => {
        const value = await receipt(tx, current.input.requestId, current.id);
        value.delivery = value.delivery === "sending" ? "effect_unknown" : "canceled";
        return { status: "terminal", outcome: { status: "aborted", result: { delivery: value.delivery } } };
      }, context4);
    }
  });
  const extension = defineExtension15({ name: "personal-telegram", tasks: [task] });
  return {
    extension,
    api(harness) {
      let receiving = false;
      let online = false;
      const receive = async (update, signal) => {
        const message = telegramMessage(update);
        const key = message && config ? `telegram:${config.botId}:${message.ownerId}:${message.id}` : void 0;
        let staged;
        if (message?.media && message.ownerId === config?.ownerId && key) {
          if (!media || !api) throw new PersonalError("media_config_missing", "\u56FE\u7247\u5904\u7406\u6A21\u5757\u4E0D\u53EF\u7528\uFF0C\u6536\u4EF6\u672A\u786E\u8BA4\uFF1B\u8BF7\u68C0\u67E5\u7A0B\u5E8F\u914D\u7F6E\u3002");
          await harness.commit(async (tx) => {
            if (!config.enabled || !isDeepStrictEqual7((await tx.doc(PersonalTelegramDoc)).config, config)) throw new PersonalError("telegram_target_changed", "Telegram \u5165\u53E3\u5DF2\u53D8\u5316\uFF0C\u672A\u63A5\u7EB3\u56FE\u7247\u3002");
          }, context2);
          const prior = (await harness.snapshot(PersonalTelegramReceiptDoc, key, context2))?.receipt;
          const priorMedia = await media.message(key);
          if (prior && prior.generation !== config.generation || priorMedia && priorMedia.source.generation !== config.generation) {
            await harness.commit(async (tx) => {
              const state = await tx.doc(PersonalTelegramDoc);
              state.rejected++;
              state.lastUpdateId = update.update_id;
            }, context2);
            return;
          }
          staged = await media.stage({ key, source: { platform: "telegram", accountId: config.botId, ownerId: config.ownerId, generation: config.generation }, body: message.text, media: message.media.map((value) => api.photo(value)) }, signal);
        }
        await harness.commit(async (tx) => {
          const state = await tx.doc(PersonalTelegramDoc);
          if (!config?.enabled || !isDeepStrictEqual7(state.config, config)) throw new PersonalError("telegram_target_changed", "Telegram \u5165\u53E3\u914D\u7F6E\u5DF2\u5931\u6548\uFF0C\u5DF2\u505C\u6B62\u6536\u4EF6\uFF1B\u8BF7\u68C0\u67E5\u5F53\u524D\u914D\u7F6E\u3002");
          state.lastUpdateId = update.update_id;
          if (!message || message.ownerId !== config.ownerId || !key) {
            state.rejected++;
            return;
          }
          const record = await tx.doc(PersonalTelegramReceiptDoc, key, null);
          if (record.receipt) {
            if (record.receipt.content !== message.text || !isDeepStrictEqual7(record.receipt.media?.identities, message.media?.map((value2) => value2.identity)) || record.receipt.direct !== void 0 && (record.receipt.direct !== message.direct || record.receipt.replyTo !== message.replyTo || record.receipt.replyBotId !== message.replyBotId)) throw new PersonalError("telegram_input_conflict", "Telegram \u540C\u4E00\u6D88\u606F\u7684\u6B63\u6587\u4E0D\u7B26\uFF0C\u5DF2\u505C\u6B62\u63A5\u6536\uFF1B\u8BF7\u4FDD\u7559\u6863\u6848\u5E76\u68C0\u67E5\u3002");
            return;
          }
          const value = { requestId: key, generation: config.generation, botId: config.botId, ownerId: config.ownerId, messageId: message.id, updateId: update.update_id, content: message.text, direct: message.direct, ...message.replyTo === void 0 ? {} : { replyTo: message.replyTo }, ...message.replyBotId === void 0 ? {} : { replyBotId: message.replyBotId }, delivery: "waiting" };
          if (staged) {
            value.media = { key, identities: staged.identities };
            if (staged.state === "rejected" || staged.state === "expired") {
              value.mediaRejected = true;
              value.reply = personalMediaRejection(staged.reason);
            } else if (message.direct) {
              const permission = await tx.doc(PersonalPermissionsDoc);
              value.permission = { mode: permission.mode, version: permission.version };
            }
          } else if (await telegramPermissionControl(tx, value) || await telegramWorkControl(tx, value) || await telegramDelegationControl(tx, value) || await control?.(tx, value)) value.control = true;
          else if (TELEGRAM_SERVICE_ACTIONS.includes(value.content)) {
            value.control = true;
            value.reply = "\u5F53\u524D\u5BBF\u4E3B\u672A\u542F\u7528\u670D\u52A1\u64CD\u4F5C\uFF1B\u8BF7\u7531\u62E5\u6709\u8005\u6838\u5B9E\u670D\u52A1\u914D\u7F6E\uFF0C\u804A\u5929\u4ECD\u53EF\u7EE7\u7EED\u3002";
          } else if (message.direct) {
            const permission = await tx.doc(PersonalPermissionsDoc);
            value.permission = { mode: permission.mode, version: permission.version };
          }
          value.accepted = staged?.accepted ?? (await tx.appendEntry(ROOT_CONVERSATION_ID14, { kind: "ruukoto.telegram-received", data: { requestId: key, generation: config.generation } })).id;
          const taskId = await tx.createTask(task, { requestId: key }, { conversationId: ROOT_CONVERSATION_ID14, ownership: { kind: "conversation" }, background: true });
          record.receipt = { ...value, taskId };
        }, context2);
        harness.resume();
      };
      return {
        receive,
        async poll(signal) {
          if (!api || !config?.enabled) return;
          if (receiving) throw new PersonalError("telegram_poll_busy", "Telegram \u6536\u4EF6\u5FAA\u73AF\u5DF2\u542F\u52A8\uFF0C\u8BF7\u4F7F\u7528\u5F53\u524D\u540E\u53F0\u8FDE\u63A5\u3002");
          receiving = true;
          let ack;
          let backoff = 1e3;
          try {
            while (!signal.aborted) {
              const offset = telegramOffset(ack);
              ack = void 0;
              try {
                const updates = await api.updates(signal, offset);
                online = true;
                const receivedAt = performance.now();
                for (const update of updates) {
                  if (signal.aborted) return;
                  await receive(update, signal);
                }
                if (updates.length) ack = { offset: updates[updates.length - 1].update_id + 1, receivedAt };
                backoff = 1e3;
              } catch (error) {
                if (signal.aborted) return;
                online = false;
                if (!(error instanceof PersonalTelegramApiError)) throw error;
                process.stderr.write("[ruukoto:personal] Telegram \u63A5\u6536\u6682\u4E0D\u53EF\u7528\uFF0C\u6536\u4EF6\u672A\u786E\u8BA4\uFF0C\u6B63\u5728\u7B49\u5F85\u6062\u590D\uFF1B\u8BF7\u68C0\u67E5\u5165\u53E3\u72B6\u6001\u3002\n");
                await new Promise((resolve3) => {
                  const done = () => {
                    clearTimeout(timer);
                    signal.removeEventListener("abort", done);
                    resolve3();
                  };
                  const timer = setTimeout(done, error.retryAfterMs ?? backoff);
                  signal.addEventListener("abort", done, { once: true });
                });
                backoff = Math.min(backoff * 2, 3e4);
              }
            }
          } finally {
            receiving = false;
            online = false;
          }
        },
        async status() {
          return harness.commit(async (tx) => {
            const state = await tx.doc(PersonalTelegramDoc);
            const page = await tx.scanTasks({ kind: TASK, order: "descending" }, 16);
            const recent = [];
            for (const current of page.items) {
              const key = current.input && typeof current.input === "object" && !Array.isArray(current.input) && current.input.requestId;
              if (typeof key !== "string") throw new PersonalError("telegram_receipt_missing", "Telegram \u6267\u884C\u7F3A\u5C11\u6536\u4EF6\u5F15\u7528\uFF0C\u8BF7\u4FDD\u7559\u6863\u6848\u3002");
              const value = await receipt(tx, key, current.id);
              recent.push({ input: value.content.slice(0, 160), delivery: value.delivery });
            }
            return { enabled: state.config?.enabled ?? false, receiving, online, rejected: state.rejected, recent };
          }, context2);
        }
      };
    }
  };
}

// test/personal-media.test.ts
import { openNodeSqliteStorage as openNodeSqliteStorage5 } from "@earendil-works/pi-durable/storage/sqlite/node";

// test/helpers/mock-provider.ts
import * as http from "node:http";
var CHUNK_ID = "chatcmpl-mock";
var CREATED = 17e8;
function chunk(model, delta, finishReason) {
  return {
    id: CHUNK_ID,
    object: "chat.completion.chunk",
    created: CREATED,
    model,
    choices: [{ index: 0, delta, finish_reason: finishReason }]
  };
}
function usageChunk(model, promptTokens, completionTokens) {
  return {
    id: CHUNK_ID,
    object: "chat.completion.chunk",
    created: CREATED,
    model,
    choices: [],
    usage: {
      prompt_tokens: promptTokens,
      completion_tokens: completionTokens,
      total_tokens: promptTokens + completionTokens
    }
  };
}
function extract(body) {
  const messages = Array.isArray(body?.messages) ? body.messages : [];
  const system = messages.find((m) => m.role === "system" || m.role === "developer") ?? null;
  const rest = messages.filter((m) => m !== system);
  return {
    messages: rest,
    tools: Array.isArray(body?.tools) ? body.tools : void 0,
    system: system ? system.content ?? null : null,
    raw: body
  };
}
function sseBody(responses) {
  return responses.map((r) => `data: ${r}

`).join("") + "data: [DONE]\n\n";
}
var MockModelServer = class {
  server;
  respond;
  counter = 0;
  /** 每次模型调用收到的一份输入（按调用顺序）。 */
  calls = [];
  constructor(responder) {
    this.respond = responder;
    this.server = http.createServer(async (req, res) => {
      res.on("error", () => {
      });
      const chunks = [];
      req.on("data", (c) => chunks.push(c));
      req.on("end", async () => {
        try {
          const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
          const recorded = extract(body);
          this.calls.push(recorded);
          const scripted = await this.respond(recorded, this.counter++);
          const out = [];
          out.push(JSON.stringify(chunk("mock-model", { role: "assistant", content: "" }, null)));
          if (scripted.kind === "text") {
            for (const piece of scripted.text.match(/.{1,16}/gs) ?? []) {
              out.push(JSON.stringify(chunk("mock-model", { content: piece }, null)));
            }
            out.push(JSON.stringify(chunk("mock-model", {}, scripted.finishReason ?? "stop")));
          } else {
            for (const [index, call] of scripted.calls.entries()) {
              const delta = {
                tool_calls: [
                  {
                    index,
                    id: call.id,
                    type: "function",
                    function: { name: call.name, arguments: JSON.stringify(call.arguments) }
                  }
                ]
              };
              out.push(JSON.stringify(chunk("mock-model", delta, null)));
            }
            out.push(JSON.stringify(chunk("mock-model", {}, "tool_calls")));
          }
          out.push(JSON.stringify(usageChunk("mock-model", 100, 10)));
          res.writeHead(200, {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            Connection: "keep-alive"
          });
          if (scripted.kind === "text" && (scripted.chunkDelayMs ?? 0) > 0) {
            for (const frame of out) {
              if (res.destroyed) return;
              res.write(`data: ${frame}

`);
              await new Promise((resolve3) => setTimeout(resolve3, scripted.chunkDelayMs));
            }
            res.end("data: [DONE]\n\n");
          } else {
            res.end(sseBody(out));
          }
        } catch (err) {
          res.writeHead(500, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ error: { message: String(err) } }));
        }
      });
    });
  }
  /** 返回 provider baseUrl（http://127.0.0.1:<port>/v1）。 */
  async start() {
    await new Promise((resolve3) => this.server.listen(0, "127.0.0.1", resolve3));
    const port = this.server.address().port;
    return `http://127.0.0.1:${port}/v1`;
  }
  async close() {
    await new Promise((resolve3) => this.server.close(() => resolve3()));
  }
};

// test/personal-media.test.ts
var context3 = BACKGROUND_CONTEXT14;
var png = Buffer.from("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000b49444154789c636000020000050001a5f645400000000049454e44ae426082", "hex");
var source2 = { platform: "qq", accountId: "bot", ownerId: "owner", generation: "generation" };
var photo = (id2 = 1, caption = "\u770B\u770B\u56FE\u7247") => ({ update_id: id2, message: { message_id: id2, from: { id: 456, is_bot: false }, chat: { id: 456, type: "private" }, caption, photo: [{ file_id: "small", file_unique_id: "small-unique", width: 1, height: 1 }, { file_id: "large", file_unique_id: "large-unique", width: 100, height: 100, file_size: png.length }] } });
var download = (bytes = png, declaredMime = "image/png") => ({ identity: randomUUID3(), declaredMime, download: async () => new Response(bytes, { headers: { "content-type": declaredMime } }) });
async function fixture(t, options = {}) {
  const directory = fs4.realpathSync(fs4.mkdtempSync("/tmp/ruukoto-media-")), lock = lockPersonalProfile(directory), requests = [], sends = [];
  let downloads = 0, h;
  const model = new MockModelServer((_input, index) => options.capture && index === 0 ? { kind: "tool_calls", calls: [{ id: "image-call", name: "capture", arguments: {} }] } : { kind: "text", text: "\u56FE\u7247\u56DE\u7B54" });
  const config = { api: "openai-completions", baseUrl: await model.start(), modelId: "mock-model", apiKeyEnv: "RUUKOTO_MEDIA_TEST_KEY", contextWindow: 128e3, maxTokens: 4096, imageInput: options.imageInput ?? true };
  const previous = process.env[config.apiKeyEnv];
  process.env[config.apiKeyEnv] = "test-only";
  const provider = personalProvider(config), media = personalMedia(lock.directory, () => h, () => config.imageInput);
  const tgConfig = { version: 1, enabled: true, generation: "generation", apiBase: "https://api.telegram.org", tokenEnv: "TOKEN", tokenDigest: "0".repeat(64), botId: "123", ownerId: "456", boundary: 0 };
  const api = { me: async () => ({ id: "123", username: "bot" }), updates: async () => [], send: async (_owner, _id, text) => {
    sends.push(text);
    return String(sends.length);
  }, photo: (input) => ({ identity: input.identity, declaredMime: "image/png", download: async () => {
    downloads++;
    return new Response(png, { headers: { "content-type": "image/png" } });
  } }) };
  const tg = personalTelegram(tgConfig, api, void 0, media);
  const capture = defineTool7({ name: "capture", description: "\u8FD4\u56DE\u6D4B\u8BD5\u56FE\u7247", parameters: Type7.Object({}), replay: "safe", execute: async (_input, execution, callContext) => {
    const artifact = await savePersonalArtifact(lock.directory, png, { mime: "image/png" });
    const image = await execution.commit((tx) => media.registerImage(tx, artifact, { conversationId: execution.conversationId, taskId: execution.taskId }), callContext);
    return { output: [image] };
  } });
  const extension = defineExtension16({ name: "media-test", tools: options.capture ? [capture] : [] }), registry = createRegistry();
  registry.install(extension);
  registry.install(tg.extension);
  const open = async () => {
    const storage = await openNodeSqliteStorage5(path4.join(directory, "personal.sqlite"));
    h = await Harness.open(storage, { models: recordedModels(provider, async (value) => {
      requests.push(value);
      await h.commit((tx) => tx.appendEntry(ROOT_CONVERSATION_ID15, { kind: "test.request", data: value }), context3);
    }, media.modelMedia), registry, ...options.compaction ? { settings: { compaction: { enabled: false, reserveTokens: 4096, keepRecentTokens: 1, backgroundTokens: 0 } } } : {} }, context3);
    const main = await h.root(context3, { agent: { model: { provider: provider.id, modelId: config.modelId }, extensions: [extension, tg.extension], tools: options.capture ? [capture] : [] } });
    await h.commit(async (tx) => {
      (await tx.doc(PersonalTelegramDoc)).config = { ...tgConfig };
    }, context3);
    await media.recover();
    h.resume();
    return { h, main, telegram: tg.api(h) };
  };
  let p = await open();
  t.after(async () => {
    await h.close(context3);
    await model.close();
    lock.release();
    if (previous === void 0) delete process.env[config.apiKeyEnv];
    else process.env[config.apiKeyEnv] = previous;
    fs4.rmSync(directory, { recursive: true, force: true });
  });
  return { directory, media, model, requests, config, sends, tgConfig, api, get downloads() {
    return downloads;
  }, get p() {
    return p;
  }, async reopen() {
    await h.close(context3);
    p = await open();
    return p;
  } };
}
async function receipt2(f, id2 = 1) {
  const value = (await f.p.h.snapshot(PersonalTelegramReceiptDoc, `telegram:123:456:${id2}`, context3)).receipt;
  await f.p.h.waitForTask(value.taskId, context3);
  return (await f.p.h.snapshot(PersonalTelegramReceiptDoc, value.requestId, context3)).receipt;
}
test("\u4E2A\u4EBA\u56FE\u7247\uFF1A\u6700\u5927Telegram\u7167\u7247\u3001caption\u4E0D\u6267\u884C\u63A7\u5236\u3001\u539F\u751F\u56FE\u8F93\u5165\u4E0E\u8BC1\u636E\u6309\u5F15\u7528\u91CD\u5EFA", async (t) => {
  const f = await fixture(t);
  assert.equal(telegramMessage(photo()).media[0].fileId, "large");
  await f.p.telegram.receive(photo(1, "\u5B8C\u5168\u8BBF\u95EE"));
  const saved = await receipt2(f);
  assert.equal(saved.delivery, "sent");
  assert.equal(saved.control, void 0);
  assert.ok(saved.accepted);
  assert.equal((await f.p.h.snapshot(PersonalPermissionsDoc, context3)).mode, "auto-review");
  assert.equal(f.downloads, 1);
  assert.equal(f.model.calls.length, 1);
  assert.match(JSON.stringify(f.model.calls[0].raw), new RegExp(png.toString("base64")));
  const entry = await f.p.h.commit(async (tx) => tx.entry((await tx.submissionByRequest(ROOT_CONVERSATION_ID15, saved.requestId)).entry), context3);
  assert.doesNotMatch(JSON.stringify(entry), new RegExp(png.toString("base64")));
  assert.doesNotMatch(JSON.stringify(f.requests), new RegExp(png.toString("base64")));
  assert.match(JSON.stringify(f.requests), /ruukotoImage/);
  await f.p.telegram.receive(photo(1, "\u5B8C\u5168\u8BBF\u95EE"));
  assert.equal(f.downloads, 1);
  assert.equal(f.model.calls.length, 1);
  await f.reopen();
  await (await f.p.main.submit({ type: "input", content: "\u539F\u56FE\u662F\u4EC0\u4E48\uFF1F", requestId: "after-reopen" }, context3)).wait(context3);
  assert.equal(f.model.calls.length, 2);
  assert.match(JSON.stringify(f.model.calls[1].raw), new RegExp(png.toString("base64")));
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1A\u7EAF\u6587\u672C\u6A21\u578B\u56FA\u5B9A\u62D2\u7EDD\u3001\u9519\u62E5\u6709\u8005\u4E0D\u4E0B\u8F7D\u3001\u65E7\u4EE3\u6B21\u91CD\u6295\u4E0D\u91CD\u65B0\u5305\u88C5", async (t) => {
  const f = await fixture(t, { imageInput: false });
  const wrong = photo();
  wrong.message.from.id = 789;
  wrong.message.chat.id = 789;
  await f.p.telegram.receive(wrong);
  assert.equal(f.downloads, 0);
  await f.p.telegram.receive(photo());
  const saved = await receipt2(f);
  assert.equal(saved.mediaRejected, true);
  assert.equal(saved.submissionId, void 0);
  assert.equal(f.model.calls.length, 0);
  assert.equal(f.downloads, 0);
  assert.match(f.sends[0], /不支持图片/);
  f.tgConfig.generation = "new-generation";
  await f.p.h.commit(async (tx) => {
    (await tx.doc(PersonalTelegramDoc)).config = { ...f.tgConfig };
  }, context3);
  await f.p.telegram.receive(photo());
  assert.equal(f.downloads, 0);
  assert.equal(f.model.calls.length, 0);
  assert.equal((await f.p.h.snapshot(PersonalTelegramReceiptDoc, saved.requestId, context3)).receipt.generation, "generation");
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1A\u683C\u5F0F\u3001\u4E0A\u9650\u3001\u4E0B\u8F7D\u5931\u8D25\u3001\u53D6\u6D88\u548C\u672A\u7ED1\u5B9A\u8FC7\u671F\u4FDD\u7559\u660E\u786E\u4E8B\u5B9E", async (t) => {
  const f = await fixture(t);
  const stage = (key, media, signal) => f.media.stage({ key, source: source2, body: "", media }, signal);
  assert.equal((await stage("count", Array.from({ length: 5 }, () => download()))).reason, "too_many_images");
  assert.equal((await stage("large", [{ ...download(), sizeBytes: 8 * 1024 * 1024 + 1 }])).reason, "image_too_large");
  assert.equal((await stage("mime", [download(png, "image/gif")])).reason, "mime_unsupported");
  assert.equal((await stage("magic", [download(Buffer.from("not png"))])).reason, "mime_mismatch");
  let attempts = 0;
  assert.equal((await stage("network", [{ identity: "network", download: async () => {
    attempts++;
    throw new Error("secret URL");
  } }])).reason, "download_failed");
  assert.equal(attempts, 3);
  const controller = new AbortController();
  let started;
  const ready = new Promise((resolve3) => {
    started = resolve3;
  });
  const pending = stage("cancel", [{ identity: "cancel", download: async () => {
    started();
    return new Promise(() => {
    });
  } }], controller.signal);
  await ready;
  controller.abort();
  await assert.rejects(pending);
  await f.media.recover();
  assert.equal((await f.media.message("cancel")).reason, "download_interrupted");
  const orphan = await stage("orphan", [download()]);
  await f.p.h.commit(async (tx) => {
    (await tx.doc(PersonalMediaMessageDoc, "orphan", null)).message.receivedAt = Date.now() - 25 * 60 * 60 * 1e3;
  }, context3);
  await f.media.recover();
  assert.equal((await f.media.message("orphan")).state, "expired");
  assert.equal(fs4.existsSync(path4.join(f.directory, "artifacts", `${orphan.artifacts[0].id}.bin`)), false);
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1AtoolResult\u539F\u751F\u5F52\u5C5E\u3001\u7F3A\u5931/\u635F\u574F/\u4F2A\u9020/partial\u5747\u4E0D\u53D1\u6A21\u578B\u8BF7\u6C42", async (t) => {
  const f = await fixture(t, { capture: true });
  await (await f.p.main.submit({ type: "input", content: "\u622A\u56FE", requestId: "capture" }, context3)).wait(context3);
  assert.equal(f.model.calls.length, 2);
  assert.match(JSON.stringify(f.model.calls[1].raw), new RegExp(png.toString("base64")));
  assert.doesNotMatch(JSON.stringify(f.requests), new RegExp(png.toString("base64")));
  const artifacts = await f.p.h.commit((tx) => f.media.mediaArtifacts(tx), context3);
  assert.equal(artifacts.length, 1);
  fs4.writeFileSync(path4.join(f.directory, "artifacts", `${artifacts[0].artifact.id}.bin`), Buffer.alloc(png.length));
  const before = f.model.calls.length;
  await (await f.p.main.submit({ type: "input", content: "\u7EE7\u7EED", requestId: "corrupt" }, context3)).wait(context3);
  assert.equal(f.model.calls.length, before);
  await assert.rejects(f.media.modelMedia.prepare({ messages: [{ role: "user", content: [{ type: "image", mimeType: "image/png", data: JSON.stringify({ ruukotoImage: { version: 1, artifact: { id: "forged", partial: true, mime: "image/png" } } }) }], timestamp: Date.now() }] }, "forged"), (error) => error instanceof PersonalError && error.code === "image_reference_invalid");
  const index = await f.p.h.snapshot(PersonalMediaDoc, context3);
  assert.equal(index.images.length, 1);
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1ATelegram\u4E0B\u8F7D\u4EC5\u56FA\u5B9AgetFile\u8DEF\u5F84\uFF0C\u58F0\u660E\u4E0E\u771F\u5B9E\u5B57\u8282\u5747\u6821\u9A8C", async () => {
  const previous = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = async (input) => {
    calls++;
    const url = String(input);
    return url.endsWith("getFile") ? Response.json({ ok: true, result: { file_path: "photos/file.png" } }) : new Response(png, { headers: { "content-type": "application/octet-stream" } });
  };
  try {
    const api = personalTelegramApi("https://api.telegram.org", "secret");
    const file = await api.photo({ identity: "photo", fileId: "file" }).download(new AbortController().signal);
    assert.equal(file.headers.get("content-type"), "image/png");
    assert.deepEqual(Buffer.from(await file.arrayBuffer()), png);
    assert.equal(calls, 2);
    globalThis.fetch = async () => Response.json({ ok: true, result: { file_path: "../secret" } });
    await assert.rejects(api.photo({ identity: "photo", fileId: "file" }).download(new AbortController().signal), (error) => error instanceof PersonalError && error.code === "download_unavailable");
  } finally {
    globalThis.fetch = previous;
  }
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1A\u63D0\u4EA4\u540E\u5C1A\u672Abind\u5373\u53EF\u6309\u539Fentry\u6062\u590D\uFF0C\u91CD\u5F00\u8865bind\u4E0D\u91CD\u590D\u6A21\u578B\u6216\u4E0B\u8F7D", async (t) => {
  const f = await fixture(t), key = "qq:bot:owner:gap";
  await f.media.stage({ key, source: source2, body: "\u7A97\u53E3\u56FE\u7247", media: [download()] });
  const submission = await f.p.main.submit({ type: "input", content: await f.media.input(key), requestId: key }, context3);
  await submission.wait(context3);
  assert.equal((await f.media.message(key)).state, "ready");
  assert.equal(f.model.calls.length, 1);
  await f.reopen();
  const message = await f.media.message(key);
  assert.equal(message.state, "bound");
  assert.equal(message.submissionId, submission.id);
  assert.equal(f.model.calls.length, 1);
  const sessionId = (await f.p.h.snapshot(ProviderDoc2, ROOT_CONVERSATION_ID15, context3)).sessionId;
  const input = await f.media.input(key);
  assert.ok(Array.isArray(input));
  await assert.rejects(f.media.modelMedia.prepare({ messages: [{ role: "user", content: input, timestamp: 1 }] }, sessionId + "other"), (error) => error instanceof PersonalError && error.code === "image_reference_invalid");
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1A\u5B9E\u9645payload\u53D8\u9020\u3001\u5220\u9664\u548C\u672A\u767B\u8BB0\u5916\u94FE\u56FE\u7247\u90FD\u5728HTTP\u524D\u62D2\u7EDD", async (t) => {
  const f = await fixture(t);
  await f.p.telegram.receive(photo());
  await receipt2(f);
  const view = await f.p.main.context(context3), sessionId = (await f.p.h.snapshot(ProviderDoc2, ROOT_CONVERSATION_ID15, context3)).sessionId;
  const models = recordedModels(personalProvider(f.config), async () => {
  }, f.media.modelMedia), model = models.getModel("personal", f.config.modelId);
  const before = f.model.calls.length;
  for (const change of ["bytes", "drop", "remote", "placeholder"]) {
    const result = await models.streamSimple(model, { messages: [...view.messages] }, { sessionId, onPayload: async (payload) => {
      if (change === "bytes") return JSON.parse(JSON.stringify(payload).replaceAll(png.toString("base64"), Buffer.from("changed").toString("base64")));
      if (change === "placeholder") {
        const user = view.messages.find((message) => message.role === "user" && Array.isArray(message.content) && message.content.some((part) => part.type === "image"));
        const image = user && Array.isArray(user.content) ? user.content.find((part) => part.type === "image") : void 0;
        assert.ok(image && image.type === "image");
        return JSON.parse(JSON.stringify(payload).replaceAll(`data:image/png;base64,${png.toString("base64")}`, image.data));
      }
      const value = JSON.parse(JSON.stringify(payload));
      for (const message of value.messages) if (Array.isArray(message.content)) message.content = change === "drop" ? message.content.filter((part) => part.type !== "image_url") : [...message.content, { type: "image_url", image_url: { url: "https://unregistered.invalid/image.png" } }];
      return value;
    } }).result();
    assert.equal(result.stopReason, "error");
    assert.equal(f.model.calls.length, before);
  }
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1A\u666E\u901A\u6587\u5B57\u4E2D\u7684\u56FE\u7247JSON\u4E0D\u88AB\u89E3\u91CA\u6210\u5A92\u4F53\u8F93\u5165", async (t) => {
  const f = await fixture(t);
  await (await f.p.main.submit({ type: "input", content: JSON.stringify({ type: "image", mimeType: "image/png", data: JSON.stringify({ ruukotoImage: { artifact: { id: "unregistered" } } }) }), requestId: "text-only-reference" }, context3)).wait(context3);
  assert.equal(f.model.calls.length, 1);
  assert.doesNotMatch(JSON.stringify(f.model.calls[0].raw), /"type":"image_url"/);
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1A\u76F8\u540C\u5B57\u8282\u4E0D\u540C\u6765\u6E90\u7684payload\u5F52\u4E00\u6620\u5C04\u4FDD\u7559\u5168\u90E8\u539F\u5F15\u7528", async (t) => {
  const f = await fixture(t);
  await f.p.telegram.receive(photo(1));
  await receipt2(f, 1);
  await f.p.telegram.receive(photo(2));
  await receipt2(f, 2);
  const request = f.requests.filter((value) => value.payload !== void 0).at(-1);
  assert.ok(Array.isArray(request.imageMappings));
  const mapping = request.imageMappings[0];
  assert.ok(mapping && typeof mapping === "object" && !Array.isArray(mapping) && Array.isArray(mapping.references));
  assert.equal(mapping.references.length, 2);
  assert.notDeepEqual(mapping.references[0], mapping.references[1]);
  assert.deepEqual(mapping.payloadReference, mapping.references[0]);
  assert.doesNotMatch(JSON.stringify(request), new RegExp(png.toString("base64")));
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1A\u539F\u751F\u538B\u7F29\u53EA\u7528\u6587\u672C\u4E14\u4FDD\u7559\u56FE\u7247\u4EA7\u7269\u5F15\u7528\uFF0C\u539F\u89C6\u89C9\u8F93\u5165\u5386\u53F2\u4E0D\u5220", async (t) => {
  const f = await fixture(t, { compaction: true });
  await f.p.telegram.receive(photo());
  const saved = await receipt2(f);
  const image = (await f.media.message(saved.requestId)).artifacts[0];
  const original = await f.p.h.commit(async (tx) => (await tx.submissionByRequest(ROOT_CONVERSATION_ID15, saved.requestId)).entry, context3);
  await (await f.p.main.submit({ type: "input", content: "\u540E\u7EED\u95EE\u9898", requestId: "later" }, context3)).wait(context3);
  const before = f.model.calls.length;
  await f.p.h.waitForTask(await f.p.main.compact("\u4FDD\u7559\u539F\u56FE\u7247\u5F15\u7528", context3), context3);
  assert.equal(f.model.calls.length, before + 1);
  const summaryInput = JSON.stringify(f.model.calls.at(-1).raw);
  assert.match(summaryInput, new RegExp(image.id));
  assert.match(summaryInput, /压缩摘要不包含图片的视觉细节/);
  assert.doesNotMatch(summaryInput, new RegExp(png.toString("base64")));
  assert.match(JSON.stringify(await f.p.h.commit((tx) => tx.entry(original), context3)), /ruukotoImage/);
});
test("\u4E2A\u4EBA\u56FE\u7247\u63A5\u7EB3\u987A\u5E8F\uFF1A\u6587\u5B57\u83DC\u5355\u5148\u5B8C\u6210\u8BFB\u53D6\uFF0C\u518D\u8FFD\u52A0accepted\uFF0C\u5BA1\u6279\u9009\u62E9\u4ECD\u53EF\u7528", async (t) => {
  const f = await fixture(t);
  const text = (id2, content, reply = false) => ({ update_id: id2, message: { message_id: id2, from: { id: 456, is_bot: false }, chat: { id: 456, type: "private" }, text: content, ...reply ? { reply_to_message: { message_id: 1, from: { id: 123, is_bot: true } } } : {} } });
  await f.p.telegram.receive(text(1, "/\u6743\u9650"));
  await receipt2(f, 1);
  await f.p.telegram.receive(text(2, "\u5B8C\u5168\u8BBF\u95EE", true));
  const selected = await receipt2(f, 2);
  assert.equal(selected.control, true);
  assert.ok(selected.accepted);
  assert.equal((await f.p.h.snapshot(PersonalPermissionsDoc, context3)).mode, "full_access");
  assert.equal(f.model.calls.length, 0);
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1A\u666E\u901A\u5DE5\u5177\u53C2\u6570\u4E2D\u7684type/image/data\u4E0D\u88AB\u56FE\u7247\u5FEB\u7167\u8BEF\u89E3\u91CA", async (t) => {
  const f = await fixture(t, { capture: true });
  await (await f.p.main.submit({ type: "input", content: "\u622A\u56FE", requestId: "ordinary-tool-args" }, context3)).wait(context3);
  const view = await f.p.main.context(context3), sessionId = (await f.p.h.snapshot(ProviderDoc2, ROOT_CONVERSATION_ID15, context3)).sessionId;
  const messages = JSON.parse(JSON.stringify(view.messages));
  const assistant = messages.find((message) => message.role === "assistant" && message.content.some((part) => part.type === "toolCall"));
  assert.ok(assistant && assistant.role === "assistant");
  const call = assistant.content.find((part) => part.type === "toolCall");
  assert.ok(call && call.type === "toolCall");
  call.arguments = { service: "image-editor", params: { type: "image", data: "asset-123" }, schema: { type: "image_url", image_url: { url: "business-value" } } };
  const prepared = await f.media.modelMedia.prepare({ messages: [...messages] }, sessionId);
  assert.match(JSON.stringify(prepared.snapshot({ messages })), /asset-123/);
  assert.doesNotThrow(() => prepared.snapshot({ messages: [{ role: "assistant", content: [{ type: "tool_use", input: call.arguments }] }, { role: "user", content: [{ type: "tool_result", content: [{ type: "image", source: { type: "base64", media_type: "image/png", data: png.toString("base64") } }] }] }] }, true));
  assert.throws(() => prepared.snapshot({ messages: [{ role: "user", content: [{ type: "image", data: JSON.stringify({ ruukotoImage: "placeholder" }) }] }] }, true), (error) => error instanceof PersonalError && error.code === "image_reference_invalid");
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1A\u5728\u9014\u91CD\u590D\u5171\u4EAB\u4E00\u6B21\u4E0B\u8F7D\uFF0C\u540C\u952E\u5F02\u53C2\u5728\u590D\u7528\u524D\u62D2\u7EDD", async (t) => {
  const f = await fixture(t);
  let release2, started, calls = 0;
  const ready = new Promise((resolve3) => {
    started = resolve3;
  }), gate = new Promise((resolve3) => {
    release2 = resolve3;
  });
  const input = { key: "in-flight", source: source2, body: "\u539F\u8BF4\u660E", media: [{ identity: "same-image", declaredMime: "image/png", download: async () => {
    calls++;
    started();
    await gate;
    return new Response(png, { headers: { "content-type": "image/png" } });
  } }] };
  const first = f.media.stage(input);
  await ready;
  const duplicate = f.media.stage(input);
  await assert.rejects(f.media.stage({ ...input, body: "\u4E0D\u540C\u8BF4\u660E" }), (error) => error instanceof PersonalError && error.code === "media_input_conflict");
  await assert.rejects(f.media.stage({ ...input, source: { ...source2, generation: "changed" } }), (error) => error instanceof PersonalError && error.code === "media_input_conflict");
  release2();
  assert.deepEqual(await duplicate, await first);
  assert.equal(calls, 1);
});
test("\u4E2A\u4EBA\u56FE\u7247\uFF1A\u5168\u90E8\u539F\u5B57\u8282\u5DF2\u767B\u8BB0\u4F46\u7F3Aready\u63D0\u4EA4\u65F6\u6062\u590D\u539F\u952E\uFF0C\u4E0D\u91CD\u65B0\u4E0B\u8F7D", async (t) => {
  const f = await fixture(t), key = "qq:complete-before-ready";
  let calls = 0;
  const original = download(), media = [{ ...original, download: async (signal) => {
    calls++;
    return original.download(signal);
  } }];
  const saved = await f.media.stage({ key, source: source2, body: "\u5DF2\u4E0B\u8F7D", media });
  await f.p.h.commit(async (tx) => {
    (await tx.doc(PersonalMediaMessageDoc, key, null)).message.state = "staging";
  }, context3);
  await f.media.recover();
  assert.equal((await f.media.message(key)).state, "ready");
  assert.equal(calls, 1);
  const replay = await f.media.stage({ key, source: source2, body: "\u5DF2\u4E0B\u8F7D", media });
  assert.deepEqual(replay.artifacts, saved.artifacts);
  assert.equal(calls, 1);
  await (await f.p.main.submit({ type: "input", content: await f.media.input(key), requestId: key }, context3)).wait(context3);
  assert.equal(f.model.calls.length, 1);
  assert.match(JSON.stringify(f.model.calls[0].raw), new RegExp(png.toString("base64")));
});
