/**
 * 审批闸门（架构工单 04）：审批请求的全程由这里负责——登记请求并把任务转入
 * 等待确认、auto-review 任务先经一次自动审查、等待拥有者决定、未批准时记录
 * 已知未执行、获批后在同一事务内复核并单次消费；等待表、计数与进行中的审查
 * 都只在这里。工具族只提供审批范围、获批后复核与（需要时）同事务提交的本地效果。
 *
 * Driver 只接线：控制面应答（含 IM 审批命令及同事务回执 txExtra）→ resolve()，
 * 工具边界模式切换 → supersedeAll()，IM 绑定失效 → supersedeConfirmations()，
 * 停止 → cancelAll()。IM 来源审批的创建通知与消费前固定身份复核经 deps 钩子接入
 * （agent-direction issue 08）。每个 Driver 一个实例。
 */

import type { ApprovalScope, ConfirmationRequest, Task, ToolAuthorization } from "@ruukoto/core/types.ts";
import type { Store } from "@ruukoto/core/store.ts";
import { RuntimeApiError } from "@ruukoto/core/api-error.ts";
import type { ToolOpLedger } from "./tool-op-ledger.ts";
import { classifyForReview, ReviewAbortedError, REVIEW_POLICY_VERSION, type ApprovalReviewer } from "./review.ts";

type ConfirmationDecision = "approved" | "rejected" | "canceled" | "superseded";

/** txExtra 的返回：/approve-standing 时携带刚创建的长期授权关联（写入批准与决定事件）。 */
type ResolveTxExtra = () => void | { standingPermission?: { id: string; version: number } };

/** 长期授权窄路径的内部哨兵：滥用范围即转人工（整笔回滚，不留下任何记录差异）。 */
class StandingFallback extends Error {}

export interface ApprovalRequest<T> {
  task: Task;
  hostOpId: string;
  toolName: string;
  params: Record<string, unknown>;
  scope: ApprovalScope;
  signal?: AbortSignal;
  /** 获批后复核：同步，在消费事务内、条件更新之前执行；返回原因即放弃消费。不得再开核心库事务。 */
  recheck?: () => string | null;
  /** 与消费同一事务提交的本地效果（通知登记）；抛错则整笔回滚。不得再开核心库事务。 */
  commit?: (approvalId: string | null, authorization: ToolAuthorization) => T;
}

/** 批准：审批 id、审批记录保存的参数快照与 commit 的返回值；否则为已知未执行的文案。 */
export type ApprovalResult<T> =
  | { approved: true; approvalId: string | null; authorization: ToolAuthorization; params: Record<string, unknown>; value: T }
  | { approved: false; text: string };

/** 未批准的已知未执行文案（落库与返回给模型的是同一句；自动拒绝不得显示成"拥有者拒绝"）。 */
function notExecutedText(
  toolName: string,
  decision: "rejected" | "canceled" | "superseded",
  source: string | null,
  reviewReason: string | null,
): string {
  if (decision === "rejected") {
    return source === "auto_review" ? `自动审查拒绝执行 ${toolName}：${reviewReason ?? "未给出理由"}` : `拥有者拒绝执行 ${toolName}`;
  }
  return decision === "superseded"
    ? `审批已失效（模式切换或任务停止），${toolName} 未执行；如仍需要请重新申请`
    : `任务停止，确认等待解除（${toolName} 未执行）`;
}

export interface ApprovalGateDeps {
  store: Store;
  ledger: ToolOpLedger;
  /** 自动审查器（模型配置变化时由 Driver 替换，每次读取当前值）。 */
  reviewer(): ApprovalReviewer | undefined;
  /**
   * IM 审批通知（agent-direction issue 08）：审批登记事务内调用（宿主登记初始
   * IM 通知，与审批同事务提交）；不得再开核心库事务。抛错则整笔回滚。
   */
  notifyConfirmation?: (confirmation: ConfirmationRequest, task: Task) => void;
  /**
   * IM 固定身份的消费前复核（agent-direction issue 08）：在消费事务内、消费
   * 条件更新之前执行；返回原因即放弃消费并使批准失效。不得再开核心库事务。
   */
  consumeRecheck?: (confirmation: ConfirmationRequest, task: Task) => string | null;
  /**
   * 长期授权候选（agent-direction issue 10）：宿主按当前 main、任务来源入口身份、
   * 本机/单元/固定动作逐项核实后的候选（候选 ≠ 依据：目标代次与修订在消费事务内
   * 重新核实）。返回 null = 无候选，走人工路径。模型不能指定授权；TUI 提交、调度
   * 与子任务消息不能因共用 main 而继承原 IM 授权。
   */
  standingCandidate?: (
    task: Task,
    scope: Extract<ApprovalScope, { kind: "service_operation" }>,
  ) => { id: string; version: number } | null;
}

export class ApprovalGate {
  private readonly deps: ApprovalGateDeps;
  private waiters = new Map<string, { task: Task; resolve: (decision: ConfirmationDecision) => void }>();
  private pendingCount = 0;
  /** 进行中的自动审查（按审批 id）；人工接管/停止时中止，迟到结果忽略。 */
  private reviewAborters = new Map<string, AbortController>();

  constructor(deps: ApprovalGateDeps) {
    this.deps = deps;
  }

  /**
   * 审批请求全程：登记并等待决定（auto-review 任务先经自动审查）；获批后在同一
   * 事务内复核、单次消费并提交本地效果。未批准、复核失败与消费失败都交回
   * 「已知未执行」文案（未批准的由闸门记入工具结果，其余由调用方原样返回）。
   */
  async request<T = void>(input: ApprovalRequest<T>): Promise<ApprovalResult<T>> {
    if (input.task.accessMode === "full_access") return this.authorizeFullAccess(input);
    const waited = await this.wait(input);
    if (!waited.approved) return waited;
    return this.consume(input, waited.confirmationId);
  }

  // Note: 见 .agents/notes/implemented/feature/2026-10-12-full-access-current-account.md
  private authorizeFullAccess<T>(input: ApprovalRequest<T>): ApprovalResult<T> {
    const store = this.deps.store;
    const params = structuredClone(input.params);
    return store.withTx(() => {
      const task = store.getTask(input.task.id);
      const reason = !task || task.status !== "running" || task.cancelRequested || input.signal?.aborted ||
        task.accessMode !== "full_access" || task.permissionVersion !== input.task.permissionVersion
        ? `任务已停止或权限已变化，${input.toolName} 未执行`
        : input.recheck?.() ?? null;
      if (reason) {
        this.recordNotExecuted(input, reason);
        return { approved: false, text: reason };
      }
      const authorization: ToolAuthorization = {
        source: "full_access", taskId: input.task.id, permissionVersion: input.task.permissionVersion, scope: structuredClone(input.scope),
      };
      if (!store.authorizeToolOp(input.hostOpId, input.task.sessionId, authorization)) {
        return { approved: false, text: `操作已被认领或没有本任务的执行意图，${input.toolName} 未执行` };
      }
      const value = input.commit ? input.commit(null, authorization) : (undefined as T);
      return { approved: true, approvalId: null, authorization, params, value };
    });
  }

  /**
   * 长期授权窄路径（agent-direction issue 10）：候选核实通过时，在单个同步事务内
   * 重读授权版本与未撤销状态、对本次执行快照逐项核实完整范围（目标代次与修订由
   * 候选检索方先行核实，消费事务内按授权行复核）、核实活动任务与取消状态、创建
   * 独立的初始已批准记录并单次消费；任务保持 running，不发布等待事件、不启动
   * 自动审查。返回 null = 无候选或核实不再成立（调用方回退人工路径重新判定，
   * 不使用旧缓存执行）；持久化失败向上抛出（不得在落库失败后继续启动执行）。
   * 长期授权本身不被消费，原单次批准也不被重复使用。
   */
  requestStanding<T>(input: ApprovalRequest<T>): ApprovalResult<T> | null {
    if (input.task.accessMode === "full_access") return this.authorizeFullAccess(input);
    if (input.scope.kind !== "service_operation" || !this.deps.standingCandidate) return null;
    const store = this.deps.store;
    const scope: Extract<ApprovalScope, { kind: "service_operation" }> = input.scope;
    const candidate = this.deps.standingCandidate(input.task, scope);
    if (!candidate) return null;
    try {
      return store.withTx((): ApprovalResult<T> => {
        // 授权版本与未撤销状态重读（候选读取后撤销/失效即不再放行；撤销先提交赢得竞争）
        const sp = store.getStandingPermission(candidate.id);
        if (!sp || sp.revokedAt !== null || sp.version !== candidate.version) throw new StandingFallback();
        // 完整范围逐项核实：授权不可变范围 vs 本次执行快照（机器/单元/固定动作/两项修订）
        if (
          sp.machineId !== scope.machineId ||
          sp.unit !== scope.unit ||
          sp.action !== scope.action ||
          sp.policyRevision !== scope.policyRevision ||
          sp.unitRevision !== scope.unitRevision
        ) {
          throw new StandingFallback();
        }
        // 活动任务与取消状态（命中授权的任务保持 running；取消意图即自行转人工）
        const task = store.getTask(input.task.id);
        if (!task || task.status !== "running" || task.cancelRequested) throw new StandingFallback();
        if (task.permissionVersion !== input.task.permissionVersion) throw new StandingFallback();
        // 复核钩子与人工路径同一个（main 身份 + 可同步核实的部署策略）；不符则转人工
        if ((input.recheck?.() ?? null) !== null) throw new StandingFallback();
        // 独立的初始已批准记录（timestamps 即决定时刻；decisionSource + 授权关联）
        const confirmation = store.insertApprovedConfirmation({
          taskId: task.id,
          sessionId: task.sessionId,
          toolOpId: input.hostOpId,
          toolName: input.toolName,
          params: input.params,
          scope: input.scope,
          permissionVersion: task.permissionVersion,
          standingPermissionId: sp.id,
          standingPermissionVersion: sp.version,
        });
        // IM 固定身份复核（原入站钉版目标 vs 当前；批准的等待型消费共用此钩子）
        if ((this.deps.consumeRecheck?.(confirmation, task) ?? null) !== null) throw new StandingFallback();
        // 公共消费边界：未消费 + 权限版本匹配 + 任务仍活动（事务内已逐项核实，失败即回滚）
        const ok = store.consumeApproval({
          confirmationId: confirmation.id,
          expectedPermissionVersion: task.permissionVersion,
          activeStatuses: ["running"],
        });
        if (!ok) throw new Error("长期授权放行后单次消费失败（事务内核实应一致）");
        store.appendEvent(
          {
            type: "task.confirmation_resolved",
            taskId: task.id,
            confirmationId: confirmation.id,
            decision: "approved",
            source: "standing_permission",
            standingPermissionId: sp.id,
            standingPermissionVersion: sp.version,
          },
          { taskId: task.id, sessionId: task.sessionId },
        );
        store.appendEvent(
          {
            type: "task.approval_consumed",
            taskId: task.id,
            confirmationId: confirmation.id,
            toolOpId: input.hostOpId,
            toolName: input.toolName,
            standingPermissionId: sp.id,
            standingPermissionVersion: sp.version,
          },
          { taskId: task.id, sessionId: task.sessionId },
        );
        const authorization: ToolAuthorization = {
          source: "approval", taskId: task.id, permissionVersion: task.permissionVersion,
          confirmationId: confirmation.id, scope: confirmation.scope,
        };
        if (!store.authorizeToolOp(input.hostOpId, task.sessionId, authorization)) throw new StandingFallback();
        const value = input.commit ? input.commit(confirmation.id, authorization) : (undefined as T);
        return { approved: true, approvalId: confirmation.id, authorization, params: confirmation.params, value };
      });
    } catch (err) {
      // 核实不再成立：整笔回滚（不留下任何批准/使用记录），交回调用方走人工路径
      if (err instanceof StandingFallback) return null;
      throw err;
    }
  }

  private async wait(input: ApprovalRequest<unknown>): Promise<{ approved: true; confirmationId: string } | { approved: false; text: string }> {
    const store = this.deps.store;
    // 自动审查只覆盖 auto-review 任务且需要任务固定的模型配置；缺任一条件退化为纯人工
    const reviewSelection =
      input.task.accessMode === "auto-review" && this.deps.reviewer() ? input.task.modelSelection : null;
    const confirmation = store.withTx(() => {
      const c = store.createConfirmation({
        taskId: input.task.id,
        sessionId: input.task.sessionId,
        toolOpId: input.hostOpId,
        toolName: input.toolName,
        params: input.params,
        scope: input.scope,
        permissionVersion: input.task.permissionVersion,
        review: reviewSelection
          ? { model: `${reviewSelection.provider}/${reviewSelection.modelId}`, policyVersion: REVIEW_POLICY_VERSION }
          : undefined,
      });
      store.transitionTask(input.task.id, ["running"], "awaiting_confirmation", {});
      // IM 审批通知与审批登记同事务：通知暂时发送失败不使操作获批，但登记失败
      // 整笔回滚（不留"审批已存在但绑定入口未获通知"的状态）
      this.deps.notifyConfirmation?.(c, input.task);
      return c;
    });

    if (input.signal?.aborted) {
      // 只动本审批；其他仍在等待的审批照常计数
      const text = notExecutedText(input.toolName, "superseded", null, null);
      store.withTx(() => {
        store.invalidateConfirmation(confirmation.id);
        this.recordNotExecuted(input, text);
        if (this.pendingCount === 0) store.transitionTask(input.task.id, ["awaiting_confirmation"], "running", {});
      });
      return { approved: false, text };
    }

    this.pendingCount++;
    const onAbort = () => this.waiters.get(confirmation.id)?.resolve("superseded");
    try {
      const decisionPromise = new Promise<ConfirmationDecision>((resolve) => {
        this.waiters.set(confirmation.id, { task: input.task, resolve });
        input.signal?.addEventListener("abort", onAbort, { once: true });
      });
      // 等待者注册后再启动自动审查，避免审查同步完成时结果无处投递
      if (reviewSelection) {
        void this.runAutoReview(confirmation, input.task, input).catch(() => {
          // 审查失败不得打断审批等待；可落盘的失败已在 runAutoReview 内转人工
        });
      }
      const decision = await decisionPromise;
      if (decision === "approved") return { approved: true, confirmationId: confirmation.id };
      // 自动拒绝不能显示成"拥有者拒绝"：重读落库的来源与理由（与决定同事务写入）
      const resolved = store.getConfirmation(confirmation.id);
      const text = notExecutedText(input.toolName, decision, resolved?.decisionSource ?? null, resolved?.reviewReason ?? null);
      // 未批准 = 已知未执行（拒绝/取消/失效都不产生外部效果）
      store.withTx(() => this.recordNotExecuted(input, text));
      return { approved: false, text };
    } finally {
      this.waiters.delete(confirmation.id);
      input.signal?.removeEventListener("abort", onAbort);
      // 等待结束（含人工抢先/取消/模式切换）：中止仍在进行的审查，迟到结果忽略
      const aborter = this.reviewAborters.get(confirmation.id);
      if (aborter) {
        aborter.abort();
        this.reviewAborters.delete(confirmation.id);
      }
      this.pendingCount--;
      if (this.pendingCount === 0) {
        store.withTx(() => {
          store.transitionTask(input.task.id, ["awaiting_confirmation"], "running", {});
        });
      }
    }
  }

  /**
   * 获批后：同一事务内复核 → 单次消费（条件更新：批准未消费、权限版本匹配、
   * 任务仍活动；消费即执行开始）→ 事件 → 提交本地效果。复核或消费失败、
   * recheck/commit 抛错都使批准失效（stale），操作按已知未执行。
   */
  private consume<T>(input: ApprovalRequest<T>, confirmationId: string): ApprovalResult<T> {
    const store = this.deps.store;
    // 执行参数取自审批记录保存的快照
    const confirmation = store.getConfirmation(confirmationId)!;
    try {
      return store.withTx((): ApprovalResult<T> => {
        const reason = input.recheck?.() ?? null;
        if (reason) {
          store.invalidateConfirmation(confirmationId);
          return { approved: false, text: reason };
        }
        // IM 固定身份复核（issue 08）：批准已接受、尚未消费期间的重新绑定/
        // 凭据变化在此拦截；失败即批准失效，操作按已知未执行
        const imReason = this.deps.consumeRecheck?.(confirmation, input.task) ?? null;
        if (imReason) {
          store.invalidateConfirmation(confirmationId);
          return { approved: false, text: imReason };
        }
        // 关联长期授权的批准（issue 10，/approve-standing 的当前操作）：消费时
        // 重读授权版本与未撤销状态——撤销先提交则本次放行失效，不能成为独立批准
        if (confirmation.standingPermissionId !== null) {
          const sp = store.getStandingPermission(confirmation.standingPermissionId);
          if (!sp || sp.revokedAt !== null || sp.version !== confirmation.standingPermissionVersion) {
            store.invalidateConfirmation(confirmationId);
            return { approved: false, text: `本次批准关联的长期授权 ${confirmation.standingPermissionId} 已撤销或失效，${input.toolName} 未执行；如仍需要请重新审批` };
          }
        }
        const ok = store.consumeApproval({
          confirmationId,
          expectedPermissionVersion: confirmation.permissionVersion,
          activeStatuses: ["running", "awaiting_confirmation"],
        });
        if (!ok) {
          store.invalidateConfirmation(confirmationId);
          return { approved: false, text: `批准已失效（任务结束、权限版本变化或已被消费），${input.toolName} 未执行` };
        }
        store.appendEvent(
          {
            type: "task.approval_consumed",
            taskId: input.task.id,
            confirmationId,
            toolOpId: input.hostOpId,
            toolName: input.toolName,
            ...(confirmation.standingPermissionId !== null
              ? { standingPermissionId: confirmation.standingPermissionId, standingPermissionVersion: confirmation.standingPermissionVersion! }
              : {}),
          },
          { taskId: input.task.id, sessionId: input.task.sessionId },
        );
        const authorization: ToolAuthorization = {
          source: "approval", taskId: input.task.id, permissionVersion: confirmation.permissionVersion,
          confirmationId, scope: confirmation.scope,
        };
        if (!store.authorizeToolOp(input.hostOpId, input.task.sessionId, authorization)) {
          throw new RuntimeApiError("tool_authorization_conflict", "批准消费时工具操作未能单次认领");
        }
        const value = input.commit ? input.commit(confirmationId, authorization) : (undefined as T);
        return { approved: true, approvalId: confirmationId, authorization, params: confirmation.params, value };
      });
    } catch (err) {
      // 整笔回滚（未消费、未提交）：批准失效，错误原样交回调用方
      try {
        store.withTx(() => store.invalidateConfirmation(confirmationId));
      } catch {
        // 失效标记写不进去时批准保持未消费（仍是已知未执行），不遮住原始错误
      }
      throw err;
    }
  }

  private recordNotExecuted(input: { task: Task; hostOpId: string }, text: string): void {
    this.deps.ledger.recordResult(input.task, input.hostOpId, text, true);
  }

  /**
   * 控制面/IM 应答确认：条件更新 pending → approved/rejected；失效应答返回 false。
   * 决定与审计事件在同一事务提交（IM 控制事件登记与回执可经 txExtra 并入同一事务，
   * 不得再开核心库事务；抛错则整笔回滚）；提交成功后才唤醒等待者。
   */
  resolve(confirmationId: string, decision: "approved" | "rejected", opts?: { txExtra?: ResolveTxExtra }): boolean {
    const waiter = this.waiters.get(confirmationId);
    if (!waiter) return false;
    const store = this.deps.store;
    // 人工决定：记录来源；进行中的自动审查同事务标记 superseded。
    // txExtra（IM 控制事件终态/回执/长期授权创建）与决定同事务提交；
    // txExtra 携带长期授权时，批准来源与授权关联写进批准与决定事件（issue 10）。
    const applied = store.withTx(() => {
      const ok = store.respondConfirmation(confirmationId, decision, { source: "owner" });
      if (!ok) return false;
      const extra = opts?.txExtra?.();
      const link = decision === "approved" ? (extra === undefined || extra === null ? undefined : extra.standingPermission) : undefined;
      if (link) store.linkConfirmationStanding(confirmationId, link.id, link.version);
      store.appendEvent(
        {
          type: "task.confirmation_resolved",
          taskId: waiter.task.id,
          confirmationId,
          decision,
          source: link ? "standing_permission" : "owner",
          ...(link ? { standingPermissionId: link.id, standingPermissionVersion: link.version } : {}),
        },
        { taskId: waiter.task.id, sessionId: waiter.task.sessionId },
      );
      return true;
    });
    if (!applied) return false;
    waiter.resolve(decision);
    return true;
  }

  /** 模式切换应用前解除全部等待：审批失效，后续执行重新判定。 */
  supersedeAll(): void {
    for (const w of this.waiters.values()) w.resolve("superseded");
    this.waiters.clear();
  }

  /** 定向解除指定审批的等待（IM 绑定失效，agent-direction issue 08）；其他审批照常。 */
  supersedeConfirmations(ids: ReadonlySet<string>): void {
    for (const id of ids) this.waiters.get(id)?.resolve("superseded");
  }

  /** 停止路径：解除全部等待（门以 block 结束，不执行该操作）；进行中的自动审查一并中止。 */
  cancelAll(): void {
    for (const w of this.waiters.values()) w.resolve("canceled");
    this.waiters.clear();
    for (const aborter of this.reviewAborters.values()) aborter.abort();
    this.reviewAborters.clear();
  }

  /**
   * 单次自动审查（issue 15）：确定性策略先行，可审查的交给无工具模型调用。
   * 决定、理由、来源与事件在同一事务落盘；与人工决定/取消/模式切换竞争时
   * 只有一方条件更新成功，失败方把审查标记为 superseded 并忽略结果。
   */
  private async runAutoReview(
    confirmation: ConfirmationRequest,
    task: Task,
    input: { toolName: string; params: Record<string, unknown>; scope: ApprovalScope },
  ): Promise<void> {
    const store = this.deps.store;
    const reviewer = this.deps.reviewer();
    const selection = task.modelSelection;
    if (!reviewer || !selection) return;

    // 确定性策略：不可审查的范围直接转人工，不发起模型调用
    if (classifyForReview(input.scope) === "ask_owner") {
      this.markReviewAskedOwner(task, confirmation.id, "该操作不属于自动批准范围，转拥有者确认");
      return;
    }

    const aborter = new AbortController();
    this.reviewAborters.set(confirmation.id, aborter);
    try {
      const outcome = await reviewer.review({
        selection,
        taskInput: task.input,
        toolName: input.toolName,
        params: input.params,
        scope: input.scope,
        signal: aborter.signal,
      });
      if (outcome.decision === "ask_owner") {
        // 上下文不足/模型失败/超时/输出非法：转人工并说明原因，等待者不动
        this.markReviewAskedOwner(task, confirmation.id, outcome.reason);
        return;
      }
      // approve/reject：条件更新要求仍 pending、权限版本匹配、任务仍活动
      const decision = outcome.decision === "approve" ? "approved" : "rejected";
      const applied = store.withTx(() =>
        store.respondConfirmation(confirmation.id, decision, {
          source: "auto_review",
          expectedPermissionVersion: confirmation.permissionVersion,
          reviewDecision: outcome.decision,
          reviewReason: outcome.reason,
        }),
      );
      if (!applied) {
        // 人工抢先/已失效：迟到结果不得落盘
        store.withTx(() => store.markConfirmationReviewSuperseded(confirmation.id));
        return;
      }
      store.withTx(() =>
        store.appendEvent(
          { type: "task.confirmation_resolved", taskId: task.id, confirmationId: confirmation.id, decision, source: "auto_review", reason: outcome.reason },
          { taskId: task.id, sessionId: task.sessionId },
        ),
      );
      this.waiters.get(confirmation.id)?.resolve(decision);
    } catch (err) {
      if (err instanceof ReviewAbortedError) {
        // 人工接管/停止：仅标记审查被取代，不动审批状态
        store.withTx(() => store.markConfirmationReviewSuperseded(confirmation.id));
        return;
      }
      // reviewer 约定只抛中止；防御性兜底：任何意外异常一律转人工
      this.markReviewAskedOwner(task, confirmation.id, `审查异常：${(err as Error).message}`);
    } finally {
      this.reviewAborters.delete(confirmation.id);
    }
  }

  /** 转人工（条件更新仍 pending；人工已抢先时不覆盖其决定、不发事件）。 */
  private markReviewAskedOwner(task: Task, confirmationId: string, reason: string): void {
    const store = this.deps.store;
    const marked = store.withTx(() => store.markConfirmationAskedOwner(confirmationId, reason));
    if (marked) {
      store.withTx(() =>
        store.appendEvent(
          { type: "task.confirmation_reviewed", taskId: task.id, confirmationId, decision: "ask_owner", reason },
          { taskId: task.id, sessionId: task.sessionId },
        ),
      );
    }
  }
}
