import assert from "node:assert/strict";
import * as fs from "node:fs";
import nodeFs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import childProcess from "node:child_process";
import { syncBuiltinESMExports } from "node:module";
import { PassThrough } from "node:stream";
import { setTimeout as delay } from "node:timers/promises";
import { test, type TestContext } from "node:test";
import { DatabaseSync } from "node:sqlite";
import { BACKGROUND_CONTEXT } from "@earendil-works/chord/context";
import { AgentDoc, ROOT_CONVERSATION_ID, SessionFailed, type StorageWrite } from "@earendil-works/pi-durable";
import { openNodeSqliteStorage } from "@earendil-works/pi-durable/storage/sqlite/node";
import { openPersonalHarness, type PersonalHarness } from "../apps/ruukoto/src/personal-harness.ts";
import { PersonalCommandDoc, personalCommandWork, resolvePersonalCommand, type PersonalCommandRef } from "../apps/ruukoto/src/personal-command-work.ts";
import type { PersonalCommandConfig } from "../apps/ruukoto/src/personal-command-config.ts";
import { personalCommandFingerprint } from "../apps/ruukoto/src/personal-command-execution.ts";
import { PersonalWorkDoc, type PersonalWorkRef } from "../apps/ruukoto/src/personal-work.ts";
import { PersonalPermissionsDoc } from "../apps/ruukoto/src/personal-permissions.ts";
import { PersonalDelegationDoc, delegatePersonalAnalysis, listPersonalDelegations, personalDelegationProgress, type PersonalDelegationRef } from "../apps/ruukoto/src/personal-delegation.ts";
import { personalReportResult } from "../apps/ruukoto/src/personal-report.ts";
import { personalServiceSourceBlocker } from "../apps/ruukoto/src/personal-service-operations.ts";
import type { ServiceManagerConfig } from "../apps/ruukoto/src/service-helper.ts";
import { personalProvider, type PersonalModelConfig } from "../apps/ruukoto/src/personal-model.ts";
import { PersonalError } from "../apps/ruukoto/src/personal-error.ts";
import { MockModelServer, type Responder } from "./helpers/mock-provider.ts";

const context = BACKGROUND_CONTEXT;
const machineId = "a".repeat(32), bootId = "12345678-1234-1234-1234-123456789abc";
const code = (expected: string) => (error: unknown) => error instanceof PersonalError && error.code === expected;
async function until(check: () => boolean | Promise<boolean>) {
  const deadline = Date.now() + 30000;
  while (!await check()) { assert.ok(Date.now() < deadline, "等待原命令事实超时"); await delay(10); }
}

async function fixture(t: TestContext, command = "echo x >> count", respond?: Responder) {
  const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "rk-command-work-")));
  const workspace = path.join(root, "work"), directory = path.join(root, "profile"), groups = path.join(root, "groups");
  fs.mkdirSync(workspace, { mode: 0o700 }); fs.mkdirSync(groups, { mode: 0o700 });
  const { dev, ino } = fs.statSync(workspace);
  const commands: PersonalCommandConfig = { version: 1, workspace, identity: { dev, ino }, machineId, tmpdir: fs.realpathSync(os.tmpdir()) };
  const children = new Map<string, { child: childProcess.ChildProcess; group: string; disk: string; description: string }>();
  const descriptors = new Map<number, string>();
  const platform = Object.getOwnPropertyDescriptor(process, "platform")!;
  const realSpawn = childProcess.spawn, realExecFile = childProcess.execFile;
  const readFile = nodeFs.readFileSync, exists = nodeFs.existsSync, access = nodeFs.accessSync, open = nodeFs.openSync, stat = nodeFs.statSync, rename = nodeFs.renameSync;
  let stopFails = false, receiptFails = false;
  const alive = (child: childProcess.ChildProcess) => child.exitCode === null && child.signalCode === null;
  Object.defineProperty(process, "platform", { value: "linux" });
  t.mock.method(nodeFs, "readFileSync", (target: fs.PathOrFileDescriptor, options?: Parameters<typeof fs.readFileSync>[1]) => {
    if (target === "/etc/machine-id") return machineId + "\n";
    if (target === "/proc/sys/kernel/random/boot_id") return bootId + "\n";
    for (const value of children.values()) {
      if (target === `/proc/${value.child.pid}/stat`) {
        if (!alive(value.child)) throw Object.assign(new Error("gone"), { code: "ENOENT" });
        return `${value.child.pid} (worker) ${["S", "1", String(value.child.pid), ...Array(16).fill("0"), "123"].join(" ")}`;
      }
      if (target === `/proc/${value.child.pid}/cgroup`) return `0::${value.group}\n`;
    }
    const match = /^\/proc\/self\/fd\/(\d+)\/cgroup.events$/.exec(String(target));
    if (match) return `populated ${alive(children.get(descriptors.get(Number(match[1]))!)!.child) ? 1 : 0}\n`;
    return readFile(target, options);
  });
  t.mock.method(nodeFs, "existsSync", (target: fs.PathLike) => {
    if (target === "/sys/fs/cgroup/cgroup.controllers") return true;
    if (target === "/proc/sys/kernel/apparmor_restrict_unprivileged_userns") return false;
    return exists(target);
  });
  t.mock.method(nodeFs, "accessSync", (target: fs.PathLike, mode?: number) => {
    if (["/usr/bin/bwrap", "/usr/bin/systemd-run", "/usr/bin/systemctl"].includes(String(target)) || String(target).endsWith("/cgroup.kill")) return;
    return access(target, mode);
  });
  t.mock.method(nodeFs, "statSync", (target: fs.PathLike, options?: fs.StatOptions) => stat([...children.values()].find(value => `/sys/fs/cgroup${value.group}` === target)?.disk ?? target, options));
  t.mock.method(nodeFs, "openSync", (target: fs.PathLike, flags: fs.OpenMode, mode?: fs.Mode) => {
    for (const [scope, value] of children) if (target === `/sys/fs/cgroup${value.group}`) { const fd = open(value.disk, flags, mode); descriptors.set(fd, scope); return fd; }
    const match = /^\/proc\/self\/fd\/(\d+)\/cgroup.kill$/.exec(String(target));
    if (match) {
      const value = children.get(descriptors.get(Number(match[1]))!)!;
      if (alive(value.child)) process.kill(-value.child.pid!, "SIGKILL");
      return open(path.join(value.disk, "kill"), "w");
    }
    return open(target, flags, mode);
  });
  t.mock.method(nodeFs, "renameSync", (from: fs.PathLike, to: fs.PathLike) => {
    if (receiptFails && String(to).endsWith("/receipt.json")) throw Object.assign(new Error("receipt-failed"), { code: "EIO" });
    return rename(from, to);
  });
  t.mock.method(childProcess, "execFile", (file: string, args: string[], options: childProcess.ExecFileOptionsWithStringEncoding,
    callback: (error: childProcess.ExecFileException | null, stdout: string, stderr: string) => void) => {
    if (file !== "/usr/bin/systemctl") return realExecFile(file, args, options, callback);
    if (args.includes("is-system-running")) callback(null, "running\n", "");
    else {
      const value = children.get(args[2])!;
      callback(stopFails && !alive(value.child) ? new Error("query failed") : null,
        `LoadState=loaded\nActiveState=${alive(value.child) ? "active" : "inactive"}\nControlGroup=${value.group}\nInvocationID=${"c".repeat(32)}\nDescription=${value.description}\n`, "");
    }
    return new childProcess.ChildProcess();
  });
  t.mock.method(childProcess, "spawn", (file: string, args: string[], options: childProcess.SpawnOptions) => {
    if (file !== "/usr/bin/systemd-run") return realSpawn(file, args, options);
    const scope = args[args.indexOf("--unit") + 1], worker = args.at(-1)!;
    const child = realSpawn(process.execPath, [worker], { cwd: workspace, detached: true, stdio: ["pipe", "pipe", "pipe"] });
    const disk = path.join(groups, scope); fs.mkdirSync(disk, { mode: 0o700 });
    children.set(scope, { child, disk, group: `/user.slice/${scope}`, description: args.find(arg => arg.startsWith("Description="))!.slice("Description=".length) });
    const marker = new PassThrough(); child.stdio[4] = marker; setImmediate(() => marker.end("started\n"));
    return child;
  });
  syncBuiltinESMExports();
  const server = new MockModelServer(respond ?? (request => request.system?.includes("你是个人助手的子 Agent") && request.messages.at(-1)?.content === "执行命令"
    ? { kind: "tool_calls", calls: [{ id: "command", name: "run_command", arguments: { command } }] }
    : { kind: "text", text: "完成" }));
  const model: PersonalModelConfig = { api: "openai-completions", baseUrl: await server.start(), modelId: "mock-model", apiKeyEnv: "RUUKOTO_COMMAND_WORK_TEST_KEY", contextWindow: 128000, maxTokens: 1024 };
  const previous = process.env[model.apiKeyEnv]; process.env[model.apiKeyEnv] = "test-only";
  const options = { directory, commands, provider: personalProvider(model), modelId: model.modelId };
  let personal: PersonalHarness | undefined;
  t.after(async () => {
    await personal?.close(); await server.close();
    for (const value of children.values()) if (alive(value.child)) process.kill(-value.child.pid!, "SIGKILL");
    t.mock.restoreAll(); syncBuiltinESMExports(); Object.defineProperty(process, "platform", platform);
    if (previous === undefined) delete process.env[model.apiKeyEnv]; else process.env[model.apiKeyEnv] = previous;
    fs.rmSync(root, { recursive: true, force: true });
  });
  return { root, directory, workspace, commands, server, provider: options.provider,
    open: async (overrides: Partial<Omit<Parameters<typeof openPersonalHarness>[0], "directory" | "profile">> = {}) => personal = await openPersonalHarness({ ...options, ...overrides }),
    failStop: (value = true) => { stopFails = value; }, failReceipt: (value = true) => { receiptFails = value; },
    launches: () => children.size,
  };
}
const draft = (requestId: string, agentId?: PersonalWorkRef["agentId"]) => ({ requestId, sourceRequestId: "owner-source", content: "执行命令", ...(agentId ? { agentId } : {}) });
async function source(p: PersonalHarness) { await p.answer("拥有者委派来源", "owner-source"); }
async function original(p: PersonalHarness) { await until(async () => (await p.commands!.list()).items.length > 0); return (await p.commands!.list()).items[0].ref; }
async function unknown(p: PersonalHarness, ref: PersonalCommandRef) { await until(async () => { const value = await p.commands!.detail(ref, "stdout"); return value.result?.effect === "effect_unknown" && value.result.code !== "started"; }); }

for (const mode of ["confirm", "auto-review", "full_access"] as const) test(`durable 命令：${mode} 保留原权限、原生 owned Task 和双流分页，非零结果也释放身份`, async t => {
  const exitCode = mode === "confirm" ? 0 : 37;
  const f = await fixture(t, `head -c 7000 /dev/zero; printf '\\376err' >&2; echo x >> count; exit ${exitCode}`);
  let p = await f.open(); await source(p);
  await p.harness.commit(async tx => { (await tx.doc(PersonalPermissionsDoc)).mode = mode; }, context);
  const work = await p.work.delegate(draft("run"));
  const command = await original(p);
  assert.equal((await p.harness.waitForTask(work.taskId, context)).state.outcome.status, "completed");
  const saved = (await p.harness.snapshot(PersonalCommandDoc, command.requestId, context))!.command!;
  const request = f.server.calls.find(call => call.system?.includes("你是个人助手的子 Agent"))!;
  assert.match(JSON.stringify(request.tools), /run_command|read_command_output/);
  assert.ok(request.system?.includes(`当前工作命令权限：${{ confirm: "请求确认", "auto-review": "自动审查", full_access: "完全访问" }[mode]}。`));
  t.diagnostic(JSON.stringify({ mode, systemPrompt: Math.ceil(request.system!.length / 4), toolSchemas: Math.ceil(JSON.stringify(request.tools).length / 4) }));
  assert.equal(saved.started, true, JSON.stringify(await p.harness.commit(tx => tx.task(command.taskId), context)));
  assert.equal(saved.work.permission.mode, mode);
  assert.equal((await p.harness.commit(tx => tx.task(command.taskId), context))!.owner, work.taskId);
  assert.deepEqual((await p.commands!.detail(command, "stdout")).result, { effect: "returned", code: "command_returned", exitCode });
  const parts: Buffer[] = []; let offset = 0;
  do {
    const page = (await p.commands!.detail(command, "stdout", offset)).output!;
    assert.equal(page.complete, true); assert.equal(page.bytes, 7000);
    const part = Buffer.from(page.data, "base64"); assert.ok(part.length <= 3072); parts.push(part); offset = page.nextOffset ?? -1;
  } while (offset >= 0);
  assert.deepEqual(Buffer.concat(parts), Buffer.alloc(7000));
  assert.deepEqual(Buffer.from((await p.commands!.detail(command, "stderr")).output!.data, "base64"), Buffer.from([254, 101, 114, 114]));
  if (mode === "full_access") {
    await p.close(); p = await f.open();
    await p.harness.commit(async tx => { (await tx.doc(PersonalPermissionsDoc)).mode = "confirm"; }, context);
  }
  const next = await p.work.delegate({ ...draft("reuse", work.agentId), content: "继续分析" });
  await p.harness.waitForTask(next.taskId, context);
  if (mode === "full_access") {
    const reused = f.server.calls.findLast(call => call.system?.includes("你是个人助手的子 Agent"))!;
    assert.match(reused.system!, /当前工作命令权限：请求确认。/);
    assert.doesNotMatch(reused.system!, /当前工作命令权限：完全访问。/);
  }
  assert.equal(next.agentId, work.agentId); assert.equal(f.launches(), 1);
  assert.equal(fs.readFileSync(path.join(f.workspace, "count"), "utf8"), "x\n");
});

for (const mode of ["auto-review", "full_access"] as const) test(`durable 命令：${mode} 未知和取消跨重启保留占用，人工效果与原引用停止都核实后才复用`, async t => {
  const f = await fixture(t); f.failReceipt(); f.failStop();
  let p = await f.open(); await source(p);
  await p.harness.commit(async tx => { (await tx.doc(PersonalPermissionsDoc)).mode = mode; }, context);
  const work = await p.work.delegate(draft("unknown")), ref = await original(p); await unknown(p, ref);
  assert.equal((await p.commands!.detail(ref, "stdout")).stopped, false);
  await assert.rejects(p.work.delegate(draft("other-member")), code("work_source_paused"));
  await assert.rejects(p.work.append(work, { requestId: "append", content: "继续执行", sourceRequestId: "owner-source" }), code("work_source_paused"));
  assert.equal(await p.answer("独立聊天", "independent"), "完成");
  const independent = await p.work.delegate({ ...draft("independent"), sourceRequestId: "independent", content: "继续分析" });
  await p.harness.waitForTask(independent.taskId, context);
  const competing = await p.work.delegate({ ...draft("competing-command"), sourceRequestId: "independent" });
  await p.harness.waitForTask(competing.taskId, context);
  assert.match(JSON.stringify(f.server.calls.at(-1)!.messages), /command_directory_busy/);
  assert.equal(f.launches(), 1); assert.equal((await p.commands!.list()).items.length, 1);
  await p.close(); const requests = f.server.calls.length; p = await f.open(); await unknown(p, ref);
  assert.equal(f.launches(), 1); assert.equal(f.server.calls.length, requests);
  assert.deepEqual((await p.commands!.list()).items[0].ref, ref);
  const canceled = p.work.cancel(work);
  await until(async () => (await p.harness.snapshot(PersonalWorkDoc, work.requestId, context))!.cancelRequested);
  await p.harness.commit(tx => resolvePersonalCommand(tx, ref, "applied", "独立目录 count 只有原操作的一行"), context);
  await assert.rejects(p.harness.commit(tx => resolvePersonalCommand(tx, ref, "not_applied", "覆盖原说明"), context), code("command_resolution_invalid"));
  await delay(30);
  assert.deepEqual((await p.work.list()).find(agent => agent.id === work.agentId)!.work, work);
  assert.equal((await p.harness.commit(tx => tx.task(work.taskId), context))!.state.status, "running");
  assert.equal((await p.commands!.detail(ref, "stdout")).stopped, false);
  f.failStop(false); f.failReceipt(false);
  await p.harness.waitForTask(await p.commands!.stop(ref), context);
  assert.equal((await canceled).state.outcome.status, "aborted");
  const detail = await p.commands!.detail(ref, "stdout");
  assert.equal(detail.result!.effect, "effect_unknown"); assert.equal(detail.stopped, true);
  assert.equal(detail.resolution!.effect, "applied");
  const reused = await p.work.delegate({ ...draft("reuse", work.agentId), content: "继续分析" }); await p.harness.waitForTask(reused.taskId, context);
  assert.equal(f.launches(), 1); assert.equal(fs.readFileSync(path.join(f.workspace, "count"), "utf8"), "x\n");
});

for (const mutation of ["admission", "permission"] as const) test(`durable 命令：恢复拒绝坏 ${mutation}，provider 与 OS 都零新增调用`, async t => {
  const f = await fixture(t); let p = await f.open(); await source(p);
  const work = await p.work.delegate(draft("tamper")), ref = await original(p); await p.harness.waitForTask(work.taskId, context);
  await p.harness.commit(async tx => {
    if (mutation === "admission") (await tx.doc(PersonalCommandDoc, ref.requestId, null)).command!.admission = (await tx.doc(PersonalCommandDoc, ref.requestId, null)).command!.startEntry!;
    else (await tx.doc(PersonalWorkDoc, work.requestId, null)).permission!.mode = "full_access";
  }, context);
  await p.close(); const requests = f.server.calls.length;
  await assert.rejects(f.open(), code("command_record_invalid"));
  assert.equal(f.server.calls.length, requests); assert.equal(f.launches(), 1);
});

test("durable 命令：首次启用拒绝未决旧工作，不恢复 provider 或补授旧工具", async t => {
  let release!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  const f = await fixture(t, "", async request => {
    if (request.system?.includes("你是个人助手的子 Agent")) await gate;
    return { kind: "text", text: "完成" };
  });
  t.after(release);
  const p = await f.open({ commands: undefined }); await source(p);
  await p.work.delegate(draft("pending")); await until(() => f.server.calls.length === 2);
  await p.close(); const requests = f.server.calls.length;
  await assert.rejects(f.open(), code("command_config_pending"));
  assert.equal(f.server.calls.length, requests); assert.equal(f.launches(), 0);
});

for (const mutation of ["worker", "mounts", "stop-task", "unproved-stop", "full-env", "full-mounts", "full-node"] as const) test(`durable 命令：恢复拒绝 ${mutation} 损坏，零新增模型和执行`, async t => {
  const f = await fixture(t);
  if (mutation === "unproved-stop") { f.failReceipt(); f.failStop(); }
  const p = await f.open(); await source(p);
  if (mutation.startsWith("full-")) await p.harness.commit(async tx => { (await tx.doc(PersonalPermissionsDoc)).mode = "full_access"; }, context);
  const work = await p.work.delegate(draft("invalid-proof")), ref = await original(p);
  if (mutation === "unproved-stop") await unknown(p, ref);
  else await p.harness.waitForTask(work.taskId, context);
  if (mutation === "stop-task") await p.harness.waitForTask(await p.commands!.stop(ref), context);
  const saved = structuredClone((await p.harness.snapshot(PersonalCommandDoc, ref.requestId, context))!.command!);
  if (mutation === "worker") {
    saved.prepared!.input.workerPath = path.join(f.root, "other-worker.mjs");
    saved.prepared!.input.runtimeReadRoots.push(saved.prepared!.input.workerPath);
  } else if (mutation === "mounts") saved.prepared!.input.mounts.push({ path: f.root, access: "read_write" });
  else if (mutation === "full-env") saved.prepared!.input.env = { TEST_VALUE: "must-not-persist" };
  else if (mutation === "full-mounts") saved.prepared!.input.mounts.push({ path: f.workspace, access: "read_write" });
  else if (mutation === "full-node") saved.prepared!.input.nodePath = "/bin/false";
  else if (mutation === "stop-task") saved.stopTask = work.taskId;
  else { saved.stopped = true; delete saved.observation; }
  if (mutation === "worker" || mutation === "mounts" || mutation.startsWith("full-")) saved.prepared!.fingerprint = personalCommandFingerprint(saved.command, saved.prepared!.spec, saved.prepared!.input);
  await p.harness.commit(async tx => { (await tx.doc(PersonalCommandDoc, ref.requestId, null)).command = saved; }, context);
  await p.close();
  if (mutation === "worker" || mutation === "mounts" || mutation.startsWith("full-")) {
    // 同步伪造的自算指纹与开始/观察记录，证明恢复仍核对宿主钉定的 worker 和可见目录。
    const db = new DatabaseSync(path.join(f.directory, "personal.sqlite"));
    try {
      db.prepare("UPDATE entries SET record = json_set(record, '$.data.prepared', json(?)) WHERE id = ?").run(JSON.stringify(saved.prepared), saved.startEntry!);
      db.prepare("UPDATE entries SET record = json_set(record, '$.data.fingerprint', ?) WHERE id = ?").run(saved.prepared!.fingerprint, saved.observation!);
    } finally { db.close(); }
  }
  const requests = f.server.calls.length;
  await assert.rejects(f.open(), code("command_record_invalid"));
  assert.equal(f.server.calls.length, requests); assert.equal(f.launches(), 1);
});

test("durable 命令：原接纳不能因任务和 document 一起丢失而静默消失", async t => {
  const f = await fixture(t); const p = await f.open(); await source(p);
  const work = await p.work.delegate(draft("orphan-admission")), ref = await original(p);
  await p.harness.waitForTask(work.taskId, context); await p.close();
  const db = new DatabaseSync(path.join(f.directory, "personal.sqlite"));
  try {
    db.prepare("DELETE FROM document_revisions WHERE document_id IN (SELECT id FROM documents WHERE kind = ? AND json_extract(record, '$.key') = ?)").run(PersonalCommandDoc.definition.kind, ref.requestId);
    db.prepare("DELETE FROM documents WHERE kind = ? AND json_extract(record, '$.key') = ?").run(PersonalCommandDoc.definition.kind, ref.requestId);
    db.prepare("DELETE FROM tasks WHERE id = ?").run(ref.taskId);
    assert.equal(db.prepare("SELECT count(*) AS count FROM entries WHERE json_extract(record, '$.kind') = 'ruukoto.command-admission'").get()!.count, 1);
  } finally { db.close(); }
  const requests = f.server.calls.length;
  await assert.rejects(f.open(), code("command_record_invalid"));
  assert.equal(f.server.calls.length, requests); assert.equal(f.launches(), 1);
});

test("durable 命令：开始意图提交失败关闭 Harness，零 OS 派发", async t => {
  const f = await fixture(t); const cause = new Error("command-start-storage-failed");
  let tempDir = "";
  const p = await f.open({ openStorage: async filename => {
    const storage = await openNodeSqliteStorage(filename); const commit = storage.commit.bind(storage);
    storage.commit = (writes, ctx) => {
      const start = writes.find(write => write.type === "entry" && write.value.kind === "ruukoto.command-start");
      if (start?.type === "entry") {
        const data = start.value.data as { prepared: { input: { tempDir: string } } };
        tempDir = data.prepared.input.tempDir; return Promise.reject(cause);
      }
      return commit(writes, ctx);
    };
    return storage;
  } });
  await source(p); const work = await p.work.delegate(draft("start-storage-failure"));
  await assert.rejects(p.harness.waitForTask(work.taskId, context), error => error === cause || error instanceof SessionFailed);
  assert.equal((await p.harness.closed).reason, "failed"); await p.close();
  assert.equal(f.launches(), 0); assert.equal(fs.existsSync(path.join(f.workspace, "count")), false);
  assert.ok(tempDir); assert.equal(fs.existsSync(tempDir), false);
  const storage = await openNodeSqliteStorage(path.join(f.directory, "personal.sqlite"));
  try {
    const tasks = await storage.scanTasks({ kind: "ruukoto.command" }, 8, undefined, context);
    assert.equal(tasks.items.length, 1);
    const entries = await storage.scanEntries({ conversationId: ROOT_CONVERSATION_ID }, 256, undefined, context);
    assert.equal(entries.items.filter(entry => entry.kind === "ruukoto.command-start").length, 0);
    assert.equal((await storage.scanEntries({ conversationId: work.agentId }, 256, undefined, context)).items.filter(entry => entry.kind === "ruukoto.command-admission").length, 1);
  } finally { await storage.close(context); }
});

test("durable 命令：回执已落盘而结果提交失败，重启读取原回执且不重发", async t => {
  const f = await fixture(t, "printf returned; echo x >> count; exit 23"), cause = new Error("command-result-storage-failed");
  let p = await f.open({ openStorage: async filename => {
    const storage = await openNodeSqliteStorage(filename); const commit = storage.commit.bind(storage);
    storage.commit = (writes, ctx) => writes.some(write => write.type === "entry" && write.value.kind === "ruukoto.command-observation") ? Promise.reject(cause) : commit(writes, ctx);
    return storage;
  } });
  await source(p); const work = await p.work.delegate(draft("result-storage-failure")), ref = await original(p);
  await assert.rejects(p.harness.waitForTask(work.taskId, context), error => error === cause || error instanceof SessionFailed);
  assert.equal((await p.harness.closed).reason, "failed"); await p.close();
  const records = fs.readdirSync(path.join(f.directory, "commands")).filter(name => name.startsWith("command-native_"));
  assert.equal(records.length, 1); assert.equal(fs.existsSync(path.join(f.directory, "commands", records[0], "receipt.json")), true);
  assert.equal(f.launches(), 1); assert.equal(fs.readFileSync(path.join(f.workspace, "count"), "utf8"), "x\n");
  p = await f.open();
  assert.equal((await p.harness.waitForTask(work.taskId, context)).state.outcome.status, "completed");
  assert.deepEqual((await p.commands!.list()).items[0].ref, ref);
  const detail = await p.commands!.detail(ref, "stdout");
  assert.deepEqual(detail.result, { effect: "returned", code: "command_returned", exitCode: 23 });
  assert.equal(detail.stopped, true); assert.equal(Buffer.from(detail.output!.data, "base64").toString(), "returned");
  assert.equal(f.launches(), 1); assert.equal(fs.readFileSync(path.join(f.workspace, "count"), "utf8"), "x\n");
});

for (const mode of ["auto-review", "full_access"] as const) test(`durable 命令：${mode} 未知暂停原源服务、主会话固定检查及委托全部成员，零 helper 外调`, async t => {
  let p!: PersonalHarness;
  let inspected = false;
  let release!: () => void;
  const waiting = new Promise<void>(resolve => { release = resolve; }); t.after(release);
  const f = await fixture(t, "echo x >> count", async request => {
    const last = request.messages.at(-1);
    if (request.system?.includes("你是个人助手的子 Agent")) {
      if (last?.role === "user" && last.content === "执行命令") return { kind: "tool_calls", calls: [{ id: "command", name: "run_command", arguments: { command: "echo x >> count" } }] };
      await waiting; return { kind: "text", text: "另一成员完成" };
    }
    if (last?.role === "user" && last.content === "委派并检查") return { kind: "tool_calls", calls: ["执行命令", "等待成员"].map((content, i) => ({ id: `member-${i}`, name: "background_work", arguments: { action: "delegate", content } })) };
    if (last?.role === "tool" && !inspected) {
      await unknown(p, await original(p));
      inspected = true;
      return { kind: "tool_calls", calls: [{ id: "inspection", name: "service_inspect", arguments: { unit: "personal-command-test.service" } }] };
    }
    return { kind: "text", text: String(last?.content) };
  });
  const helper = path.join(f.root, "helper"); fs.mkdirSync(path.join(helper, "units"), { recursive: true }); fs.mkdirSync(path.join(helper, "ops"));
  const helperPath = path.join(helper, "helper.mjs"), policyPath = path.join(helper, "services.json"), unit = "personal-command-test.service";
  fs.copyFileSync(new URL("./helpers/fake-service-helper.mjs", import.meta.url), helperPath);
  fs.writeFileSync(policyPath, JSON.stringify({ machineId: "test-machine", inspectUid: 1, inspectGid: 1, services: { [unit]: { actions: ["restart"] } } }));
  fs.writeFileSync(path.join(helper, "units", unit), "[Service]\nExecStart=/usr/bin/true\n");
  fs.writeFileSync(path.join(helper, "state.json"), JSON.stringify({ [unit]: { loadState: "loaded", activeState: "active", subState: "running", mainPid: 123, invocationId: "before", result: "success", activeEnterTimestamp: "2026-10-17T00:00:00Z", starts: 0 } }));
  const service: ServiceManagerConfig = { helperPath, policyPath, useSudo: false, sudoPath: "/usr/bin/sudo", timeouts: { inspectMs: 1000, restartMs: 1000, stopMs: 1000 } };
  f.failReceipt(); f.failStop(); p = await f.open({ service, serviceOperations: true });
  await p.harness.commit(async tx => { (await tx.doc(PersonalPermissionsDoc)).mode = mode; }, context);
  assert.match(await p.answer("委派并检查", "owner-source"), /work_source_paused/);
  const ref = await original(p), saved = (await p.harness.snapshot(PersonalCommandDoc, ref.requestId, context))!.command!;
  assert.deepEqual(await p.harness.commit(tx => personalServiceSourceBlocker(tx, "owner-source"), context), { command: ref.requestId, admission: saved.admission });
  await assert.rejects(p.service!.request({ requestId: "service-bypass", sourceRequestId: "owner-source", unit, mode: "full_access" }), code("work_source_paused"));
  const group = (await p.harness.commit(tx => listPersonalDelegations(tx), context)).items[0].ref;
  const progress = await p.harness.commit(tx => personalDelegationProgress(tx, group), context);
  assert.equal(progress.paused, true); assert.equal(progress.members.length, 2);
  await p.answer("新的独立说明", "fresh-note");
  for (const [i, member] of progress.members.entries()) await assert.rejects(p.work.append(member.ref, { requestId: `append-${i}`, content: "继续执行", sourceRequestId: "fresh-note" }), code("work_source_paused"));
  await assert.rejects(p.harness.commit(async tx => delegatePersonalAnalysis(tx, (await tx.doc(AgentDoc, ROOT_CONVERSATION_ID)).model!, { ...draft("continue-group"), sourceRequestId: "fresh-note", content: "续派成员" }, group), context), code("work_source_paused"));
  assert.equal(fs.existsSync(path.join(helper, "calls.log")), false); assert.equal((await p.inspections!.list()).length, 0);
  assert.equal(f.launches(), 1);
});

for (const mode of ["auto-review", "full_access"] as const) test(`durable 命令：${mode} 报告记录 command 暂停并跨重启观察原记录，效果和停止均核实才汇总`, async t => {
  let group!: PersonalDelegationRef;
  const f = await fixture(t, "echo x >> count", request => {
    const last = request.messages.at(-1);
    if (request.system?.includes("你是个人助手的子 Agent")) return last?.role === "user" && last.content === "报告前命令"
      ? { kind: "tool_calls", calls: [{ id: "command", name: "run_command", arguments: { command: "echo x >> count" } }] }
      : { kind: "text", text: "成员完成" };
    if (String(last?.content).startsWith("宿主委托汇总参考")) return { kind: "text", text: "完整命令汇总" };
    if (last?.role === "user" && last.content === "multi") return { kind: "tool_calls", calls: ["A", "B"].map(id => ({ id, name: "background_work", arguments: { action: "delegate", content: id } })) };
    if (last?.role === "user" && last.content === "report") return { kind: "tool_calls", calls: [{ id: "report", name: "background_work", arguments: { action: "report", delegation: group.entryId } }] };
    return { kind: "text", text: "完成" };
  });
  f.failReceipt(); f.failStop();
  let p!: PersonalHarness, command: PersonalCommandRef | undefined, armed = true;
  const provider = f.provider;
  p = await f.open({ provider: { ...provider, streamSimple: (model, input, options) => provider.streamSimple(model, input, { ...options, onPayload: async payload => {
    if (armed && JSON.stringify(input.messages.at(-1)).includes("宿主委托汇总参考")) {
      armed = false;
      await p.work.delegate({ requestId: "report-pause-command", sourceRequestId: "owner-source", content: "报告前命令" });
      command = await original(p); await unknown(p, command);
    }
    return await options?.onPayload?.(payload, model) ?? payload;
  } }) } });
  await p.harness.commit(async tx => { (await tx.doc(PersonalPermissionsDoc)).mode = mode; }, context);
  await p.answer("multi", "owner-source"); group = (await p.harness.commit(tx => listPersonalDelegations(tx), context)).items[0].ref;
  const members = (await p.harness.snapshot(PersonalDelegationDoc, String(group.entryId), context))!.delegation!.members;
  for (const member of members) await p.harness.waitForTask(member.taskId, context);
  await p.answer("report", "report-source");
  await until(async () => (await p.harness.snapshot(PersonalDelegationDoc, String(group.entryId), context))!.delegation!.report!.attempt === 1);
  assert.ok(command); const ref = command;
  const summaryCalls = () => f.server.calls.filter(request => String(request.messages.findLast(message => message.role === "user")?.content).startsWith("宿主委托汇总参考"));
  assert.equal(summaryCalls().length, 0);
  const report = (await p.harness.snapshot(PersonalDelegationDoc, String(group.entryId), context))!.delegation!.report!;
  assert.equal(report.pauses.length, 1);
  const pause = await p.harness.commit(tx => tx.entry(report.pauses[0]), context);
  assert.equal(pause!.kind, "ruukoto.report-pause");
  assert.deepEqual(pause!.data && typeof pause!.data === "object" && !Array.isArray(pause!.data) && pause!.data.blocker, { command: ref.requestId, admission: (await p.harness.snapshot(PersonalCommandDoc, ref.requestId, context))!.command!.admission });
  assert.equal(await p.answer("独立聊天", "independent"), "完成");
  await p.close(); p = await f.open();
  assert.equal((await p.harness.commit(tx => personalDelegationProgress(tx, group), context)).paused, true);
  await p.harness.commit(tx => resolvePersonalCommand(tx, ref, "applied", "已从独立目录 count 核实原操作一行"), context);
  await delay(30); assert.equal(summaryCalls().length, 0); assert.equal((await p.commands!.detail(ref, "stdout")).stopped, false);
  f.failStop(false); await p.harness.waitForTask(await p.commands!.stop(ref), context);
  assert.equal((await p.harness.waitForTask(report.taskId, context)).state.outcome.status, "completed");
  assert.deepEqual(await p.harness.commit(tx => personalReportResult(tx, group), context), { delivery: "local", state: "completed", text: "完整命令汇总" });
  assert.equal(summaryCalls().length, 1); assert.equal(f.launches(), 1); assert.equal(fs.readFileSync(path.join(f.workspace, "count"), "utf8"), "x\n");
});

test("durable 命令：在线 faulted 立即进入可核实状态，效果与原停止齐备前工作仍占用", async t => {
  const f = await fixture(t, "echo x >> count; printf started; sleep 30");
  f.failStop(); const p = await f.open(); await source(p);
  const work = await p.work.delegate(draft("online-fault")), ref = await original(p);
  await until(() => fs.existsSync(path.join(f.workspace, "count")));
  const task = await p.harness.commit(tx => tx.task(ref.taskId), context);
  assert.ok(task); assert.equal(task.state.status, "running");
  assert.equal((await p.harness.snapshot(PersonalCommandDoc, ref.requestId, context))!.command!.result!.code, "started");
  // SDK 的 Transaction.setTask 保留正常提交发布；只注入终态，不改原接纳、意图与 OS 绑定。
  await p.harness.commit(async tx => {
    const mutable = tx as typeof tx & { setTask(value: Extract<StorageWrite, { type: "task" }>["value"]): void };
    mutable.setTask({ ...task, memos: undefined, endedAt: Date.now(), state: { status: "terminal", outcome: { status: "faulted", error: { message: "injected-online-command-fault" } } } });
  }, context);
  const listed = (await p.commands!.list()).items[0];
  assert.deepEqual(listed.result, { effect: "effect_unknown", code: "interrupted" }); assert.equal(listed.stopped, false);
  const detail = await p.commands!.detail(ref, "stdout");
  assert.equal(detail.canResolve, true); assert.equal(detail.canRecheck, true); assert.equal(detail.stopped, false);
  assert.deepEqual(detail.result, listed.result);
  const canceled = p.work.cancel(work);
  await until(async () => (await p.harness.snapshot(PersonalWorkDoc, work.requestId, context))!.cancelRequested);
  await p.harness.commit(tx => resolvePersonalCommand(tx, ref, "applied", "count 中已观察到原命令的一行"), context);
  await delay(30);
  assert.deepEqual((await p.work.list()).find(agent => agent.id === work.agentId)!.work, work);
  assert.equal((await p.commands!.detail(ref, "stdout")).stopped, false);
  await assert.rejects(p.work.closeAgent(work.agentId), code("subagent_busy"));
  assert.equal(await p.answer("独立聊天", "online-fault-chat"), "完成");
  f.failStop(false);
  await p.harness.waitForTask(await p.commands!.stop(ref), context);
  assert.equal((await canceled).state.outcome.status, "aborted");
  assert.equal((await p.commands!.detail(ref, "stdout")).stopped, true);
  assert.equal((await p.harness.commit(tx => tx.task(ref.taskId), context))!.state.outcome!.status, "faulted");
  const reused = await p.work.delegate({ ...draft("after-online-fault", work.agentId), content: "继续分析" }); await p.harness.waitForTask(reused.taskId, context);
  assert.equal(f.launches(), 1); assert.equal(fs.readFileSync(path.join(f.workspace, "count"), "utf8"), "x\n");
});

test("命令权限提示：缺工作及读取失败覆盖旧完全访问说明，主会话不渲染子权限", async t => {
  const f = await fixture(t), p = await f.open(); await source(p);
  const work = await p.work.delegate({ ...draft("permission-render"), content: "继续分析" });
  await p.harness.waitForTask(work.taskId, context);
  const render = personalCommandWork(f.directory, f.commands).extension.sections![0].render;
  const input = { conversationId: work.agentId, agent: await p.main.agent(context), env: undefined, shown: { "command-permission": "当前工作命令权限：完全访问。" }, read: p.harness };
  assert.equal(await render(input, context), "当前工作命令权限无法核实，请结束本轮并报告拥有者。");
  t.mock.method(p.harness, "snapshot", async () => { throw new Error("read-failed"); });
  assert.equal(await render(input, context), "当前工作命令权限无法核实，请结束本轮并报告拥有者。");
  assert.equal(await render({ ...input, conversationId: ROOT_CONVERSATION_ID }, context), undefined);
});
