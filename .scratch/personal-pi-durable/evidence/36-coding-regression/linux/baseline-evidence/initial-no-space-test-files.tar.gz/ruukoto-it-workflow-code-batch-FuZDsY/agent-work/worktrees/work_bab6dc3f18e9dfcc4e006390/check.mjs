import assert from "node:assert/strict"; import {readFileSync} from "node:fs"; for(let i=1;i<=6;i++) assert.equal(readFileSync(`item-${i}.txt`,"utf8"),i===6?"base-6\n":`changed-${i}\n`);
