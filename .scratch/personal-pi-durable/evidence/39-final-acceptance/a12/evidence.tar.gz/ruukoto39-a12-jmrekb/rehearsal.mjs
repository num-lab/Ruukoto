import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import { createHash, randomBytes } from 'node:crypto';
import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { once } from 'node:events';
import { pathToFileURL } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import { setTimeout as delay } from 'node:timers/promises';

const [current, old, node] = process.argv.slice(2).map(p => p && path.resolve(p));
for (const p of [current, old, node]) assert.ok(p && /^[A-Za-z0-9_./-]+$/.test(p), '传入三个不含空白的绝对路径：current repo、old repo、node');
assert.equal(process.platform, 'linux');
assert.notEqual(current, old);
for (const p of [path.join(current, 'apps/ruukoto/bin/ruukoto.mjs'), path.join(old, 'apps/ruukoto/src/product.ts'), node]) assert.ok(fs.existsSync(p), p);
const root = fs.mkdtempSync('/tmp/ruukoto39-a12-');
fs.chmodSync(root, 0o700);
fs.copyFileSync(new URL(import.meta.url), path.join(root, 'rehearsal.mjs'));
const nonce = path.basename(root).toLowerCase();
const names = { old: `${nonce}-old.service`, fresh: `${nonce}-new.service`, rollback: `${nonce}-rollback.service`, scope: `${nonce}-scope.scope` };
const execute = promisify(execFile);
const steps = [];
const log = (stage, facts = {}) => { const row = { at: new Date().toISOString(), stage, ...facts }; steps.push(row); fs.appendFileSync(path.join(root, 'steps.jsonl'), JSON.stringify(row) + '\n', { mode: 0o600 }); process.stdout.write(JSON.stringify(row) + '\n'); };
async function run(file, args, allowFailure = false) {
  try { const result = await execute(file, args, { encoding: 'utf8', maxBuffer: 8 * 1024 * 1024, timeout: 30000 }); return { ...result, code: 0 }; }
  catch (error) { if (!allowFailure) throw error; return { stdout: String(error.stdout ?? ''), stderr: String(error.stderr ?? ''), code: error.code }; }
}
const ctl = (...args) => run('/usr/bin/systemctl', ['--user', ...args]);
async function until(check, label, timeout = 20000) { const end = Date.now() + timeout; while (!await check()) { assert.ok(Date.now() < end, label); await delay(40); } }
async function state(unit) {
  assert.ok(Object.values(names).includes(unit));
  const result = await run('/usr/bin/systemctl', ['--user', 'show', unit, '--property=Id,LoadState,ActiveState,SubState,MainPID,NRestarts,InvocationID,ControlGroup,Restart,UnitFileState'], true);
  const fields = Object.fromEntries(result.stdout.trim().split('\n').filter(Boolean).map(line => { const i = line.indexOf('='); return [line.slice(0, i), line.slice(i + 1)]; }));
  assert.ok(fields.LoadState, `无法核实 ${unit}`);
  return fields;
}
function proc(pid) { try { const raw = fs.readFileSync(`/proc/${pid}/stat`, 'utf8'); return { pid: Number(pid), startTime: raw.slice(raw.lastIndexOf(') ') + 2).split(' ')[19] }; } catch (error) { if (error.code === 'ENOENT' || error.code === 'ESRCH') return null; throw error; } }
function groupPids(group) {
  if (!group) return [];
  const directory = path.join('/sys/fs/cgroup', group);
  if (!fs.existsSync(directory)) return [];
  const pids = [];
  const visit = dir => { for (const item of fs.readdirSync(dir, { withFileTypes: true })) { const target = path.join(dir, item.name); if (item.isDirectory()) visit(target); else if (item.name === 'cgroup.procs') pids.push(...fs.readFileSync(target, 'utf8').trim().split(/\s+/).filter(Boolean).map(Number)); } };
  visit(directory); return [...new Set(pids)];
}
const imported = async (repo, relative) => import(pathToFileURL(path.join(repo, relative)).href);
const { MockModelServer } = await imported(current, 'test/helpers/mock-provider.ts');
const model = new MockModelServer(() => ({ kind: 'text', text: 'A12_FIXED_REPLY' }));
const modelBase = await model.start();
const TOKEN = '123:ruukoto39-a12-test-only';
const OWNER = '456';
const polls = [], sends = [];
let queue = [], sequence = 0;
const push = text => { const update = { update_id: ++sequence, message: { message_id: sequence, date: Math.floor(Date.now() / 1000), chat: { id: Number(OWNER), type: 'private' }, from: { id: Number(OWNER), is_bot: false, first_name: 'A12' }, text } }; queue.push(update); return update; };
const bot = http.createServer(async (req, res) => {
  try {
    const chunks = []; for await (const chunk of req) chunks.push(Buffer.from(chunk));
    const body = JSON.parse(Buffer.concat(chunks).toString() || '{}');
    const reply = result => res.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify({ ok: true, result }));
    if (req.url === `/bot${TOKEN}/getMe`) return reply({ id: 123, is_bot: true, username: 'ruukoto39_a12' });
    if (req.url === `/bot${TOKEN}/getUpdates`) {
      polls.push({ at: Date.now(), ...body });
      if (Number.isInteger(body.offset)) queue = body.offset < 0 ? queue.slice(body.offset) : queue.filter(item => item.update_id >= body.offset);
      await delay(25); if (!res.destroyed) reply(queue.slice(0, body.limit ?? 100)); return;
    }
    if (req.url === `/bot${TOKEN}/sendMessage`) { sends.push({ at: Date.now(), ...body }); return reply({ message_id: 10000 + sends.length, chat: { id: Number(body.chat_id), type: 'private' } }); }
    res.writeHead(404).end();
  } catch (error) { log('bot_failure', { message: String(error) }); res.destroy(); }
});
bot.listen(0, '127.0.0.1'); await once(bot, 'listening');
const apiBase = `http://127.0.0.1:${bot.address().port}`;
const configDir = path.join(os.homedir(), '.config/systemd/user');
fs.mkdirSync(configDir, { recursive: true });
const unitDir = path.join(root, 'units'); fs.mkdirSync(unitDir, { mode: 0o700 });
const installed = [], clients = [];
let scopeProcess;
const common = ['HOME=' + os.homedir(), 'PATH=' + path.dirname(node) + ':/usr/bin:/bin', 'XDG_RUNTIME_DIR=' + process.env.XDG_RUNTIME_DIR, 'DBUS_SESSION_BUS_ADDRESS=' + (process.env.DBUS_SESSION_BUS_ADDRESS || `unix:path=${process.env.XDG_RUNTIME_DIR}/bus`)];
const quote = value => '"' + String(value).replaceAll('%', '%%').replaceAll('\\', '\\\\').replaceAll('"', '\\"') + '"';
function install(unit, args) {
  assert.ok(Object.values(names).includes(unit));
  const source = path.join(unitDir, unit), link = path.join(configDir, unit);
  assert.equal(fs.existsSync(link), false);
  fs.writeFileSync(source, `[Unit]\nDescription=Ruukoto 39 isolated A12 ${unit}\n[Service]\nType=simple\nExecStart=${['/usr/bin/env', '-i', ...common, ...args].map(quote).join(' ')}\nRestart=on-failure\nRestartSec=1\nKillMode=control-group\nTimeoutStopSec=20\nStandardOutput=append:${root}/${unit}.log\nStandardError=append:${root}/${unit}.log\n[Install]\nWantedBy=default.target\n`, { mode: 0o600 });
  fs.symlinkSync(source, link); installed.push(unit);
}
const { ControlClient } = await imported(old, 'packages/control/src/client.ts');
async function oldClient(directory) {
  let client;
  await until(async () => {
    try { client = await ControlClient.connect(path.join(directory, 'control/control.sock'), 200); }
    catch (error) { if (['ENOENT', 'ECONNREFUSED', 'control_unavailable', 'connect_timeout', 'connection_error'].includes(error.code)) return false; throw error; }
    return true;
  }, '旧入口未就绪');
  await client.authenticate(fs.readFileSync(path.join(directory, 'control/owner.token'), 'utf8').trim());
  await client.handshake(); clients.push(client); return client;
}
async function configureOld(client, enable = true) {
  await client.request('add_credential', { name: 'a12-bot', host: new URL(apiBase).host, header: 'none', purpose: 'telegram_bot', secret: TOKEN });
  await client.request('telegram_configure', { api_base: apiBase, credential: 'a12-bot', user_id: OWNER });
  if (enable) await client.request('telegram_set_enabled', { enabled: true });
}
function prepareOld(directory) {
  for (const name of ['data', 'agent', 'control']) fs.mkdirSync(path.join(directory, name), { recursive: true, mode: 0o700 });
  fs.writeFileSync(path.join(directory, 'agent/models.json'), JSON.stringify({ providers: { mock: { name: 'Mock', baseUrl: modelBase, apiKey: 'a12-test-only', api: 'openai-completions', models: [{ id: 'mock-model', name: 'Mock', reasoning: false, input: ['text'], cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }, contextWindow: 128000, maxTokens: 1024, compat: { supportsUsageInStreaming: true } }] } } }) + '\n', { mode: 0o600 });
}
function oldArgs(directory) { return ['RUUKOTO_CONTROL_DIR=' + path.join(directory, 'control'), node, '--import', path.join(old, 'node_modules/tsx/dist/loader.mjs'), path.join(old, 'apps/ruukoto/src/main.ts'), 'server', '--data-dir', path.join(directory, 'data'), '--agent-dir', path.join(directory, 'agent'), '--model', 'mock/mock-model', '--thinking', 'off', '--tools', 'mock']; }
async function stopAndMask(unit) {
  const before = await state(unit), identity = proc(before.MainPID);
  await ctl('disable', unit); await ctl('stop', unit); await ctl('mask', '--runtime', unit);
  await delay(2200);
  const after = await state(unit);
  assert.ok(['inactive', 'failed'].includes(after.ActiveState), JSON.stringify(after));
  assert.equal(after.UnitFileState, 'masked-runtime');
  assert.equal(Number(after.MainPID), 0);
  assert.deepEqual(groupPids(before.ControlGroup), []);
  if (identity) assert.notDeepEqual(proc(identity.pid), identity);
  const attempt = await run('/usr/bin/systemctl', ['--user', 'start', unit], true);
  assert.notEqual(attempt.code, 0, '旧单元 mask 后仍被启动');
  log('stopped_and_masked', { unit, before, identity, after, restartAttemptCode: attempt.code });
}
function fingerprint(directory) {
  const items = [];
  const visit = (dir, relative = '') => { for (const name of fs.readdirSync(dir).sort()) { const target = path.join(dir, name), key = path.join(relative, name), stat = fs.lstatSync(target); if (stat.isDirectory()) { items.push({ path: key, type: 'directory', mode: stat.mode & 0o777 }); visit(target, key); } else if (stat.isFile()) items.push({ path: key, type: 'file', bytes: stat.size, mode: stat.mode & 0o777, sha256: createHash('sha256').update(fs.readFileSync(target)).digest('hex') }); else throw new Error(`归档仍含特殊对象 ${target}`); } };
  visit(directory); return items;
}
async function freeze(directory, label) {
  const protect = dir => { for (const item of fs.readdirSync(dir, { withFileTypes: true })) { const target = path.join(dir, item.name); if (item.isDirectory()) protect(target); else if (item.isFile()) fs.chmodSync(target, 0o400); else throw new Error(`归档仍含特殊对象 ${target}`); } fs.chmodSync(dir, 0o500); };
  protect(directory); const manifest = fingerprint(directory);
  fs.writeFileSync(path.join(root, label + '-manifest.json'), JSON.stringify(manifest, null, 2) + '\n', { mode: 0o600 });
  const archive = path.join(root, label + '-backup.tar.gz'); await run('/usr/bin/tar', ['-czf', archive, '-C', path.dirname(directory), path.basename(directory)]); fs.chmodSync(archive, 0o400);
  log('archive_frozen', { label, files: manifest.filter(item => item.type === 'file').length, sha256: createHash('sha256').update(JSON.stringify(manifest)).digest('hex'), backupSha256: createHash('sha256').update(fs.readFileSync(archive)).digest('hex') }); return manifest;
}
const oldDirectory = path.join(root, 'old-profile'), newDirectory = path.join(root, 'durable-profile'), rollbackDirectory = path.join(root, 'rollback-profile');
try {
  assert.ok(process.env.XDG_RUNTIME_DIR && fs.existsSync(path.join(process.env.XDG_RUNTIME_DIR, 'bus')), '缺少 user manager');
  log('environment', { root, current, old, node, platform: process.platform, nodeVersion: process.version, loadavg: os.loadavg(), cpuCount: os.availableParallelism(), uname: (await run('/usr/bin/uname', ['-a'])).stdout.trim(), units: names, real: ['Linux user service', 'Restart=on-failure', '独立 user scope', 'PID/starttime/cgroup 停止核实'], doubles: ['本机 Telegram Bot API', '本机模型', 'scope 心跳执行探针'] });
  const sourceMetadata = {};
  for (const [label, repo] of [['current', current], ['old', old]]) {
    const hashes = {};
    for (const relative of ['package-lock.json', 'package.json', 'apps/ruukoto/package.json', 'apps/ruukoto/src/main.ts', 'worker/worker.mjs', 'node_modules/.package-lock.json']) { const file = path.join(repo, relative); if (fs.existsSync(file)) hashes[relative] = createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
    sourceMetadata[label] = { directory: repo, hashes, snapshotGitHead: (await run('/usr/bin/git', ['-C', repo, 'rev-parse', 'HEAD'])).stdout.trim() };
  }
  fs.writeFileSync(path.join(root, 'source-metadata.json'), JSON.stringify({ ...sourceMetadata, originalOldRef: '12b1a66c source export; local snapshot Git is not original history' }, null, 2) + '\n', { mode: 0o600 });
  const codeBackup = path.join(root, 'old-code-and-lock.tar.gz');
  await run('/usr/bin/tar', ['--exclude=.git', '--exclude=node_modules', '--exclude=*/node_modules', '--exclude=.scratch', '-czf', codeBackup, '-C', old, '.']); fs.chmodSync(codeBackup, 0o400);
  log('old_code_and_lock_preserved', { sha256: createHash('sha256').update(fs.readFileSync(codeBackup)).digest('hex'), sourceMetadata });
  prepareOld(oldDirectory); install(names.old, oldArgs(oldDirectory)); await ctl('daemon-reload'); await ctl('enable', names.old); await ctl('start', names.old);
  let client = await oldClient(oldDirectory); await configureOld(client);
  const baseline = push('A12_OLD_BASELINE'); await until(() => sends.some(send => Number(send.reply_parameters?.message_id) === baseline.message.message_id), '旧真实入口聊天未完成');
  log('old_entry_chat', { modelCalls: model.calls.length, sends: sends.length });
  const heartbeat = path.join(root, 'scope-heartbeat.log');
  scopeProcess = spawn('/usr/bin/systemd-run', ['--user', '--scope', '--unit', names.scope, '--property=Delegate=yes', node, '--input-type=module', '--eval', `import fs from 'node:fs'; setInterval(()=>fs.appendFileSync(${JSON.stringify(heartbeat)}, Date.now()+'\\n'),100);`], { stdio: ['ignore', 'ignore', 'pipe'] });
  let scopeError = ''; scopeProcess.stderr.on('data', chunk => { scopeError += String(chunk); });
  await until(() => fs.existsSync(heartbeat), '独立 scope 未就绪：' + scopeError);
  const scopeBefore = await state(names.scope); assert.ok(scopeBefore.ControlGroup); assert.ok(groupPids(scopeBefore.ControlGroup).length);
  const before = await state(names.old), original = proc(before.MainPID); client.close();
  await ctl('kill', '--kill-whom=main', '--signal=SIGKILL', names.old);
  await until(async () => { const after = await state(names.old); return Number(after.NRestarts) > Number(before.NRestarts) && after.MainPID !== before.MainPID && Number(after.MainPID) > 0 && after.InvocationID !== before.InvocationID; }, '旧服务未自动重启');
  client = await oldClient(oldDirectory); const restarted = await state(names.old); assert.notDeepEqual(proc(original.pid), original); log('old_restart_verified', { before, original, restarted }); client.close();
  await stopAndMask(names.old);
  const aliveAt = fs.statSync(heartbeat).size; await delay(350); assert.ok(fs.statSync(heartbeat).size > aliveAt, '独立 scope 不应被 KillMode=control-group 顺带停止');
  const scopeIdentities = groupPids(scopeBefore.ControlGroup).map(proc).filter(Boolean);
  await ctl('stop', names.scope); await until(() => groupPids(scopeBefore.ControlGroup).length === 0, 'scope cgroup 未清空');
  const stoppedSize = fs.statSync(heartbeat).size; await delay(350); assert.equal(fs.statSync(heartbeat).size, stoppedSize); for (const identity of scopeIdentities) assert.notDeepEqual(proc(identity.pid), identity);
  log('independent_scope_stopped', { before: scopeBefore, identities: scopeIdentities, after: await state(names.scope), heartbeatBytes: stoppedSize });
  const { Db } = await imported(old, 'packages/core/src/db.ts'); const { Store } = await imported(old, 'packages/core/src/store.ts'); const { SchedulerStore } = await imported(old, 'packages/channels/src/scheduler/store.ts');
  const database = new Db(path.join(oldDirectory, 'data')), store = new Store(database), scheduler = new SchedulerStore(store);
  let seeded;
  store.withTx(() => {
    const main = store.getAgentRole('main'); assert.ok(main);
    const tg = database.prepare('SELECT * FROM telegram_config WHERE id=1').get();
    const target = { channel: 'telegram', account: '123', chatId: OWNER, configVersion: tg.config_version };
    const inbound = store.registerInboundEvent({ source: 'telegram', externalId: '123:456:a12-registered', actor: 'telegram:' + OWNER, targetRole: 'main', body: 'A12_OLD_REGISTERED_INBOUND', replyTarget: target }).event;
    const notification = scheduler.insertOp({ sourceKind: 'confirmation', sourceKey: 'a12-pending', taskId: null, hostOpId: null, target, text: 'A12_OLD_PENDING_NOTIFICATION', sourceRefs: [] }).op;
    const at = new Date(Date.now() - 60000).toISOString();
    const plan = scheduler.insertSchedule({ createKey: 'a12-active', paramsDigest: 'a12', createTaskId: null, createOpId: null, projectId: main.projectId, createPermissionVersion: 1, accessMode: 'confirm', rule: { kind: 'once', at, timeZone: 'UTC', disambiguation: 'compatible' }, instruction: 'A12_OLD_ACTIVE_SCHEDULE', sourceRefs: [], target, nextDueAt: at, tzData: 'UTC', reason: 'A12 隔离旧积压' }, 'a12');
    const task = store.insertQueuedTask({ sessionId: main.sessionId, requestId: 'a12-unknown', input: 'A12_OLD_UNKNOWN_EXECUTION', modelSelection: null, submissionDigest: createHash('sha256').update('a12-unknown').digest('hex'), agentId: 'main' }).task;
    store.recordToolIntent({ id: 'a12-unknown-op', taskId: task.id, sessionId: task.sessionId, toolName: 'bash', params: { command: 'A12_OLD_UNKNOWN_EXECUTION' } }); store.markToolOpEffectUnknown('a12-unknown-op');
    database.prepare("UPDATE tasks SET status='interrupted', effect_unknown=1, interrupt_reason='a12_fixture_unknown' WHERE id=?").run(task.id);
    seeded = { inbound, notification, plan, task: store.getTask(task.id), operation: store.getToolOp('a12-unknown-op') };
  });
  database.close();
  const checkpoint = new DatabaseSync(path.join(oldDirectory, 'data/ruukoto.db')); checkpoint.exec('PRAGMA wal_checkpoint(TRUNCATE)'); checkpoint.close();
  fs.writeFileSync(path.join(root, 'old-seeded-records.json'), JSON.stringify(seeded, null, 2) + '\n', { mode: 0o600 });
  assert.equal(seeded.inbound.status, 'registered'); assert.equal(seeded.notification.status, 'pending'); assert.equal(seeded.plan.status, 'active'); assert.equal(seeded.operation.effectUnknown, true);
  const oldManifest = await freeze(oldDirectory, 'old');
  const { savePersonalConfig } = await imported(current, 'apps/ruukoto/src/personal-config.ts'); const { configurePersonalTelegram } = await imported(current, 'apps/ruukoto/src/personal-cli.ts'); const { personalControl } = await imported(current, 'apps/ruukoto/src/personal-control.ts');
  await savePersonalConfig(newDirectory, { api: 'openai-completions', baseUrl: modelBase, modelId: 'mock-model', apiKeyEnv: 'A12_MODEL_KEY', contextWindow: 128000, maxTokens: 1024 });
  process.env.A12_BOT_KEY = TOKEN;
  push('A12_OLD_PLATFORM_BACKLOG'); const pairingStart = polls.length;
  const answers = ['1', apiBase, 'A12_BOT_KEY', '2', '', '1'];
  await configurePersonalTelegram({ question: async prompt => { if (prompt.includes('私聊发送')) push(prompt.match(/“([^”]+)”/)[1]); assert.ok(answers.length, prompt); return answers.shift(); }, write: text => fs.appendFileSync(path.join(root, 'pairing.log'), text, { mode: 0o600 }) }, newDirectory);
  const binding = JSON.parse(fs.readFileSync(path.join(newDirectory, 'telegram.json'), 'utf8')); assert.equal(queue.filter(update => update.update_id <= binding.boundary).length, 0);
  log('current_takeover_boundary', { boundary: binding.boundary, polls: polls.slice(pairingStart) });
  const beforeNew = { calls: model.calls.length, sends: sends.length };
  install(names.fresh, ['RUUKOTO_PERSONAL_DIR=' + newDirectory, 'A12_MODEL_KEY=a12-test-only', 'A12_BOT_KEY=' + TOKEN, node, path.join(current, 'apps/ruukoto/bin/ruukoto.mjs'), 'serve']); await ctl('daemon-reload'); await ctl('start', names.fresh);
  await until(async () => { try { await personalControl(newDirectory, 'GET', '/status'); return true; } catch (error) { if (['control_unavailable', 'control_starting', 'control_response_lost'].includes(error.code)) return false; throw error; } }, '当前入口未就绪');
  await delay(1300); assert.equal(model.calls.length, beforeNew.calls); assert.equal(sends.length, beforeNew.sends);
  const fresh = push('A12_NEW_ACCEPTED_ONCE'); await until(() => sends.some(send => Number(send.reply_parameters?.message_id) === fresh.message.message_id), '当前入口新消息未完成');
  assert.equal(model.calls.length, beforeNew.calls + 1); assert.equal(sends.length, beforeNew.sends + 1); assert.deepEqual(fingerprint(oldDirectory), oldManifest);
  log('current_takeover_verified', { modelCalls: model.calls.length - beforeNew.calls, sends: sends.length - beforeNew.sends, oldArchiveUnchanged: true });
  await stopAndMask(names.fresh);
  const newManifest = await freeze(newDirectory, 'durable');
  prepareOld(rollbackDirectory); install(names.rollback, oldArgs(rollbackDirectory)); await ctl('daemon-reload'); await ctl('start', names.rollback);
  client = await oldClient(rollbackDirectory); await configureOld(client, false);
  const lostDuringWindow = push('A12_ROLLBACK_WINDOW_UNACCEPTED');
  const fetchUpdates = async offset => { const response = await fetch(apiBase + `/bot${TOKEN}/getUpdates`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ offset, timeout: 0, limit: 100 }) }); assert.equal(response.status, 200); return (await response.json()).result; };
  const last = await fetchUpdates(-1); assert.ok(last.length); const rollbackBoundary = last.at(-1).update_id; await fetchUpdates(rollbackBoundary + 1); assert.ok(rollbackBoundary >= lostDuringWindow.update_id);
  const beforeRollback = { calls: model.calls.length, sends: sends.length };
  await client.request('telegram_set_enabled', { enabled: true });
  await delay(1300); assert.equal(model.calls.length, beforeRollback.calls); assert.equal(sends.length, beforeRollback.sends);
  const accepted = push('A12_ROLLBACK_NEW_ACCEPTED_ONCE'); await until(() => sends.some(send => Number(send.reply_parameters?.message_id) === accepted.message.message_id), '空白旧代码回退新消息未完成');
  assert.equal(model.calls.length, beforeRollback.calls + 1); assert.equal(sends.length, beforeRollback.sends + 1);
  const read = new DatabaseSync(path.join(rollbackDirectory, 'data/ruukoto.db'), { readOnly: true });
  const rollbackCounts = { inbound: read.prepare('SELECT count(*) n FROM inbound_events').get().n, pending: read.prepare("SELECT count(*) n FROM notification_ops WHERE status='pending'").get().n, schedules: read.prepare('SELECT count(*) n FROM schedules').get().n, unknown: read.prepare('SELECT count(*) n FROM tool_ops WHERE effect_unknown=1').get().n };
  read.close(); assert.equal(rollbackCounts.schedules, 0); assert.equal(rollbackCounts.unknown, 0); assert.equal(rollbackCounts.pending, 0);
  client.close(); await stopAndMask(names.rollback);
  assert.deepEqual(fingerprint(oldDirectory), oldManifest); assert.deepEqual(fingerprint(newDirectory), newManifest);
  // WAL只读连接也可能创建sidecar；核对已checkpoint主库的字节副本，原归档不再交给SQLite打开。
  const readCopy = path.join(root, 'old-archive-readcheck.sqlite'); fs.copyFileSync(path.join(oldDirectory, 'data/ruukoto.db'), readCopy); fs.chmodSync(readCopy, 0o600);
  assert.equal(createHash('sha256').update(fs.readFileSync(readCopy)).digest('hex'), createHash('sha256').update(fs.readFileSync(path.join(oldDirectory, 'data/ruukoto.db'))).digest('hex'));
  const archiveRead = new DatabaseSync(readCopy, { readOnly: true });
  const retained = { registered: archiveRead.prepare("SELECT count(*) n FROM inbound_events WHERE body='A12_OLD_REGISTERED_INBOUND' AND status='registered'").get().n, pending: archiveRead.prepare("SELECT count(*) n FROM notification_ops WHERE text='A12_OLD_PENDING_NOTIFICATION' AND status='pending'").get().n, active: archiveRead.prepare("SELECT count(*) n FROM schedules WHERE instruction='A12_OLD_ACTIVE_SCHEDULE' AND status='active'").get().n, unknown: archiveRead.prepare("SELECT count(*) n FROM tool_ops WHERE id='a12-unknown-op' AND effect_unknown=1").get().n }; archiveRead.close(); assert.deepEqual(retained, { registered: 1, pending: 1, active: 1, unknown: 1 });
  assert.deepEqual(fingerprint(oldDirectory), oldManifest);
  log('blank_profile_rollback_verified', { boundary: rollbackBoundary, rollbackCounts, oldRetained: retained, oldArchiveUnchanged: true, durableArchiveUnchanged: true });
  fs.writeFileSync(path.join(root, 'platform.json'), JSON.stringify({ polls, sends }, null, 2) + '\n', { mode: 0o600 });
  fs.writeFileSync(path.join(root, 'model-calls.json'), JSON.stringify(model.calls, null, 2) + '\n', { mode: 0o600 });
  fs.writeFileSync(path.join(root, 'summary.json'), JSON.stringify({ status: 'checks_passed_cleanup_pending', root, source: { current, old }, node: process.version, coverage: ['旧实际入口', '真实自动重启', '真实独立 scope 停止', '接管前核实', '平台替身 ack 边界', '四类旧积压不执行', '旧代码第三空白档案回退', '双归档内容与权限指纹不变'], limitations: ['真实 IM/模型另验', 'scope 为真实 OS 心跳探针，非原生 worker 全链路', 'QQ 旧重投由定向离线用例另验'] }, null, 2) + '\n', { mode: 0o600 });
} catch (error) {
  fs.writeFileSync(path.join(root, 'failure.json'), JSON.stringify({ message: String(error), stack: error.stack }, null, 2) + '\n', { mode: 0o600 }); log('failed', { message: String(error) }); process.exitCode = 1;
} finally {
  fs.writeFileSync(path.join(root, 'platform.json'), JSON.stringify({ polls, sends }, null, 2) + '\n', { mode: 0o600 });
  fs.writeFileSync(path.join(root, 'model-calls.json'), JSON.stringify(model.calls, null, 2) + '\n', { mode: 0o600 });
  for (const client of clients) client.close();
  for (const unit of installed) {
    try { await ctl('stop', unit); await run('/usr/bin/systemctl', ['--user', 'disable', unit], true); await run('/usr/bin/systemctl', ['--user', 'unmask', '--runtime', unit], true); fs.rmSync(path.join(configDir, unit), { force: true }); }
    catch (error) { log('unit_cleanup_failed', { unit, message: String(error) }); process.exitCode = 1; }
  }
  if (scopeProcess) { try { await run('/usr/bin/systemctl', ['--user', 'stop', names.scope], true); } catch (error) { log('scope_cleanup_failed', { message: String(error) }); process.exitCode = 1; } }
  await ctl('daemon-reload');
  bot.closeAllConnections(); await new Promise(resolve => bot.close(resolve)); await model.close();
  const cleanup = {};
  for (const unit of Object.values(names)) { const facts = await state(unit); cleanup[unit] = facts; assert.notEqual(facts.ActiveState, 'active'); assert.equal(Number(facts.MainPID || 0), 0); }
  fs.writeFileSync(path.join(root, 'cleanup.json'), JSON.stringify(cleanup, null, 2) + '\n', { mode: 0o600 });
  if (fs.existsSync(path.join(root, 'summary.json'))) { const summary = JSON.parse(fs.readFileSync(path.join(root, 'summary.json'), 'utf8')); summary.status = process.exitCode ? 'cleanup_failed' : 'passed'; fs.writeFileSync(path.join(root, 'summary.json'), JSON.stringify(summary, null, 2) + '\n', { mode: 0o600 }); }
  log('finished', { root, exitCode: process.exitCode ?? 0 });
}
