import os,json,sys
roots=sys.argv[1:]
assert all(p.startswith('/tmp/ruukoto39-a12-') for p in roots)
ancestors=set()
pid=os.getpid()
while pid>0 and pid not in ancestors:
 ancestors.add(pid)
 try:
  raw=open('/proc/%d/stat'%pid).read()
  pid=int(raw[raw.rfind(') ')+2:].split()[1])
 except (FileNotFoundError,PermissionError): break
matches=[]
for entry in os.scandir('/proc'):
 if not entry.name.isdigit() or int(entry.name) in ancestors: continue
 for name in ('cmdline','environ','cwd'):
  try: value=os.readlink(entry.path+'/'+name) if name=='cwd' else open(entry.path+'/'+name,'rb').read().decode(errors='replace')
  except (FileNotFoundError,ProcessLookupError,PermissionError): continue
  hit=[root for root in roots if root in value]
  if hit: matches.append(dict(pid=int(entry.name),surface=name,roots=hit))
unit_links=[]
for root in roots:
 rows=[json.loads(line) for line in open(root+'/steps.jsonl')]
 units=list(rows[0]['units'].values())
 for base in (os.path.expanduser('~/.config/systemd/user'),os.environ['XDG_RUNTIME_DIR']+'/systemd/user'):
  if not os.path.isdir(base): continue
  for directory,dirs,files in os.walk(base):
   for name in files+dirs:
    if name in units: unit_links.append(os.path.join(directory,name))
result=dict(roots=roots,matching_processes=matches,remaining_exact_unit_links=unit_links,loadavg=os.getloadavg())
print(json.dumps(result,indent=2))
assert not matches and not unit_links,result
