#!/bin/sh
set -eu
if [ "$#" -ne 3 ]; then
  echo 'usage: ruukoto39-a12-rehearsal.sh CURRENT_REPO OLD_REPO NODE_BIN' >&2
  exit 2
fi
current_repo=$1
old_repo=$2
node_bin=$3
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "$node_bin" --import "$current_repo/node_modules/tsx/dist/loader.mjs" "$script_dir/ruukoto39-a12-rehearsal.mjs" "$current_repo" "$old_repo" "$node_bin"
