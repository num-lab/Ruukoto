import os,sys,json,hashlib,stat
root=sys.argv[1]
assert root.startswith('/tmp/ruukoto39-a12-')
result={}
for label,name in [('old','old-profile'),('durable','durable-profile')]:
 expected=json.load(open(os.path.join(root,label+'-manifest.json')))
 rows=[]
 def walk(directory,prefix=''):
  for name in sorted(os.listdir(directory)):
   target=os.path.join(directory,name)
   key=os.path.join(prefix,name)
   info=os.lstat(target)
   if stat.S_ISDIR(info.st_mode):
    rows.append(dict(path=key,type='directory',mode=stat.S_IMODE(info.st_mode)))
    walk(target,key)
   else:
    assert stat.S_ISREG(info.st_mode),target
    rows.append(dict(path=key,type='file',bytes=info.st_size,mode=stat.S_IMODE(info.st_mode),sha256=hashlib.sha256(open(target,'rb').read()).hexdigest()))
 walk(os.path.join(root,name))
 assert expected==rows,(label,expected,rows)
 result[label]=dict(unchanged=True,files=sum(row['type']=='file' for row in rows))
print(json.dumps(result))
