import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import net from 'node:net';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { once } from 'node:events';
import { setTimeout as delay } from 'node:timers/promises';
const execute=promisify(execFile);
const root=fs.mkdtempSync('/tmp/ruukoto39-browser-'); fs.chmodSync(root,0o700); fs.copyFileSync(new URL(import.meta.url),path.join(root,'probe.mjs'));
const binary=path.join(os.homedir(),'.local/ruukoto39/tools/agent-browser-linux-arm64-v0.39.1'),chrome='/snap/bin/chromium';
const profile=path.join(root,'chromium-profile'),sockets=path.join(root,'sockets'),session=path.basename(root).toLowerCase();
for(const dir of [profile,sockets])fs.mkdirSync(dir,{mode:0o700});
const config=path.join(root,'config.json');fs.writeFileSync(config,'{}\n',{mode:0o600});
const events=[];const log=(stage,facts={})=>{const row={at:new Date().toISOString(),stage,...facts};events.push(row);fs.appendFileSync(path.join(root,'steps.jsonl'),JSON.stringify(row)+'\n',{mode:0o600});process.stdout.write(JSON.stringify(row)+'\n');};
const env={HOME:os.homedir(),PATH:'/usr/bin:/bin',XDG_RUNTIME_DIR:process.env.XDG_RUNTIME_DIR,DBUS_SESSION_BUS_ADDRESS:process.env.DBUS_SESSION_BUS_ADDRESS,AGENT_BROWSER_SOCKET_DIR:sockets,AGENT_BROWSER_IDLE_TIMEOUT_MS:'60000'};
const run=async(args)=>{const result=await execute(binary,['--config',config,'--session',session,'--json',...args],{env,cwd:root,timeout:20000,maxBuffer:4*1024*1024});return{stdout:result.stdout,stderr:result.stderr,json:JSON.parse(result.stdout)};};
function info(pid){try{const raw=fs.readFileSync(`/proc/${pid}/stat`,'utf8'),fields=raw.slice(raw.lastIndexOf(') ')+2).split(' ');return{pid:Number(pid),ppid:Number(fields[1]),startTime:fields[19],state:fields[0],argv:fs.readFileSync(`/proc/${pid}/cmdline`,'utf8').replaceAll('\0',' ').trim(),cgroup:fs.readFileSync(`/proc/${pid}/cgroup`,'utf8').trim(),apparmor:fs.readFileSync(`/proc/${pid}/attr/current`,'utf8').trim(),userNamespace:fs.readlinkSync(`/proc/${pid}/ns/user`),status:fs.readFileSync(`/proc/${pid}/status`,'utf8').split('\n').filter(s=>/^(NoNewPrivs|Seccomp|NSpid|Uid):/.test(s))};}catch(error){if(['ENOENT','ESRCH','EACCES'].includes(error.code))return null;throw error;}}
const list=()=>fs.readdirSync('/proc').filter(s=>/^\d+$/.test(s)).map(info).filter(Boolean);
const alive=identity=>{const now=info(identity.pid);return now&&now.startTime===identity.startTime&&!now.state.startsWith('Z');};
async function until(check,label,timeout=20000){const end=Date.now()+timeout;while(!await check()){assert.ok(Date.now()<end,label);await delay(50);}}
const page=http.createServer((req,res)=>{res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><html><head><title>Ruukoto 39 local browser probe</title></head><body><h1>Ruukoto 39 real headless probe</h1><p>This page is served only on loopback.</p><button id="probe">Local action</button></body></html>');});page.listen(0,'127.0.0.1');await once(page,'listening');const pageUrl=`http://127.0.0.1:${page.address().port}/`;
const portServer=net.createServer();portServer.listen(0,'127.0.0.1');await once(portServer,'listening');const debugPort=portServer.address().port;await new Promise(resolve=>portServer.close(resolve));const cdp=`http://127.0.0.1:${debugPort}`;
let child,identities=[],endpoint,cdpVerified=false;
try{
 log('environment',{root,binary,chrome,pageUrl,cdp,sysctls:(await execute('/usr/sbin/sysctl',['kernel.unprivileged_userns_clone','kernel.apparmor_restrict_unprivileged_userns'])).stdout.trim(),loadavg:os.loadavg()});
 const stderr=fs.openSync(path.join(root,'chromium.stderr.log'),'w',0o600);
 const args=['--headless=new','--no-first-run','--no-default-browser-check','--remote-debugging-address=127.0.0.1',`--remote-debugging-port=${debugPort}`,`--user-data-dir=${profile}`,'about:blank'];
 assert.ok(!args.some(x=>x.includes('no-sandbox')));
 child=spawn(chrome,args,{env,cwd:profile,detached:true,stdio:['ignore','ignore',stderr]});fs.closeSync(stderr);child.on('error',error=>log('spawn_error',{message:String(error)}));
 await until(async()=>{try{const response=await fetch(cdp+'/json/version',{signal:AbortSignal.timeout(1000)});if(!response.ok)return false;endpoint=await response.json();return true;}catch{return false;}},'Chromium没有在预算内提供CDP',30000);
 assert.ok(fs.readFileSync(path.join(root,'chromium.stderr.log'),'utf8').includes(endpoint.webSocketDebuggerUrl),'CDP与本次浏览器启动日志身份不符');cdpVerified=true;
 const opened=await run(['--cdp',cdp,'open',pageUrl]);fs.writeFileSync(path.join(root,'open.json'),JSON.stringify(opened,null,2)+'\n',{mode:0o600});
 const snapshot=await run(['--cdp',cdp,'snapshot']);fs.writeFileSync(path.join(root,'local-snapshot.json'),JSON.stringify(snapshot,null,2)+'\n',{mode:0o600});assert.match(snapshot.stdout,/Ruukoto 39 real headless probe/);assert.match(snapshot.stdout,/Local action/);
 let rows=list(),owned=rows.filter(row=>row.argv.includes(`--user-data-dir=${profile}`));const pids=new Set(owned.map(row=>row.pid));let changed=true;while(changed){changed=false;for(const row of rows)if(pids.has(row.ppid)&&!pids.has(row.pid)){pids.add(row.pid);changed=true;}}
 identities=rows.filter(row=>pids.has(row.pid));assert.ok(identities.length);for(const row of identities)assert.ok(!row.argv.includes('--no-sandbox'),JSON.stringify(row));fs.writeFileSync(path.join(root,'browser-processes.json'),JSON.stringify(identities,null,2)+'\n',{mode:0o600});
 const sandboxOpen=await run(['--cdp',cdp,'open','chrome://sandbox/']);const sandbox=await run(['--cdp',cdp,'snapshot']);fs.writeFileSync(path.join(root,'sandbox-snapshot.json'),JSON.stringify(sandbox,null,2)+'\n',{mode:0o600});
 log('snapshot_passed',{localSnapshot:snapshot.json,browser:endpoint.Browser,processes:identities.map(row=>({pid:row.pid,apparmor:row.apparmor,userNamespace:row.userNamespace,status:row.status})),sandbox:sandbox.json});
 fs.writeFileSync(path.join(root,'summary.json'),JSON.stringify({status:'checks_passed_cleanup_pending',root,binary,chrome,browser:endpoint.Browser,localSnapshot:true,noNoSandboxFlag:true,sandbox:sandbox.json,limitation:'直接CDP探针；产品owned模式与Snap profile文件可见性未在本探针验证'},null,2)+'\n',{mode:0o600});
}catch(error){fs.writeFileSync(path.join(root,'failure.json'),JSON.stringify({message:String(error),stack:error.stack},null,2)+'\n',{mode:0o600});log('failed',{message:String(error)});process.exitCode=1;}
finally{
 try{if(cdpVerified)await run(['--cdp',cdp,'close']);}catch(error){log('agent_close_result',{message:String(error)});}
 try{if(cdpVerified){const response=await fetch(cdp+'/json/version',{signal:AbortSignal.timeout(1000)});if(response.ok){const value=await response.json();await new Promise((resolve,reject)=>{const socket=new WebSocket(value.webSocketDebuggerUrl);const timer=setTimeout(()=>{socket.close();resolve();},3000);socket.onopen=()=>socket.send(JSON.stringify({id:1,method:'Browser.close'}));socket.onmessage=()=>{clearTimeout(timer);socket.close();resolve();};socket.onclose=()=>{clearTimeout(timer);resolve();};socket.onerror=()=>{clearTimeout(timer);resolve();};});}}}catch(error){log('cdp_close_observation',{message:String(error)});}
 if(!identities.length){const rows=list();identities=rows.filter(row=>row.argv.includes(`--user-data-dir=${profile}`));}
 await until(()=>identities.every(identity=>!alive(identity)),'浏览器退出未核实',8000).catch(async error=>{log('close_wait_failed',{message:String(error)});for(const identity of identities)if(alive(identity))process.kill(identity.pid,'SIGTERM');await until(()=>identities.every(identity=>!alive(identity)),'原浏览器身份仍未退出',5000);});
 await new Promise(resolve=>page.close(resolve));
 const remaining=[];for(const row of list()){if(row.pid===process.pid)continue;let environment='';try{environment=fs.readFileSync(`/proc/${row.pid}/environ`,'utf8');}catch(error){if(!['ENOENT','ESRCH','EACCES'].includes(error.code))throw error;}if(row.argv.includes(root)||environment.includes(root))remaining.push({pid:row.pid,startTime:row.startTime});}
 fs.writeFileSync(path.join(root,'cleanup.json'),JSON.stringify({originalIdentitiesExited:identities.every(identity=>!alive(identity)),remaining},null,2)+'\n',{mode:0o600});if(remaining.length){log('cleanup_failed',{remaining});process.exitCode=1;}
 const summaryFile=path.join(root,'summary.json');if(fs.existsSync(summaryFile)){const summary=JSON.parse(fs.readFileSync(summaryFile,'utf8'));summary.status=process.exitCode?'cleanup_failed':'passed';fs.writeFileSync(summaryFile,JSON.stringify(summary,null,2)+'\n',{mode:0o600});}
 log('finished',{root,exitCode:process.exitCode??0});
}
