import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import { once } from 'node:events';
import { pathToFileURL } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';
const root=fs.mkdtempSync('/tmp/ruukoto39-browser-owned-');fs.chmodSync(root,0o700);fs.copyFileSync(new URL(import.meta.url),path.join(root,'probe.mjs'));
const current=path.join(os.homedir(),'.local/ruukoto39/current'),binary=path.join(os.homedir(),'.local/ruukoto39/tools/agent-browser-linux-arm64-v0.39.1'),chrome='/opt/ruukoto39-chromium/chrome';
const { BrowserManager }=await import(pathToFileURL(path.join(current,'packages/agent/src/browser-manager.ts')).href);
const log=(stage,facts={})=>{const row={at:new Date().toISOString(),stage,...facts};fs.appendFileSync(path.join(root,'steps.jsonl'),JSON.stringify(row)+'\n',{mode:0o600});process.stdout.write(JSON.stringify(row)+'\n');};
const manager=new BrowserManager({dataDir:root,binaryPath:binary,chromePath:chrome,headed:false,initialState:null,persist(state,binding){fs.writeFileSync(path.join(root,'browser-state.json'),state+'\n',{mode:0o600});fs.appendFileSync(path.join(root,'bindings.jsonl'),JSON.stringify(binding)+'\n',{mode:0o600});}});
const page=http.createServer((req,res)=>{res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><title>Ruukoto 39 owned browser</title><h1>Ruukoto 39 owned real browser</h1><p>Only loopback is used.</p><button>Owned local action</button>');});page.listen(0,'127.0.0.1');await once(page,'listening');const url=`http://127.0.0.1:${page.address().port}/`,session=path.basename(root);
function info(pid){try{const raw=fs.readFileSync(`/proc/${pid}/stat`,'utf8'),fields=raw.slice(raw.lastIndexOf(') ')+2).split(' ');return{pid:Number(pid),ppid:Number(fields[1]),startTime:fields[19],state:fields[0],argv:fs.readFileSync(`/proc/${pid}/cmdline`,'utf8').replaceAll('\0',' ').trim(),apparmor:fs.readFileSync(`/proc/${pid}/attr/current`,'utf8').trim(),userNamespace:fs.readlinkSync(`/proc/${pid}/ns/user`),status:fs.readFileSync(`/proc/${pid}/status`,'utf8').split('\n').filter(line=>/^(NoNewPrivs|Seccomp|NSpid|Uid):/.test(line))};}catch(error){if(['ENOENT','ESRCH','EACCES'].includes(error.code))return null;throw error;}}
const list=()=>fs.readdirSync('/proc').filter(s=>/^\d+$/.test(s)).map(info).filter(Boolean);
const alive=identity=>{const now=info(identity.pid);return now&&now.startTime===identity.startTime&&!now.state.startsWith('Z');};
let identities=[];
try{
 log('environment',{root,current,binary,chrome,url,node:process.version,loadavg:os.loadavg(),usernsRestriction:fs.readFileSync('/proc/sys/kernel/apparmor_restrict_unprivileged_userns','utf8').trim()});
 const binding=await manager.start(session,{headed:false});assert.equal(binding.kind,'owned');assert.equal(binding.state,'ready');assert.ok(binding.chrome&&binding.daemon&&binding.dashboard);assert.ok(fs.existsSync(path.join(binding.profileDir,'DevToolsActivePort')));
 const opened=await manager.command(session,['open',url]);const snapshot=await manager.command(session,['snapshot']);assert.match(JSON.stringify(snapshot),/Ruukoto 39 owned real browser/);assert.match(JSON.stringify(snapshot),/Owned local action/);
 fs.writeFileSync(path.join(root,'local-snapshot.json'),JSON.stringify(snapshot,null,2)+'\n',{mode:0o600});
 const rows=list(),pids=new Set([binding.chrome.pid]);let changed=true;while(changed){changed=false;for(const row of rows)if(pids.has(row.ppid)&&!pids.has(row.pid)){pids.add(row.pid);changed=true;}}identities=rows.filter(row=>pids.has(row.pid));assert.ok(identities.length);for(const row of identities)assert.ok(!row.argv.includes('--no-sandbox'));assert.ok(identities.some(row=>row.apparmor==='ruukoto39-chromium (unconfined)'));
 fs.writeFileSync(path.join(root,'browser-processes.json'),JSON.stringify(identities,null,2)+'\n',{mode:0o600});
 await manager.command(session,['open','chrome://sandbox/']);const sandbox=await manager.command(session,['snapshot']);fs.writeFileSync(path.join(root,'sandbox-snapshot.json'),JSON.stringify(sandbox,null,2)+'\n',{mode:0o600});assert.match(JSON.stringify(sandbox),/adequately sandboxed/);
 assert.equal(fs.readFileSync('/proc/sys/kernel/apparmor_restrict_unprivileged_userns','utf8').trim(),'1');
 fs.writeFileSync(path.join(root,'summary.json'),JSON.stringify({status:'checks_passed_cleanup_pending',root,binary,chrome,owned:true,profileVisible:true,localSnapshot:true,noNoSandboxFlag:true,namespaceSeccomp:sandbox,binding},null,2)+'\n',{mode:0o600});
 log('owned_snapshot_passed',{binding,snapshot,sandbox});
}catch(error){fs.writeFileSync(path.join(root,'failure.json'),JSON.stringify({message:String(error),code:error.code,stack:error.stack,status:manager.status(session)},null,2)+'\n',{mode:0o600});log('failed',{message:String(error),code:error.code});process.exitCode=1;}
finally{
 const closed=await manager.close(session);await manager.shutdown();await new Promise(resolve=>page.close(resolve));
 const end=Date.now()+5000;while(identities.some(alive)&&Date.now()<end)await delay(50);
 const remaining=[];for(const row of list()){if(row.pid===process.pid)continue;let environment='';try{environment=fs.readFileSync(`/proc/${row.pid}/environ`,'utf8');}catch(error){if(!['ENOENT','ESRCH','EACCES'].includes(error.code))throw error;}if(row.argv.includes(root)||environment.includes(root))remaining.push({pid:row.pid,startTime:row.startTime});}
 const cleanup={closed,state:manager.status(session)?.state,originalChromeIdentitiesExited:identities.every(identity=>!alive(identity)),remaining};fs.writeFileSync(path.join(root,'cleanup.json'),JSON.stringify(cleanup,null,2)+'\n',{mode:0o600});if(!closed||cleanup.state!=='closed'||!cleanup.originalChromeIdentitiesExited||remaining.length)process.exitCode=1;
 const summaryFile=path.join(root,'summary.json');if(fs.existsSync(summaryFile)){const summary=JSON.parse(fs.readFileSync(summaryFile,'utf8'));summary.status=process.exitCode?'cleanup_failed':'passed';fs.writeFileSync(summaryFile,JSON.stringify(summary,null,2)+'\n',{mode:0o600});}
 log('finished',{root,exitCode:process.exitCode??0,cleanup});
}
