import os,sys,stat,json,hashlib,shutil,subprocess,uuid
assert os.geteuid()==0
source='/home/ubuntu/.local/ruukoto39/tools/playwright-browsers/chromium-1248/chrome-linux-arm64'
target='/opt/ruukoto39-chromium'
profile='/etc/apparmor.d/ruukoto39-chromium'
profile_source='/tmp/ruukoto39-chromium.apparmor'
expected='''abi <abi/4.0>,
include <tunables/global>

# 仅为固定、root 拥有的官方 Chromium 路径开放 userns；浏览器自身仍启用 namespace/seccomp 沙箱。
profile ruukoto39-chromium /opt/ruukoto39-chromium/chrome flags=(unconfined) {
  userns,
}
'''
assert open(profile_source).read()==expected
for path in [target,profile]:assert not os.path.lexists(path),f'refuse existing target: {path}'
for parent in ['/opt','/etc/apparmor.d']:
 info=os.lstat(parent);assert stat.S_ISDIR(info.st_mode) and info.st_uid==0 and not(info.st_mode&0o022),parent
loaded_before=open('/sys/kernel/security/apparmor/profiles').read().splitlines()
assert not any('ruukoto39-chromium' in line for line in loaded_before)
for base,dirs,files in os.walk('/etc/apparmor.d'):
 for name in files:
  p=os.path.join(base,name)
  try:text=open(p,errors='replace').read()
  except OSError:continue
  assert target not in text and 'profile ruukoto39-chromium ' not in text,p
assert os.path.realpath(source)==source
before=subprocess.run(['/usr/sbin/sysctl','-n','kernel.apparmor_restrict_unprivileged_userns'],capture_output=True,text=True,check=True).stdout.strip()
assert before=='1'
subprocess.run(['/usr/sbin/apparmor_parser','-Q','-K',profile_source],check=True)
def manifest(root):
 rows=[]
 for base,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   p=os.path.join(base,name);info=os.lstat(p)
   assert not stat.S_ISLNK(info.st_mode),p
   assert stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode),p
  for name in files:
   p=os.path.join(base,name);info=os.stat(p)
   with open(p,'rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
   rows.append(dict(path=os.path.relpath(p,root),bytes=info.st_size,sha256=digest,executable=bool(info.st_mode&0o111)))
 return sorted(rows,key=lambda row:row['path'])
source_manifest=manifest(source)
stage='/opt/.ruukoto39-chromium.stage-'+uuid.uuid4().hex
os.mkdir(stage,0o700)
payload=stage+'/payload'
shutil.copytree(source,payload,copy_function=shutil.copy2,symlinks=True)
assert manifest(payload)==source_manifest
for base,dirs,files in os.walk(payload):
 os.chown(base,0,0);os.chmod(base,0o755)
 for name in files:
  p=os.path.join(base,name);entry=next(row for row in source_manifest if row['path']==os.path.relpath(p,payload));os.chown(p,0,0);os.chmod(p,0o755 if entry['executable'] else 0o644)
assert not os.path.lexists(target)
subprocess.run(['/usr/bin/mv','-T','--no-clobber',payload,target],check=True)
assert not os.path.exists(payload),'target appeared; mv refused to overwrite'
os.rmdir(stage)
assert manifest(target)==source_manifest
for base,dirs,files in os.walk(target):
 for name in ['.']+dirs+files:
  p=base if name=='.' else os.path.join(base,name);info=os.lstat(p)
  assert info.st_uid==0 and info.st_gid==0 and not(info.st_mode&0o6022),p
fd=os.open(profile,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644)
with os.fdopen(fd,'w') as f:f.write(expected)
os.chown(profile,0,0);os.chmod(profile,0o644)
subprocess.run(['/usr/sbin/apparmor_parser','-a','-K',profile],check=True)
loaded_after=open('/sys/kernel/security/apparmor/profiles').read().splitlines()
added=sorted(set(loaded_after)-set(loaded_before));removed=sorted(set(loaded_before)-set(loaded_after))
assert added==['ruukoto39-chromium (unconfined)'],added
assert not removed,removed
after=subprocess.run(['/usr/sbin/sysctl','-n','kernel.apparmor_restrict_unprivileged_userns'],capture_output=True,text=True,check=True).stdout.strip()
assert after==before=='1'
result=dict(target=target,chrome=target+'/chrome',profile=profile,version='156.0.8078.4',source=source,files=len(source_manifest),added_profiles=added,removed_profiles=removed,userns_restriction_before=before,userns_restriction_after=after,profile_sha256=hashlib.sha256(expected.encode()).hexdigest(),manifest=source_manifest)
file='/tmp/ruukoto39-chromium-installed.json'
with open(file,'w') as f:f.write(json.dumps(result,indent=2)+'\n')
os.chown(file,1001,1001)
print(json.dumps({k:v for k,v in result.items() if k!='manifest'},indent=2))
