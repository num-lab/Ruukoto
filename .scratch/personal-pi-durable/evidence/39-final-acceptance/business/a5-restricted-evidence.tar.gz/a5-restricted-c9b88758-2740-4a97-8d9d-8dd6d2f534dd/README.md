# 工单39 Oracle A5受限命令确认/自动审查增量

当前Oracle ARM64 Linux、Node24.15.0、bubblewrap0.9.0、真实running user manager与cgroup v2上，独立私有档案confirm/auto-review各执行一条短命令。复用旧26 restricted和25正式p.work.delegate→run_command→p.commands链，MockModelServer仅模型替身；provider HTTP/SSE、durable任务、Node/Bash、bwrap、scope、原回执/停止均真实，未mock platform/spawn/proc/cgroup。env -i启动，只留用户manager必要合成环境，未读实际模型/IM/service/live配置。

各自真实本机owner输入接纳、原工作permission和原LaunchSpec模式均一致且落盘；独立SQLite复核各1条命令admission/start/observation、1次run_command工具调用、原native Task owner=work task、1行唯一marker。目录外只读合成文件读ENOENT、外写EROFS、网络EPERM，宿主127计数只有1次preflight、两种业务path均0；两项合成用户环境不可见。原request/receipt/stdout/stderr哈希匹配，returned/exit0/stoppedtrue；原scope not-found、原temp目录已消失，档案及loopback已关闭。两例各3次本地Mock模型HTTP，不计真实模型或真实IM通过。

根/远端源码未写；源码及worker前后逐项SHA一致，source-files-tested.tar.gz为实际运行版本。与真实full正常业务属于互补，不重跑旧26整组，也不重复旧业务或服务。两个隔离档案原记录不删除不改写。

首启动有探针版本清单路径假设错误（pi-durable已hoist，app局部package.json不存在），在Mock/loopback/Harness/命令启动前ENOENT，原失败log保留。仅修正清单路径后重开本次两例，未重复任何实际命令。该失败不记产品缺陷。

独立审计见independent-audit.json；常见秘密格式扫描0，全部内容为合成业务。根另持已知四凭据扫描材料。
