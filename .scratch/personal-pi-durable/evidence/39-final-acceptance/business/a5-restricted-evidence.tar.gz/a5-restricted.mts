import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import * as os from 'node:os';
import { createHash, randomUUID, randomBytes } from 'node:crypto';
import { createServer, get } from 'node:http';
import { execFileSync } from 'node:child_process';
import { BACKGROUND_CONTEXT } from '/home/ubuntu/.local/ruukoto39/current/node_modules/@earendil-works/chord/dist/context/index.js';
import { openPersonalHarness } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-harness.ts';
import { PersonalCommandDoc } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-command-work.ts';
import { savePersonalCommands } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-command-config.ts';
import { readPersonalCommandReceipt } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-command-execution.ts';
import { PersonalPermissionsDoc } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-permissions.ts';
import { personalSource } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-source.ts';
import { personalProvider } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-model.ts';
import { MockModelServer } from '/home/ubuntu/.local/ruukoto39/current/test/helpers/mock-provider.ts';
const home='/home/ubuntu/.local/ruukoto39',repo=home+'/current',base=home+'/test-business/a5-restricted-'+randomUUID();
fs.mkdirSync(base,{mode:0o700});const context=BACKGROUND_CONTEXT;
const sha=(v:any)=>createHash('sha256').update(v).digest('hex');
const write=(n:string,v:any)=>fs.writeFileSync(path.join(base,n),JSON.stringify(v,null,2)+'\n',{mode:0o600});
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms));
async function bounded<T,>(promise:Promise<T>,label:string){let timer:any;try{return await Promise.race([promise,new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(new Error('timeout: '+label)),120000);})]);}finally{clearTimeout(timer);}}
const quote=(s:string)=>"'"+s.replaceAll("'","'\\''")+"'";
const versions=['apps/ruukoto/node_modules/@earendil-works/pi-ai/package.json','node_modules/@earendil-works/pi-durable/package.json','node_modules/@earendil-works/chord/package.json'].map(relative=>{const data=fs.readFileSync(path.join(repo,relative));return{path:relative,version:JSON.parse(data.toString()).version,sha256:sha(data)};});
const sourcePaths=[...fs.readdirSync(repo+'/apps/ruukoto/src').filter(n=>n.endsWith('.ts')).map(n=>'apps/ruukoto/src/'+n),...fs.readdirSync(repo+'/packages/agent/src/execution').filter(n=>n.endsWith('.ts')).map(n=>'packages/agent/src/execution/'+n),'worker/personal-command-worker.mjs','test/helpers/mock-provider.ts'];
const frozen=sourcePaths.map(relative=>({path:relative,sha256:sha(fs.readFileSync(path.join(repo,relative)))}));write('source-manifest.json',{frozen,versions,scriptSha256:sha(fs.readFileSync(process.argv[1]))});
const report:any={base,startedAt:new Date().toISOString(),realSystem:true,realModel:false,modelSubstitute:'MockModelServer only; actual provider HTTP/SSE and product Harness/work/commands/native launch',noOSMocks:true,liveTouched:false,imSends:0,serviceOperations:0,scenarios:[]};
const networkCalls:any[]=[];const network=createServer((req,res)=>{networkCalls.push({url:req.url,at:new Date().toISOString()});res.writeHead(200);res.end('a5-loopback-ready');});
await new Promise<void>(r=>network.listen(0,'127.0.0.1',r));const addr=network.address();assert.ok(addr&&typeof addr==='object');const url='http://127.0.0.1:'+addr.port;
await new Promise<void>((resolve,reject)=>{get(url+'/preflight',res=>{res.resume();res.once('end',resolve);}).once('error',reject);});assert.equal(networkCalls.length,1);
write('environment.json',{at:new Date().toISOString(),platform:process.platform,arch:process.arch,node:process.version,uid:process.getuid?.(),kernel:execFileSync('uname',['-a'],{encoding:'utf8'}).trim(),bwrap:execFileSync('/usr/bin/bwrap',['--version'],{encoding:'utf8'}).trim(),userManager:execFileSync('/usr/bin/systemctl',['--user','is-system-running'],{encoding:'utf8'}).trim(),cgroupV2:fs.existsSync('/sys/fs/cgroup/cgroup.controllers'),loopbackListening:{address:addr.address,port:addr.port},hostPreflightRequests:1,environmentExplicitlySynthetic:true,noOSMocks:true,realModel:false});
try{
 for(const mode of ['confirm','auto-review'] as const){
  const root=path.join(base,mode),workspace=path.join(root,'work'),profile=path.join(root,'profile');fs.mkdirSync(root,{mode:0o700});fs.mkdirSync(workspace,{mode:0o700});
  const marker='A5_39_'+mode.replace('-','_')+'_'+randomUUID().replaceAll('-','');
  fs.writeFileSync(path.join(root,'outside-readable'),'outside synthetic fixture '+marker,{mode:0o600});const outsideHash=sha(fs.readFileSync(path.join(root,'outside-readable')));
  const secret=randomBytes(24).toString('hex');process.env.RUUKOTO_A5_SYNTHETIC_SECRET=secret;process.env.RUUKOTO_A5_SYNTHETIC_USER='synthetic-user-environment';
  const code=`const fs=require('fs'),http=require('http');fs.appendFileSync('count',${JSON.stringify(marker+'\n')});let readDenied=false,writeDenied=false,readCode,writeCode;try{fs.readFileSync(${JSON.stringify(path.join(root,'outside-readable'))})}catch(e){readDenied=true;readCode=e.code}try{fs.writeFileSync(${JSON.stringify(path.join(root,'outside-written'))},'forbidden')}catch(e){writeDenied=true;writeCode=e.code}let finished=false;const done=(networkDenied,networkCode)=>{if(finished)return;finished=true;fs.writeFileSync('restricted-facts.json',JSON.stringify({marker:${JSON.stringify(marker)},readDenied,writeDenied,readCode,writeCode,networkDenied,networkCode,secretVisible:process.env.RUUKOTO_A5_SYNTHETIC_SECRET!==undefined,userEnvVisible:process.env.RUUKOTO_A5_SYNTHETIC_USER!==undefined}));process.stdout.write(${JSON.stringify(marker+'\n')});};const req=http.get(${JSON.stringify(url+'/'+mode)},res=>{res.resume();res.on('end',()=>done(false,'response'));});req.on('error',e=>done(true,e.code||e.message));req.setTimeout(2000,()=>req.destroy(new Error('network_timeout')));`;
  const command=quote(process.execPath)+' -e '+quote(code),trigger='执行唯一A5受限命令 '+marker;let commandIntents=0;
  const model=new MockModelServer(request=>{if(request.system?.includes('你是个人助手的子 Agent')&&request.messages.at(-1)?.content===trigger){commandIntents++;assert.equal(commandIntents,1);return{kind:'tool_calls',calls:[{id:'a5-command-'+mode,name:'run_command',arguments:{command}}]};}return{kind:'text',text:'完成'};});
  process.env.RUUKOTO_A5_MOCK_KEY='test-only';const provider={api:'openai-completions' as const,baseUrl:await model.start(),modelId:'mock-model',apiKeyEnv:'RUUKOTO_A5_MOCK_KEY',contextWindow:128000,maxTokens:1024};
  const {dev,ino}=fs.statSync(workspace),config={version:1 as const,workspace,identity:{dev,ino},machineId:fs.readFileSync('/etc/machine-id','utf8').trim(),tmpdir:fs.realpathSync(os.tmpdir())};
  let p:Awaited<ReturnType<typeof openPersonalHarness>>|undefined,ref:any;const scenario:any={mode,marker,root,workspace,profile,command,commandIntents:0,networkCountBefore:networkCalls.length};report.scenarios.push(scenario);write('progress.json',report);
  try{
   await savePersonalCommands(profile,config);p=await openPersonalHarness({directory:profile,commands:config,provider:personalProvider(provider),modelId:provider.modelId});
   await p.harness.commit(async tx=>{const permission=await tx.doc(PersonalPermissionsDoc);permission.mode=mode;},context);
   const sourceRequest='a5-owner-'+marker;assert.equal(await p.answer('拥有者明确委派这一项受限命令测试；不允许目录外或网络效果。',sourceRequest),'完成');
   const source=await p.harness.commit(tx=>personalSource(tx,sourceRequest),context);assert.equal(source.permission.mode,mode);scenario.source=source;
   const work=await p.work.delegate({requestId:'a5-work-'+marker,sourceRequestId:sourceRequest,content:trigger});scenario.work=work;
   const settled=await bounded(p.harness.waitForTask(work.taskId,context),'restricted '+mode+' completes');assert.equal(settled.state.outcome.status,'completed');
   const operations=await p.commands!.list();assert.equal(operations.items.length,1);ref=operations.items[0].ref;
   const op=(await p.harness.snapshot(PersonalCommandDoc,ref.requestId,context))!.command!;assert.ok(op.started&&op.prepared);assert.equal(op.work.permission.mode,mode);assert.deepEqual(op.work.permission,source.permission);assert.equal(op.prepared.spec.mode,mode);assert.equal(op.prepared.spec.workspace,workspace);assert.deepEqual(op.prepared.spec.workspaceIdentity,{dev,ino});assert.deepEqual(op.prepared.spec.grantedPaths,[]);assert.equal(op.prepared.spec.env,undefined);assert.equal(op.stopped,true);assert.deepEqual(op.result,{effect:'returned',code:'command_returned',exitCode:0});
   const task=await p.harness.commit(tx=>tx.task(ref.taskId),context);assert.equal(task!.owner,work.taskId);
   const receipt=await readPersonalCommandReceipt(path.join(profile,'commands'),op.execution,op.prepared.fingerprint);assert.ok(receipt);assert.equal(receipt.exit.code,0);
   const facts=JSON.parse(fs.readFileSync(path.join(workspace,'restricted-facts.json'),'utf8'));assert.equal(facts.marker,marker);assert.deepEqual([facts.readDenied,facts.writeDenied,facts.networkDenied],[true,true,true]);assert.equal(facts.secretVisible,false);assert.equal(facts.userEnvVisible,false);assert.equal(networkCalls.length,scenario.networkCountBefore);assert.equal(fs.existsSync(path.join(root,'outside-written')),false);assert.equal(sha(fs.readFileSync(path.join(root,'outside-readable'))),outsideHash);assert.equal(fs.readFileSync(path.join(workspace,'count'),'utf8'),marker+'\n');assert.equal(commandIntents,1);
   const childCall=model.calls.find(call=>call.system?.includes('你是个人助手的子 Agent'));assert.ok(childCall);assert.match(childCall.system!,mode==='confirm'?/当前工作命令权限：请求确认。/:/当前工作命令权限：自动审查。/);
   const stdout=await p.commands!.detail(ref,'stdout'),stderr=await p.commands!.detail(ref,'stderr');assert.equal(stdout.stopped,true);assert.equal(stdout.output!.complete,true);assert.equal(Buffer.from(stdout.output!.data,'base64').toString(),marker+'\n');assert.equal(stderr.output!.bytes,0);assert.equal(fs.existsSync(op.prepared.input.tempDir),false);assert.ok(!JSON.stringify(op.prepared).includes(secret));assert.ok(!fs.readFileSync(path.join(profile,'commands','command-'+op.execution.executionId,'request.json'),'utf8').includes(secret));
   const scope='ruukoto-'+op.execution.executionId+'.scope';let unit:string;try{unit=execFileSync('/usr/bin/systemctl',['--user','show',scope,'--property=LoadState,ActiveState,ControlGroup,InvocationID'],{encoding:'utf8'}).trim();}catch(error:any){unit=String(error.stdout??'');}assert.match(unit,/LoadState=not-found/);
   Object.assign(scenario,{commandIntents,modelHttpCalls:model.calls.length,commandOperations:operations.items.length,command:op,nativeTask:task,settled,receipt,facts,stdout,stderr,networkCountAfter:networkCalls.length,scope,unit,tempAbsent:true,passed:true});
   const save=(name:string,value:any)=>write(mode+'/'+name,value);save('result.json',scenario);save('model-requests.json',model.calls);save('request.json',JSON.parse(fs.readFileSync(path.join(profile,'commands','command-'+op.execution.executionId,'request.json'),'utf8')));
  }finally{
   if(p&&ref){const state=await p.commands!.detail(ref,'stdout');if(!state.stopped)await bounded(p.harness.waitForTask(await p.commands!.stop(ref),context),'cleanup original command '+mode);}
   await p?.close();await model.close();delete process.env.RUUKOTO_A5_SYNTHETIC_SECRET;delete process.env.RUUKOTO_A5_SYNTHETIC_USER;delete process.env.RUUKOTO_A5_MOCK_KEY;scenario.closedAt=new Date().toISOString();write('progress.json',report);
  }
 }
 const after=frozen.map(({path:relative})=>({path:relative,sha256:sha(fs.readFileSync(path.join(repo,relative)))}));assert.deepEqual(after,frozen,'source/worker frozen for both scenarios');report.sourceUnchanged=true;report.passed=true;
}catch(error){report.failure=error instanceof Error?{name:error.name,message:error.message,stack:error.stack}:String(error);process.exitCode=1;}
finally{await new Promise<void>(r=>network.close(()=>r()));report.finishedAt=new Date().toISOString();report.networkRequests=networkCalls;report.loopbackClosed=true;write('result.json',report);}
process.stdout.write(JSON.stringify({base,passed:report.passed,failure:report.failure,scenarios:report.scenarios.map((s:any)=>({mode:s.mode,passed:s.passed,commandIntents:s.commandIntents,modelHttpCalls:s.modelHttpCalls,operation:s.command?.ref,facts:s.facts,stopped:s.command?.stopped,tempAbsent:s.tempAbsent,unit:s.unit})),networkRequests:report.networkRequests})+'\n');
