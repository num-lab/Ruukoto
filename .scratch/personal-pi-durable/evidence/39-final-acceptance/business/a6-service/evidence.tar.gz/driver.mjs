import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import childProcess from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import { pathToFileURL } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';

const ROOT = '/home/ubuntu/.local/ruukoto39/current';
const BASE = '/home/ubuntu/.local/ruukoto39';
const DIR = process.env.RUUKOTO39_CHAOS_DIR;
assert.ok(DIR && path.dirname(DIR) === BASE && path.basename(DIR).startsWith('chaos-service-'));
const PROFILE = path.join(DIR, 'profile');
const UNIT = 'ruukoto39-test.service';
const HELPER = '/usr/local/libexec/ruukoto39/ruukoto-service';
const POLICY = '/etc/ruukoto/services.json';
const SUDO = '/usr/bin/sudo';
const AUTH = 'a6-chaos-source';
const REQUEST = 'a6-chaos-restart';
const SERVICE = { helperPath: HELPER, policyPath: POLICY, useSudo: true, sudoPath: SUDO };
let secret = '';
function safe(value) {
  let text = JSON.stringify(value);
  if (secret) for (const form of [secret, encodeURIComponent(secret), Buffer.from(secret).toString('base64')]) text = text.split(form).join('[REDACTED]');
  return text;
}
function save(name, value) {
  const target = path.join(DIR, name), temporary = `${target}.${process.pid}.tmp`;
  fs.writeFileSync(temporary, safe(value) + '\n', { mode: 0o600 });
  fs.renameSync(temporary, target);
}
function read(name) { return JSON.parse(fs.readFileSync(path.join(DIR, name), 'utf8')); }
function event(kind, data = {}) { fs.appendFileSync(path.join(DIR, 'events.jsonl'), safe({ at: new Date().toISOString(), pid: process.pid, kind, ...data }) + '\n', { mode: 0o600 }); }
function hashFile(filename) { return crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex'); }
function command(file, args) {
  const value = childProcess.spawnSync(file, args, { encoding: 'utf8', timeout: 15000, env: { PATH: '/usr/bin:/bin' } });
  assert.equal(value.status, 0, safe({ file, args, code: value.status, error: value.error?.code, stderr: value.stderr }));
  return value.stdout;
}
function serviceState() {
  const text = command('/bin/systemctl', ['show', UNIT, '--no-pager', '-p', 'ActiveState', '-p', 'SubState', '-p', 'InvocationID', '-p', 'ExecMainPID', '-p', 'ExecMainStartTimestampMonotonic']);
  const state = Object.fromEntries(text.trim().split('\n').map(line => { const split = line.indexOf('='); return [line.slice(0, split), line.slice(split + 1)]; }));
  return { ...state, count: Number(fs.readFileSync('/var/lib/ruukoto39/test-service/count', 'utf8').trim()), starts: fs.readFileSync('/var/lib/ruukoto39/test-service/starts.log', 'utf8').trim().split('\n') };
}
function helperCalls() {
  const file = path.join(DIR, 'events.jsonl');
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line)).filter(value => value.kind === 'helper_start') : [];
}
function installHelperAudit() {
  const original = childProcess.spawn;
  childProcess.spawn = function(file, args, options) {
    if (file === SUDO && Array.isArray(args) && args[0] === '-n' && args[1] === HELPER) {
      const verb = args[2];
      event('helper_start', { verb, argv: args.slice(2) });
      if (verb === 'restart') {
        assert.equal(args.at(-1), UNIT);
        fs.writeFileSync(path.join(DIR, 'restart-issued.json'), safe({ at: new Date().toISOString(), argv: args.slice(2) }) + '\n', { mode: 0o600, flag: 'wx' });
      }
      const child = original.call(childProcess, file, args, options);
      event('helper_spawn', { verb, childPid: child.pid });
      child.once('close', (code, signal) => event('helper_close', { verb, childPid: child.pid, code, signal }));
      return child;
    }
    return original.call(childProcess, file, args, options);
  };
  syncBuiltinESMExports();
}
async function modules() {
  const harness = await import(pathToFileURL(path.join(ROOT, 'apps/ruukoto/src/personal-harness.ts')));
  const model = await import(pathToFileURL(path.join(ROOT, 'apps/ruukoto/src/personal-model.ts')));
  const service = await import(pathToFileURL(path.join(ROOT, 'apps/ruukoto/src/personal-service-operations.ts')));
  const { BACKGROUND_CONTEXT } = await import('@earendil-works/chord/context');
  const { openNodeSqliteStorage } = await import('@earendil-works/pi-durable/storage/sqlite/node');
  return { ...harness, ...model, ...service, BACKGROUND_CONTEXT, openNodeSqliteStorage };
}
async function provider(m) {
  const source = JSON.parse(fs.readFileSync(path.join(BASE, 'credentials/model-source.json'), 'utf8'));
  const definition = source.providers.deepseek;
  assert.ok(definition && typeof definition.apiKey === 'string' && definition.apiKey);
  const model = definition.models[0];
  secret = definition.apiKey;
  const config = m.parsePersonalModel({ api: model.api ?? definition.api, baseUrl: definition.baseUrl, modelId: model.id, apiKeyEnv: 'RUUKOTO39_A6_MODEL_KEY', contextWindow: model.contextWindow, maxTokens: Math.min(model.maxTokens, 1024), imageInput: model.input.includes('image') });
  process.env[config.apiKeyEnv] = secret;
  const origin = new URL(config.baseUrl).origin;
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (input, init) => {
    const url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url);
    if (url.origin !== origin) return originalFetch(input, init);
    assert.ok(!fs.existsSync(path.join(DIR, 'model-http-failed.json')), '前次真实模型请求失败，拒绝继续外调');
    const count = fs.existsSync(path.join(DIR, 'model-count.json')) ? read('model-count.json').count : 0;
    assert.ok(count < 4, '本轮真实模型HTTP预算已耗尽');
    save('model-count.json', { count: count + 1 });
    event('model_http', { number: count + 1, method: init?.method ?? 'POST', origin, pathname: url.pathname });
    try {
      const response = await originalFetch(input, init);
      if (!response.ok) save('model-http-failed.json', { number: count + 1, status: response.status });
      event('model_http_headers', { number: count + 1, status: response.status });
      return response;
    } catch (error) {
      save('model-http-failed.json', { number: count + 1, name: error.name, message: error.message });
      throw error;
    }
  };
  const base = m.personalProvider(config);
  const value = { ...base, stream: (model, input, options) => base.stream(model, input, { ...options, toolChoice: 'none' }), streamSimple: (model, input, options) => base.streamSimple(model, input, { ...options, toolChoice: 'none' }) };
  return { config, provider: value };
}
async function waitFor(label, check, timeoutMs = 30000) {
  const until = Date.now() + timeoutMs;
  for (;;) {
    const result = await check();
    if (result) return result;
    assert.ok(Date.now() < until, `${label}等待超时`);
    await delay(50);
  }
}
function replyFrom(data) {
  const stderr = Buffer.from(data.stderr, 'base64').toString('utf8');
  const lines = stderr.split('\n').filter(line => line.startsWith('RUUKOTO_SERVICE_REPLY '));
  assert.equal(lines.length, 1);
  return JSON.parse(lines[0].slice('RUUKOTO_SERVICE_REPLY '.length));
}
async function noTools(p, context) {
  const entries = (await p.main.entries({ order: 'ascending' }, 256, undefined, context)).items;
  assert.equal(entries.filter(entry => entry.kind === 'pi.tool').length, 0, '只读占位不应调工具');
  assert.ok(!entries.some(entry => entry.model?.some(message => message.role === 'assistant' && message.content.some(part => part.type === 'toolCall'))), '只读占位不应生成工具调用');
  return entries;
}
async function child() {
  installHelperAudit();
  const m = await modules();
  const real = await provider(m);
  const p = await m.openPersonalHarness({ directory: PROFILE, provider: real.provider, modelId: real.config.modelId, service: SERVICE, serviceOperations: true, openStorage: async filename => {
    const storage = await m.openNodeSqliteStorage(filename), commit = storage.commit.bind(storage);
    storage.commit = async (writes, context) => {
      const evidence = writes.find(write => write.type === 'entry' && write.value.kind === 'ruukoto.service-operation-evidence' && write.value.data.verb === 'restart');
      if (evidence) {
        const reply = replyFrom(evidence.value.data);
        assert.equal(reply.verb, 'restart'); assert.equal(reply.ok, true); assert.equal(reply.exitCode, 0); assert.equal(reply.launched, true);
        save('result-blocked.json', { at: new Date().toISOString(), childPid: process.pid, evidence: evidence.value.data, reply });
        event('result_commit_blocked', { hostOpId: reply.hostOpId, opUnit: reply.opUnit });
        return await new Promise(() => {});
      }
      return await commit(writes, context);
    };
    return storage;
  } });
  const ref = await p.service.request({ requestId: REQUEST, sourceRequestId: AUTH, unit: UNIT, mode: 'full_access' });
  save('operation-ref.json', ref);
  event('operation_admitted', { ref });
  setInterval(() => {}, 1000);
}
async function run() {
  fs.writeFileSync(path.join(DIR, 'run-claimed.json'), safe({ at: new Date().toISOString(), unit: UNIT }) + '\n', { mode: 0o600, flag: 'wx' });
  const policy = JSON.parse(fs.readFileSync(POLICY, 'utf8'));
  assert.deepEqual(Object.keys(policy.services), [UNIT]);
  assert.deepEqual(policy.services[UNIT].actions, ['restart']);
  const helperHash = command(SUDO, ['-n', '/usr/bin/sha256sum', HELPER]).trim().split(/\s+/)[0];
  assert.equal(helperHash, '3f645f2ef05ff626f1def39ef1b0065f893385f96bdb0142c14aad864fb6433f');
  assert.equal(hashFile(POLICY), '83cbea028f2c5954d6ffe06d559a8c8862fa65e5bae02700743b3f5854c654da');
  const before = serviceState();
  assert.equal(before.count, 2); assert.equal(before.InvocationID, '9811888c0d074fc9bed074098cb38628');
  assert.equal(before.ActiveState, 'active'); assert.equal(before.SubState, 'running');
  save('before.json', { service: before, helperSha256: helperHash, policySha256: hashFile(POLICY), serviceUnitSha256: hashFile('/etc/systemd/system/' + UNIT), sourceSha256: Object.fromEntries(['personal-harness.ts', 'personal-model.ts', 'personal-service-operations.ts', 'service-helper.ts'].map(name => [name, hashFile(path.join(ROOT, 'apps/ruukoto/src', name))])) });
  installHelperAudit();
  const m = await modules(), real = await provider(m), context = m.BACKGROUND_CONTEXT;
  const options = { directory: PROFILE, provider: real.provider, modelId: real.config.modelId, service: SERVICE, serviceOperations: true };
  let p = await m.openPersonalHarness(options);
  try {
    const answer = await p.answer('这条输入明确授权本次宿主仅对专用 ruukoto39-test.service 执行一次 restart 进行故障窗口验收。你只用纯文本回答 A6_AUTH_RECEIVED，不调用任何工具，不委派，不创建计划；真实服务动作由可信宿主另行按原输入执行。', AUTH);
    assert.match(answer, /A6_AUTH_RECEIVED/);
    await noTools(p, context);
    save('source-answer.json', { answer, modelHttpCount: read('model-count.json').count });
  } finally { await p.close(); p = undefined; }
  const stdout = fs.openSync(path.join(DIR, 'child.stdout.log'), 'a', 0o600), stderr = fs.openSync(path.join(DIR, 'child.stderr.log'), 'a', 0o600);
  const launched = childProcess.spawn(process.execPath, ['--import', 'tsx', path.join(DIR, 'driver.mjs'), 'child'], { cwd: ROOT, env: { ...process.env, RUUKOTO39_CHAOS_DIR: DIR }, stdio: ['ignore', stdout, stderr] });
  fs.closeSync(stdout); fs.closeSync(stderr);
  event('harness_child_spawn', { childPid: launched.pid });
  let childExit;
  const closed = new Promise(resolve => launched.once('close', (code, signal) => { childExit = { code, signal }; event('harness_child_close', { childPid: launched.pid, code, signal }); resolve(childExit); }));
  let fault;
  launched.once('error', error => { fault = error; });
  try {
    await waitFor('restart结果提交门', () => {
      if (fault) throw fault;
      assert.ok(!childExit, 'Harness子进程在提交门前退出');
      return fs.existsSync(path.join(DIR, 'result-blocked.json'));
    }, 180000);
    const gate = read('result-blocked.json'), ref = read('operation-ref.json'), afterEffect = serviceState();
    assert.equal(afterEffect.count, 3); assert.notEqual(afterEffect.InvocationID, before.InvocationID); assert.equal(afterEffect.ActiveState, 'active'); assert.equal(afterEffect.SubState, 'running');
    assert.equal(helperCalls().filter(call => call.verb === 'restart').length, 1);
    const events = fs.readFileSync(path.join(DIR, 'events.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const originalClose = events.find(value => value.kind === 'helper_close' && value.verb === 'restart');
    assert.ok(originalClose && originalClose.code === 0 && originalClose.signal === null, '原helper调用必须已关闭后才强杀Harness');
    save('effect-before-kill.json', { service: afterEffect, ref, gate, originalHelperClose: originalClose });
    event('sigkill_own_harness', { childPid: launched.pid });
    launched.kill('SIGKILL');
    assert.deepEqual(await closed, { code: null, signal: 'SIGKILL' });
    p = await m.openPersonalHarness(options);
    await waitFor('恢复未知效果', async () => {
      const status = await p.service.status(ref);
      return status.operation.result?.effect === 'effect_unknown' && status.operation.result.code !== 'started' ? status : undefined;
    });
    const unknown = await p.service.status(ref);
    assert.equal(unknown.operation.result.effect, 'effect_unknown'); assert.equal(unknown.operation.result.code, 'interrupted');
    assert.equal(unknown.operation.resolution, undefined); assert.notEqual(unknown.task.state.status, 'terminal');
    assert.equal(await p.harness.commit(tx => m.personalServiceSourceBlocker(tx, AUTH), context), REQUEST);
    assert.equal(helperCalls().filter(call => call.verb === 'restart').length, 1);
    assert.equal(serviceState().count, 3); assert.equal(serviceState().InvocationID, afterEffect.InvocationID);
    save('recovered-unknown.json', unknown);
    const independent = await p.answer('这是与服务核实无关的独立只读聊天。只用纯文本回答 A6_INDEPENDENT_OK，不调用任何工具，不委派，不创建计划。', 'a6-independent');
    assert.match(independent, /A6_INDEPENDENT_OK/);
    await noTools(p, context);
    assert.equal(await p.harness.commit(tx => m.personalServiceSourceBlocker(tx, AUTH), context), REQUEST);
    save('independent-answer.json', { answer: independent, modelHttpCount: read('model-count.json').count });
    const evidence = `独立服务计数2→3；InvocationID ${before.InvocationID}→${afterEffect.InvocationID}；原helper进程已close code=0，hostOpId=${gate.reply.hostOpId}；仅本轮Harness受SIGKILL，恢复未重发。`;
    await p.service.resolve(ref, 'applied', evidence);
    await p.service.recheckStop(ref);
    const settled = await p.harness.waitForTask(ref.taskId, context), final = await p.service.status(ref);
    assert.equal(final.operation.result.effect, 'effect_unknown'); assert.equal(final.operation.resolution.effect, 'applied'); assert.equal(final.operation.launcherStopped, true); assert.equal(settled.state.status, 'terminal'); assert.equal(settled.state.outcome.status, 'completed');
    assert.equal(await p.harness.commit(tx => m.personalServiceSourceBlocker(tx, AUTH), context), undefined);
    const entries = (await p.main.entries({ order: 'ascending' }, 256, undefined, context)).items;
    const stops = entries.filter(entry => entry.kind === 'ruukoto.service-operation-evidence' && entry.data.requestId === REQUEST && entry.data.verb === 'stop-op').map(entry => ({ entryId: entry.id, evidence: entry.data, reply: replyFrom(entry.data) }));
    assert.ok(stops.some(value => value.reply.ok === true && value.reply.hostOpId === gate.reply.hostOpId && value.reply.machineId === gate.reply.machineId && value.reply.exited === true && value.reply.launcherExited === true));
    assert.equal(entries.filter(entry => entry.kind === 'ruukoto.service-operation-evidence' && entry.data.requestId === REQUEST && entry.data.verb === 'restart').length, 0, '被卡住的restart结果不得落盘');
    const after = serviceState(); assert.equal(after.count, 3); assert.equal(after.InvocationID, afterEffect.InvocationID); assert.equal(helperCalls().filter(call => call.verb === 'restart').length, 1);
    const sourceBlocker = await p.harness.commit(tx => m.personalServiceSourceBlocker(tx, AUTH), context);
    save('final.json', { pass: true, ref, before, after, final, settled, stops, restartAttempts: helperCalls().filter(call => call.verb === 'restart').length, modelHttpCount: read('model-count.json').count, sourceBlockerReleased: sourceBlocker === undefined, realModelRounds: ['source authorization receipt', 'independent read-only chat'], sourceResultCommitMissing: true });
    event('complete', { count: after.count, invocationId: after.InvocationID, restartAttempts: 1, modelHttpCount: read('model-count.json').count });
  } finally {
    if (!childExit && launched.exitCode === null && launched.signalCode === null) { launched.kill('SIGKILL'); await closed; }
    await p?.close();
  }
  assert.equal(command(SUDO, ['-n', '/usr/bin/sha256sum', HELPER]).trim().split(/\s+/)[0], helperHash);
  assert.equal(hashFile(POLICY), '83cbea028f2c5954d6ffe06d559a8c8862fa65e5bae02700743b3f5854c654da');
}
try {
  if (process.argv[2] === 'child') await child();
  else { assert.equal(process.argv[2], 'run'); await run(); process.stdout.write(safe({ pass: true, directory: DIR, restartAttempts: 1, modelHttpCount: read('model-count.json').count }) + '\n'); }
} catch (error) {
  save(`failure-${process.argv[2] ?? 'unknown'}-${process.pid}.json`, { name: error.name, code: error.code, message: error.message, stack: error.stack, modelHttpCount: fs.existsSync(path.join(DIR, 'model-count.json')) ? read('model-count.json').count : 0, restartAttempts: helperCalls().filter(call => call.verb === 'restart').length });
  event('failed', { name: error.name, code: error.code, message: error.message });
  process.stderr.write('[ruukoto:a6-chaos] ' + safe({ name: error.name, code: error.code, message: error.message }) + '\n');
  process.exitCode = 1;
}
