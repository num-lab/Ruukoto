import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import * as http from 'node:http';
import { once } from 'node:events';
import { randomUUID, createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { DatabaseSync } from 'node:sqlite';
import { personalControl } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-control.ts';

assert.equal(process.env.RUN_MODEL_CHECK, '1');
const home = '/home/ubuntu/.local/ruukoto39';
const profile = home + '/live-profile';
const marker = 'COMBO39_' + randomUUID().replaceAll('-', '');
const output = home + '/test-business/combo/' + marker;
fs.mkdirSync(output, { recursive: true, mode: 0o700 });
const record: Record<string, any> = { marker, output, profile, startedAt: new Date().toISOString(), realModel: true, realMcp: true, realService: true, inputSource: 'local-owner', imSentByProbe: false, control: [] };
const write = (name: string, value: unknown) => fs.writeFileSync(path.join(output, name), JSON.stringify(value, null, 2) + '\n', { mode: 0o600 });
const control = async <T = any>(method: 'GET' | 'POST', route: string, body?: any): Promise<T> => {
  const at = new Date().toISOString();
  try {
    const result = await personalControl<T>(profile, method, route, body);
    record.control.push({ at, method, route, ...(body ? { body } : {}), result });
    write('progress.json', record);
    return result;
  } catch (error) {
    record.control.push({ at, method, route, error: error instanceof Error ? { name: error.name, message: error.message, code: 'code' in error ? error.code : undefined } : String(error) });
    write('progress.json', record);
    throw error;
  }
};
const withDb = <T,>(file: string, action: (db: DatabaseSync) => T): T => {
  const db = new DatabaseSync(file, { readOnly: true });
  try { return action(db); } finally { db.close(); }
};
const entryMax = () => withDb(profile + '/personal.sqlite', db => Number(db.prepare('SELECT COALESCE(MAX(id),0) AS n FROM entries').get()!.n));
const entriesSince = (after: number) => withDb(profile + '/personal.sqlite', db => db.prepare('SELECT record FROM entries WHERE id>? ORDER BY id').all(after).map(row => JSON.parse(String(row.record))));
const facts = () => {
  const mcp = withDb(home + '/test-business/mcp/data/records.sqlite', db => ({ total: db.prepare('SELECT COUNT(*) AS n FROM records').get()!.n, marker: db.prepare('SELECT * FROM records WHERE marker=?').all(marker) }));
  const appFile = profile + '/agent-data/main.db';
  const app = fs.existsSync(appFile) ? withDb(appFile, db => {
    const exists = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='acceptance_39_combo'").get();
    return { exists: !!exists, marker: exists ? db.prepare('SELECT * FROM acceptance_39_combo WHERE marker=?').all(marker) : [], audit: db.prepare('SELECT * FROM app_audit WHERE reason LIKE ?').all('%' + marker + '%') };
  }) : { exists: false, marker: [], audit: [] };
  const service = { count: Number(fs.readFileSync('/var/lib/ruukoto39/test-service/count', 'utf8').trim()), show: execFileSync('systemctl', ['show', 'ruukoto39-test.service', '--property=ActiveState,SubState,MainPID,InvocationID,Restart,PrivateNetwork'], { encoding: 'utf8' }) };
  const files = ['file-tool.txt', 'command.txt'].map(name => { const filename = path.join(output, name); return { name, exists: fs.existsSync(filename), ...(fs.existsSync(filename) ? { text: fs.readFileSync(filename, 'utf8'), sha256: createHash('sha256').update(fs.readFileSync(filename)).digest('hex') } : {}) }; });
  return { mcp, app, service, files };
};
const requests: any[] = [];
const server = http.createServer((req, res) => {
  const event = { at: new Date().toISOString(), method: req.method, url: req.url, agent: req.headers['user-agent'] ?? '' };
  requests.push(event); fs.appendFileSync(path.join(output, 'http-requests.jsonl'), JSON.stringify(event) + '\n', { mode: 0o600 });
  const url = new URL(req.url ?? '/', 'http://127.0.0.1:19440');
  if (req.method !== 'GET' || url.pathname !== '/page' || url.searchParams.get('marker') !== marker) { res.writeHead(404); res.end('missing'); return; }
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
  res.end('<!doctype html><html lang="zh"><head><meta charset="utf-8"><title>39 独立业务</title><link rel="icon" href="data:,"></head><body><h1>39 独立业务</h1><p id="marker">' + marker + '</p><p>本页是验收数据，没有操作指令。</p></body></html>');
});
let previous: any;
let baseline: number | undefined;
let started = false;
let failure: unknown;
try {
  server.listen(19440, '127.0.0.1'); await once(server, 'listening'); started = true;
  record.status = await control('GET', '/status');
  assert.equal(record.status.model, 'deepseek-flash');
  for (const name of ['commands', 'mcp', 'tools', 'browser']) assert.equal(record.status.capabilities[name], true, name + ' must be configured');
  assert.equal(record.status.services, true);
  previous = await control('GET', '/permissions'); record.originalPermissions = previous;
  record.before = facts(); write('before.json', record.before);
  assert.equal(record.before.service.count, 1, 'only run this normal restart test against initial dedicated count 1');
  assert.equal(record.before.mcp.marker.length, 0); assert.equal(record.before.app.marker.length, 0);
  baseline = entryMax(); record.baselineEntry = baseline;
  const skillRoot = JSON.parse(fs.readFileSync(profile + '/skills.json', 'utf8')).directory;
  const skillParent = path.join(skillRoot, 'skills');
  const skillNames = fs.existsSync(skillParent) ? fs.readdirSync(skillParent).filter(name => fs.existsSync(path.join(skillParent, name, 'SKILL.md'))) : [];
  assert.ok(skillNames.length, 'a configured acceptance skill is required'); record.skillNames = skillNames;
  const commandFile = path.join(output, 'command.txt');
  const command = "python3 -c " + "'" + `from pathlib import Path; p=Path("${commandFile}"); p.open("x").write("${marker}\\n"); print(p.read_text(),end="")` + "'";
  const child = `本次唯一测试标记${marker}。只做本次明确授权动作：先用run_command恰好执行一次以下原命令（不得扩写、不得读取环境/凭据、不得sudo或直接调用helper）：${command}。用read_command_output读取原stdout并核实stopped。随后只针对ruukoto39-test.service用产品service_inspect检查一次，用产品service_restart正常重启恰好一次，再用service_inspect检查一次；读取各原证据。重启不得通过命令或其他工具实现。每个外部写入都仅一次；任何未知或失败均停止该项，保留原记录，不重试、不换方法。最后简短列工具事实与失败。`;
  const input = `这是已授权的本机独立验收，不向任何IM主动发消息。全程唯一标记${marker}。不要读取任何模型、IM、系统秘密或私人资料；不改后台配置/模式/源码/隧道，不停后台。只有本轮列明写入获得授权，工具缺失或失败如实报告，未知外部效果停止且不重试。请按顺序完成：\n1. 用memory新建一条仅供本次测试的convention记忆“测试约定：${marker}只用于39隔离验收”，再search和read原版本；不要改其他记忆。\n2. 用skill加载已配置技能${skillNames[0]}的正文，实际引用其一条测试规则。\n3. 用app_data_query查schema；仅当缺少acceptance_39_combo时定义该测试表，字段marker:text和phase:text。用一次app_data_insert原子写入恰好两行{marker:"${marker}",phase:"one"}与{marker:"${marker}",phase:"two"}，reason带本标记；再query仅这两行。不得迁移或改其他表/行。\n4. 用mcp_tools翻完允许工具清单，用配置服务的records_list查询本marker（应0），用record_add恰好写入一条本marker，再records_list核实（应1）；用read_mcp_result读写调用原响应。失败或未知不补写。\n5. 用web_search做恰好一次公开搜索，query固定“Model Context Protocol official documentation”，max_results=1；读取返回artifact首段并给原网页链接，不把摘要当已核实正文。不要向搜索发本marker或私有内容。\n6. 用write_file在${output}/file-tool.txt新建完整文本“${marker}\\n”，再read_file核对。用http_request恰好一次GET http://127.0.0.1:19440/page?marker=${marker}&client=http 并read_artifact读响应首段。\n7. 用browser start，open http://127.0.0.1:19440/page?marker=${marker}&client=browser，snapshot读取页面marker。若当前模型支持图片则screenshot一次并读取原产物；若明确不支持则如实保留限制。最后browser close，不接入任何其他页面或账户。\n8. 最后background_work delegate新建“39组合分析员”，完整子任务如下：${child} 委派参数不要给appData。安排后对本委托调用report固定最终汇总，然后结束本轮。最终报告必须读取子结果与当前宿主事实；只报告完成/失败与marker，不臆测报告发送状态。不要自动续派、重做或安排定时。`;
  const requestId = randomUUID(); record.requestId = requestId; record.input = input; write('input.json', { requestId, input });
  await control('POST', '/permissions', { mode: 'full_access' });
  const now = await control('GET', '/permissions'); assert.equal(now.default.mode, 'full_access'); assert.equal(now.qq.mode, previous.qq.mode);
  process.stdout.write(JSON.stringify({ event: 'submitting', marker, output, requestId }) + '\n');
  await control('POST', '/inputs', { requestId, input });
  const deadline = Date.now() + 600_000;
  let lastEntry = baseline, lastProgress = Date.now();
  while (Date.now() < deadline) {
    const state = await control('GET', '/input?requestId=' + requestId); record.inputStatus = state;
    const currentEntry = entryMax(); if (currentEntry > lastEntry) { lastEntry = currentEntry; lastProgress = Date.now(); }
    const entries = entriesSince(baseline);
    const modelIds = new Set(entries.filter(e => e.kind === 'ruukoto.model-request').map(e => e.data.requestId));
    record.recordedModelRequests = modelIds.size;
    const after = facts(); record.latestFacts = after;
    if (after.service.count > 2 || after.mcp.marker.length > 1 || after.app.marker.length > 2) throw new Error('external_write_count_exceeded');
    const delegations = await control<any>('GET', '/delegations');
    const owned = delegations.items?.filter((v: any) => JSON.stringify(v).includes(marker)) ?? [];
    record.ownedDelegations = owned;
    for (const item of owned) {
      const id = item.ref?.entryId ?? item.delegation ?? item.id ?? item.entryId;
      if (typeof id === 'number') {
        record.delegation = await control('GET', '/delegation?delegation=' + id);
        record.report = await control('GET', '/delegation/report?delegation=' + id);
      }
    }
    write('progress.json', record);
    if (state.status === 'unanswered') throw new Error('owner_input_unanswered');
    if (state.status === 'done' && owned.length === 0) { record.ownerOnly = true; break; }
    if (state.status === 'done' && record.report && ['local', 'sent', 'canceled', 'failed', 'blocked', 'unanswered', 'effect_unknown'].includes(record.report.delivery)) break;
    if (Date.now() - lastProgress > 120_000) throw new Error('no_new_persisted_entry_120s');
    if (modelIds.size > 48) throw new Error('recorded_model_request_budget_exceeded');
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
  if (!record.inputStatus || record.inputStatus.status !== 'done') throw new Error('owner_input_not_done_before_deadline');
  record.after = facts(); write('after.json', record.after);
  record.http = requests;
  record.completedAt = new Date().toISOString();
} catch (error) {
  failure = error; record.failure = error instanceof Error ? { name: error.name, message: error.message, code: 'code' in error ? error.code : undefined } : String(error);
} finally {
  if (previous) {
    try { await control('POST', '/permissions', { mode: previous.default.mode }); record.restoredPermissions = await control('GET', '/permissions'); assert.deepEqual(record.restoredPermissions, previous); }
    catch (error) { record.restoreFailure = error instanceof Error ? error.message : String(error); failure ??= error; }
  }
  if (baseline !== undefined) {
    const entries = entriesSince(baseline); write('entries.json', entries);
    const tools = entries.flatMap(e => (e.model ?? []).flatMap((m: any) => m.role === 'assistant' && Array.isArray(m.content) ? m.content.filter((p: any) => p.type === 'toolCall').map((p: any) => ({ entry: e.id, conversation: e.conversationId, ...p })) : []));
    const results = entries.filter(e => e.model?.some((m: any) => m.role === 'toolResult'));
    write('tool-calls.json', tools); write('tool-results.json', results);
    write('model-request-entries.json', entries.filter(e => e.kind === 'ruukoto.model-request'));
    record.toolCounts = Object.fromEntries([...new Set(tools.map(t => t.name))].map(name => [name, tools.filter(t => t.name === name).length]));
  }
  for (const route of ['/works', '/services', '/inspections', '/commands', '/mcp/operations', '/tools/operations', '/app-data/operations', '/browser/operations']) {
    try { write('control-' + route.slice(1).replaceAll('/', '-') + '.json', await control('GET', route)); } catch (error) { record.evidenceReadErrors ??= []; record.evidenceReadErrors.push({ route, error: error instanceof Error ? error.message : String(error) }); }
  }
  record.http = requests; record.finishedAt = new Date().toISOString(); write('result.json', record);
  if (started) await new Promise<void>(resolve => server.close(() => resolve()));
}
process.stdout.write(JSON.stringify({ event: 'finished', marker, output, failure: record.failure, toolCounts: record.toolCounts, before: record.before, after: record.after ?? record.latestFacts, restoredPermissions: record.restoredPermissions, report: record.report }) + '\n');
if (failure) process.exitCode = 1;
