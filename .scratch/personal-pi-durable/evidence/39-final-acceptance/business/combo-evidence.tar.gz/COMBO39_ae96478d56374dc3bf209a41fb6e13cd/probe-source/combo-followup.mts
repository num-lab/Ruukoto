import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { randomUUID } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { execFileSync } from 'node:child_process';
import { personalControl } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-control.ts';
assert.equal(process.env.RUN_MODEL_CHECK,'1');
const stage=process.argv[2];assert.ok(stage==='readonly-images'||stage==='command-service');
const home='/home/ubuntu/.local/ruukoto39',profile=home+'/live-profile',marker='COMBO39_ae96478d56374dc3bf209a41fb6e13cd';
const base=home+'/test-business/combo/'+marker,output=base+'/'+stage;assert.ok(!fs.existsSync(output),'do not repeat this stage');fs.mkdirSync(output,{mode:0o700});
const result:any={stage,marker,output,startedAt:new Date().toISOString(),inputSource:'local-owner',control:[]};
const write=(name:string,value:unknown)=>fs.writeFileSync(path.join(output,name),JSON.stringify(value,null,2)+'\n',{mode:0o600});
const call=async(method:'GET'|'POST',route:string,body?:any)=>{try{const value=await personalControl<any>(profile,method,route,body);result.control.push({at:new Date().toISOString(),method,route,...(body?{body}:{}),result:value});write('progress.json',result);return value;}catch(error){result.control.push({method,route,error:error instanceof Error?error.message:String(error)});throw error;}};
const withDb=<T,>(file:string,fn:(db:DatabaseSync)=>T)=>{const db=new DatabaseSync(file,{readOnly:true});try{return fn(db);}finally{db.close();}};
const getEntries=(after:number)=>withDb(profile+'/personal.sqlite',db=>db.prepare('SELECT record FROM entries WHERE id>? ORDER BY id').all(after).map(r=>JSON.parse(String(r.record))));
const facts=()=>({serviceCount:Number(fs.readFileSync('/var/lib/ruukoto39/test-service/count','utf8').trim()),serviceShow:execFileSync('systemctl',['show','ruukoto39-test.service','--property=ActiveState,SubState,MainPID,InvocationID'],{encoding:'utf8'}),commandFileExists:fs.existsSync(base+'/command.txt'),...(fs.existsSync(base+'/command.txt')?{commandFile:fs.readFileSync(base+'/command.txt','utf8')}:{}),mcpMarkerCount:withDb(home+'/test-business/mcp/data/records.sqlite',db=>db.prepare('SELECT COUNT(*) AS n FROM records WHERE marker=?').get(marker)!.n),appMarkerCount:withDb(profile+'/agent-data/main.db',db=>db.prepare('SELECT COUNT(*) AS n FROM acceptance_39_combo WHERE marker=?').get(marker)!.n)});
let baseline=0,previous:any,failed=false;
try{
 result.status=await call('GET','/status');previous=await call('GET','/permissions');result.originalPermissions=previous;
 result.before=facts();write('before.json',result.before);
 baseline=withDb(profile+'/personal.sqlite',db=>Number(db.prepare('SELECT COALESCE(MAX(id),0) AS n FROM entries').get()!.n));result.baseline=baseline;
 let input:string;
 if(stage==='readonly-images')input=`这是一个新的独立只读请求，与上轮未回答输入分开。仅查看上下文中已经保存的Telegram照片和${marker}那张浏览器截图，分别用一句话说明两图内容，并保留截图中可见marker。不要调用任何工具，不创建或修改记忆、数据、MCP记录、文件、命令、服务、浏览器或委派；不重试上一轮业务，不发送IM消息。只用本地回答。`;
 else{
  assert.equal(result.before.serviceCount,1);assert.equal(result.before.commandFileExists,false);assert.equal(result.before.mcpMarkerCount,1);assert.equal(result.before.appMarkerCount,2);
  const command="python3 -c '"+`from pathlib import Path; p=Path("${base}/command.txt"); p.open("x").write("${marker}\\n"); print(p.read_text(),end="")`+"'";
  const child=`唯一测试标记${marker}。用run_command恰好一次执行此原命令，不扩写、不读取环境或秘密、不sudo、不通过命令调用helper：${command}。随后用read_command_output读原stdout/stderr并核对stopped。然后仅针对ruukoto39-test.service用产品service_inspect检查一次、用service_restart正常重启恰好一次、再service_inspect检查一次，并读原证据。service_restart是唯一允许的服务写入口，禁止命令/systemctl/helper替代。任何失败或未知停止该项，不重试；不重复命令和重启。最后简短列原事实与失败。`;
  input=`这是新的独立本机验收，只授权以下全新未执行动作，与上轮已完成的记忆、skill、appdata、MCP、HTTP、搜索、文件、浏览器完全分开。唯一标记${marker}。不得重做任何上轮业务，不读取模型/IM秘密、不改配置/源码/权限/隧道、不主动发IM。请background_work delegate新建“39命令服务分析员”，完整子任务如下：${child} 不给appData。安排后对本委托report固定最终汇总，结束本轮。最终报告只读取本子结果/宿主事实，准确说明失败，不臆测报告发送状态。`;
  await call('POST','/permissions',{mode:'full_access'});const p=await call('GET','/permissions');assert.equal(p.default.mode,'full_access');assert.equal(p.qq.mode,previous.qq.mode);
 }
 const requestId=randomUUID();result.requestId=requestId;result.input=input;write('input.json',{requestId,input});
 process.stdout.write(JSON.stringify({event:'submitting',stage,marker,output,requestId})+'\n');
 await call('POST','/inputs',{requestId,input});
 const deadline=Date.now()+(stage==='readonly-images'?120000:240000);
 while(Date.now()<deadline){
  const state=await call('GET','/input?requestId='+requestId);result.inputStatus=state;
  if(state.status==='unanswered')throw new Error('owner_input_unanswered');
  if(stage==='command-service'){
   const list=await call('GET','/delegations');const own=list.items.filter((v:any)=>v.content===input.slice(0,160)||v.content.includes('新的独立本机验收'));result.delegations=own;
   for(const d of own){result.delegation=await call('GET','/delegation?delegation='+d.ref.entryId);result.report=await call('GET','/delegation/report?delegation='+d.ref.entryId);}
   result.latestFacts=facts();assert.ok(result.latestFacts.serviceCount<=2,'restart must be at most once');
   if(state.status==='done'&&result.report&&['local','sent','canceled','failed','blocked','unanswered','effect_unknown'].includes(result.report.delivery))break;
   if(state.status==='done'&&own.length===0)throw new Error('model_did_not_delegate');
  }else if(state.status==='done')break;
  write('progress.json',result);await new Promise(resolve=>setTimeout(resolve,2000));
 }
 assert.equal(result.inputStatus?.status,'done');
 result.after=facts();write('after.json',result.after);
 const entries=getEntries(baseline);const requests=entries.filter(e=>e.kind==='ruukoto.model-request');result.modelRequestIds=new Set(requests.map(e=>e.data.requestId)).size;result.payloadRecords=requests.filter(e=>e.data.payload!==undefined).length;
 if(stage==='readonly-images'){assert.ok(result.payloadRecords>0,'real adapter payload must persist');assert.ok(entries.some(e=>e.kind==='pi.assistant'&&e.model?.some((m:any)=>m.role==='assistant'&&m.stopReason==='stop')));assert.equal(result.before.serviceCount,result.after.serviceCount);assert.equal(result.after.commandFileExists,false);}
 else{assert.equal(result.after.serviceCount,2);assert.equal(result.after.commandFile,marker+'\n');assert.equal(result.after.mcpMarkerCount,1);assert.equal(result.after.appMarkerCount,2);assert.equal(result.report.delivery,'local');}
 result.passed=true;
}catch(error){failed=true;result.failure=error instanceof Error?{name:error.name,message:error.message,code:'code'in error?error.code:undefined}:String(error);}
finally{
 if(previous&&stage==='command-service')try{await call('POST','/permissions',{mode:previous.default.mode});result.restoredPermissions=await call('GET','/permissions');assert.deepEqual(result.restoredPermissions,previous);}catch(error){failed=true;result.restoreFailure=error instanceof Error?error.message:String(error);}
 if(baseline){const entries=getEntries(baseline);write('entries.json',entries);write('model-request-entries.json',entries.filter(e=>e.kind==='ruukoto.model-request'));write('assistant-entries.json',entries.filter(e=>e.kind==='pi.assistant'));write('tool-result-entries.json',entries.filter(e=>e.kind==='pi.tool-result'));}
 for(const route of ['/commands','/services','/inspections','/works','/delegations'])try{write('control-'+route.slice(1)+'.json',await call('GET',route));}catch(error){result.evidenceReadError??=[];result.evidenceReadError.push({route,error:error instanceof Error?error.message:String(error)});}
 result.finishedAt=new Date().toISOString();write('result.json',result);
}
process.stdout.write(JSON.stringify({event:'finished',stage,output,passed:result.passed,failure:result.failure,inputStatus:result.inputStatus,modelRequestIds:result.modelRequestIds,payloadRecords:result.payloadRecords,before:result.before,after:result.after??result.latestFacts,report:result.report,restoredPermissions:result.restoredPermissions})+'\n');if(failed)process.exitCode=1;
