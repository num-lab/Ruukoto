import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { DatabaseSync, backup } from 'node:sqlite';
import { isDeepStrictEqual as equal } from 'node:util';
import { ProviderDoc } from '/home/ubuntu/.local/ruukoto39/current/node_modules/@earendil-works/pi-durable/dist/index.js';
import { apply } from '/home/ubuntu/.local/ruukoto39/current/node_modules/@earendil-works/chord/dist/delta/index.js';
import { personalMedia } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-media.ts';
import { loadPersonalArtifact } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-artifacts.ts';
import { personalProvider, recordedModels } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-model.ts';
const root='/home/ubuntu/.local/ruukoto39';
const profile=root+'/live-profile';
const output=root+'/test-business/combo/COMBO39_ae96478d56374dc3bf209a41fb6e13cd';
const request=JSON.parse(fs.readFileSync(output+'/last-model-request.json','utf8')).data;
const snapshot=output+'/failure-source.sqlite';
if(!fs.existsSync(snapshot)){
 const live=new DatabaseSync(profile+'/personal.sqlite',{readOnly:true});
 try{await backup(live,snapshot);}finally{live.close();}fs.chmodSync(snapshot,0o600);
}
const db=new DatabaseSync(snapshot,{readOnly:true});
function doc(kind:string,key='',owner?:number){
 const row=db.prepare('SELECT id,record FROM documents WHERE kind=? AND key_value=? AND retired_at IS NULL'+(owner===undefined?'':' AND owner_id=?')).get(...(owner===undefined?[JSON.stringify(kind),JSON.stringify(key)]:[JSON.stringify(kind),JSON.stringify(key),owner]));assert.ok(row,kind+':'+key);
 const base=db.prepare("SELECT seq,content FROM document_revisions WHERE document_id=? AND kind='base' ORDER BY seq DESC LIMIT 1").get(row.id)!;
 let value=JSON.parse(String(base.content));
 for(const r of db.prepare('SELECT kind,content FROM document_revisions WHERE document_id=? AND seq>? ORDER BY seq').all(row.id,base.seq)){assert.equal(r.kind,'delta');value=apply(value,JSON.parse(String(r.content)));}
 return value;
}
const entry=(id:number)=>{const r=db.prepare('SELECT record FROM entries WHERE id=?').get(id);return r?JSON.parse(String(r.record)):undefined;};
const task=(id:number)=>{const r=db.prepare('SELECT record FROM tasks WHERE id=?').get(id);return r?JSON.parse(String(r.record)):undefined;};
const submission=(conversation:number,id:string)=>{const r=db.prepare('SELECT record FROM submissions WHERE conversation_id=? AND request_id=?').get(conversation,JSON.stringify(id));return r?JSON.parse(String(r.record)):undefined;};
const contains=(models:any[],image:any)=>models?.some(m=>m.role!=='assistant'&&Array.isArray(m.content)&&m.content.some((p:any)=>p.type==='image'&&equal(p,image)))===true;
const checks:any[]=[];
for(const message of request.input.messages){
 if(!Array.isArray(message.content))continue;
 for(const image of message.content){
  if(image.type!=='image')continue;
  const ref=JSON.parse(image.data).ruukotoImage,saved=doc('ruukoto.image',ref.artifact.id).image,anchor=entry(saved.entry),provider=doc(ProviderDoc.definition.kind,'',ref.conversationId);
  const c:any={source:ref.source,artifact:ref.artifact,savedRefEqual:equal(saved.ref,ref),anchorKind:anchor?.kind,anchorConversationEqual:anchor?.conversationId===ref.conversationId,anchorRefEqual:equal(anchor?.data,ref),providerSessionEqual:provider.sessionId===request.sessionId};
  if(ref.source.kind==='inbound'){
   const m=doc('ruukoto.media-message',ref.source.requestId).message,s=submission(ref.conversationId,ref.source.requestId),e=s?.entry&&entry(s.entry),received=entry(m.accepted),r=doc('ruukoto.telegram-receipt',m.key).receipt,t=r&&task(r.taskId);
   Object.assign(c,{messageKeyEqual:m.key===ref.source.requestId,messageState:m.state,artifactRegistered:m.artifacts.some((a:any)=>equal(a,ref.artifact)),rootConversation:ref.conversationId===1,submissionType:s?.type,submissionIdEqual:m.submissionId===undefined||m.submissionId===s?.id,userEntryKind:e?.kind,userEntryConversationEqual:e?.conversationId===ref.conversationId,userEntryContainsImage:contains(e?.model,image),receivedEntryKind:received?.kind,receivedRoot:received?.conversationId===1,receivedDataEqual:equal(received?.data,{key:m.key,source:m.source,body:m.body,identities:m.identities}),receiptExists:!!r,receiptPlatformEqual:(r?.platform??'telegram')===m.source.platform,receiptRequestEqual:r?.requestId===m.key,receiptMediaKeyEqual:r?.media?.key===m.key,receiptIdentitiesEqual:equal(r?.media?.identities,m.identities),receiptNotRejected:!r?.mediaRejected,receiptNotControl:!r?.control,receiptGenerationEqual:r?.generation===m.source.generation,receiptAccountEqual:r?.botId===m.source.accountId,receiptOwnerEqual:r?.ownerId===m.source.ownerId,receiptContentEqual:r?.content===m.body,receiptAcceptedEqual:r?.accepted===m.accepted,receiptTaskKind:t?.kind,receiptTaskRoot:t?.conversationId===1,receiptSubmissionEqual:r?.submissionId===undefined||r.submissionId===s?.id});
  }else{
   const t=task(ref.source.taskId),e=t?.state?.outcome?.result?.entryId&&entry(t.state.outcome.result.entryId);
   Object.assign(c,{taskKind:t?.kind,taskConversationEqual:t?.conversationId===ref.conversationId,inputKind:t?.input?.kind,taskStatus:t?.state?.status,resultEntry:e?.id,resultEntryKind:e?.kind,resultConversationEqual:e?.conversationId===ref.conversationId,resultContainsImage:contains(e?.model,image),callIdEqual:e?.model?.some((m:any)=>m.role==='toolResult'&&m.toolCallId===t.input.callId)===true});
  }
  const bytes=loadPersonalArtifact(profile,ref.artifact);c.artifactOriginalReadValid=true;c.actualBytes=bytes.length;
  const copies=path.join(output,'failure-images');fs.mkdirSync(copies,{recursive:true,mode:0o700});fs.writeFileSync(path.join(copies,ref.artifact.id+'.bin'),bytes,{mode:0o600});checks.push(c);
 }
}
const tx={doc:async(d:any,...args:any[])=>doc(d.definition.kind,d.definition.family?String(args[0]):'',d.definition.scope==='conversation'?Number(args[0]):undefined),entry:async(id:number)=>entry(id),task:async(id:number)=>task(id),submissionByRequest:async(c:number,id:string)=>submission(c,id)};
const readOnlyHarness={commit:async(fn:any)=>fn(tx)};
const media=personalMedia(profile,()=>readOnlyHarness as any,()=>true);
fs.writeFileSync(output+'/media-source-conditions.json',JSON.stringify(checks,null,2)+'\n',{mode:0o600});
const prepared=await media.modelMedia.prepare(request.input,request.sessionId);
const rebuilt=prepared.snapshot(request.input);assert.ok(rebuilt);const result:any={checks,allPrepareVerificationPassed:true,inputSnapshotPassed:true,httpCalls:0};
const originalFetch=globalThis.fetch;globalThis.fetch=async()=>{result.httpCalls++;throw new Error('offline_probe_forbids_http');};
process.env.RUUKOTO39_OFFLINE_DUMMY='offline-no-credential';
try{
 const models=recordedModels(personalProvider({api:'openai-responses',baseUrl:'https://offline.invalid/v1',modelId:'deepseek-flash',apiKeyEnv:'RUUKOTO39_OFFLINE_DUMMY',contextWindow:128000,maxTokens:4096,imageInput:true}),async e=>{if(e.payload)throw new Error('offline_record_abort_after_valid_payload');},media.modelMedia);
 const model=models.getModel('personal','deepseek-flash')!;
 const answer=await models.streamSimple(model,request.input,{sessionId:request.sessionId,onPayload:payload=>{
   const file=output+'/actual-responses-payload-before-gate.json';fs.writeFileSync(file,JSON.stringify(payload,null,2)+'\n',{mode:0o600});
   const value=payload as any;result.payloadShape=value.input.map((v:any)=>({type:v.type,role:v.role,contentTypes:Array.isArray(v.content)?v.content.map((p:any)=>p.type):typeof v.content,outputTypes:Array.isArray(v.output)?v.output.map((p:any)=>p.type):typeof v.output}));
   result.inputImages=value.input.flatMap((v:any)=>Array.isArray(v.content)?v.content:[]).filter((p:any)=>p.type==='input_image').length;
   result.outputImages=value.input.flatMap((v:any)=>Array.isArray(v.output)?v.output:[]).filter((p:any)=>p.type==='input_image').length;
 }}).result();result.adapterStopReason=answer.stopReason;result.adapterError=answer.errorMessage;
}finally{globalThis.fetch=originalFetch;delete process.env.RUUKOTO39_OFFLINE_DUMMY;db.close();}
assert.equal(result.httpCalls,0);fs.writeFileSync(output+'/media-source-verification.json',JSON.stringify(result,null,2)+'\n',{mode:0o600});process.stdout.write(JSON.stringify(result,null,2)+'\n');
