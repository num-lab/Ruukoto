import ctypes,hashlib,json,os,signal,struct,sys,time
from pathlib import Path
HELPER='/usr/local/libexec/ruukoto39/ruukoto-service'
UNIT='ruukoto39-test.service'
libc=ctypes.CDLL(None,use_errno=True);libc.ptrace.restype=ctypes.c_long;libc.ptrace.argtypes=[ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_void_p]
def ptrace(request,pid,a=0,b=0):
 ctypes.set_errno(0);r=libc.ptrace(request,pid,a,b)
 if r==-1 and ctypes.get_errno():raise OSError(ctypes.get_errno(),'ptrace')
 return r
def save(p,v):
 p.write_text(json.dumps(v,indent=2)+'\n');p.chmod(0o644)
def proc(pid):
 p=Path('/proc')/str(pid);f=(p/'stat').read_text().rsplit(') ',1)[1].split();status=dict(line.split(':',1) for line in (p/'status').read_text().splitlines() if ':' in line)
 return {'pid':pid,'state':f[0],'startTime':f[19],'processGroup':int(f[2]),'tracerPid':int(status['TracerPid'].strip()),'argv':(p/'cmdline').read_bytes().split(b'\0')[:-1]}
def clean(p):return {k:([x.decode() for x in v] if k=='argv' else v) for k,v in p.items()}
def observe(ready):
 q=json.loads(ready.read_text());claim=Path('/var/lib/ruukoto/service-ops')/q['inspectionId']/'claim.json';s=claim.lstat();c=json.loads(claim.read_text());assert s.st_uid==0 and s.st_nlink==1 and (s.st_mode&0o777)==0o600 and c['claimedBy']=='inspect-op' and c['unit']==UNIT
 assert c['launcher']==q['claim']['launcher'] and c['inspectionId']==q['inspectionId'];id=c['launcher'];boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();members=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:v=proc(int(p.name))
  except (FileNotFoundError,ProcessLookupError):continue
  if v['processGroup']==id['processGroup']:members.append(clean(v))
 try:v=proc(id['pid'])
 except (FileNotFoundError,ProcessLookupError):v=None
 return q,c,v,{'at':time.time(),'bootId':boot,'claim':c,'claimUid':s.st_uid,'claimMode':oct(s.st_mode&0o777),'claimNlink':s.st_nlink,'original':clean(v) if v else None,'members':members,'sameBoot':boot==id['bootId'],'claimSha256':hashlib.sha256(claim.read_bytes()).hexdigest()}
mode=sys.argv[1]
if mode in ['observe','kill']:
 ready=Path(sys.argv[2]);q,c,v,out=observe(ready);id=c['launcher']
 if mode=='kill' and v is not None:
  fd=os.pidfd_open(id['pid']);again=proc(id['pid']);assert out['sameBoot'] and again['startTime']==id['startTime'] and again['processGroup']==id['processGroup'] and again['argv']==[b'/usr/local/bin/node',HELPER.encode(),b'inspect-op',q['inspectionId'].encode(),c['machineId'].encode(),UNIT.encode()]
  signal.pidfd_send_signal(fd,signal.SIGKILL);os.close(fd);out['pidfdSignal']='SIGKILL'
 print(json.dumps(out));sys.exit(0)
assert mode=='run' and os.geteuid()==0
folder=Path(sys.argv[2]);args=sys.argv[3:];assert len(args)==5 and args[0]==HELPER and args[1]=='inspect-op' and args[-1]==UNIT
assert not (folder/'gate-ready.json').exists();pid=os.fork()
if pid==0:
 ptrace(0,0);os.execv('/usr/local/bin/node',['/usr/local/bin/node']+args)
traced=True;released=False
try:
 _,status=os.waitpid(pid,0);assert os.WIFSTOPPED(status);ptrace(0x4200,pid,0,1|0x100000);enter=True;deliver=0
 class Vec(ctypes.Structure):_fields_=[('base',ctypes.c_void_p),('length',ctypes.c_size_t)]
 while True:
  ptrace(24,pid,0,deliver);deliver=0;_,status=os.waitpid(pid,0)
  if os.WIFEXITED(status) or os.WIFSIGNALED(status):raise RuntimeError('helper ended before gate: '+str(status))
  sig=os.WSTOPSIG(status)
  if sig!=(signal.SIGTRAP|0x80):
   deliver=sig;continue
  regs=(ctypes.c_ulonglong*34)();vec=Vec(ctypes.cast(regs,ctypes.c_void_p),ctypes.sizeof(regs));ptrace(0x4204,pid,1,ctypes.byref(vec))
  if enter and regs[8]==64 and regs[0]==1 and 0<regs[2]<=4096:
   data=b''.join(struct.pack('Q',ptrace(2,pid,int(regs[1])+i,0)&((1<<64)-1)) for i in range(0,int(regs[2]),8))[:int(regs[2])]
   if b'ActiveState=' in data and b'InvocationID=' in data and b'Id='+UNIT.encode() in data:
    claim=json.loads((Path('/var/lib/ruukoto/service-ops')/args[2]/'claim.json').read_text());assert claim['launcher']['pid']==pid
    ptrace(17,pid,0,signal.SIGSTOP);traced=False
    _,status=os.waitpid(pid,os.WUNTRACED);assert os.WIFSTOPPED(status) and os.WSTOPSIG(status)==signal.SIGSTOP
    state=proc(pid);assert state['state']=='T' and state['tracerPid']==0
    save(folder/'gate-ready.json',{'at':time.time(),'inspectionId':args[2],'claim':claim,'helper':clean(state),'tracerPid':os.getpid(),'stdoutBytes':len(data),'stdoutSha256':hashlib.sha256(data).hexdigest(),'systemctlShowReturned':True,'stage':'before original helper write(fd1), no structured reply yet'});released=True;sys.exit(0)
  enter=not enter
finally:
 if not released:
  try:
   fd=os.pidfd_open(pid);signal.pidfd_send_signal(fd,signal.SIGKILL);os.close(fd);os.waitpid(pid,0)
  except ProcessLookupError:pass
