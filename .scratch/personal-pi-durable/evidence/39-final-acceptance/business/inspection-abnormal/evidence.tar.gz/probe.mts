import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import childProcess from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import { pathToFileURL } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';
const ROOT='/home/ubuntu/.local/ruukoto39/current',DIR=process.env.RUUKOTO39_INSPECTION_DIR!;
assert.ok(DIR && path.dirname(DIR)==='/home/ubuntu/.local/ruukoto39/test-business' && path.basename(DIR).startsWith('inspection-abnormal-'));
const PROFILE=path.join(DIR,'profile'),HELPER='/usr/local/libexec/ruukoto39/ruukoto-service',UNIT='ruukoto39-test.service',GATE=path.join(DIR,'gate.py');
const READY=path.join(DIR,'gate-ready.json'),EVENTS=path.join(DIR,'events.jsonl'),SELF=process.argv[1],SOURCE='inspection-abnormal-owner',WORK='inspection-abnormal-work';
const service={helperPath:HELPER,policyPath:'/etc/ruukoto/services.json',sudoPath:'/usr/bin/sudo',useSudo:true,timeouts:{inspectMs:90000,stopMs:5000}};
const hash=(data:Buffer|string)=>crypto.createHash('sha256').update(data).digest('hex');
const save=(n:string,v:unknown)=>fs.writeFileSync(path.join(DIR,n),JSON.stringify(v,null,2)+'\n',{mode:0o600});
const event=(kind:string,data:unknown={})=>fs.appendFileSync(EVENTS,JSON.stringify({at:new Date().toISOString(),pid:process.pid,kind,data})+'\n',{mode:0o600});
function command(file:string,args:string[]){const out=childProcess.spawnSync(file,args,{encoding:'utf8',timeout:15000,env:{PATH:'/usr/local/bin:/usr/bin:/bin'}});assert.equal(out.status,0,JSON.stringify({file,args,code:out.status,stderr:out.stderr}));return out.stdout;}
const observe=()=>JSON.parse(command('/usr/bin/sudo',['-n','/usr/bin/python3',GATE,'observe',READY]));
const killOriginal=()=>JSON.parse(command('/usr/bin/sudo',['-n','/usr/bin/python3',GATE,'kill',READY]));
async function until(check:()=>unknown|Promise<unknown>,label:string,ms=15000){const end=Date.now()+ms;while(!await check()){assert.ok(Date.now()<end,'timeout '+label);await delay(20);}}
const events=()=>fs.existsSync(EVENTS)?fs.readFileSync(EVENTS,'utf8').trim().split('\n').filter(Boolean).map(x=>JSON.parse(x)):[];
function audit(gated:boolean){const original=childProcess.spawn;childProcess.spawn=function(file:any,args:any,options:any){if(file==='/usr/bin/sudo'&&args?.[0]==='-n'&&args[1]===HELPER){const verb=args[2];event('helper-attempt',{verb,args:args.slice(2)});assert.ok(['inspect-op','stop-inspect'].includes(verb));if(verb==='inspect-op'){assert.equal(args.at(-1),UNIT);assert.equal(events().filter(x=>x.kind==='helper-attempt'&&x.data.verb==='inspect-op').length,1,'never start a second inspection');assert.ok(gated);const out=original.call(childProcess,file,['-n','/usr/bin/python3',GATE,'run',DIR,...args.slice(1)],options);event('instrumented-spawn',{pid:out.pid});out.once('close',(code,signal)=>event('instrumented-close',{pid:out.pid,code,signal}));return out;}const out=original.call(childProcess,file,args,options);out.once('close',(code,signal)=>event('stop-inspect-close',{pid:out.pid,code,signal}));return out;}return original.call(childProcess,file,args,options);} as typeof original;syncBuiltinESMExports();}
const {BACKGROUND_CONTEXT:ctx}=await import(pathToFileURL(ROOT+'/node_modules/@earendil-works/chord/dist/context/index.js').href);
const {openPersonalHarness}=await import(pathToFileURL(ROOT+'/apps/ruukoto/src/personal-harness.ts').href);
const {personalProvider}=await import(pathToFileURL(ROOT+'/apps/ruukoto/src/personal-model.ts').href);
const {PersonalInspectionDoc,PersonalPendingInspectionsDoc}=await import(pathToFileURL(ROOT+'/apps/ruukoto/src/personal-service-inspection.ts').href);
const {PersonalWorkDoc}=await import(pathToFileURL(ROOT+'/apps/ruukoto/src/personal-work.ts').href);
process.env.RUUKOTO39_INSPECTION_MOCK_KEY='test-only';
if(process.argv[2]==='backend'){
 audit(true);const config=JSON.parse(fs.readFileSync(path.join(DIR,'model-config.json'),'utf8'));
 const p=await openPersonalHarness({directory:PROFILE,provider:personalProvider(config),modelId:config.modelId,service});
 const ref=await p.work.delegate({requestId:WORK,sourceRequestId:SOURCE,content:'只检查一次ruukoto39-test.service，不执行任何写操作。'});save('work.json',ref);event('delegated',ref);setInterval(()=>{},1000);
}else{
 const {MockModelServer}=await import(pathToFileURL(ROOT+'/test/helpers/mock-provider.ts').href);
 let intents=0;const model=new MockModelServer(request=>{if(request.system?.startsWith('你是个人助手的子 Agent')&&request.messages.at(-1)?.role==='user'){intents++;assert.equal(intents,1);return{kind:'tool_calls',calls:[{id:'one-real-inspection',name:'service_inspect',arguments:{unit:UNIT}}]};}return{kind:'text',text:'独立工作完成'};});
 const config={api:'openai-completions',baseUrl:await model.start(),modelId:'mock-model',apiKeyEnv:'RUUKOTO39_INSPECTION_MOCK_KEY',contextWindow:128000,maxTokens:1024};save('model-config.json',config);
 const options={directory:PROFILE,provider:personalProvider(config),modelId:config.modelId,service};
 let p:any,backend:childProcess.ChildProcess|undefined,cancel:Promise<any>|undefined;const report:any={startedAt:new Date().toISOString(),directory:DIR,realOS:true,realModel:false,imActions:0,restarts:0};
 const unit=()=>({state:command('/usr/bin/systemctl',['--system','show',UNIT,'--property=ActiveState,SubState,MainPID,InvocationID']),count:fs.readFileSync('/var/lib/ruukoto39/test-service/count','utf8'),startsSha256:hash(fs.readFileSync('/var/lib/ruukoto39/test-service/starts.log'))});
 async function snapshot(name:string,ref:any){const list=await p.inspections.list();const doc=(await p.harness.snapshot(PersonalInspectionDoc,String(ref.taskId),ctx)).inspection;const work=(await p.harness.snapshot(PersonalWorkDoc,WORK,ctx));const value={at:new Date().toISOString(),list,inspection:doc,work,status:await p.work.status(work.ref),agents:await p.work.list(),pending:await p.harness.snapshot(PersonalPendingInspectionsDoc,ctx)};save(name,value);return value;}
 try{
  save('environment.json',{at:new Date().toISOString(),node:process.version,platform:process.platform,arch:process.arch,uid:process.getuid?.(),kernel:command('/usr/bin/uname',['-a']).trim(),load:fs.readFileSync('/proc/loadavg','utf8').trim(),helperSha256:command('/usr/bin/sudo',['-n','/usr/bin/sha256sum',HELPER]).split(' ')[0],policySha256:hash(fs.readFileSync(service.policyPath)),unit:unit()});
  p=await openPersonalHarness(options);assert.equal(await p.answer('授权本次隔离只读服务检查与取消/原身份停止核实。不得重启或改变服务。',SOURCE),'独立工作完成');await p.close();p=undefined;
  backend=childProcess.spawn(process.execPath,['--import',ROOT+'/node_modules/tsx/dist/loader.mjs',SELF,'backend'],{env:{PATH:'/usr/local/bin:/usr/bin:/bin',RUUKOTO39_INSPECTION_DIR:DIR},stdio:['ignore',fs.openSync(path.join(DIR,'backend.stdout.log'),'wx'),fs.openSync(path.join(DIR,'backend.stderr.log'),'wx')]});event('backend-start',{pid:backend.pid});
  await until(()=>fs.existsSync(READY),'gate before stdout',30000);const ready=JSON.parse(fs.readFileSync(READY,'utf8'));save('captured-gate.json',ready);
  await until(()=>{const v=observe();return v.original?.state==='T'&&v.original?.tracerPid===0&&v.members.filter((x:any)=>x.state!=='Z').every((x:any)=>x.pid===ready.claim.launcher.pid);},'only frozen original helper in group');
  save('frozen-before-kill.json',observe());assert.equal(events().filter(x=>x.kind==='helper-attempt'&&x.data.verb==='inspect-op').length,1);
  const exited=new Promise(resolve=>backend!.once('close',(code,signal)=>resolve({code,signal})));event('backend-kill',{pid:backend.pid});backend.kill('SIGKILL');report.backendExit=await exited;backend=undefined;assert.deepEqual(report.backendExit,{code:null,signal:'SIGKILL'});
  command('/usr/bin/python3',['-c',"import sqlite3,sys; s=sqlite3.connect('file:'+sys.argv[1]+'?mode=ro',uri=True); d=sqlite3.connect(sys.argv[2]);s.backup(d);assert d.execute('pragma quick_check').fetchone()[0]=='ok';d.close();s.close()",PROFILE+'/personal.sqlite',DIR+'/after-kill.sqlite']);save('orphan-after-kill.json',observe());
  audit(false);p=await openPersonalHarness(options);const work=(await p.harness.snapshot(PersonalWorkDoc,WORK,ctx)).ref;let pending=(await p.inspections.list())[0];assert.ok(pending);const ref={taskId:pending.taskId,admission:pending.admission};const restored=await snapshot('restored-pending.json',ref);assert.equal(restored.inspection.inspectionId,ready.inspectionId);assert.equal(restored.inspection.stopped,false);assert.equal(restored.status.stopVerified,false);assert.equal(restored.inspection.result,undefined);
  cancel=p.work.cancel(work);void cancel.catch(()=>undefined);await until(async()=> (await p.work.status(work)).cancelRequested,'cancel recorded');const stopping=await snapshot('canceled-pending.json',ref);assert.ok(stopping.agents.some((x:any)=>x.work?.taskId===work.taskId));
  const firstStop=await p.requestInspectionStop(ref);const firstSettled=await p.harness.waitForTask(firstStop,ctx);save('first-control-stop.json',firstSettled);assert.equal(firstSettled.state.outcome.result.stopped,false);assert.equal((await snapshot('stop-still-pending.json',ref)).inspection.stopped,false);
  assert.equal(await p.answer('独立聊天不受原检查停止未知影响。','independent-owner'),'独立工作完成');save('before-helper-end.json',observe());event('end-original-helper');save('original-pidfd-kill.json',killOriginal());await until(()=>observe().members.length===0,'original process group empty');
  const finalStop=await p.requestInspectionStop(ref);const finalSettled=await p.harness.waitForTask(finalStop,ctx);save('final-control-stop.json',finalSettled);assert.equal(finalSettled.state.outcome.result.stopped,true);assert.equal((await cancel).state.outcome.status,'aborted');cancel=undefined;
  const final=await snapshot('final-released.json',ref);assert.equal(final.inspection.inspectionId,ready.inspectionId);assert.equal(final.inspection.admission,ref.admission);assert.equal(final.inspection.stopped,true);assert.equal(final.list.length,0);assert.equal(final.agents.find((x:any)=>x.id===work.agentId)?.work,undefined);
  const history=(await (await p.harness.conversation(final.inspection.conversationId,ctx)).entries({order:'ascending'},256,undefined,ctx)).items;save('inspection-entries.json',history);save('helper-ended.json',observe());
  const callCount=model.calls.length;await p.close();p=undefined;p=await openPersonalHarness(options);assert.equal((await p.inspections.list()).length,0);await delay(80);assert.equal(model.calls.length,callCount);assert.equal(events().filter(x=>x.kind==='helper-attempt'&&x.data.verb==='inspect-op').length,1);assert.equal(intents,1);assert.deepEqual(unit(),JSON.parse(fs.readFileSync(path.join(DIR,'environment.json'),'utf8')).unit);report.calls=model.calls.length;report.inspectionId=ready.inspectionId;report.ref=ref;report.work=work;report.passed=true;
 }catch(error){report.failure={name:(error as Error).name,message:(error as Error).message,stack:(error as Error).stack};process.exitCode=1;}
 finally{
  if(backend&&backend.exitCode===null&&backend.signalCode===null){backend.kill('SIGKILL');await new Promise(resolve=>backend!.once('close',resolve));}
  if(fs.existsSync(READY)){try{save('cleanup-kill.json',killOriginal());}catch(error){report.cleanupFailure=String(error);process.exitCode=1;}}
  if(p){if(cancel){await Promise.race([cancel,delay(2000)]);cancel=undefined;}await p.close();}
  save('model-requests.json',model.calls);await model.close();report.finishedAt=new Date().toISOString();report.helperAttempts=events().filter(x=>x.kind==='helper-attempt');report.closed=true;save('result.json',report);process.stdout.write(JSON.stringify(report)+'\n');
 }
}
