import * as fs from 'node:fs';
import assert from 'node:assert/strict';
process.umask(0o077);
const base='/tmp/ruukoto39-napcat-runtime-diagnostic';
const credentials='/private/tmp/ruukoto-human-fxhh5b4x/credentials/';
const token=fs.readFileSync(credentials+'napcat.token','utf8').trim();
const secrets=[token,fs.readFileSync(credentials+'telegram.token','utf8').trim(),fs.readFileSync(credentials+'tavily.token','utf8').trim(),JSON.parse(fs.readFileSync(credentials+'model-source.json','utf8')).providers.deepseek.apiKey];assert.ok(secrets.every(x=>typeof x==='string'&&x));
const safe={action:'nc_get_packet_status',startedAt:new Date().toISOString(),deadlineMs:12000,retries:0,outboundActions:[],opened:false,matchedResponse:false,qqPacketOperationsRequested:0,mediaHttpRequests:0,getRkeyActions:0,imSends:0,modelRequests:0,rawResponsePersisted:false};
let ws,done=false,timer;const echo='39-packet-status-once-'+Date.now();
const finish=result=>{if(done)return;done=true;clearTimeout(timer);safe.result=result;safe.endedAt=new Date().toISOString();safe.elapsedMs=Date.parse(safe.endedAt)-Date.parse(safe.startedAt);const s=JSON.stringify(safe,null,2)+'\n';assert.ok(secrets.every(x=>!s.includes(x)));fs.writeFileSync(base+'/packet-status-once.safe.json',s,{mode:0o600,flag:'wx'});if(ws&&ws.readyState<2)ws.close();process.stdout.write(s);};
timer=setTimeout(()=>finish('timeout'),12000);
try{
 ws=new WebSocket('ws://127.0.0.1:3001',{headers:{Authorization:`Bearer ${token}`}});
 ws.addEventListener('open',()=>{if(done)return;safe.opened=true;safe.sentAt=new Date().toISOString();safe.outboundActions.push('nc_get_packet_status');ws.send(JSON.stringify({action:'nc_get_packet_status',params:{},echo}));});
 ws.addEventListener('message',async e=>{if(done)return;let v;try{v=JSON.parse(typeof e.data==='string'?e.data:await e.data.text());}catch{return;}if(v.echo!==echo)return;safe.matchedResponse=true;safe.status=typeof v.status==='string'?v.status:null;safe.retcode=typeof v.retcode==='number'?v.retcode:null;safe.responseKeys=Object.keys(v).sort();
  let text=[v.message,v.wording].filter(x=>typeof x==='string').join('\n');
  for(const secret of secrets){for(const variant of [secret,JSON.stringify(secret).slice(1,-1),encodeURIComponent(secret),Buffer.from(secret).toString('base64'),Buffer.from(secret).toString('base64url')])text=text.split(variant).join('<redacted-credential>');}
  text=text.replace(/https?:\/\/[^\s<>"'`]+/g,'<redacted-url>').replace(/([?&]rkey=|(?:private_rkey|group_rkey|rkey)\s*[:=]\s*)[^\s,;<>]+/gi,'$1<redacted-rkey>');
  safe.errorCategories=[];
  const classifications=[['unsupported_qq_version_arch',/不支持当前QQ版本架构/],['packet_backend_disabled',/已禁用PacketBackend/],['native_client_initialization_failed',/NativePacketClient 初始化失败/],['initial_packet_fetch_rkey_failed',/测试Packet状态异常/],['native_permission_error',/Permission denied|Operation not permitted|permission denied|task_for_pid|KERN_PROTECTION_FAILURE/],['timeout',/ETIMEDOUT|timed?\s*out|超时/],['native_fetch_rkey_disabled',/Native.FetchRkey 已被禁用/]];
  for(const [name,pattern] of classifications)if(pattern.test(text))safe.errorCategories.push(name);
  const version=text.match(/不支持当前QQ版本架构[：:]\s*([0-9]+\.[0-9]+\.[0-9]+(?:[-.][0-9]+)?)-(arm64|x64|ia32)\b/);
  if(version)safe.unsupportedRuntime={qqVersion:version[1],arch:version[2]};
  safe.packetStatusInferred=v.status==='ok'&&v.retcode===0?true:safe.errorCategories.length>0?false:null;
  safe.unclassifiedFailure=v.status!=='ok'&&safe.errorCategories.length===0;finish('response');
 });
 ws.addEventListener('error',e=>{safe.socketErrorType=e.type;finish('socket_error');});
 ws.addEventListener('close',e=>{if(!done){safe.closeCode=e.code;finish('closed_before_response');}});
}catch(e){safe.localErrorName=e.name;finish('local_error');}
