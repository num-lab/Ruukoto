import * as fs from 'node:fs';
import assert from 'node:assert/strict';
process.umask(0o077);
const base='/tmp/ruukoto39-napcat-runtime-diagnostic';fs.mkdirSync(base+'/private',{mode:0o700});
const token=fs.readFileSync('/private/tmp/ruukoto-human-fxhh5b4x/credentials/napcat.token','utf8').trim();assert.ok(token);
const safe={action:'get_version_info',startedAt:new Date().toISOString(),deadlineMs:12000,retries:0,outboundActions:[],opened:false,matchedResponse:false,mediaHttpRequests:0,getRkeyActions:0,imSends:0,modelRequests:0,copiedVersion:'4.18.30'};
let ws,done=false,timer;const echo='39-version-once-'+Date.now();
const finish=result=>{if(done)return;done=true;clearTimeout(timer);safe.result=result;safe.endedAt=new Date().toISOString();safe.elapsedMs=Date.parse(safe.endedAt)-Date.parse(safe.startedAt);const s=JSON.stringify(safe,null,2)+'\n';assert.ok(!s.includes(token));fs.writeFileSync(base+'/version-once.safe.json',s,{mode:0o600,flag:'wx'});if(ws&&ws.readyState<2)ws.close();process.stdout.write(s);};
timer=setTimeout(()=>finish('timeout'),12000);
try{
 ws=new WebSocket('ws://127.0.0.1:3001',{headers:{Authorization:`Bearer ${token}`}});
 ws.addEventListener('open',()=>{if(done)return;safe.opened=true;safe.sentAt=new Date().toISOString();safe.outboundActions.push('get_version_info');ws.send(JSON.stringify({action:'get_version_info',params:{},echo}));});
 ws.addEventListener('message',async e=>{if(done)return;let v;try{v=JSON.parse(typeof e.data==='string'?e.data:await e.data.text());}catch{return;}if(v.echo!==echo)return;fs.writeFileSync(base+'/private/version-response.json',JSON.stringify(v,null,2)+'\n',{mode:0o600,flag:'wx'});safe.matchedResponse=true;safe.status=typeof v.status==='string'?v.status:null;safe.retcode=typeof v.retcode==='number'?v.retcode:null;safe.dataKeys=v.data&&typeof v.data==='object'?Object.keys(v.data).sort():[];safe.version={};for(const k of ['app_name','app_version','protocol_version','runtime_version','runtime_os','runtime_arch']){if(typeof v.data?.[k]==='string'&&/^[a-zA-Z0-9_. /+()-]{1,100}$/.test(v.data[k]))safe.version[k]=v.data[k];}safe.versionStringMatchesCopy=safe.version.app_version===safe.copiedVersion;finish('response');});
 ws.addEventListener('error',e=>{safe.socketErrorType=e.type;finish('socket_error');});
 ws.addEventListener('close',e=>{if(!done){safe.closeCode=e.code;finish('closed_before_response');}});
}catch(e){safe.localErrorName=e.name;finish('local_error');}
