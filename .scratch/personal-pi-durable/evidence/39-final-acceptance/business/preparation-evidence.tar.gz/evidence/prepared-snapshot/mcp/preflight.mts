import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { randomUUID, createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { DatabaseSync } from 'node:sqlite';
import { connectMcpEndpoint } from '/home/ubuntu/.local/ruukoto39/current/packages/agent/src/mcp/transport.ts';
const directory = '/home/ubuntu/.local/ruukoto39/test-business/mcp';
const endpoint = 'https://127.0.0.1:19439/mcp';
const token = fs.readFileSync(path.join(directory, 'private/bearer-token'), 'utf8').trim();
const result: Record<string, unknown> = { endpoint, ca: process.env.NODE_EXTRA_CA_CERTS, passed: false };
const db = new DatabaseSync(path.join(directory, 'data/records.sqlite'), { readOnly: true });
const rowCount = () => Number(db.prepare('SELECT count(*) AS count FROM records').get()!.count);
let connection: Awaited<ReturnType<typeof connectMcpEndpoint>> | undefined;
try {
  const noCa = JSON.parse(execFileSync(process.execPath, ['--input-type=module', '--eval', `try { await fetch(${JSON.stringify(endpoint)}); process.stdout.write(JSON.stringify({ rejected: false })); } catch (error) { process.stdout.write(JSON.stringify({ rejected: true, code: error.cause?.code })); }`], { encoding: 'utf8', env: { PATH: '/usr/bin:/bin' } }));
  assert.equal(noCa.rejected, true); assert.match(noCa.code, /CERT|VERIFY|ISSUER/);
  result.withoutCa = noCa;
  const before = rowCount();
  for (const authorization of [undefined, 'Bearer wrong-token']) {
    const response = await fetch(endpoint, { method: 'POST', headers: { 'content-type': 'application/json', ...(authorization ? { authorization } : {}) }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'tools/call', params: { name: 'record_add', arguments: { marker: 'UNAUTHORIZED39' } } }) });
    assert.equal(response.status, 401);
  }
  assert.equal(rowCount(), before); result.unauthorized = { missing: 401, wrong: 401, countUnchanged: true };
  connection = await connectMcpEndpoint({ serviceId: 'business39', endpoint }, { resolveToken: async () => token });
  const tools = await connection.listTools(); assert.deepEqual(tools.map(t => t.name).sort(), ['record_add', 'records_list']); result.discoveredTools = tools;
  const add = tools.find(t => t.name === 'record_add')!, list = tools.find(t => t.name === 'records_list')!;
  const marker = 'PREFLIGHT39_' + randomUUID().replaceAll('-', '');
  const write = await connection.callTool(add, { marker }); assert.ok(!write.isError); assert.equal(rowCount(), before + 1);
  const read = await connection.callTool(list, { marker }); assert.ok(!read.isError);
  const text = read.content.find(part => part.type === 'text'); assert.ok(text?.type === 'text'); const payload = JSON.parse(text.text); assert.equal(payload.rows.length, 1); assert.equal(payload.rows[0].marker, marker);
  assert.equal(Number(db.prepare('SELECT count(*) AS count FROM records WHERE marker=?').get(marker)!.count), 1);
  result.authenticated = { serverInfo: connection.serverInfo, protocolVersion: connection.protocolVersion, marker, before, after: rowCount(), markerCount: 1, write, read }; result.passed = true;
} finally {
  await connection?.close(); db.close();
  result.credentialDigest = createHash('sha256').update(fs.readFileSync(path.join(directory, 'private/bearer-token'))).digest('hex');
  const serialized = JSON.stringify(result, null, 2) + '\n'; assert.ok(!serialized.includes(token));
  fs.writeFileSync(path.join(directory, 'preflight.json'), serialized, { mode: 0o600 });
  process.stdout.write(JSON.stringify({ passed: result.passed, endpoint, database: path.join(directory, 'data/records.sqlite') }) + '\n');
}
