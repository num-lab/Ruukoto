import * as fs from 'node:fs';
import * as path from 'node:path';
import * as https from 'node:https';
import { fileURLToPath } from 'node:url';
import { timingSafeEqual } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { McpServer, createMcpHandler } from '@modelcontextprotocol/server';
import { toNodeHandler, localhostHostValidation, localhostOriginValidation } from '@modelcontextprotocol/node';
import * as z from 'zod/v4';
process.umask(0o077);
const directory = path.dirname(fileURLToPath(import.meta.url));
const credential = fs.readFileSync(path.join(directory, 'private/bearer-token'), 'utf8').trim();
const expected = Buffer.from(`Bearer ${credential}`);
const database = new DatabaseSync(path.join(directory, 'data/records.sqlite'));
database.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; CREATE TABLE IF NOT EXISTS records (id INTEGER PRIMARY KEY, marker TEXT NOT NULL, created_at TEXT NOT NULL);');
const write = database.prepare('INSERT INTO records (marker, created_at) VALUES (?, ?) RETURNING id, marker, created_at');
const read = database.prepare('SELECT id, marker, created_at FROM records ORDER BY id LIMIT 100');
const readMarker = database.prepare('SELECT id, marker, created_at FROM records WHERE marker = ? ORDER BY id LIMIT 100');
const count = database.prepare('SELECT count(*) AS count FROM records');
const log = event => process.stdout.write(JSON.stringify({ at: new Date().toISOString(), ...event }) + '\n');
const handler = createMcpHandler(() => {
  const server = new McpServer({ name: 'ruukoto39-isolated-business', version: '1.0.0' });
  server.registerTool('records_list', { description: '读取专用验收记录，marker省略时列出至多100条；只读，不修改业务。', inputSchema: z.object({ marker: z.string().min(1).max(128).optional() }), annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false } }, async ({ marker }) => {
    const rows = marker ? readMarker.all(marker) : read.all();
    log({ event: 'records_list', filter: marker ?? null, returned: rows.length });
    return { content: [{ type: 'text', text: JSON.stringify({ rows, total: count.get().count }) }] };
  });
  server.registerTool('record_add', { description: '向专用SQLite验收库追加一条marker记录；一次调用只插入一行，重复调用会新增记录。', inputSchema: z.object({ marker: z.string().min(1).max(128) }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false } }, async ({ marker }) => {
    const row = write.get(marker, new Date().toISOString());
    log({ event: 'record_add', rowId: row.id, marker, count: count.get().count });
    return { content: [{ type: 'text', text: JSON.stringify({ inserted: row, total: count.get().count }) }] };
  });
  return server;
}, { responseMode: 'json' });
const nodeHandler = toNodeHandler(handler);
const validateHost = localhostHostValidation();
const validateOrigin = localhostOriginValidation();
const server = https.createServer({ key: fs.readFileSync(path.join(directory, 'tls/server.key')), cert: fs.readFileSync(path.join(directory, 'tls/server.crt')) }, (request, response) => {
  const actual = Buffer.from(request.headers.authorization ?? '');
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
    log({ event: 'auth_rejected', method: request.method });
    response.writeHead(401, { 'content-type': 'application/json', 'www-authenticate': 'Bearer realm="ruukoto39"' });
    response.end(JSON.stringify({ error: 'unauthorized' })); return;
  }
  if (request.url !== '/mcp') { response.writeHead(404); response.end(); return; }
  if (!validateHost(request, response) || !validateOrigin(request, response)) return;
  void Promise.resolve().then(() => nodeHandler(request, response)).catch(error => { log({ event: 'handler_error', code: error?.code ?? 'unknown' }); if (!response.headersSent) response.writeHead(500); response.end(); });
});
server.listen(19439, '127.0.0.1', () => {
  fs.writeFileSync(path.join(directory, 'ready.json'), JSON.stringify({ pid: process.pid, address: server.address(), endpoint: 'https://127.0.0.1:19439/mcp' }) + '\n', { mode: 0o600 });
  log({ event: 'listening', endpoint: 'https://127.0.0.1:19439/mcp', pid: process.pid });
});
server.on('error', error => { log({ event: 'server_error', code: error.code }); process.exitCode = 1; });
let stopping = false;
const stop = async () => {
  if (stopping) return; stopping = true;
  await handler.close();
  server.closeAllConnections();
  await new Promise(resolve => server.close(resolve));
  database.close();
  log({ event: 'stopped' });
};
process.once('SIGTERM', () => { void stop().catch(() => { process.exitCode = 1; }); });
process.once('SIGINT', () => { void stop().catch(() => { process.exitCode = 1; }); });
