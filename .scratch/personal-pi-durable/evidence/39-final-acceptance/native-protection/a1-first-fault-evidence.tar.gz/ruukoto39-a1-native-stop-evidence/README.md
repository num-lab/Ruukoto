# A1停止首故障实验交付

macOS原38单例真实1/1、exit0、未复现；辅助raw tee首轮存在规范路径匹配缺口，按原用例断言范围报告。Linux首轮原122真实0/1，但共享依赖overlay在受限namespace内不可见，故降为安装布局混杂；独立可见性对照已证明这一前提错误。自有副本实字节复制既有依赖后，唯一合格原122为1/1、exit0、105.719秒、无跳过，无停止失败诊断。两轮原日志与源指纹分开保留。

原17 macOS、原38 identity_unavailable和原17 Linux local PGID失败仍未精确归因；早期not-unique解释保留。没有放宽身份/停止/占用判据、抬预算、重放旧任务或操作live/模型/IM/服务；根工作区未改。诊断patch是实验仪器，未建议直接合入产品。

Linux首轮core.db与main.db是14:46:41Z的只读一致备份，保留verify_4 stopVerified=false与两条占用。原fixture由未改finally删除，部分原copytree先报Error，无法恢复未复制的资料；未手工stop/recheck原scope。原始临时凭据和未筛选部分目录不在本交付；选定首轮证据按临时owner token变体扫描0匹配。更细边界、重现命令、源SHA及副本依赖模式见两平台README与manifest。

未来只应在首次真实失败时根据首故障字段决定下一检查，不能用窄绿或本轮安装混杂关闭旧归因，也不能把本轮当宽组合验收。
