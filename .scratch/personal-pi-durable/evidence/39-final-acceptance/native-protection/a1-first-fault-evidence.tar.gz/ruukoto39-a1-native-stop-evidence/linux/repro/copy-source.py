from pathlib import Path
import shutil,json,hashlib,datetime,os
source=Path('/home/ubuntu/.local/ruukoto39/current')
target=Path('/home/ubuntu/.local/ruukoto39/native-stop-diag-20261018')
assert not target.exists()
shutil.copytree(source,target,symlinks=True,ignore=shutil.ignore_patterns('.git','node_modules','dist','.DS_Store'))
shared=[]
for dependency_root in [source/'node_modules',source/'apps/ruukoto/node_modules']:
    destination=target/dependency_root.relative_to(source)
    destination.mkdir()
    for entry in dependency_root.iterdir():
        if entry.name=='@ruukoto':
            scope=destination/entry.name
            scope.mkdir()
            for item in entry.iterdir():
                resolved=item.resolve()
                assert resolved.is_relative_to(source)
                (scope/item.name).symlink_to(target/resolved.relative_to(source),target_is_directory=True)
        else:
            (destination/entry.name).symlink_to(entry,target_is_directory=entry.is_dir())
            shared.append(str(entry))
files=['packages/agent/src/managed-processes.ts','packages/agent/src/tool-worker/host.ts','packages/agent/src/execution/native.ts','packages/agent/src/execution/approved-ops.ts','packages/agent/src/execution/native-macos-supervisor.c','test/122-workflow-code-acceptance.test.ts','package-lock.json','worker/worker.mjs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(source),'copy':str(target),'sourceFiles':{f:sha(source/f) for f in files},'copyFilesBeforeDiagnostic':{f:sha(target/f) for f in files},'nativeBatchProtectionPresent':'assertGrantsNotProtected(roots, [protectedReal])' in (target/files[2]).read_text(),'dependencyMode':'read-only shared existing installed dependencies via task-owned symlink overlay; workspace symlinks point to this diagnostic copy; no independent setup/install','sharedDependencyEntryCount':len(shared),'node':os.popen('/usr/local/bin/node --version').read().strip()}
assert meta['sourceFiles']==meta['copyFilesBeforeDiagnostic']
assert meta['nativeBatchProtectionPresent']
(target/'diagnostic-copy-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(meta,ensure_ascii=False))
