from pathlib import Path
import os,subprocess,time,datetime,json,hashlib,shutil,threading,sqlite3
root=Path('/home/ubuntu/.local/ruukoto39/native-stop-diag-20261018')
output=Path('/tmp/ruukoto39-linux-stop-diag-result')
output.mkdir(exist_ok=False)
temp=Path('/tmp/r39-stopdiag-20261018')
temp.mkdir(exist_ok=False)
files=['packages/agent/src/managed-processes.ts','packages/agent/src/tool-worker/host.ts','packages/agent/src/execution/native.ts','packages/agent/src/execution/approved-ops.ts','test/122-workflow-code-acceptance.test.ts','worker/worker.mjs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'diagnostic-copy-manifest.json').read_text())
manifest.update({'diagnosticFiles':{f:sha(root/f) for f in files},'platform':dict(zip(['sysname','nodename','release','version','machine'],os.uname())),'resolvedWorkspaceAgent':str((root/'node_modules/@ruukoto/agent').resolve()),'hypotheses':['command group query unavailable or still alive','worker exit precedes stopped output','earlier command cleanup false cached before shutdown'],'testSourceUnchanged':sha(root/files[4])==manifest['sourceFiles'][files[4]],'readyToRunAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
assert manifest['testSourceUnchanged']
assert manifest['resolvedWorkspaceAgent']==str(root/'packages/agent')
command=['/usr/local/bin/node','--import','tsx','--test','--test-concurrency=1','test/122-workflow-code-acceptance.test.ts']
env=os.environ.copy();env['RUN_MODEL_CHECK']='0';env['TMPDIR']=str(temp);env['PATH']='/usr/local/bin:'+env.get('PATH','/usr/bin:/bin')
started=time.monotonic();proc=subprocess.Popen(command,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
manifest.update({'command':command,'pid':proc.pid,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'temporaryFixtureParent':str(temp)})
(output/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
snapshots=[];snapshot_thread=None;faults=[]
def preserve():
    for fixture in temp.glob('ruukoto-it-workflow-code-batch-*'):
        record={'fixture':str(fixture),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'read-only copy after observed diagnostic failure; raw copy is non-atomic, SQLite backup recorded separately'}
        try:
            destination=output/'first-failure-scene'/fixture.name
            shutil.copytree(fixture,destination,symlinks=True)
            for db in fixture.rglob('*.db'):
                target=destination/(str(db.relative_to(fixture))+'.consistent-backup')
                source=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True,timeout=1)
                saved=sqlite3.connect(target)
                source.backup(saved)
                saved.close();source.close()
            record['copied']=True
        except Exception as exc:
            record['errorType']=type(exc).__name__
        snapshots.append(record)
with (output/'test.log').open('w') as log:
    for line in proc.stdout:
        log.write(line);log.flush();print(line,end='',flush=True)
        if 'stop_diagnostic ' in line:
            faults.append(line.rstrip())
            if snapshot_thread is None:
                snapshot_thread=threading.Thread(target=preserve);snapshot_thread.start()
exitcode=proc.wait()
if snapshot_thread is not None:snapshot_thread.join()
result={'exitCode':exitcode,'wallSeconds':round(time.monotonic()-started,3),'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'diagnosticLineCount':len(faults),'failureSnapshots':snapshots,'fixtureResiduals':[str(p) for p in temp.iterdir()],'testPidStillPresent':Path('/proc/'+str(proc.pid)).exists(),'currentSourceAfter':{f:sha(Path(manifest['source'])/f) for f in files if f!='worker/worker.mjs'}}
(output/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('DIAGNOSTIC_RESULT '+json.dumps(result,ensure_ascii=False),flush=True)
raise SystemExit(exitcode)
