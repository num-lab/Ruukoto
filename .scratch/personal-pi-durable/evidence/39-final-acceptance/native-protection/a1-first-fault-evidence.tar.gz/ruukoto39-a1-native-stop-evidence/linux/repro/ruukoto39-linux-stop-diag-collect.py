from pathlib import Path
import os,stat,json,datetime,hashlib,shutil,re
root=Path('/tmp/ruukoto39-linux-stop-diag-result')
source=root/'first-failure-scene/ruukoto-it-workflow-code-batch-HGStGq'
output=root/'ordinary-recovery'
output.mkdir(exist_ok=False)
counts={'regularFilesCopied':0,'directoriesCopied':0,'specialFilesSkipped':0,'credentialFilesExcluded':0,'readErrors':0}
excluded={'owner.token','auth.json','models.json'}
for current,dirs,files in os.walk(source,followlinks=False):
    relative=Path(current).relative_to(source)
    (output/relative).mkdir(exist_ok=True)
    counts['directoriesCopied']+=1
    for name in list(dirs):
        if (Path(current)/name).is_symlink():dirs.remove(name);counts['specialFilesSkipped']+=1
    for name in files:
        path=Path(current)/name
        if name in excluded:counts['credentialFilesExcluded']+=1;continue
        try:
            if not stat.S_ISREG(path.lstat().st_mode):counts['specialFilesSkipped']+=1;continue
            shutil.copy2(path,output/relative/name,follow_symlinks=False);counts['regularFilesCopied']+=1
        except OSError:counts['readErrors']+=1
info={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceIsPartialSavedCopy':True,'originalFixtureDeletedByUnchangedFinally':not Path('/tmp/r39-stopdiag-20261018/ruukoto-it-workflow-code-batch-HGStGq').exists(),'originalRawCopyErrorRetainedInResult':'Error; original exception detail was not saved, cannot assert exact skipped special file','recoveryScope':'only ordinary files/directories present in partial copy; cannot reconstruct files absent there; two later consistent SQLite backups are authoritative snapshots at their manifest times','counts':counts}
(root/'ordinary-recovery-manifest.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n')
meta=json.loads((root/'readonly-scope-and-dependency-analysis.json').read_text())
worker=Path('/home/ubuntu/.local/ruukoto39/native-stop-diag-20261018/worker/worker.mjs')
meta['workerExternalImportSites']=[{'line':n,'text':line.strip()} for n,line in enumerate(worker.read_text().splitlines(),1) if '@earendil-works' in line]
(root/'readonly-scope-and-dependency-analysis.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(info,ensure_ascii=False))
