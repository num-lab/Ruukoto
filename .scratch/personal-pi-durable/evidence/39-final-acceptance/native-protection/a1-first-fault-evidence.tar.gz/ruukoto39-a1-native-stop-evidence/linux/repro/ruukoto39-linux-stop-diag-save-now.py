from pathlib import Path
import json,sqlite3,datetime,hashlib
root=Path('/tmp/r39-stopdiag-20261018/ruukoto-it-workflow-code-batch-HGStGq')
output=Path('/tmp/ruukoto39-linux-stop-diag-result/consistent-db')
output.mkdir(exist_ok=False)
records=[]
for db in [root/'data/ruukoto.db',root/'data/agent-data/main.db']:
    dest=output/('core.db' if db.name=='ruukoto.db' else 'main.db')
    source=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True,timeout=2)
    saved=sqlite3.connect(dest);source.backup(saved);saved.close();source.close()
    records.append({'source':str(db),'saved':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
(output/'manifest.json').write_text(json.dumps(records,indent=2)+'\n')
core=sqlite3.connect(output/'core.db');core.row_factory=sqlite3.Row
names=[r[0] for r in core.execute("SELECT name FROM sqlite_master WHERE type='table'")]
for name in ['tasks','workflow_executions','workflow_steps','workflow_runs']:
    if name not in names:continue
    cols=[r[1] for r in core.execute('PRAGMA table_info('+name+')')]
    selected=[c for c in ['id','task_id','step_id','status','error_message','error','reason','stop_verified','script_stop_verified','kind','execution_identity'] if c in cols]
    rows=[dict(r) for r in core.execute('SELECT '+','.join(selected)+' FROM '+name)]
    (output/(name+'-selected.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'backups':records,'selectedTableFiles':[p.name for p in output.glob('*-selected.json')]}))
