import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { prepareNativeLaunch } from "./packages/agent/src/execution/native.ts";
import { linuxNativeArgs } from "./packages/agent/src/execution/native-linux.ts";

const root = path.dirname(fileURLToPath(import.meta.url));
const output = "/tmp/ruukoto39-linux-stop-diag-result";
const phase = process.argv[2];
if (!["overlay", "copied"].includes(phase)) throw new Error("invalid phase");
const workspace = fs.mkdtempSync("/tmp/r39-visible-");
const identity = fs.statSync(workspace);
const input = await prepareNativeLaunch({ workerPath: path.join(root, "worker/worker.mjs"), protectedRoots: [root] }, {
  taskId: `diagnostic_visibility_${phase}`, mode: "confirm", workspace, workspaceIdentity: { dev: identity.dev, ino: identity.ino }, grantedPaths: [],
});
const probe = path.join(root, `worker/diagnostic-visibility-${phase}.mjs`);
fs.writeFileSync(probe, `import fs from 'node:fs';
const packagePath=${JSON.stringify(path.join(root, "node_modules/@earendil-works/pi-coding-agent/package.json"))};
const result={packageVisible:fs.existsSync(packagePath)};
try{result.packageRealpathVisible=Boolean(fs.realpathSync(packagePath));}catch(error){result.realpathErrorCode=error.code;}
if(${JSON.stringify(phase)}==='copied'){
try{const module=await import('@earendil-works/pi-coding-agent');result.staticClosureLoaded=['createBashToolDefinition','createEditToolDefinition','createReadToolDefinition','createWriteToolDefinition','generateUnifiedPatch','getShellConfig'].every(key=>typeof module[key]==='function');}catch(error){result.staticClosureLoaded=false;result.importErrorCode=error.code;}
}
process.stdout.write(JSON.stringify(result)+'\\n');
`, { flag: "wx" });
const original = linuxNativeArgs(input);
const args = original.slice(0, original.lastIndexOf("--seccomp"));
const mountPosition = args.indexOf("--remount-ro");
args.splice(mountPosition, 0, "--ro-bind", probe, probe);
args.push(input.nodePath, probe);
const run = async (extraTarget: boolean): Promise<Record<string, unknown>> => {
  const actual = [...args];
  if (extraTarget) actual.splice(actual.indexOf("--remount-ro"), 0, "--ro-bind", "/home/ubuntu/.local/ruukoto39/current/node_modules", "/home/ubuntu/.local/ruukoto39/current/node_modules");
  const child = spawn("/usr/bin/bwrap", actual, { env: { PATH: "/usr/bin:/bin", LANG: "C.UTF-8" }, stdio: ["ignore", "pipe", "pipe"] });
  let stdout = "", stderr = "", timedOut = false;
  child.stdout.on("data", chunk => { stdout += String(chunk); });
  child.stderr.on("data", chunk => { stderr += String(chunk); });
  const timer = setTimeout(() => { timedOut = true; child.kill("SIGKILL"); }, 10_000);
  const ended = await new Promise<{ code: number | null; signal: string | null }>((resolve, reject) => { child.once("close", (code, signal) => resolve({ code, signal })); child.once("error", reject); });
  clearTimeout(timer);
  return { extraTarget, pid: child.pid, ...ended, timedOut, stdout: stdout.trim(), stderr: stderr.trim() };
};
const results = [await run(false)];
if (phase === "overlay") results.push(await run(true));
const result = { phase, at: new Date().toISOString(), scope: "fresh filesystem-only unshare namespace; no systemd unit, worker tool, model or live state; seccomp omitted for trusted fixed fs/module probe", runtimeReadRoots: input.runtimeReadRoots, results };
fs.writeFileSync(path.join(output, `visibility-${phase}.json`), `${JSON.stringify(result, null, 2)}\n`);
fs.rmSync(workspace, { recursive: true, force: true });
fs.rmSync(input.tempDir, { recursive: true, force: true });
process.stdout.write(`${JSON.stringify(result)}\n`);
