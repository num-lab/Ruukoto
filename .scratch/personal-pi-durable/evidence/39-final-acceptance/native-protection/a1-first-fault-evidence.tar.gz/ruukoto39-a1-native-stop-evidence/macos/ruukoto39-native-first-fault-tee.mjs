import fs from 'node:fs';
import path from 'node:path';
import childProcess from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
const helper = '/tmp/ruukoto39-native-batch/worker/native-macos-supervisor';
const helperAliases = new Set([helper, fs.realpathSync(helper)]);
const original = childProcess.spawn;
const events = `/tmp/ruukoto39-native-first-fault-tee-${process.pid}.jsonl`;
function event(value) { fs.appendFileSync(events, JSON.stringify({ at: new Date().toISOString(), observerPid: process.pid, ...value }) + '\n'); }
childProcess.spawn = function(file, args, options) {
  const child = original.call(childProcess, file, args, options);
  if (!helperAliases.has(path.resolve(String(file)))) return child;
  event({ kind: 'helper_spawn', childPid: child.pid });
  let captured = 0;
  const output = `/tmp/ruukoto39-native-first-fault-helper-${child.pid}.stderr`;
  child.stderr?.on('data', value => {
    const remaining = 16384 - captured;
    if (remaining > 0) { const part = value.subarray(0, remaining); fs.appendFileSync(output, part); captured += part.length; }
  });
  child.once('close', (code, signal) => event({ kind: 'helper_close', childPid: child.pid, code, signal, stderrBytes: captured, stderrPath: output, stderrExists: fs.existsSync(output) }));
  return child;
};
syncBuiltinESMExports();
