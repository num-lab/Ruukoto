import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as path from "node:path";
import * as http from "node:http";
import { once } from "node:events";
import { randomUUID, createHash } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { BACKGROUND_CONTEXT as context } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/node_modules/@earendil-works/chord/dist/context/index.js";
import { openPersonalHarness, type PersonalHarness } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-harness.ts";
import { parsePersonalModel, personalProvider } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-model.ts";
import { PersonalWorkDoc, PersonalAgentsDoc, personalWorkResult } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-work.ts";
import { personalReportResult } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-report.ts";
import { PersonalDelegationDoc } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-delegation.ts";
import { PersonalTelegramReceiptDoc } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-telegram-records.ts";
import { lockPersonalProfile, type PersonalProfileLock } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-profile.ts";

assert.equal(process.env.RUN_MODEL_CHECK, "1");
const root = "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable";
const prior = JSON.parse(fs.readFileSync("/tmp/ruukoto39-real-report-2026-10-18T130116-027Z/result.json", "utf8"));
const directory = prior.directory;
assert.equal(directory, "/tmp/ruukoto39-real-report-2026-10-18T130116-027Z/profile");
const output = fs.mkdtempSync("/tmp/ruukoto39-offset-real-"); fs.chmodSync(output, 0o700);
fs.mkdirSync(path.join(output, "requests"), { mode: 0o700 });
fs.copyFileSync(import.meta.filename, path.join(output, "executed-probe.mts"));
const sqlite = path.join(directory, "personal.sqlite");
const marker = `OFFSET39_${randomUUID().replaceAll("-", "")}`, end = `END39_${randomUUID().replaceAll("-", "")}`;
const result: any = { output, directory, realModel: true, realIm: false, model: "deepseek-flash", maxTokens: 4096, modelHttpBudget: 12, passed: false, marker, end, stages: [], findings: [], sourceHashes: Object.fromEntries(["personal-work.ts", "personal-report.ts", "personal-work-tools.ts", "personal-model.ts"].map(name => [name, createHash("sha256").update(fs.readFileSync(path.join(root, "apps/ruukoto/src", name))).digest("hex")])) };
const save = (name: string, value: unknown) => fs.writeFileSync(path.join(output, name), JSON.stringify(value, null, 2) + "\n", { mode: 0o600 });
let personal: PersonalHarness | undefined, bot: http.Server | undefined, initialLock: PersonalProfileLock | undefined, count = 0, credential = "", beforeMaxEntry = 0;
const originalFetch = globalThis.fetch, sends: any[] = [];
const credentialName = "PERSONAL_FINAL_REPORT_MODEL_KEY";
let fakeCredentialName = "";
const bounded = async <T>(name: string, op: Promise<T>): Promise<T> => {
  const stage: any = { name, startedAt: new Date().toISOString(), status: "running" }; result.stages.push(stage); save("progress.json", result);
  process.stdout.write(JSON.stringify({ stage: name, state: "started", modelHttp: count }) + "\n");
  let timer: ReturnType<typeof setTimeout> | undefined;
  try { const value = await Promise.race([op, new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error(`step_timeout:${name}`)), 180000); })]); stage.status = "passed"; return value; }
  catch (error) { stage.status = "failed"; throw error; }
  finally { clearTimeout(timer); stage.finishedAt = new Date().toISOString(); save("progress.json", result); }
};
try {
  const source = JSON.parse(fs.readFileSync("/private/tmp/ruukoto-human-fxhh5b4x/credentials/model-source.json", "utf8"));
  const selected = Object.entries(source.providers).flatMap(([id, p]: [string, any]) => p.models.filter((m: any) => `${id}/${m.id}` === "deepseek/deepseek-flash").map((model: any) => ({ provider: p, model })));
  assert.equal(selected.length, 1); const { provider, model } = selected[0];
  assert.ok(provider.apiKey && !provider.apiKey.startsWith("!") && !Object.keys(provider.headers ?? {}).length);
  credential = process.env[provider.apiKey] ?? provider.apiKey; assert.ok(credential.length > 16);
  assert.equal(process.env[credentialName], undefined); process.env[credentialName] = credential;
  const config = parsePersonalModel({ api: model.api ?? provider.api, baseUrl: provider.baseUrl, modelId: model.id, apiKeyEnv: credentialName, contextWindow: model.contextWindow ?? 128000, maxTokens: result.maxTokens });
  const modelOrigin = new URL(config.baseUrl).origin;
  globalThis.fetch = async (input, init) => {
    const url = new URL(typeof input === "string" ? input : input instanceof URL ? input.href : input.url);
    assert.ok(url.origin === modelOrigin || url.hostname === "127.0.0.1", "external_origin_rejected");
    if (url.origin === modelOrigin) {
      if (count === 12) { result.httpBudgetBlocked = true; throw new Error("model_http_budget_exhausted"); }
      count++;
      const body = typeof init?.body === "string" ? init.body : input instanceof Request ? await input.clone().text() : undefined;
      assert.ok(body); assert.ok(!body.includes(credential));
      save(`requests/request-${String(count).padStart(2, "0")}.json`, JSON.parse(body));
      result.modelHttpCount = count; save("progress.json", result);
    }
    return originalFetch(input, init);
  };
  initialLock = lockPersonalProfile(directory);
  const db = new DatabaseSync(sqlite);
  db.exec("PRAGMA wal_checkpoint(TRUNCATE)");
  beforeMaxEntry = Number(db.prepare("SELECT max(id) AS id FROM entries").get()!.id);
  const row = db.prepare("SELECT content FROM document_revisions WHERE document_id=(SELECT id FROM documents WHERE kind='\"ruukoto.telegram\"') AND kind='base' ORDER BY seq DESC LIMIT 1").get()!;
  const telegram = JSON.parse(String(row.content)).config;
  db.close();
  assert.equal(new URL(telegram.apiBase).hostname, "127.0.0.1");
  fakeCredentialName = telegram.tokenEnv; process.env[fakeCredentialName] = "123:local-report-probe-only";
  assert.equal(createHash("sha256").update(process.env[fakeCredentialName]!).digest("hex"), telegram.tokenDigest);
  fs.copyFileSync(sqlite, path.join(output, "before-personal.sqlite")); fs.chmodSync(path.join(output, "before-personal.sqlite"), 0o600);
  result.beforeDatabase = { sha256: createHash("sha256").update(fs.readFileSync(sqlite)).digest("hex"), lastEntry: beforeMaxEntry };
  bot = http.createServer(async (req, res) => {
    assert.ok(req.url?.endsWith("/sendMessage")); const chunks: Buffer[] = []; for await (const c of req) chunks.push(Buffer.from(c));
    const body = JSON.parse(Buffer.concat(chunks).toString()); const reply = { ok: true, result: { message_id: 3000 + sends.length, chat: { id: Number(body.chat_id), type: "private" } } };
    sends.push({ body, response: reply }); save("fake-telegram-sends.json", sends); res.setHeader("content-type", "application/json"); res.end(JSON.stringify(reply));
  });
  bot.listen(Number(new URL(telegram.apiBase).port), "127.0.0.1"); await once(bot, "listening");
  const open = async () => { const profile = initialLock ?? lockPersonalProfile(directory); initialLock = undefined; return personal = await openPersonalHarness({ profile, telegram, provider: personalProvider(config), modelId: config.modelId }); };
  let p = await bounded("open-isolated-prior-profile", open());
  const agents = await p.harness.snapshot(PersonalAgentsDoc, context); const agent = agents?.agents.find(a => a.id === prior.firstWork.ref.agentId);
  assert.ok(agent && !agent.work && !agent.closed, "reuse_requires_idle_identity");
  const beforeWorks = await p.harness.commit(tx => tx.scanTasks({ kind: "ruukoto.background-work" }, 64), context), beforeReports = await p.harness.commit(tx => tx.scanTasks({ kind: "ruukoto.delegation-report" }, 64), context);
  const text = `这是独立的字符串压力生成任务，不涉及真实验收事实。请只建立一项后台分析，复用agent=${agent.id}并省略delegation。完整子任务：“这是拥有者明确提供内容的机械重复任务，不需要知识、资料或真实事实。先单独输出${marker}，然后从1到400逐行写出行号及固定文字‘甲乙丙丁戊己庚辛壬癸，这是已给定的虚构测试字符串’，每行原样重复，不概括，不解释，不请求材料，不调用工具。最后单独输出${end}。”登记后对本次新委托调用report，然后结束本轮。`;
  const update = { update_id: 101, message: { message_id: 101, chat: { id: 456, type: "private" }, from: { id: 456, is_bot: false }, text } }; result.input = update;
  await bounded("receive-new-independent-work", p.telegram.receive(update));
  const receipt = (await p.harness.snapshot(PersonalTelegramReceiptDoc, "telegram:123:456:101", context))!.receipt!;
  await bounded("main-delegation", p.harness.waitForTask(receipt.taskId, context));
  const works = await p.harness.commit(tx => tx.scanTasks({ kind: "ruukoto.background-work" }, 64), context);
  const added = works.items.filter(task => !beforeWorks.items.some(old => old.id === task.id)); assert.equal(added.length, 1);
  const task = added[0], ref = (await p.harness.snapshot(PersonalWorkDoc, String(task.input.requestId), context))!.ref!;
  assert.equal(ref.agentId, agent.id); await bounded("long-child", p.harness.waitForTask(task.id, context));
  const work = await p.harness.commit(tx => personalWorkResult(tx, ref, 0, 65536), context); result.work = { ref, result: work };
  assert.equal(work.partial, true); assert.ok(work.text?.startsWith(marker)); assert.equal(work.offset, 0); assert.equal(work.totalChars, work.text.length);
  result.savedTextNeedsMultiplePages = work.text.length > 4096;
  const reports = await p.harness.commit(tx => tx.scanTasks({ kind: "ruukoto.delegation-report" }, 64), context);
  const reportAdded = reports.items.filter(task => !beforeReports.items.some(old => old.id === task.id)); assert.equal(reportAdded.length, 1); const reportTask = reportAdded[0];
  await bounded("report-summary", p.harness.waitForTask(reportTask.id, context));
  const report = await p.harness.commit(tx => personalReportResult(tx, reportTask.input.delegation, 0, 65536), context); result.report = report;
  const saved = (await p.harness.snapshot(PersonalDelegationDoc, String(reportTask.input.delegation.entryId), context))!.delegation!; result.reportFacts = saved;
  assert.equal(report.delivery, "sent"); const sent = sends.filter(x => x.body.text === saved.report!.reply); assert.equal(sent.length, 1); assert.equal(sent[0].body.chat_id, "456"); assert.equal(sent[0].body.reply_parameters.message_id, 101);
  assert.ok(report.text?.includes(marker)); assert.match(report.text ?? "", /截断|长度限制|不完整/);
  assert.doesNotMatch(report.text ?? "", /该片段首字被切掉|原文首字(?:缺失|丢失|被切掉)|仍在生成中|仅留本机|未外发/);
  result.transportFacts = { uniqueReportSends: sent.length, originalMessageId: 101, fixedOwner: "456", delivery: report.delivery, platformMessageId: saved.report!.platformMessageId };
  const beforeRestart = { modelHttp: count, sends: sends.length };
  await bounded("close", p.close()); personal = undefined; p = await bounded("reopen", open()); await bounded("requery-original-report", p.harness.waitForTask(reportTask.id, context));
  assert.equal(count, beforeRestart.modelHttp); assert.equal(sends.length, beforeRestart.sends); result.restartNoReplay = { before: beforeRestart, after: { modelHttp: count, sends: sends.length } };
  await bounded("final-close", p.close()); personal = undefined; result.passed = true;
} catch (error) {
  result.error = error instanceof Error ? { name: error.name, message: error.message.replaceAll(credential || "__unused__", "[REDACTED]").slice(0, 1500) } : "unknown"; process.exitCode = 1;
} finally {
  if (personal) { try { await bounded("cleanup-close", personal.close()); personal = undefined; } catch { result.cleanupError = "close_failed"; process.exitCode = 1; } }
  initialLock?.release();
  if (bot?.listening) { bot.closeAllConnections(); await new Promise<void>(resolve => bot!.close(() => resolve())); }
  globalThis.fetch = originalFetch; result.modelHttpCount = count; result.stopped = personal === undefined;
  if (result.stopped) {
    const lock = lockPersonalProfile(directory);
    try {
      const db = new DatabaseSync(sqlite); db.exec("PRAGMA wal_checkpoint(TRUNCATE)");
      const entries = db.prepare("SELECT record FROM entries WHERE id > ? ORDER BY id").all(beforeMaxEntry).map(row => JSON.parse(String(row.record)));
      const requests = entries.filter(e => e.kind === "ruukoto.model-request"); save("new-model-request-entries.json", requests);
      const last = requests.findLast(e => e.data.payload && e.conversationId === 1); if (last) save("last-request-payload.json", last);
      const target = result.work?.ref.taskId;
      const pages = entries.flatMap(e => (e.model ?? []).filter((m: any) => m.role === "toolResult" && m.toolName === "background_work").flatMap((m: any) => m.content.filter((c: any) => c.type === "text").flatMap((c: any) => { try { const value = JSON.parse(c.text); return value.work === target && typeof value.text === "string" ? [{ entry: e.id, ...value }] : []; } catch { return []; } })));
      result.modelResultPages = pages.map(({ text, ...facts }: any) => ({ ...facts, returnedChars: text.length, prefix: text.slice(0, 48), suffix: text.slice(-40), matchesSavedSlice: text === result.work.result.text.slice(facts.offset, facts.offset + text.length) }));
      result.generatedAnswerEntries = entries.filter(e => e.conversationId === result.work?.ref.agentId).flatMap(e => (e.model ?? []).filter((m: any) => m.role === "assistant" && m.content.some((c: any) => c.type === "text" && c.text.includes(marker))).map((m: any) => ({ entry: e.id, stopReason: m.stopReason, textChars: m.content.filter((c: any) => c.type === "text").map((c: any) => c.text).join("").length })));
      result.newRequestEvidence = { uniqueRequests: new Set(requests.map(e => e.data.requestId)).size, entries: requests.length };
      db.close(); fs.copyFileSync(sqlite, path.join(output, "after-personal.sqlite")); fs.chmodSync(path.join(output, "after-personal.sqlite"), 0o600); result.afterDatabaseSha256 = createHash("sha256").update(fs.readFileSync(sqlite)).digest("hex"); result.lockReacquired = true;
    } finally { lock.release(); }
  }
  save("result.json", result);
  const variants = credential ? [credential, Buffer.from(credential).toString("base64"), encodeURIComponent(credential)] : [];
  const hits: string[] = []; function scan(folder: string) { for (const entry of fs.readdirSync(folder, { withFileTypes: true })) { const file = path.join(folder, entry.name); if (entry.isDirectory()) scan(file); else if (variants.some(v => v && fs.readFileSync(file).includes(Buffer.from(v)))) hits.push(path.relative(output, file)); } } scan(output);
  result.credentialScan = { matchedFiles: hits, variants: variants.length }; if (hits.length) { result.passed = false; result.error = { message: "credential_in_evidence" }; process.exitCode = 1; }
  delete process.env[credentialName]; if (fakeCredentialName) delete process.env[fakeCredentialName]; save("result.json", result);
  process.stdout.write(JSON.stringify({ output, passed: result.passed, modelHttp: count, stopped: result.stopped, error: result.error }) + "\n");
}
