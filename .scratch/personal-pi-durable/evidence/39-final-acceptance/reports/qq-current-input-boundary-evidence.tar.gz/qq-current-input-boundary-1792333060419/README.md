# 39 真实QQ拥有者输入被误当旧报告参考：私有证据

真实QQ receipt无control，content为独立后台sleep45请求；accepted451→submission454(done)→entry453(pi.user,root,seq914)→answer470/generation467。3轮真实provider请求分别对应generation455/461/467，实际仅查询旧委托331 progress及旧work346 result，没有新建委派或命令。原平台receipt记录sent。此诊断只读SQLite一致backup，不发模型、不提交拥有者消息、不执行外部业务。

实际第一请求payload entry457/request5c82eb32-032d-491d-8e35-5585ebe19556内，input[89]是旧宿主参考，input[90]是独立QQ新要求，均为role=user/content单input_text。normalize输入同样是分离的messages[71]/[72]。QQ要求不在旧参考字符串里；不存在宿主字符串拼接或SDK数组合并的实证。原宿主参考entry442仍属于旧未回答report，末尾没有说明范围结束；紧跟其后的空错误assistant未进入实际payload，故两条user相邻。模型最终却把新QQ要求误称为“汇总参考末尾附带”。

系统参考已有泛化的参考/权限边界说明，缺本轮持久输入种类的显式说明。建议仅root唯一当前输入按实际pi.user或ruukoto.delegation-report分类，在已经保存的实际system参考里陈述当前来源事实；不增工具、权限、存储格式，不移动或改写旧记录，保持宿主门禁。仅关闭未来报告模板尾部无法覆盖当前已提交的旧参考；对历史做闭合投影则要额外匹配/映射。提示改进仍需实际模型验证。

原receipt、submission、entry、生成Task、3轮原请求、模型错误回答和上下文邻接均在本目录。LiveDoc为current-only，本目录不补造历史inputs数组；独立submission/消息边界、旧报告终态及当前回答归属有各自持久证据。包含私人平台标识、会话与图片引用，按私有原始材料保管；模型/IM秘密未读取，需root用已持有实际值另做精确扫描。
