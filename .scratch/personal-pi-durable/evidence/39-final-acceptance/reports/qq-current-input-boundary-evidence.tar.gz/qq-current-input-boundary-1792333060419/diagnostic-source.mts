import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import { DatabaseSync, backup } from 'node:sqlite';
import { apply } from '/home/ubuntu/.local/ruukoto39/current/node_modules/@earendil-works/chord/dist/delta/index.js';
const base='/home/ubuntu/.local/ruukoto39/test-business/qq-current-input-boundary-'+Date.now();fs.mkdirSync(base,{mode:0o700});
const original='/home/ubuntu/.local/ruukoto39/live-profile/personal.sqlite';const live=new DatabaseSync(original,{readOnly:true});try{await backup(live,base+'/source.sqlite');}finally{live.close();}fs.chmodSync(base+'/source.sqlite',0o600);
const db=new DatabaseSync(base+'/source.sqlite',{readOnly:true});
const write=(name:string,v:unknown)=>fs.writeFileSync(base+'/'+name,JSON.stringify(v,null,2)+'\n',{mode:0o600});
const entry=(id:number)=>{const row=db.prepare('SELECT commit_seq,record FROM entries WHERE id=?').get(id);return row?{commitSeq:row.commit_seq,...JSON.parse(String(row.record))}:undefined;};
function doc(kind:string,key:string){const d=db.prepare('SELECT id,record FROM documents WHERE kind=? AND key_value=? AND retired_at IS NULL').get(JSON.stringify(kind),JSON.stringify(key));assert.ok(d,kind+':'+key);const b=db.prepare("SELECT seq,content FROM document_revisions WHERE document_id=? AND kind='base' ORDER BY seq DESC LIMIT 1").get(d.id)!;let value=JSON.parse(String(b.content));const revisions:any[]=[{seq:b.seq,kind:'base',content:value}];for(const r of db.prepare('SELECT seq,kind,content FROM document_revisions WHERE document_id=? AND seq>? ORDER BY seq').all(d.id,b.seq)){const delta=JSON.parse(String(r.content));value=apply(value,delta);revisions.push({seq:r.seq,kind:r.kind,content:delta});}return {record:JSON.parse(String(d.record)),value,revisions};}
const text=(m:any)=>typeof m.content==='string'?m.content:Array.isArray(m.content)?m.content.filter((p:any)=>p.type==='text'||p.type==='input_text').map((p:any)=>p.text).join('\n'):'';
try{
 const submissions=db.prepare('SELECT record FROM submissions WHERE conversation_id=1 ORDER BY id').all().map(r=>JSON.parse(String(r.record)));
 const source=submissions.find(s=>s.requestId?.startsWith('qq:')&&s.entry&&text(entry(s.entry).model?.[0]??{}).includes('QQ后台39-1018完成'));assert.ok(source,'actual QQ owner input');
 const sourceEntry=entry(source.entry),answer=entry(source.answer);assert.ok(answer,'QQ answered entry');
 const receipt=doc('ruukoto.telegram-receipt',source.requestId);write('qq-receipt.json',receipt);write('qq-submission.json',source);write('qq-user-entry.json',sourceEntry);write('qq-answer-entry.json',answer);
 const tasks=db.prepare('SELECT record FROM tasks ORDER BY id').all().map(r=>JSON.parse(String(r.record)));
 const scopeEntries=db.prepare('SELECT record FROM entries WHERE id>=? AND id<=? ORDER BY id').all(source.entry,source.answer).map(r=>JSON.parse(String(r.record)));
 const requestEntries=scopeEntries.filter(e=>e.kind==='ruukoto.model-request'&&e.conversationId===1);
 const assistants=scopeEntries.filter(e=>e.kind==='pi.assistant'&&e.conversationId===1);
 write('qq-scope-entries.json',scopeEntries);write('qq-model-requests.json',requestEntries);write('qq-generations.json',tasks.filter(t=>assistants.some(e=>e.byTaskId===t.id)));write('receipt-task.json',tasks.find(t=>t.id===receipt.value.receipt.taskId));
 const requestShapes=requestEntries.map(e=>{
  const data=e.data,input=data.input;const messages=input.messages.map((m:any,index:number)=>({index,role:m.role,contentType:typeof m.content==='string'?'string':'array',text:text(m),contentTypes:Array.isArray(m.content)?m.content.map((p:any)=>p.type):undefined,sections:m.sections}));
  const wire=data.payload?.input?.map((m:any,index:number)=>({index,type:m.type,role:m.role,contentType:typeof m.content==='string'?'string':Array.isArray(m.content)?'array':'other',text:text(m),contentTypes:Array.isArray(m.content)?m.content.map((p:any)=>p.type):undefined,outputTypes:Array.isArray(m.output)?m.output.map((p:any)=>p.type):undefined}));
  return{entry:e.id,requestId:data.requestId,hasPayload:data.payload!==undefined,messages,wire};
 });write('qq-request-shapes.json',requestShapes);
 const before=db.prepare('SELECT record FROM entries WHERE conversation_id=1 AND id<? ORDER BY id DESC LIMIT 12').all(source.entry).map(r=>JSON.parse(String(r.record))).reverse();write('preceding-root-entries.json',before);
 const toolCalls=assistants.flatMap(e=>(e.model??[]).flatMap((m:any)=>Array.isArray(m.content)?m.content.filter((p:any)=>p.type==='toolCall').map((p:any)=>({entry:e.id,task:e.byTaskId,...p})):[]));
 const summary={base,requestId:source.requestId,receipt:{platform:receipt.value.receipt.platform,requestId:receipt.value.receipt.requestId,submissionId:receipt.value.receipt.submissionId,content:receipt.value.receipt.content,accepted:receipt.value.receipt.accepted,control:receipt.value.receipt.control,delivery:receipt.value.receipt.delivery,taskId:receipt.value.receipt.taskId},submission:source,entry:{id:sourceEntry.id,kind:sourceEntry.kind,conversationId:sourceEntry.conversationId,commitSeq:sourceEntry.commitSeq,text:text(sourceEntry.model[0])},answer:{id:answer.id,task:answer.byTaskId,text:text(answer.model[0])},toolCalls,requests:requestShapes.map(r=>({entry:r.entry,requestId:r.requestId,hasPayload:r.hasPayload,lastUsers:r.messages.filter((m:any)=>m.role==='user').slice(-4).map((m:any)=>({index:m.index,contentType:m.contentType,contentTypes:m.contentTypes,textHead:m.text.slice(0,220),textTail:m.text.slice(-280)})),lastWireUsers:r.wire?.filter((m:any)=>m.role==='user').slice(-4).map((m:any)=>({index:m.index,contentType:m.contentType,contentTypes:m.contentTypes,textHead:m.text.slice(0,220),textTail:m.text.slice(-280)}))})),preceding:before.map(e=>({id:e.id,kind:e.kind,role:e.model?.[0]?.role,textHead:e.model?.[0]?text(e.model[0]).slice(0,100):undefined,textTail:e.model?.[0]?text(e.model[0]).slice(-160):undefined}))};
 write('summary.json',summary);process.stdout.write(JSON.stringify(summary,null,2)+'\n');
}finally{db.close();}
