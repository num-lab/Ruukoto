import * as fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
process.umask(0o077);
const out='/tmp/ruukoto39-qq-media-diagnostic';
const priv=out+'/private'; fs.mkdirSync(priv,{recursive:true,mode:0o700}); fs.chmodSync(priv,0o700);
const event=JSON.parse(fs.readFileSync('/private/tmp/ruukoto39-qq-image-observation/private-event.json','utf8'));
const photo=event.message.find(x=>x.type==='image'); assert.equal(typeof photo?.data?.file,'string');
const token=fs.readFileSync('/private/tmp/ruukoto-human-fxhh5b4x/credentials/napcat.token','utf8').trim(); assert.ok(token);
const hash=v=>createHash('sha256').update(v).digest('hex');
const safe={action:'get_image',budget:{maxActions:1,deadlineMs:12000,retries:0},startedAt:new Date().toISOString(),outboundActions:[],mediaHttpRequests:0,modelRequests:0,imSends:0,identityMatchesOriginal:true,opened:false,matchedResponse:false,result:'not_started',responseKeys:[],dataKeys:[]};
const echo='39-get-image-once-'+Date.now(); let ws;
let done=false; let timer;
const urlMeta=value=>{
 const meta={length:value.length,sha256:hash(value)};
 try{const u=new URL(value); return {...meta,protocol:u.protocol,host:u.hostname,pathShape:u.pathname==='/download'?'/download':`segments:${u.pathname.split('/').filter(Boolean).length}`,queryKeys:[...u.searchParams.keys()],rkeyPresent:u.searchParams.has('rkey'),rkeyLength:u.searchParams.get('rkey')?.length??0,equalsOriginalUrl:value===photo.data.url};}
 catch{return {...meta,absolutePath:path.isAbsolute(value),extension:path.extname(value)};}
};
const finish=(result)=>{
 if(done)return;done=true; clearTimeout(timer);safe.result=result;safe.endedAt=new Date().toISOString();safe.elapsedMs=Date.parse(safe.endedAt)-Date.parse(safe.startedAt);
 const text=JSON.stringify(safe,null,2)+'\n';
 const originalRkey=new URL(photo.data.url).searchParams.get('rkey');
 assert.ok(!text.includes(token)&&!text.includes(photo.data.url)&&!text.includes(photo.data.file)&&(!originalRkey||!text.includes(originalRkey)));
 fs.writeFileSync(out+'/get-image-once.safe.json',text,{mode:0o600,flag:'wx'});
 if(ws&&ws.readyState<2)ws.close();
 process.stdout.write(text);
};
timer=setTimeout(()=>finish('timeout'),12000);
try{
 ws=new WebSocket('ws://127.0.0.1:3001',{headers:{Authorization:`Bearer ${token}`}});
 ws.addEventListener('open',()=>{if(done)return;safe.opened=true;safe.sentAt=new Date().toISOString();safe.outboundActions.push('get_image');ws.send(JSON.stringify({action:'get_image',params:{file:photo.data.file},echo}));});
 ws.addEventListener('message',async e=>{
  if(done)return;
  let value;try{value=JSON.parse(typeof e.data==='string'?e.data:await e.data.text());}catch{return;}
  if(value.echo!==echo)return;
  fs.writeFileSync(priv+'/get-image-response.json',JSON.stringify(value,null,2)+'\n',{mode:0o600,flag:'wx'});
  safe.matchedResponse=true;safe.responseKeys=Object.keys(value).sort();safe.status=typeof value.status==='string'?value.status:null;safe.retcode=typeof value.retcode==='number'?value.retcode:null;
  const data=value.data;if(data&&typeof data==='object'){
   safe.dataKeys=Object.keys(data).sort();
   if(typeof data.url==='string')safe.url=urlMeta(data.url);
   if(typeof data.file==='string')safe.file={present:true,length:data.file.length,sha256:hash(data.file),absolutePath:path.isAbsolute(data.file),extension:path.extname(data.file)};
   safe.base64Present=typeof data.base64==='string';if(safe.base64Present){const bytes=Buffer.from(data.base64,'base64');safe.base64={encodedLength:data.base64.length,decodedBytes:bytes.length,sha256:hash(bytes)};}
  }
  finish('response');
 });
 ws.addEventListener('error',e=>{safe.socketErrorType=e.type;finish('socket_error');});
 ws.addEventListener('close',e=>{if(!done){safe.closeCode=e.code;finish('closed_before_response');}});
}catch(e){safe.localErrorName=e.name;finish('local_error');}
