from pathlib import Path
import json, subprocess, shlex, os
from urllib.parse import urlsplit
base=Path('/tmp/ruukoto39-qq-media-diagnostic')
response=json.loads((base/'private/get-image-response.json').read_text())
url=response['data']['url']
u=urlsplit(url)
assert u.scheme=='https' and u.hostname=='gchat.qpic.cn' and u.path=='/download' and not(u.username or u.password)
assert not(base/'get-refreshed-url-once.safe.json').exists()
remote=r'''
import * as fs from 'node:fs';
import {createHash} from 'node:crypto';
process.umask(0o077);
let input='';for await(const chunk of process.stdin)input+=chunk;
const {url}=JSON.parse(input);const u=new URL(url);
if(u.protocol!=='https:'||u.hostname!=='gchat.qpic.cn'||u.username||u.password)throw Error('invalid_endpoint');
const maxBytes=8*1024*1024;const started=Date.now();
const result={probe:'get_image_returned_url',host:u.hostname,urlSha256:createHash('sha256').update(url).digest('hex'),maxHttpRequests:1,httpRequests:0,redirect:'error',maxBytes,deadlineMs:15000,retries:0,tokenSent:false,startedAt:new Date(started).toISOString()};
const abort=new AbortController();const timer=setTimeout(()=>abort.abort(),15000);
try{
 result.httpRequests++;
 const response=await fetch(url,{redirect:'error',signal:abort.signal});result.status=response.status;const type=response.headers.get('content-type')??'';result.mime=type.split(';')[0].trim().toLowerCase();
 const chunks=[];let bytes=0;const reader=response.body?.getReader();if(reader)while(true){const part=await reader.read();if(part.done)break;bytes+=part.value.byteLength;if(bytes>maxBytes){result.overLimit=true;abort.abort();await reader.cancel();break;}chunks.push(part.value);}
 result.bytes=Math.min(bytes,maxBytes);if(!result.overLimit){const data=Buffer.concat(chunks);result.sha256=createHash('sha256').update(data).digest('hex');result.imageMagic=data[0]===0xff&&data[1]===0xd8&&data[2]===0xff?'jpeg':data.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))?'png':data.subarray(0,4).toString()==='RIFF'&&data.subarray(8,12).toString()==='WEBP'?'webp':null;}result.outcome='response';
}catch(e){result.outcome=abort.signal.aborted?'deadline_or_limit':'fetch_error';result.errorName=e.name;result.errorCode=typeof e.cause?.code==='string'?e.cause.code:null;}
finally{clearTimeout(timer);}
result.endedAt=new Date().toISOString();result.elapsedMs=Date.now()-started;
const out='/home/ubuntu/.local/ruukoto39/test-business/qq-refreshed-url-once.safe.json';fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{mode:0o600,flag:'wx'});process.stdout.write(JSON.stringify(result,null,2)+'\n');
'''
cmd='/home/ubuntu/.local/ruukoto39/node-v24.15.0-linux-arm64/bin/node --input-type=module -e '+shlex.quote(remote)
r=subprocess.run(['ssh','-T','-S','/tmp/ruukoto39-ssh-control.sock','-o','BatchMode=yes','oracle-4c24g',cmd],input=json.dumps({'url':url}),text=True,capture_output=True,timeout=30)
if r.returncode:
 (base/'private/refreshed-url-ssh-failure.json').write_text(json.dumps({'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}));os.chmod(base/'private/refreshed-url-ssh-failure.json',0o600)
 raise SystemExit('ssh_probe_failed_private_metadata_preserved')
safe=json.loads(r.stdout);text=json.dumps(safe,indent=2)+'\n'
assert url not in text and u.query not in text
(base/'get-refreshed-url-once.safe.json').write_text(text);os.chmod(base/'get-refreshed-url-once.safe.json',0o600)
print(text)
