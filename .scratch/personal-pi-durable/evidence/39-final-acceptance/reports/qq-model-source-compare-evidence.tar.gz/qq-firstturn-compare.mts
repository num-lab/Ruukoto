import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { randomUUID, createHash } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { apply } from '/home/ubuntu/.local/ruukoto39/current/node_modules/@earendil-works/chord/dist/delta/index.js';
import { createModels } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/node_modules/@earendil-works/pi-ai/dist/index.js';
import { personalProvider, parsePersonalModel } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-model.ts';
import { personalMedia } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-media.ts';
assert.equal(process.env.RUN_MODEL_CHECK,'1');
const home='/home/ubuntu/.local/ruukoto39',profile=home+'/live-profile';
const sourceDir=home+'/test-business/qq-current-input-boundary-1792333060419';
const output=home+'/test-business/qq-firstturn-compare-'+randomUUID();fs.mkdirSync(output,{mode:0o700});
const db=new DatabaseSync(sourceDir+'/source.sqlite',{readOnly:true});
const captured=JSON.parse(fs.readFileSync(sourceDir+'/qq-model-requests.json','utf8')).find((e:any)=>e.id===457).data;
const harnessSource=fs.readFileSync(home+'/current/apps/ruukoto/src/personal-harness.ts','utf8');
const matched=harnessSource.match(/const currentSource = sourceKind === "pi\.user" \? ("(?:[^"\\]|\\.)*")/);assert.ok(matched,'read exact candidate owner text from current harness');
const candidateText=JSON.parse(matched[1]);
const protectedSource=home+'/credentials/model-source.json';const protectedStat=fs.lstatSync(protectedSource);assert.ok(protectedStat.isFile()&&!protectedStat.isSymbolicLink()&&protectedStat.uid===process.getuid?.()&&!(protectedStat.mode&0o077));
const source=JSON.parse(fs.readFileSync(protectedSource,'utf8'));
const selected=Object.entries(source.providers).flatMap(([providerId,p]:[string,any])=>(p.models??[]).filter((m:any)=>providerId==='deepseek'&&m.id==='deepseek-flash').map((model:any)=>({providerId,provider:p,model})));assert.equal(selected.length,1);
const {provider,model}=selected[0];assert.ok(typeof provider.apiKey==='string'&&!provider.apiKey.startsWith('!')&&Object.keys(provider.headers??{}).length===0);
const envMatch=provider.apiKey.match(/^\$\{([A-Z_][A-Z0-9_]*)\}$/);let secret:string;
if(envMatch)secret=process.env[envMatch[1]]??'';else if(/^[A-Z_][A-Z0-9_]*$/.test(provider.apiKey))secret=process.env[provider.apiKey]??'';else secret=process.env[provider.apiKey]??provider.apiKey;
assert.ok(secret,'selected credential environment value must exist');
const probeEnv='RUUKOTO39_FIRSTTURN_SELECTED_KEY';assert.equal(process.env[probeEnv],undefined);process.env[probeEnv]=secret;
const config=parsePersonalModel({api:model.api??provider.api,baseUrl:provider.baseUrl,modelId:model.id,apiKeyEnv:probeEnv,contextWindow:model.contextWindow??128000,maxTokens:captured.payload.max_output_tokens??model.maxTokens??4096,imageInput:true});assert.equal(config.api,'openai-responses');
const secretVariants=[secret,JSON.stringify(secret).slice(1,-1),encodeURIComponent(secret),Buffer.from(secret).toString('base64')].filter((v,i,a)=>v&&a.indexOf(v)===i);
let redactions=0;
const sanitize=(value:unknown)=>{let text=JSON.stringify(value,null,2);for(const s of secretVariants)if(text.includes(s)){text=text.split(s).join('[REDACTED_CREDENTIAL]');redactions++;}return text.replaceAll(/\b(telegram|qq):[0-9]+:[0-9]+:[^"\\\s]+/g,'$1:<account>:<owner>:<message>');};
const write=(name:string,value:unknown)=>fs.writeFileSync(path.join(output,name),sanitize(value)+'\n',{mode:0o600});
const report:any={output,selected:'deepseek/deepseek-flash',sourceRequestEntry:457,sourceInputEntry:453,sourceInputKind:'pi.user',harnessSha256:createHash('sha256').update(harnessSource).digest('hex'),candidateText,realModel:true,toolsExecuted:0,liveInputsSubmitted:0,imSends:0,networkLimit:2,networkCalls:0,retryAttemptsBlocked:0,variants:[],startedAt:new Date().toISOString()};
function document(d:any,...args:any[]){const definition=d.definition;let i=0;const owner=definition.scope==='session'?0:Number(args[i++]);const key=definition.family?String(args[i++]):'';const row=db.prepare('SELECT id FROM documents WHERE kind=? AND key_value=? AND owner_id=? AND retired_at IS NULL').get(JSON.stringify(definition.kind),JSON.stringify(key),owner);if(!row)return definition.initial(args[i]);const base=db.prepare("SELECT seq,content FROM document_revisions WHERE document_id=? AND kind='base' ORDER BY seq DESC LIMIT 1").get(row.id)!;let value=JSON.parse(String(base.content));for(const r of db.prepare('SELECT kind,content FROM document_revisions WHERE document_id=? AND seq>? ORDER BY seq').all(row.id,base.seq)){assert.equal(r.kind,'delta');value=apply(value,JSON.parse(String(r.content)));}return value;}
const read=(table:string,id:number)=>{const r=db.prepare('SELECT record FROM '+table+' WHERE id=?').get(id);return r?JSON.parse(String(r.record)):undefined;};
const tx={doc:async(d:any,...args:any[])=>document(d,...args),entry:async(...args:any[])=>read('entries',args.length===1?args[0]:args[1]),task:async(id:number)=>read('tasks',id),submissionByRequest:async(conversation:number,requestId:string)=>{const r=db.prepare('SELECT record FROM submissions WHERE conversation_id=? AND request_id=?').get(conversation,JSON.stringify(requestId));return r?JSON.parse(String(r.record)):undefined;}};
const projection={commit:async(fn:any)=>fn(tx)};
const media=personalMedia(profile,()=>projection as any,()=>true);
const originalFetch=globalThis.fetch;let active:any,controller:AbortController|undefined,stop=false;
globalThis.fetch=async(input:any,init?:any)=>{const url=new URL(typeof input==='string'?input:input instanceof URL?input.href:input.url);assert.equal(url.origin,new URL(config.baseUrl).origin,'only selected model origin may be contacted');if(!active||active.httpCalls>=1||report.networkCalls>=2){report.retryAttemptsBlocked++;stop=true;controller?.abort(new Error('unexpected_retry_blocked'));throw new Error('unexpected_retry_blocked');}active.httpCalls++;report.networkCalls++;const call={at:new Date().toISOString(),origin:url.origin,path:url.pathname,method:init?.method??input?.method??'GET'};active.http.push(call);write('progress.json',report);const response=await originalFetch(input,init);Object.assign(call,{status:response.status});return response;};
const textOf=(m:any)=>typeof m.content==='string'?m.content:Array.isArray(m.content)?m.content.filter((p:any)=>p.type==='text'||p.type==='input_text').map((p:any)=>p.text).join('\n'):'';
const metrics=(payload:any)=>{const system=payload.input.filter((m:any)=>m.role==='system').map(textOf).join('\n');const schemas=JSON.stringify(payload.tools??[]);return{systemPromptChars:system.length,systemPromptUtf8Bytes:Buffer.byteLength(system),toolSchemaCount:payload.tools?.length??0,toolSchemasChars:schemas.length,toolSchemasUtf8Bytes:Buffer.byteLength(schemas),toolSchemasSha256:createHash('sha256').update(schemas).digest('hex'),wireInputItems:payload.input.length};};
try{
 report.originalPayloadMetrics=metrics(captured.payload);
 for(const variant of ['A-original-system','B-current-source'] as const){
  if(stop)break;
  active={variant,httpCalls:0,http:[],startedAt:new Date().toISOString()};report.variants.push(active);fs.mkdirSync(path.join(output,variant),{mode:0o700});
  const input=JSON.parse(JSON.stringify(captured.input));assert.equal(input.messages[0].role,'system');assert.ok(input.messages[0].sections?.personal);assert.equal(input.messages[0].sections['personal-current-source'],undefined);
  if(variant==='B-current-source')input.messages[0].sections['personal-current-source']=candidateText;
  const prepared=await media.modelMedia.prepare(input,captured.sessionId);active.imageMappings=prepared.imageMappings;write(variant+'/input.json',prepared.snapshot(input));
  const models=createModels();models.setProvider(personalProvider(config));const selectedModel=models.getModel('personal',config.modelId)!;
  controller=new AbortController();const timer=setTimeout(()=>controller?.abort(new Error('first_turn_timeout_120s')),120000);
  try{
   const reply=await models.streamSimple(selectedModel,prepared.input,{sessionId:captured.sessionId,signal:controller.signal,onPayload:payload=>{const value=payload as any;assert.deepEqual(value.tools,captured.payload.tools,'actual tool schemas must match original request');active.metrics=metrics(value);active.payloadCaptured=true;write(variant+'/payload.json',prepared.snapshot(value,true));}}).result();
   active.stopReason=reply.stopReason;active.error=reply.errorMessage;active.intent=reply.content.filter((p:any)=>p.type==='toolCall').map((p:any)=>({name:p.name,arguments:p.arguments}));active.text=reply.content.filter((p:any)=>p.type==='text').map((p:any)=>p.text).join('');active.usage=reply.usage;write(variant+'/first-turn.json',reply);
  }finally{clearTimeout(timer);active.finishedAt=new Date().toISOString();write('progress.json',report);}
  assert.equal(active.httpCalls,1,'each variant permits exactly one provider HTTP');
 }
 assert.ok(report.networkCalls<=2);assert.equal(report.retryAttemptsBlocked,0,'unexpected retries must stop comparison');
 if(report.variants.length===2){const[a,b]=report.variants;assert.equal(a.metrics.toolSchemasSha256,b.metrics.toolSchemasSha256);assert.equal(a.metrics.toolSchemasChars,b.metrics.toolSchemasChars);report.delta={systemPromptChars:b.metrics.systemPromptChars-a.metrics.systemPromptChars,systemPromptUtf8Bytes:b.metrics.systemPromptUtf8Bytes-a.metrics.systemPromptUtf8Bytes,toolSchemaCount:b.metrics.toolSchemaCount-a.metrics.toolSchemaCount,toolSchemasChars:b.metrics.toolSchemasChars-a.metrics.toolSchemasChars,toolSchemasUtf8Bytes:b.metrics.toolSchemasUtf8Bytes-a.metrics.toolSchemasUtf8Bytes};}
}catch(error){report.failure=error instanceof Error?{name:error.name,message:error.message,code:'code'in error?error.code:undefined}:String(error);}
finally{globalThis.fetch=originalFetch;delete process.env[probeEnv];db.close();report.finishedAt=new Date().toISOString();report.redactions=redactions;write('result.json',report);const hits:any[]=[];for(const folder of [output,...fs.readdirSync(output,{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>path.join(output,e.name))])for(const name of fs.readdirSync(folder)){const f=path.join(folder,name);if(!fs.lstatSync(f).isFile())continue;const data=fs.readFileSync(f);for(let i=0;i<secretVariants.length;i++)if(data.includes(Buffer.from(secretVariants[i])))hits.push({path:path.relative(output,f),variant:i});}write('selected-secret-scan.json',{selectedCredentialVariants:secretVariants.length,hits,modelAndImSourcesNotCopied:true});assert.equal(hits.length,0);}
process.stdout.write(sanitize({event:'finished',output,networkCalls:report.networkCalls,retryAttemptsBlocked:report.retryAttemptsBlocked,failure:report.failure,variants:report.variants.map((v:any)=>({variant:v.variant,http:v.http,stopReason:v.stopReason,error:v.error,intent:v.intent,text:v.text,metrics:v.metrics})),delta:report.delta,toolsExecuted:0,liveInputsSubmitted:0,imSends:0})+'\n');if(report.failure)process.exitCode=1;
