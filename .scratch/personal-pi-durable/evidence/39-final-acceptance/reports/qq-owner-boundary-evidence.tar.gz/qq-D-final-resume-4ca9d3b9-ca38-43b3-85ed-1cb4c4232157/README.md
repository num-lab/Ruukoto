# 工单39 原QQ输入结构边界D探针

保持B的v1 system当前来源事实，不使用C位置文案。逐对象验证原457 input最后user与已持久pi.user453.model[0]一致后，仅给其content包固定本轮拥有者输入首尾marker，原body71字逐字保存，原两图合法ref与schema均保持不变。第一轮旧progress331，第二轮旧result346 offset0；独立D预算2耗尽时先停止。根明确授权恢复仅1HTTP后，精确重放原466，第三轮模型转向新background_work delegate，内容为一次sleep45及原stdout/stderr/stopped核对，最终QQ后台39-1018完成。看到新delegate立即停止，绝未执行。

D共3真实HTTP200，连同A/B/C全组累计8，retry0。前probe5停止、D独立2停止、额外明确恢复1均在独立result记录，不隐去预算增量。没有完成后台执行、report或真实QQ复验；只能说明本次同阶段模型调用意图已转向当前任务。

独立Python核对D第一输入仅增加v1 system和当前user边界、原user正文和图片不变；D第二和第三输入均等于原已保存input加原assistant与精确记录结果，只有toolCallId关联重映射。实际payload除该user文本外与B首轮相同、schema不变。所有DB连接关闭，无live writer/IM/工具执行。

所选模型真实凭据2种去重变体扫描0，常见私钥/Bearer/TG/model-key格式扫描0，无模型/IM源配置、原SQLite、原图字节；根仍需做其已知其他秘密扫描。A/B及C原包保留不覆盖。
