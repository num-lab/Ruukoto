# 工单39 QQ新输入位置文案C探针

沿用同原输入与合法恢复图片、实际pi-ai1.3 Responses adapter，系统只加根精确74字符候选，SHA218b06ae2002e2e2307a6ebbd0e7bd45528684a3be2ad6d2f936ff20e9de71b5；未携B拒绝续文。首轮1次真实HTTP200，已有A/B+续B共3次，因此全probe总4/5。

模型提出background_work progress {action:progress,delegation:331,offset:0}及result {action:result,work:346,offset:0}。原档案progress调用无offset字段；严格name+args比对无匹配，故不重放任何结果、不继续第二HTTP、不执行任何工具。没有最终正文，C行为结论不可验证；不得将只查旧工作或未知只读参数记为模型拒绝，也不得记为纠正通过。

实际system为977 UTF16字符/2345 UTF8字节，按共享estimateTokens包装role:user文本为245tokens；工具24项、18681字符/29203字节、4671tokens，与A/B完全相同。候选本身74字符/214UTF8字节，模型system section分隔另增2字符。

独立进程核对normalized input与原A只差候选section、actual payload除system外全相同、最后真实user原样、无B拒绝记录、0重放/0工具/live/IM。只读DB已关闭；无运行中探针。

所选真实模型凭据raw/JSON/URL/base64去重2变体命中0、常见密钥格式命中0。没有复制模型或IM配置、原SQLite或图片字节；未读取其他秘密进行全量已知凭据扫描。
