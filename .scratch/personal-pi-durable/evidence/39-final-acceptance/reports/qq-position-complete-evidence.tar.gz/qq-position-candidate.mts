import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { randomUUID, createHash } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { apply } from '/home/ubuntu/.local/ruukoto39/current/node_modules/@earendil-works/chord/dist/delta/index.js';
import { createModels } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/node_modules/@earendil-works/pi-ai/dist/index.js';
import { personalProvider, parsePersonalModel } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-model.ts';
import { estimateTokens } from '/home/ubuntu/.local/ruukoto39/current/node_modules/@earendil-works/pi-coding-agent/dist/core/compaction/compaction.js';
import { personalMedia } from '/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-media.ts';
assert.equal(process.env.RUN_MODEL_CHECK,'1');
const home='/home/ubuntu/.local/ruukoto39',profile=home+'/live-profile';
const sourceDir=home+'/test-business/qq-current-input-boundary-1792333060419';
const originalProbe=home+'/test-business/qq-firstturn-compare-691a1caa-b4bb-43a8-b154-bab1c93d934b';
const output=home+'/test-business/qq-position-candidate-'+randomUUID();fs.mkdirSync(output,{mode:0o700});
const db=new DatabaseSync(sourceDir+'/source.sqlite',{readOnly:true});
const captured=JSON.parse(fs.readFileSync(sourceDir+'/qq-model-requests.json','utf8')).find((e:any)=>e.id===457).data;
const originalReport=JSON.parse(fs.readFileSync(originalProbe+'/result.json','utf8'));
const continuationDir=home+'/test-business/qq-B-bounded-continuation-a3fd1352-1a36-470a-a4e0-65f9e43c2fe8';
const priorContinuation=JSON.parse(fs.readFileSync(continuationDir+'/result.json','utf8'));
assert.equal(originalReport.networkCalls,2);assert.equal(originalReport.retryAttemptsBlocked,0);assert.equal(priorContinuation.networkCalls,1);assert.equal(priorContinuation.totalNetworkCalls,3);assert.equal(priorContinuation.retryAttemptsBlocked,0);
const candidateFile=process.env.RUUKOTO39_POSITION_TEXT_FILE;assert.ok(candidateFile?.startsWith(home+'/test-business/'),'explicit exact candidate text file required; HTTP must not start before root supplies it');
const candidateStat=fs.lstatSync(candidateFile);assert.ok(candidateStat.isFile()&&!candidateStat.isSymbolicLink()&&candidateStat.uid===process.getuid?.()&&!(candidateStat.mode&0o077));
const candidateBytes=fs.readFileSync(candidateFile);assert.equal(createHash('sha256').update(candidateBytes).digest('hex'),'218b06ae2002e2e2307a6ebbd0e7bd45528684a3be2ad6d2f936ff20e9de71b5','candidate must match root exact supplied text');const candidateText=candidateBytes.toString('utf8');assert.ok(candidateText.length>0&&candidateText!==originalReport.candidateText);
let pending:any;
const historicalEntries=JSON.parse(fs.readFileSync(sourceDir+'/qq-scope-entries.json','utf8'));
const protectedSource=home+'/credentials/model-source.json';const protectedStat=fs.lstatSync(protectedSource);assert.ok(protectedStat.isFile()&&!protectedStat.isSymbolicLink()&&protectedStat.uid===process.getuid?.()&&!(protectedStat.mode&0o077));
const source=JSON.parse(fs.readFileSync(protectedSource,'utf8'));
const selected=Object.entries(source.providers).flatMap(([providerId,p]:[string,any])=>(p.models??[]).filter((m:any)=>providerId==='deepseek'&&m.id==='deepseek-flash').map((model:any)=>({providerId,provider:p,model})));assert.equal(selected.length,1);
const {provider,model}=selected[0];assert.ok(typeof provider.apiKey==='string'&&!provider.apiKey.startsWith('!')&&Object.keys(provider.headers??{}).length===0);
const envMatch=provider.apiKey.match(/^\$\{([A-Z_][A-Z0-9_]*)\}$/);let secret:string;
if(envMatch)secret=process.env[envMatch[1]]??'';else if(/^[A-Z_][A-Z0-9_]*$/.test(provider.apiKey))secret=process.env[provider.apiKey]??'';else secret=process.env[provider.apiKey]??provider.apiKey;
assert.ok(secret,'selected credential environment value must exist');
const probeEnv='RUUKOTO39_POSITION_SELECTED_KEY';assert.equal(process.env[probeEnv],undefined);process.env[probeEnv]=secret;
const config=parsePersonalModel({api:model.api??provider.api,baseUrl:provider.baseUrl,modelId:model.id,apiKeyEnv:probeEnv,contextWindow:model.contextWindow??128000,maxTokens:captured.payload.max_output_tokens??model.maxTokens??4096,imageInput:true});assert.equal(config.api,'openai-responses');
const secretVariants=[secret,JSON.stringify(secret).slice(1,-1),encodeURIComponent(secret),Buffer.from(secret).toString('base64')].filter((v,i,a)=>v&&a.indexOf(v)===i);
let redactions=0;
const sanitize=(value:unknown)=>{let text=JSON.stringify(value,null,2);for(const s of secretVariants)if(text.includes(s)){text=text.split(s).join('[REDACTED_CREDENTIAL]');redactions++;}return text.replaceAll(/\b(telegram|qq):[0-9]+:[0-9]+:[^"\\\s]+/g,'$1:<account>:<owner>:<message>');};
const write=(name:string,value:unknown)=>fs.writeFileSync(path.join(output,name),sanitize(value)+'\n',{mode:0o600});
const report:any={output,sourceProbe:originalProbe,priorContinuation:continuationDir,candidateFile,candidateSha256:createHash('sha256').update(candidateText).digest('hex'),selected:'deepseek/deepseek-flash',sourceRequestEntry:457,sourceInputEntry:453,sourceInputKind:'pi.user',candidateText,realModel:true,toolsExecuted:0,liveInputsSubmitted:0,imSends:0,networkLimit:5,previousNetworkCalls:3,additionalNetworkLimit:2,networkCalls:0,totalNetworkCalls:3,retryAttemptsBlocked:0,turns:[],replays:[],startedAt:new Date().toISOString()};
function document(d:any,...args:any[]){const definition=d.definition;let i=0;const owner=definition.scope==='session'?0:Number(args[i++]);const key=definition.family?String(args[i++]):'';const row=db.prepare('SELECT id FROM documents WHERE kind=? AND key_value=? AND owner_id=? AND retired_at IS NULL').get(JSON.stringify(definition.kind),JSON.stringify(key),owner);if(!row)return definition.initial(args[i]);const base=db.prepare("SELECT seq,content FROM document_revisions WHERE document_id=? AND kind='base' ORDER BY seq DESC LIMIT 1").get(row.id)!;let value=JSON.parse(String(base.content));for(const r of db.prepare('SELECT kind,content FROM document_revisions WHERE document_id=? AND seq>? ORDER BY seq').all(row.id,base.seq)){assert.equal(r.kind,'delta');value=apply(value,JSON.parse(String(r.content)));}return value;}
const read=(table:string,id:number)=>{const r=db.prepare('SELECT record FROM '+table+' WHERE id=?').get(id);return r?JSON.parse(String(r.record)):undefined;};
const tx={doc:async(d:any,...args:any[])=>document(d,...args),entry:async(...args:any[])=>read('entries',args.length===1?args[0]:args[1]),task:async(id:number)=>read('tasks',id),submissionByRequest:async(conversation:number,requestId:string)=>{const r=db.prepare('SELECT record FROM submissions WHERE conversation_id=? AND request_id=?').get(conversation,JSON.stringify(requestId));return r?JSON.parse(String(r.record)):undefined;}};
const projection={commit:async(fn:any)=>fn(tx)};
const media=personalMedia(profile,()=>projection as any,()=>true);
const originalFetch=globalThis.fetch;let active:any,controller:AbortController|undefined,stop=false;
globalThis.fetch=async(input:any,init?:any)=>{const url=new URL(typeof input==='string'?input:input instanceof URL?input.href:input.url);assert.equal(url.origin,new URL(config.baseUrl).origin,'only selected model origin may be contacted');if(!active||active.httpCalls>=1||report.networkCalls>=2||report.totalNetworkCalls>=5){report.retryAttemptsBlocked++;stop=true;controller?.abort(new Error('unexpected_retry_blocked'));throw new Error('unexpected_retry_blocked');}active.httpCalls++;report.networkCalls++;report.totalNetworkCalls++;const call={at:new Date().toISOString(),origin:url.origin,path:url.pathname,method:init?.method??input?.method??'GET'};active.http.push(call);write('progress.json',report);const response=await originalFetch(input,init);Object.assign(call,{status:response.status});return response;};
const textOf=(m:any)=>typeof m.content==='string'?m.content:Array.isArray(m.content)?m.content.filter((p:any)=>p.type==='text'||p.type==='input_text').map((p:any)=>p.text).join('\n'):'';
const metrics=(payload:any)=>{const system=payload.input.filter((m:any)=>m.role==='system').map(textOf).join('\n');const schemas=JSON.stringify(payload.tools??[]);return{systemPromptChars:system.length,systemPromptUtf8Bytes:Buffer.byteLength(system),toolSchemaCount:payload.tools?.length??0,toolSchemasChars:schemas.length,toolSchemasUtf8Bytes:Buffer.byteLength(schemas),toolSchemasSha256:createHash('sha256').update(schemas).digest('hex'),wireInputItems:payload.input.length};};
const estimatePayload=(payload:any)=>{const system=payload.input.filter((m:any)=>m.role==='system').map(textOf).join('\n');const schemas=JSON.stringify(payload.tools??[]);return{...metrics(payload),systemPromptEstimatedTokens:estimateTokens({role:'user',content:system,timestamp:0}),toolSchemasEstimatedTokens:estimateTokens({role:'user',content:schemas,timestamp:0}),method:'shared pi-coding-agent estimateTokens; role:user text; UTF16 length/4 ceiling; no calibration/provider usage'};};
const allowedArguments=[{action:'progress',delegation:331},{action:'result',work:346,offset:0}];
const exact=(a:any,b:any)=>{try{assert.deepEqual(a,b);return true;}catch{return false;}};
function historicalResult(call:any){
 if(call.name!=='background_work')return undefined;
 const allowed=allowedArguments.find(a=>exact(call.arguments,a));if(!allowed)return undefined;
 const matches:any[]=[];
 for(const entry of historicalEntries)for(const message of entry.model??[])if(message.role==='assistant')for(const historicCall of message.content??[])if(historicCall.type==='toolCall'&&historicCall.name===call.name&&exact(historicCall.arguments,call.arguments)){
  for(const resultEntry of historicalEntries)for(const result of resultEntry.model??[])if(result.role==='toolResult'&&result.toolCallId===historicCall.id&&result.toolName===call.name)matches.push({callEntry:entry.id,resultEntry:resultEntry.id,historicCall,result});
 }
 assert.equal(matches.length,1,'allowed historical query must have unique original recorded result');
 const match=matches[0];assert.ok(!match.result.isError);return match;
}
try{
 report.firstTurnEstimates={};
 for(const name of ['A-original-system','B-current-source']){
  const payload=JSON.parse(fs.readFileSync(originalProbe+'/'+name+'/payload.json','utf8'));
  report.firstTurnEstimates[name]=estimatePayload(payload);
  assert.equal(report.firstTurnEstimates[name].systemPromptChars,name==='A-original-system'?901:948);
  assert.equal(report.firstTurnEstimates[name].toolSchemasChars,18681);
 }
 const input=JSON.parse(JSON.stringify(captured.input));assert.equal(input.messages[0].role,'system');assert.ok(input.messages[0].sections?.personal);assert.equal(input.messages[0].sections['personal-current-source'],undefined);
 input.messages[0].sections['personal-current-source']=candidateText;
 for(let step=1;step<=2;step++){
  const calls=pending?.content.filter((part:any)=>part.type==='toolCall')??[];
  if(pending&&!calls.length){report.termination='assistant_without_tools';report.finalText=pending.content.filter((part:any)=>part.type==='text').map((part:any)=>part.text).join('');break;}
  const replies:any[]=[];let blocked:any;
  for(const call of calls){
   const match=historicalResult(call);
   if(!match){blocked={name:call.name,arguments:call.arguments,id:call.id,reason:'not_exact_recorded_read_query; no tool executed'};break;}
   const replay=JSON.parse(JSON.stringify(match.result));replay.toolCallId=call.id;
   const original=JSON.parse(JSON.stringify(replay));original.toolCallId=match.historicCall.id;assert.deepEqual(original,match.result);
   replies.push(replay);report.replays.push({beforeAdditionalHttp:step,name:call.name,arguments:call.arguments,originalCallEntry:match.callEntry,originalResultEntry:match.resultEntry,originalCallId:match.historicCall.id,replayCallId:call.id,contentSha256:createHash('sha256').update(JSON.stringify(match.result.content)).digest('hex'),modifiedFields:['toolCallId']});
  }
  if(blocked){report.termination='unexecuted_unknown_or_mutating_intent';report.blockedIntent=blocked;break;}
  if(pending)input.messages.push(pending,...replies);
  active={step,httpCalls:0,http:[],replayCount:replies.length,startedAt:new Date().toISOString()};report.turns.push(active);
  const folder='C-position-'+step;fs.mkdirSync(path.join(output,folder),{mode:0o700});
  const prepared=await media.modelMedia.prepare(input,captured.sessionId);active.imageMappings=prepared.imageMappings;write(folder+'/input.json',prepared.snapshot(input));
  const models=createModels();models.setProvider(personalProvider(config));const selectedModel=models.getModel('personal',config.modelId)!;
  controller=new AbortController();const timer=setTimeout(()=>controller?.abort(new Error('continuation_timeout_120s')),120000);
  try{
   pending=await models.streamSimple(selectedModel,prepared.input,{sessionId:captured.sessionId,signal:controller.signal,onPayload:payload=>{const value=payload as any;assert.deepEqual(value.tools,captured.payload.tools,'actual tool schemas must match original request');active.metrics=estimatePayload(value);active.payloadCaptured=true;write(folder+'/payload.json',prepared.snapshot(value,true));}}).result();
   active.stopReason=pending.stopReason;active.error=pending.errorMessage;active.intent=pending.content.filter((p:any)=>p.type==='toolCall').map((p:any)=>({name:p.name,arguments:p.arguments,id:p.id}));active.text=pending.content.filter((p:any)=>p.type==='text').map((p:any)=>p.text).join('');active.usage=pending.usage;write(folder+'/assistant.json',pending);
  }finally{clearTimeout(timer);active.finishedAt=new Date().toISOString();write('progress.json',report);}
  assert.equal(active.httpCalls,1,'one actual HTTP per continuation step');
  if(stop||pending.stopReason==='error'||pending.stopReason==='aborted'){report.termination='adapter_error_or_abort';break;}
  const nextCalls=pending.content.filter((p:any)=>p.type==='toolCall');
  if(!nextCalls.length){report.termination='assistant_without_tools';report.finalText=active.text;break;}
  const unknown=nextCalls.find((call:any)=>!historicalResult(call));
  if(unknown){report.termination='unexecuted_unknown_or_mutating_intent';report.blockedIntent={name:unknown.name,arguments:unknown.arguments,id:unknown.id,reason:'not_exact_recorded_read_query; no tool executed'};break;}
  if(step===2)report.termination='additional_http_budget_exhausted';
 }
 assert.ok(report.networkCalls<=2&&report.totalNetworkCalls<=5);assert.equal(report.retryAttemptsBlocked,0,'unexpected retries must stop continuation');

}catch(error){report.failure=error instanceof Error?{name:error.name,message:error.message,code:'code'in error?error.code:undefined}:String(error);}
finally{globalThis.fetch=originalFetch;delete process.env[probeEnv];db.close();report.finishedAt=new Date().toISOString();report.redactions=redactions;write('result.json',report);const hits:any[]=[];for(const folder of [output,...fs.readdirSync(output,{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>path.join(output,e.name))])for(const name of fs.readdirSync(folder)){const f=path.join(folder,name);if(!fs.lstatSync(f).isFile())continue;const data=fs.readFileSync(f);for(let i=0;i<secretVariants.length;i++)if(data.includes(Buffer.from(secretVariants[i])))hits.push({path:path.relative(output,f),variant:i});}write('selected-secret-scan.json',{selectedCredentialVariants:secretVariants.length,hits,modelAndImSourcesNotCopied:true});assert.equal(hits.length,0);}
process.stdout.write(sanitize({event:'finished',output,networkCalls:report.networkCalls,retryAttemptsBlocked:report.retryAttemptsBlocked,failure:report.failure,previousNetworkCalls:report.previousNetworkCalls,totalNetworkCalls:report.totalNetworkCalls,termination:report.termination,blockedIntent:report.blockedIntent,turns:report.turns,finalText:report.finalText,firstTurnEstimates:report.firstTurnEstimates,toolsExecuted:0,liveInputsSubmitted:0,imSends:0})+'\n');if(report.failure)process.exitCode=1;
