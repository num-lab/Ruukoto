import fs from 'node:fs';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
const source='/private/tmp/ruukoto39-qq-image-observation/private-event.json';
const stat=fs.lstatSync(source);assert.ok(stat.isFile()&&!stat.isSymbolicLink()&&stat.uid===process.getuid()&&!(stat.mode&0o077));
const event=JSON.parse(fs.readFileSync(source,'utf8'));assert.equal(event.message_id,880487927);
const photos=event.message.filter(part=>part.type==='image');assert.equal(photos.length,1);
const address=photos[0].data.url,u=new URL(address);assert.equal(u.protocol,'https:');assert.equal(u.hostname,'gchat.qpic.cn');assert.ok(!u.username&&!u.password);
async function probe(address,place){
 const result={place,method:'GET',redirect:'error',attempts:1,startedAt:new Date().toISOString()};
 try{
  const response=await fetch(address,{method:'GET',redirect:'error',signal:AbortSignal.timeout(15000)});
  Object.assign(result,{status:response.status,mime:response.headers.get('content-type'),locationHost:response.headers.get('location')?new URL(response.headers.get('location'),address).hostname:null});
  let bytes=0;const parts=[];
  for await(const part of response.body){bytes+=part.byteLength;if(bytes>8*1024*1024)throw Object.assign(new Error('limit'),{code:'body_over_8MiB'});parts.push(part);}
  const data=Buffer.concat(parts);Object.assign(result,{bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')});
 }catch(error){result.error={name:error.name,code:error.code??error.cause?.code??null};}
 result.finishedAt=new Date().toISOString();return result;
}
const remoteSource=`import {createHash} from 'node:crypto';let input='';for await(const part of process.stdin)input+=part;const {address}=JSON.parse(input);const probe=${probe.toString()};process.stdout.write(JSON.stringify(await probe(address,'oracle'))+'\n');`;
const remote=new Promise((resolve,reject)=>{const child=spawn('ssh',['-S','/tmp/ruukoto39-ssh-control.sock','oracle-4c24g',"/home/ubuntu/.local/ruukoto39/node-v24.15.0-linux-arm64/bin/node --input-type=module --eval "+"'"+remoteSource.replaceAll("'","'\\''")+"'"],{stdio:['pipe','pipe','pipe']});let output='';child.stdout.on('data',part=>{output+=part;});child.stderr.resume();child.on('error',reject);child.on('close',code=>{if(code!==0)reject(new Error('remote_probe_process_failed'));else{try{resolve(JSON.parse(output));}catch{reject(new Error('remote_probe_metadata_invalid'));}}});child.stdin.end(JSON.stringify({address}));});
const results=await Promise.all([probe(address,'local'),remote]);
const report={eventMessageId:event.message_id,sourceHost:u.hostname,sourceProtocol:u.protocol,fullUrlArchived:false,rawEventCopied:false,connectionCredentialsAttached:false,probes:results};
fs.writeFileSync('/tmp/ruukoto39-qq-schedule-audit/image-download-probes.json',JSON.stringify(report,null,2)+'\n',{mode:0o600});
process.stdout.write(JSON.stringify(report)+'\n');
