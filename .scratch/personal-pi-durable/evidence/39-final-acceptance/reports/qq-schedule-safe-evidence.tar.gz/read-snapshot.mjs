import fs from 'node:fs';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { apply } from '/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/node_modules/@earendil-works/chord/dist/delta/index.js';
const root='/tmp/ruukoto39-qq-schedule-audit',db=new DatabaseSync(root+'/source.sqlite',{readOnly:true});
const entry=id=>{const row=db.prepare('SELECT record FROM entries WHERE id=?').get(id);return row?JSON.parse(row.record):undefined;};
const task=id=>{const row=db.prepare('SELECT record FROM tasks WHERE id=?').get(id);return row?JSON.parse(row.record):undefined;};
const submission=id=>{const row=db.prepare('SELECT record FROM submissions WHERE id=?').get(id);return row?JSON.parse(row.record):undefined;};
function doc(row){let value;for(const r of db.prepare('SELECT kind,content FROM document_revisions WHERE document_id=? ORDER BY seq').all(row.id)){const content=JSON.parse(r.content);value=r.kind==='base'?content:apply(value,content);}return {documentId:row.id,kind:JSON.parse(row.kind),key:JSON.parse(row.key_value),value};}
const rows=db.prepare('SELECT id,kind,key_value FROM documents WHERE retired_at IS NULL').all();
const imageDocs=rows.filter(row=>row.key_value.includes('880487927')||row.key_value.includes('940475107')).map(doc);
const media=imageDocs.filter(row=>row.kind==='ruukoto.media-message');
const imageEntries=[];for(let id=638;id<=671;id++){const e=entry(id);if(e)imageEntries.push({id:e.id,kind:e.kind,conversationId:e.conversationId,byTaskId:e.byTaskId,dataKeys:Object.keys(e.data??{}),modelRoles:e.model?.map(m=>m.role),imageParts:e.model?.flatMap(m=>Array.isArray(m.content)?m.content:[]).filter(p=>p.type==='image').length??0});}
const imageFacts={documents:imageDocs,entries:imageEntries,mainTextEntry:entry(666),assistantEntry:entry(671)};
const plan=doc(rows.find(row=>JSON.parse(row.kind)==='ruukoto.schedule'&&row.key_value.includes('74e432'))).value.plan;
const run=doc(rows.find(row=>JSON.parse(row.kind)==='ruukoto.schedule-run'&&row.key_value.includes('ef78ab'))).value.run;
const scheduledEntries=db.prepare('SELECT record FROM entries WHERE conversation_id=? ORDER BY id').all(run.conversationId).map(r=>JSON.parse(r.record));
const original={plan,run,planAdmission:entry(plan.admission),runTask:task(run.taskId),summaryAnswer:entry(752),result:entry(753),sendTask:task(754),sendObservation:entry(757),scheduledEntries,childTask:task(717),childEntries:db.prepare('SELECT record FROM entries WHERE conversation_id=? ORDER BY id').all(711).map(r=>JSON.parse(r.record))};
assert.equal(original.summaryAnswer.kind,'pi.assistant');assert.equal(original.result.kind,'ruukoto.schedule-result');
const text=original.summaryAnswer.model.filter(m=>m.role==='assistant').flatMap(m=>m.content).filter(p=>p.type==='text').map(p=>p.text).join('');
assert.equal(text,original.result.data.text);
fs.writeFileSync(root+'/schedule-answer-original.txt',text,{mode:0o600});
fs.writeFileSync(root+'/schedule-original-records.json',JSON.stringify(original,null,2)+'\n',{mode:0o600});
fs.writeFileSync(root+'/qq-image-records.json',JSON.stringify(imageFacts,null,2)+'\n',{mode:0o600});
console.log(JSON.stringify({media:media.map(d=>({documentId:d.documentId,key:d.key,state:d.value.message?.state,reason:d.value.message?.reason,artifacts:d.value.message?.artifacts?.length,submissionId:d.value.message?.submissionId})),receiptKinds:imageDocs.map(d=>d.kind),planId:plan.id,runId:run.id,runKeys:Object.keys(run),delivery:run.delivery,resultKeys:run.result?Object.keys(run.result):[],planCreator:plan.createdBy.actor,summaryAnswerChars:text.length,scheduledEntryCount:scheduledEntries.length},null,2));db.close();
