import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as path from "node:path";
import * as http from "node:http";
import { once } from "node:events";
import { randomUUID, createHash } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { BACKGROUND_CONTEXT } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/node_modules/@earendil-works/chord/dist/context/index.js";
import { openPersonalHarness, type PersonalHarness } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-harness.ts";
import { parsePersonalModel, personalProvider } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-model.ts";
import { PersonalWorkDoc, personalWorkResult } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-work.ts";
import { personalReportResult } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-report.ts";
import { PersonalDelegationDoc } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-delegation.ts";
import { PersonalTelegramReceiptDoc } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-telegram-records.ts";
import { lockPersonalProfile } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-profile.ts";

const output = "/tmp/ruukoto39-real-report-" + new Date().toISOString().replaceAll(":", "").replaceAll(".", "-");
fs.mkdirSync(output, { mode: 0o700 });
const directory = path.join(output, "profile");
const context = BACKGROUND_CONTEXT;
const OLD = `OLD39_${randomUUID().replaceAll("-", "")}`;
const CURRENT = `CURRENT39_${randomUUID().replaceAll("-", "")}`;
const END = `END39_${randomUUID().replaceAll("-", "")}`;
const credentialName = "PERSONAL_FINAL_REPORT_MODEL_KEY";
const fakeCredentialName = "PERSONAL_FINAL_REPORT_FAKE_BOT_KEY";
const result: Record<string, unknown> = { output, directory, realModel: true, realIm: false, fakePlatform: "loopback Telegram sendMessage", passed: false, stopped: false, stages: [], modelHttp: [], markers: { OLD, CURRENT, END }, sourceHead: "b1e975437f4cd3ca8084a8b07e451f19ba80ba17" };
const findings: { code: string; detail: string }[] = [];
function assess(text: string, facts: { delivery: string; partial: boolean; current: string; old: string }) {
  const codes: string[] = [];
  if (facts.delivery === "sent" && /(?:仍|还|正在|尚)[^。\n]{0,12}(?:生成|发送|回报)中|delivery\s*[=:]\s*["']?(?:waiting|pending|sending)/u.test(text)) codes.push("stale_delivery_generation_claim");
  if (facts.delivery === "sent" && /(?:仅|只)(?:留|保留|存|保存|在)[^。\n]{0,14}本机|(?:报告|结果)[^。\n]{0,14}(?:仅|只)[^。\n]{0,14}本机|尚未(?:发送|送达)|未(?:外发|发送|送达)|没有(?:发送|外发)|待(?:发送|外发)/u.test(text)) codes.push("false_local_or_unsent_claim");
  if (text.includes(facts.old)) codes.push("old_work_context_pollution");
  if (!text.includes(facts.current)) codes.push("current_work_marker_missing");
  if (facts.partial && !/(截断|不完整|未完整|未完成输出|长度限制|输出[^。\n]{0,12}(?:上限|限制))/u.test(text)) codes.push("missing_partial_notice");
  return codes;
}
assert.deepEqual(assess(`本次结果${CURRENT}。报告仅留本机，未外发。`, { delivery: "sent", partial: false, current: CURRENT, old: OLD }), ["false_local_or_unsent_claim"]);
assert.ok(assess(`${CURRENT}，旧结果${OLD}。`, { delivery: "sent", partial: true, current: CURRENT, old: OLD }).includes("old_work_context_pollution"));
assert.ok(assess(`${CURRENT}。`, { delivery: "sent", partial: true, current: CURRENT, old: OLD }).includes("missing_partial_notice"));
assert.deepEqual(assess(`${CURRENT}：子分析因长度限制截断。`, { delivery: "sent", partial: true, current: CURRENT, old: OLD }), []);
assert.ok(assess(`${CURRENT}，最终汇总报告仍在生成中（delivery=waiting）。`, { delivery: "sent", partial: false, current: CURRENT, old: OLD }).includes("stale_delivery_generation_claim"));
result.sourceHashes = Object.fromEntries(["personal-harness.ts", "personal-report.ts", "personal-work-tools.ts", "personal-work.ts", "personal-delegation.ts", "personal-model.ts"].map(name => { const file = "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/" + name; return [file, createHash("sha256").update(fs.readFileSync(file)).digest("hex")]; }));
result.redCapability = { passed: true, known37WrongDeliveryCaught: true, oldContextCaught: true, missingPartialCaught: true };
let personal: PersonalHarness | undefined;
let bot: http.Server | undefined;
let credential = "";
let originalFetch = globalThis.fetch;
let count = 0;
const sends: { sequence: number; at: string; method: string; body: Record<string, unknown>; response: unknown }[] = [];
const bounded = async <T>(name: string, operation: Promise<T>): Promise<T> => {
  const stage = { name, startedAt: new Date().toISOString(), finishedAt: "", result: "running" };
  (result.stages as unknown[]).push(stage);
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    const value = await Promise.race([operation, new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error(`step_timeout:${name}`)), 120_000); })]);
    stage.result = "passed"; return value;
  } catch (error) { stage.result = "failed"; throw error; }
  finally { clearTimeout(timer); stage.finishedAt = new Date().toISOString(); fs.writeFileSync(path.join(output, "progress.json"), JSON.stringify(result, null, 2) + "\n", { mode: 0o600 }); }
};
try {
  assert.equal(process.env.RUN_MODEL_CHECK, "1", "real model requires explicit RUN_MODEL_CHECK=1");
  assert.equal(process.env.RUN_PERSONAL_MODEL, "deepseek/deepseek-flash");
  const source = JSON.parse(fs.readFileSync(process.env.RUN_PERSONAL_MODELS_FILE!, "utf8"));
  const selected = Object.entries(source.providers).flatMap(([id, p]: [string, any]) => p.models.filter((m: any) => `${id}/${m.id}` === process.env.RUN_PERSONAL_MODEL).map((model: any) => ({ provider: p, model })));
  assert.equal(selected.length, 1);
  const { provider, model } = selected[0];
  assert.ok(provider.apiKey && !provider.apiKey.startsWith("!") && !Object.keys(provider.headers ?? {}).length);
  credential = process.env[provider.apiKey] ?? provider.apiKey;
  assert.equal(process.env[credentialName], undefined);
  process.env[credentialName] = credential;
  process.env[fakeCredentialName] = "123:local-report-probe-only";
  const config = parsePersonalModel({ api: model.api ?? provider.api, baseUrl: provider.baseUrl, modelId: model.id, apiKeyEnv: credentialName, contextWindow: model.contextWindow ?? 128000, maxTokens: 1024 });
  result.model = { selected: process.env.RUN_PERSONAL_MODEL, api: config.api, maxTokens: config.maxTokens, contextWindow: config.contextWindow };
  const modelOrigin = new URL(config.baseUrl).origin;
  globalThis.fetch = async (input, init) => {
    const url = new URL(typeof input === "string" ? input : input instanceof URL ? input.href : input.url);
    assert.ok(url.origin === modelOrigin || url.hostname === "127.0.0.1", "probe must not contact another external origin");
    if (url.origin === modelOrigin) {
      count++; assert.ok(count <= 24, "model HTTP budget exceeded");
      (result.modelHttp as unknown[]).push({ number: count, at: new Date().toISOString(), method: init?.method ?? "GET" });
    }
    return originalFetch(input, init);
  };
  bot = http.createServer(async (request, response) => {
    const chunks: Buffer[] = []; for await (const chunk of request) chunks.push(Buffer.from(chunk));
    const body = JSON.parse(Buffer.concat(chunks).toString() || "{}");
    assert.ok(request.url?.endsWith("/sendMessage"), "only fake Telegram sendMessage is allowed");
    const reply = { ok: true, result: { message_id: 1000 + sends.length, chat: { id: Number(body.chat_id), type: "private" } } };
    sends.push({ sequence: sends.length + 1, at: new Date().toISOString(), method: "sendMessage", body, response: reply });
    fs.writeFileSync(path.join(output, "fake-telegram-sends.json"), JSON.stringify(sends, null, 2) + "\n", { mode: 0o600 });
    response.setHeader("content-type", "application/json"); response.end(JSON.stringify(reply));
  });
  bot.listen(0, "127.0.0.1"); await once(bot, "listening"); const address = bot.address(); assert.ok(address && typeof address !== "string");
  const telegram = { version: 1 as const, enabled: true, generation: randomUUID(), apiBase: `http://127.0.0.1:${address.port}`, tokenEnv: fakeCredentialName, tokenDigest: createHash("sha256").update(process.env[fakeCredentialName]!).digest("hex"), botId: "123", ownerId: "456", boundary: 10 };
  const open = async () => personal = await openPersonalHarness({ directory, telegram, provider: personalProvider(config), modelId: config.modelId });
  let p = await bounded("first-open", open());
  result.localInput = `这是本机隔离验收第一项。请用background_work的delegate新建名为“39分析员”的后台分析，完整子任务是“仅回复${OLD}，不调用工具”。随后对该委托调用report安排最终汇总，登记后结束本轮。`;
  result.localAnswer = await bounded("first-local-delegation", p.answer(String(result.localInput), "report39-local-first"));
  const firstTasks = await p.harness.commit(tx => tx.scanTasks({ kind: "ruukoto.background-work" }, 16), context);
  assert.equal(firstTasks.items.length, 1, "exactly one first background work required");
  const firstTask = firstTasks.items[0];
  const first = (await p.harness.snapshot(PersonalWorkDoc, String(firstTask.input.requestId), context))!.ref!;
  await bounded("first-child", p.harness.waitForTask(first.taskId, context));
  result.firstWork = { ref: first, result: await p.harness.commit(tx => personalWorkResult(tx, first), context) };
  assert.ok((result.firstWork as any).result.text?.includes(OLD), "first child must return old marker");
  const firstReports = await p.harness.commit(tx => tx.scanTasks({ kind: "ruukoto.delegation-report" }, 16), context);
  assert.equal(firstReports.items.length, 1, "first local report required");
  await bounded("first-local-report", p.harness.waitForTask(firstReports.items[0].id, context));
  result.firstReport = await p.harness.commit(tx => personalReportResult(tx, firstReports.items[0].input.delegation, 0, 65536), context);
  assert.equal((result.firstReport as any).delivery, "local"); assert.equal(sends.length, 0);
  await bounded("first-normal-close", p.close()); personal = undefined;
  p = await bounded("restart-open", open());
  const input = `这是与此前独立的新委托。请用background_work的delegate复用原39分析员（agent=${first.agentId}，省略delegation）。完整子任务为“这是新工作，请忽略以前工作标记。先单独写${CURRENT}，然后从1到400逐条输出，每条至少20个汉字解释本次隔离验收的独立事实，不要省略、合并或概括，最后单独写${END}。不调用工具。”登记后对这个新委托调用report安排最终汇总，然后结束本轮。`;
  const update = { update_id: 11, message: { message_id: 11, chat: { id: 456, type: "private" }, from: { id: 456, is_bot: false }, text: input } };
  result.telegramInput = update;
  await bounded("fake-telegram-receive", p.telegram.receive(update));
  const receiptKey = "telegram:123:456:11";
  const receipt = (await p.harness.snapshot(PersonalTelegramReceiptDoc, receiptKey, context))!.receipt!;
  await bounded("second-main-delegation", p.harness.waitForTask(receipt.taskId, context));
  result.telegramReceipt = (await p.harness.snapshot(PersonalTelegramReceiptDoc, receiptKey, context))!.receipt!;
  const secondTasks = await p.harness.commit(tx => tx.scanTasks({ kind: "ruukoto.background-work" }, 16), context);
  assert.equal(secondTasks.items.length, 2, "restart must add exactly one new background work");
  const secondTask = secondTasks.items.find(task => task.id !== first.taskId)!;
  const second = (await p.harness.snapshot(PersonalWorkDoc, String(secondTask.input.requestId), context))!.ref!;
  assert.equal(second.agentId, first.agentId, "original background identity must be reused");
  await bounded("second-long-child", p.harness.waitForTask(second.taskId, context));
  const secondResult = await p.harness.commit(tx => personalWorkResult(tx, second, 0, 65536), context);
  result.secondWork = { ref: second, result: secondResult };
  assert.ok(secondResult.text?.includes(CURRENT), "second child must return current marker");
  if (secondResult.partial !== true) findings.push({ code: "long_answer_not_truncated", detail: "Long-answer probe did not reach model length stop; no truncation acceptance claimed." });
  const reports = await p.harness.commit(tx => tx.scanTasks({ kind: "ruukoto.delegation-report" }, 16), context);
  assert.equal(reports.items.length, 2, "each delegation must have exactly one report");
  const reportTask = reports.items.find(task => task.id !== firstReports.items[0].id)!;
  await bounded("second-final-report", p.harness.waitForTask(reportTask.id, context));
  const report = await p.harness.commit(tx => personalReportResult(tx, reportTask.input.delegation, 0, 65536), context);
  result.secondReport = report;
  const saved = (await p.harness.snapshot(PersonalDelegationDoc, String(reportTask.input.delegation.entryId), context))!.delegation!;
  result.reportFacts = saved;
  assert.equal(report.delivery, "sent", "report must be acknowledged by fake Telegram");
  const reportSends = sends.filter(send => send.body.text === saved.report!.reply);
  assert.equal(reportSends.length, 1, "report must be sent exactly once");
  assert.equal(reportSends[0].body.chat_id, "456");
  assert.deepEqual(reportSends[0].body.reply_parameters, { message_id: 11, allow_sending_without_reply: true });
  assert.equal(String(reportSends[0].response && (reportSends[0].response as any).result.message_id), saved.report!.platformMessageId);
  for (const code of assess(report.text ?? "", { delivery: report.delivery, partial: secondResult.partial === true, current: CURRENT, old: OLD })) findings.push({ code, detail: "Actual report text conflicts with current work/host facts; raw report and fake transport retained." });
  result.transportFacts = { uniqueReportSends: reportSends.length, originalMessageId: 11, fixedOwnerId: "456", reportDelivery: report.delivery, platformMessageId: saved.report!.platformMessageId, fullReportCharacters: [...report.text ?? ""].length, sentCharacters: [...String(saved.report!.reply)].length };
  assert.equal((await p.work.list()).length, 1);
  const beforeRestart = { modelHttp: count, sends: sends.length };
  await bounded("second-normal-close", p.close()); personal = undefined;
  p = await bounded("final-open", open());
  await bounded("final-report-query", p.harness.waitForTask(reportTask.id, context));
  result.afterFinalRestartReport = await p.harness.commit(tx => personalReportResult(tx, reportTask.input.delegation, 0, 65536), context);
  assert.equal((result.afterFinalRestartReport as any).delivery, "sent");
  assert.equal(count, beforeRestart.modelHttp, "terminal restart must not request another model response");
  assert.equal(sends.length, beforeRestart.sends, "terminal restart must not send again");
  result.restartNoReplay = { passed: true, before: beforeRestart, after: { modelHttp: count, sends: sends.length } };
  await bounded("final-normal-close", p.close()); personal = undefined;
  result.passed = findings.length === 0;
} catch (error) {
  result.error = error instanceof Error ? { name: error.name, message: error.message.replaceAll(credential || "__not_a_credential__", "[REDACTED]").slice(0, 1500) } : { name: "unknown" };
  process.exitCode = 1;
} finally {
  if (personal) { try { await bounded("cleanup-close", personal.close()); personal = undefined; } catch { result.cleanupError = "close_failed"; process.exitCode = 1; } }
  result.stopped = personal === undefined;
  if (result.stopped && fs.existsSync(directory)) { try { const lock = lockPersonalProfile(directory); lock.release(); result.lockReacquired = true; } catch { result.lockReacquired = false; process.exitCode = 1; } }
  if (bot) { bot.closeAllConnections(); await new Promise<void>(resolve => bot!.close(() => resolve())); }
  globalThis.fetch = originalFetch;
  result.modelHttpCount = count;
  result.findings = findings;
  if (findings.length) process.exitCode = 1;
  const sqlite = path.join(directory, "personal.sqlite");
  if (result.stopped && fs.existsSync(sqlite)) {
    const db = new DatabaseSync(sqlite, { readOnly: true });
    try {
      const entries = db.prepare("SELECT record FROM entries").all().map(row => JSON.parse(String(row.record)));
      const evidence = entries.filter(entry => entry.kind === "ruukoto.model-request");
      const ids = [...new Set(evidence.map(entry => entry.data.requestId))];
      result.requestEvidence = { requests: ids.length, entries: evidence.length, paired: ids.every(id => evidence.filter(entry => entry.data.requestId === id).length === 2) };
      result.assistantStopReasons = entries.flatMap(entry => (entry.model ?? []).filter((message: any) => message.role === "assistant").map((message: any) => ({ entry: entry.id, conversation: entry.conversationId, stopReason: message.stopReason })));
    } finally { db.close(); }
    const variants = credential ? [credential, Buffer.from(credential).toString("base64"), encodeURIComponent(credential)] : [];
    const hits: string[] = [];
    function scan(folder: string) { for (const entry of fs.readdirSync(folder, { withFileTypes: true })) { const file = path.join(folder, entry.name); if (entry.isDirectory()) scan(file); else if (variants.some(secret => secret && fs.readFileSync(file).includes(Buffer.from(secret)))) hits.push(path.relative(output, file)); } }
    scan(output); result.credentialScan = { matchedFiles: hits, variants: variants.length };
    assert.equal(hits.length, 0, "retained evidence must not contain model credential");
    result.database = { path: sqlite, sha256: createHash("sha256").update(fs.readFileSync(sqlite)).digest("hex"), bytes: fs.statSync(sqlite).size };
  }
  delete process.env[credentialName]; delete process.env[fakeCredentialName];
  result.finishedAt = new Date().toISOString();
  fs.writeFileSync(path.join(output, "result.json"), JSON.stringify(result, null, 2) + "\n", { mode: 0o600 });
  process.stdout.write(JSON.stringify({ output, passed: result.passed, stopped: result.stopped, modelHttpCount: count, findings, error: result.error }) + "\n");
}
