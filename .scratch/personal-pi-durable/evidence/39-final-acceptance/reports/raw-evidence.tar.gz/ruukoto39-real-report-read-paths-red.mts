import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as path from "node:path";
import { BACKGROUND_CONTEXT } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/node_modules/@earendil-works/chord/dist/context/index.js";
import { openPersonalHarness } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-harness.ts";
import { personalProvider } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-model.ts";
import { personalReportResult } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-report.ts";
import { MockModelServer } from "/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/test/helpers/mock-provider.ts";
const context = BACKGROUND_CONTEXT;
const action = process.env.PROBE_ACTION ?? "progress";
assert.ok(["progress", "delegations", "report_result"].includes(action));
const folder = fs.mkdtempSync("/tmp/ruukoto39-real-report-progress-red-");
let ref: { entryId: number };
let observed: unknown;
const model = new MockModelServer(request => {
  if (request.system?.includes("你是个人助手的子 Agent")) return { kind: "text", text: "业务完成" };
  const summary = String(request.messages.findLast(message => message.role === "user")?.content).startsWith("宿主委托汇总参考");
  if (summary) {
    const last = request.messages.at(-1);
    if (last?.role !== "tool") return { kind: "tool_calls", calls: [{ id: "summary-progress", name: "background_work", arguments: action === "delegations" ? { action } : { action, delegation: ref.entryId } }] };
    const progress = JSON.parse(String(last.content)); observed = progress;
    return { kind: "text", text: (action === "delegations" ? progress.delegations[0].report?.delivery : action === "report_result" ? progress.delivery : progress.report?.delivery) === "waiting" ? "业务完成。最终汇总报告仍在生成中（delivery=waiting）。" : "业务完成。" };
  }
  if (request.messages.at(-1)?.role === "tool") return { kind: "text", text: "已登记" };
  return { kind: "tool_calls", calls: [{ id: "new-work", name: "background_work", arguments: { action: "delegate", content: "只回复业务完成" } }] };
});
process.env.REPORT39_MOCK_KEY = "probe-only";
const config = { api: "openai-completions" as const, baseUrl: await model.start(), modelId: "mock-model", apiKeyEnv: "REPORT39_MOCK_KEY", contextWindow: 128000, maxTokens: 1024 };
const p = await openPersonalHarness({ directory: path.join(folder, "profile"), provider: personalProvider(config), modelId: config.modelId });
try {
  await p.answer("建立一项工作", "owner");
  const tasks = await p.harness.commit(tx => tx.scanTasks({ kind: "ruukoto.background-work" }, 16), context);
  assert.equal(tasks.items.length, 1);
  await p.harness.waitForTask(tasks.items[0].id, context);
  // 原委托由主输入entry固定；从已经完成的原生工具结果取同一引用，不猜ID。
  const delegateResult = model.calls.flatMap(call => call.messages).filter(message => message.role === "tool").map(message => { try { return JSON.parse(String(message.content)); } catch { return undefined; } }).find(value => value?.delegation);
  ref = { entryId: delegateResult.delegation };
  const { requestPersonalReport } = await import("/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-report.ts");
  const { PersonalWorkDoc } = await import("/Users/eitrous/orca/workspaces/ruukoto/migrate-to-pi-durable/apps/ruukoto/src/personal-work.ts");
  const doc = (await p.harness.snapshot(PersonalWorkDoc, String(tasks.items[0].input.requestId), context))!;
  const reportTask = await p.harness.commit(tx => requestPersonalReport(tx, ref, "owner", doc.modelCall!), context);
  await p.harness.waitForTask(reportTask, context);
  const report = await p.harness.commit(tx => personalReportResult(tx, ref), context);
  const result = { folder, action, realModel: false, realIm: false, observedProgress: observed, report, requests: model.calls.length, noHistoryOrRestartRequired: true };
  fs.writeFileSync(path.join(folder, "result.json"), JSON.stringify(result, null, 2) + "\n");
  process.stdout.write(JSON.stringify(result, null, 2) + "\n");
  assert.doesNotMatch(report.text ?? "", /仍在生成中|delivery=waiting/, "completed report must not repeat its own generation-time delivery state");
} finally { await p.close(); await model.close(); delete process.env.REPORT39_MOCK_KEY; }
