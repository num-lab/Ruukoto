# 工单39：报告封组登记与效果就绪分离

候选仅在独立 worktree 修改，不改根/live。requirePersonalDelegationActive抽取现有取消和原IM有效检查并返回value；原requireReady继续active+sourcesReady。requestPersonalReport保留原输入验证和已封组幂等，新登记只用active。后台allSettled、效果blocker、membersStopped、provider发送前门禁保持原实现；不改共享command unresolved/source blocker，不把恢复started假设正常，也不改存储格式。

3条新用例精确名称为“durable 命令：封组登记不等待命令 running，效果和停止核实后才唯一汇总”、“durable 命令：封组登记不等待命令 unknown，效果和停止核实后才唯一汇总”、“durable 命令：封组登记不等待命令 restored，效果和停止核实后才唯一汇总”。原代码3条实际report工具结果work_source_paused红；修复后全部绿。原命令被release文件持住，首次登记waiting、summary0、独立聊天继续、重复report同Task；正常释放后唯一summary/local。未知先核实effect但stop缺失，恢复缺receipt先核实stop但effect缺失，各自仍零summary/零新委派；二事实齐后原command仅执行一次。模型为MockModelServer且fixture模拟OS，不计真实模型或Linux外部验收。

最终影响检查：personal-command-work、personal-reports、personal-delegations、personal-work-notes、personal-work-tools五文件126/126；check:static完整exit0，含类型/notes/docs/budgets/markdown；git diff --check与根git apply --check均通过。未重跑787个人宽组。

background_work描述和action使用点明确report只封组、活动/未知也可登记、宿主待停止和原效果核实后生成发送；新登记仍须原入口有效且未取消。实际SDK wire快照按共享estimateTokens包装role:user文本估算：owner system138→138/toolSchemas3413→3433，summary135→135/3413→3433，child73→73/1006→1006；主schema13650→13732字符（+82），未用provider usage或校准。before/after快照在包内。

诊断失败保留：最初新测试的Mock响应把工具结果统一改成“完成”，无法证明具体红，改为直接回显原tool结果后重跑得到有效work_source_paused红；仅有效红作为回归证明。独立worktree最初整node_modules链接回根造成@ruukoto私有类来自两份源码TS2322，后来仅将副本workspace依赖映射至副本自身，源码不变，再跑最终static和126均通过。两个原失败日志保留，不记产品失败。

不含真实凭据、生产配置、原SQLite或原图。真实593来源/receipt只读材料另存report593-diagnostic-evidence包，根决定何时以唯一writer按原源和modelCall620补唯一report；本修复没有执行维护或IM发送。
