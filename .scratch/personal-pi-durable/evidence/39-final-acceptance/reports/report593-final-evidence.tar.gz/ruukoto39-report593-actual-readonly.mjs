import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import { apply } from '/home/ubuntu/.local/ruukoto39/current/node_modules/@earendil-works/chord/dist/delta/index.js';
const base='/home/ubuntu/.local/ruukoto39/test-business/report593-once-fcd90c93-6027-498e-a64d-9e04a570c029';
const out=base+'/independent-audit';
const db=new DatabaseSync(out+'/post-maintenance.sqlite',{readOnly:true});
const record=(table,id)=>{const r=db.prepare('SELECT record FROM '+table+' WHERE id=?').get(id);return r&&JSON.parse(r.record)};
const doc=(kind,key)=>{const d=db.prepare('SELECT id FROM documents WHERE kind=? AND key_value=? AND owner_id=0 AND retired_at IS NULL').get(JSON.stringify(kind),JSON.stringify(key));const b=db.prepare("SELECT seq,content FROM document_revisions WHERE document_id=? AND kind='base' ORDER BY seq DESC LIMIT 1").get(d.id);let v=JSON.parse(b.content);for(const r of db.prepare('SELECT content FROM document_revisions WHERE document_id=? AND seq>? ORDER BY seq').all(d.id,b.seq))v=apply(v,JSON.parse(r.content));return v};
try{
const group=doc('ruukoto.analysis-delegation','593').delegation,report=group.report;
const entries=db.prepare('SELECT record FROM entries ORDER BY id').all().map(r=>JSON.parse(r.record));
const fresh=entries.filter(e=>e.id>=report.admission);
const req=fresh.filter(e=>e.kind==='ruukoto.model-request');
const submission=db.prepare('SELECT record FROM submissions WHERE conversation_id=1 AND request_id=?').get(JSON.stringify('personal-report:762:0'));
const full={result:JSON.parse(fs.readFileSync(base+'/result.json','utf8')),group,reportTask:record('tasks',762),sourceReceipt:doc('ruukoto.telegram-receipt',group.source.requestId).receipt,reportSubmission:JSON.parse(submission.record),modelRequestEntries:req,reportAnswer:record('entries',report.answer),newEntries:fresh};
fs.writeFileSync(out+'/actual-full-private.json',JSON.stringify(full,null,2)+'\n',{mode:0o600});
fs.writeFileSync(out+'/report-full-original.txt',report.reply+'\n',{mode:0o600});
const summary={reportTask:report.taskId,delivery:report.delivery,answer:report.answer,reportChars:Array.from(report.reply).length,content:report.content,reply:report.reply,requests:req.map(e=>({entry:e.id,requestId:e.data.requestId,payloadPresent:!!e.data.payload,inputKeys:Object.keys(e.data.input??{}),inputCurrentSource:e.data.input?.messages?.[0]?.sections?.['personal-current-source'],inputMessages:e.data.input?.messages?.slice(-7),payloadKeys:e.data.payload&&Object.keys(e.data.payload)})),tools:fresh.filter(e=>e.model?.some(m=>m.role==='toolResult'||m.role==='assistant'&&m.content?.some(p=>p.type==='toolCall'))).map(e=>({entry:e.id,kind:e.kind,byTaskId:e.byTaskId,model:e.model}))};
fs.writeFileSync(out+'/actual-focused-private.json',JSON.stringify(summary,null,2)+'\n',{mode:0o600});
process.stdout.write(JSON.stringify({out,requests:req.length,requestIds:new Set(req.map(e=>e.data.requestId)).size,reportTask:report.taskId,delivery:report.delivery,answer:report.answer,reportChars:Array.from(report.reply).length})+'\n');
}finally{db.close()}
