import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as path from "node:path";
import * as net from "node:net";
import { createHash, randomUUID } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { setTimeout as delay } from "node:timers/promises";
import { BACKGROUND_CONTEXT, withAbortSignal } from "/home/ubuntu/.local/ruukoto39/current/node_modules/@earendil-works/chord/dist/context/index.js";
import { apply } from "/home/ubuntu/.local/ruukoto39/current/node_modules/@earendil-works/chord/dist/delta/index.js";
import { LiveDoc, ROOT_CONVERSATION_ID, type TaskId, type EntryId, type Tx } from "/home/ubuntu/.local/ruukoto39/current/node_modules/@earendil-works/pi-durable/dist/index.js";
import { lazyStream, type Provider } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/node_modules/@earendil-works/pi-ai/dist/index.js";
import { lockPersonalProfile, type PersonalProfileLock } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-profile.ts";
import { readPersonalConfig } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-config.ts";
import { readPersonalTelegram } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-telegram-config.ts";
import { readPersonalQq } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-qq-config.ts";
import { readPersonalServices } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-service-config.ts";
import { readPersonalCommands } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-command-config.ts";
import { readPersonalMcp } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-mcp-config.ts";
import { readPersonalTools } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-tools-config.ts";
import { readPersonalBrowser } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-browser-config.ts";
import { openPersonalHarness, type PersonalHarness } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-harness.ts";
import { personalProvider } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-model.ts";
import { PersonalError } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-error.ts";
import { personalDelegation, PersonalDelegationDoc, requirePersonalDelegationInput, requirePersonalDelegationReady } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-delegation.ts";
import { PersonalTelegramReceiptDoc } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-telegram-records.ts";
import { requestPersonalReport, personalReportResult } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-report.ts";
import { personalWorkStatus } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-work.ts";
import { personalCommand, personalCommandUnresolved, type PersonalCommandRef } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-command-work.ts";
import { readPersonalCommandReceipt } from "/home/ubuntu/.local/ruukoto39/current/apps/ruukoto/src/personal-command-execution.ts";

// 审阅稿：没有执行入口参数时，不打开档案、凭据或数据库。
const HOME39 = "/home/ubuntu/.local/ruukoto39", ROOT39 = HOME39 + "/current", PROFILE = HOME39 + "/live-profile";
const CA = HOME39 + "/test-business/mcp/tls/ca.crt", context = BACKGROUND_CONTEXT;
const GROUP = { entryId: 593 as EntryId }, COMMAND = { requestId: "personal-command-tool:614", taskId: 616 as PersonalCommandRef["taskId"] };
const MAX_MODELS = 6, TOTAL_MS = 300_000, MODEL_MS = 90_000, CLEANUP_MS = 30_000;
const sha = (value: string | Buffer) => createHash("sha256").update(value).digest("hex");
function fail(code: string): never { throw new PersonalError(code, "单次维护前提不成立；保留原记录，不自动重试。"); }
function privateFile(filename: string) { const stat = fs.lstatSync(filename); assert.ok(stat.isFile() && !stat.isSymbolicLink() && stat.uid === process.getuid?.() && !(stat.mode & 0o077)); return fs.readFileSync(filename, "utf8").trim(); }
function errorCode(error: unknown) { return error instanceof PersonalError ? error.code : error instanceof Error && "code" in error && typeof error.code === "string" ? error.code : "maintenance_failed"; }
// SQLite/JSON边界；该适配器只供持锁前置读取，不接受写入或继续执行任务。
type Wire = Record<string, any>;
function reader(db: DatabaseSync) {
  const record = (table: "tasks" | "entries" | "submissions", id: number): Wire | undefined => { const row = db.prepare(`SELECT record FROM ${table} WHERE id=?`).get(id) as { record: string } | undefined; return row && JSON.parse(row.record); };
  const all = (table: "tasks" | "submissions") => db.prepare(`SELECT record FROM ${table} ORDER BY id`).all().map(row => JSON.parse(String(row.record)) as Wire);
  const document = (token: Wire, ...args: unknown[]) => {
    const d = token.definition; let i = 0; const owner = d.scope === "session" ? 0 : Number(args[i++]); const key = d.family ? String(args[i++]) : "";
    const row = db.prepare("SELECT id FROM documents WHERE kind=? AND key_value=? AND owner_id=? AND retired_at IS NULL").get(JSON.stringify(d.kind), JSON.stringify(key), owner) as { id: number } | undefined;
    if (!row) return d.initial(args[i]);
    const base = db.prepare("SELECT seq,content FROM document_revisions WHERE document_id=? AND kind='base' ORDER BY seq DESC LIMIT 1").get(row.id) as { seq: number; content: string } | undefined; assert.ok(base);
    let value = JSON.parse(base.content);
    for (const delta of db.prepare("SELECT kind,content FROM document_revisions WHERE document_id=? AND seq>? ORDER BY seq").all(row.id, base.seq)) { assert.equal(delta.kind, "delta"); value = apply(value, JSON.parse(String(delta.content))); }
    return value;
  };
  const tx = { doc: async (token: Wire, ...args: unknown[]) => document(token, ...args), entry: async (...args: unknown[]) => record("entries", Number(args.at(-1))), task: async (id: number) => record("tasks", id), submissionByRequest: async (conversation: number, requestId: string) => { const row = db.prepare("SELECT record FROM submissions WHERE conversation_id=? AND request_id=?").get(conversation, JSON.stringify(requestId)) as { record: string } | undefined; return row && JSON.parse(row.record); }, scanTasks: async (options: Wire, limit: number, cursor: unknown) => { assert.equal(cursor, undefined); let items = all("tasks").filter(t => (!options.kind || t.kind === options.kind) && (!options.conversationId || t.conversationId === options.conversationId)); if (options.order === "descending") items.reverse(); assert.ok(items.length <= limit, "只读前置不猜分页；超出即停止"); return { items }; } } as unknown as Tx;
  return { record, all, document, tx };
}
async function socketOffline(filename: string) { return new Promise<boolean>(resolve => { const socket = net.createConnection(filename); let done = false; const finish = (offline: boolean) => { if (done) return; done = true; socket.destroy(); resolve(offline); }; socket.once("connect", () => finish(false)); socket.once("error", error => finish(["ENOENT", "ECONNREFUSED"].includes((error as NodeJS.ErrnoException).code ?? ""))); socket.setTimeout(500, () => finish(false)); }); }
async function main() {
  if (process.argv[2] !== "--execute-report593-once") { process.stdout.write("审阅稿，未执行；须经根审阅、正常停止后台并提供停止回执后才可运行。\n"); return; }
  assert.equal(process.env.RUN_MODEL_CHECK, "1"); assert.equal(process.env.NODE_EXTRA_CA_CERTS, CA); assert.ok(fs.statSync(CA).isFile());
  const stopPath = process.argv[3]; assert.ok(stopPath && path.isAbsolute(stopPath)); const stopFile = fs.lstatSync(stopPath); assert.ok(stopFile.isFile() && !stopFile.isSymbolicLink());
  const stop = JSON.parse(fs.readFileSync(stopPath, "utf8")) as Wire;
  assert.equal(stop.before?.tasks, 0); assert.equal(stop.before?.inputs, 0); assert.equal(stop.stopped, true); assert.equal(stop.credentialsOmitted, true);
  assert.equal(path.join(path.dirname(stop.snapshot), "live-profile"), PROFILE);
  const snapshotStat = fs.lstatSync(stop.snapshot); assert.ok(snapshotStat.isFile() && !snapshotStat.isSymbolicLink() && snapshotStat.uid === process.getuid?.() && (snapshotStat.mode & 0o777) === 0o600);
  const stamp = /-(\d{13})\.sqlite$/.exec(path.basename(stop.snapshot)); assert.ok(stamp); const stopVerifiedAt = new Date(Number(stamp[1])).toISOString();
  assert.ok(await socketOffline(path.join(PROFILE, "control.sock")), "控制socket仍可连接或状态未知");
  assert.ok(fs.statSync(path.join(PROFILE, "personal.sqlite")).isFile());
  const audit: Wire = { script: "report593-once-v1-review", startedAt: new Date().toISOString(), group: 593, originalTool: 620, originalWork: 602, originalCommand: 616, stopVerifiedAt, stopReceiptSHA256: sha(fs.readFileSync(stopPath)), stoppedSnapshot: stop.snapshot, modelLimit: MAX_MODELS, modelCalls: 0, httpCalls: 0, retryAttemptsBlocked: 0, reportFrames: 0, otherQqFrames: 0, newOwnerEvents: 0, registered: false, pollClosed: false, harnessClosed: false, canceledReportOnFailure: false };
  const output = path.join(HOME39, "test-business", "report593-once-" + randomUUID()); fs.mkdirSync(output, { mode: 0o700 });
  const write = () => fs.writeFileSync(path.join(output, "result.json"), JSON.stringify(audit, null, 2) + "\n", { mode: 0o600 });
  let profile: PersonalProfileLock | undefined, personal: PersonalHarness | undefined, handedOff = false, reportId: TaskId | undefined, rawDb: DatabaseSync | undefined;
  const overall = new AbortController(), pollStop = new AbortController(); let poll: Promise<void> | undefined, timer: ReturnType<typeof setTimeout> | undefined;
  let sourceRequestId = "", owner = "", originalMessage = 0, activeModel: { number: number; http: number } | undefined;
  const priorFetch = globalThis.fetch, PriorWebSocket = globalThis.WebSocket;
  const stopMaintenance = (code: string) => { audit.stopCode ??= code; overall.abort(new Error(code)); write(); };
  const signalStop = () => stopMaintenance("maintenance_interrupted"); process.on("SIGINT", signalStop); process.on("SIGTERM", signalStop);
  try {
    audit.phase = "profile_lock"; profile = lockPersonalProfile(PROFILE); audit.exclusiveProfileLock = true;
    const config = readPersonalConfig(profile), telegram = readPersonalTelegram(profile), qq = readPersonalQq(profile), services = readPersonalServices(profile), commands = readPersonalCommands(profile), mcp = readPersonalMcp(profile), tools = readPersonalTools(profile), browser = readPersonalBrowser(profile);
    assert.ok(qq?.enabled && telegram && commands); assert.equal(config.api, "openai-responses");
    const credentials = path.join(HOME39, "credentials"), source = JSON.parse(privateFile(path.join(credentials, "model-source.json"))) as Wire;
    const candidates = Object.values(source.providers).flatMap((p: any) => (p.models ?? []).filter((m: any) => m.id === config.modelId && (m.api ?? p.api) === config.api && p.baseUrl === config.baseUrl).map(() => p)); assert.equal(candidates.length, 1);
    const selected = candidates[0]; assert.ok(typeof selected.apiKey === "string" && !selected.apiKey.startsWith("!") && Object.keys(selected.headers ?? {}).length === 0);
    const match = /^\$\{([A-Z_][A-Z0-9_]*)\}$/.exec(selected.apiKey); const modelKey = match ? process.env[match[1]] : /^[A-Z_][A-Z0-9_]*$/.test(selected.apiKey) ? process.env[selected.apiKey] : selected.apiKey; assert.ok(modelKey);
    process.env[config.apiKeyEnv] = modelKey; process.env[qq.tokenEnv] = privateFile(path.join(credentials, "napcat.token")); process.env[telegram.tokenEnv] = privateFile(path.join(credentials, "telegram.token"));
    const tavily = privateFile(path.join(credentials, "tavily.token")); if (tools?.search) process.env[tools.search.apiKeyEnv] = tavily;
    audit.privateCredentialsLoaded = 4; audit.caLoadedBeforeProcessStart = true;
    const required = { "apps/ruukoto/src/personal-delegation.ts": "a4e3c1116180bbbc93b9c05c5cc6ce0e586461076bcd409176a6af508dab7a41", "apps/ruukoto/src/personal-report.ts": "5d373f90175dee7d1f6bbe1a3822aa615a4726f89de9f151855829d356fb942d" };
    for (const [relative, digest] of Object.entries(required)) assert.equal(sha(fs.readFileSync(path.join(ROOT39, relative))), digest, "已审report登记修复字节不符"); audit.sourceSHA = required;
    audit.phase = "readonly_preflight"; rawDb = new DatabaseSync(path.join(PROFILE, "personal.sqlite"), { readOnly: true }); const read = reader(rawDb);
    const tasks = read.all("tasks"); const pending = tasks.filter(t => t.state.status !== "terminal" && t.kind !== "ruukoto.schedule-supervisor"); assert.deepEqual(pending.map(t => t.id), [], "后台不是空闲维护前提");
    assert.deepEqual(read.all("submissions").filter(s => ["queued", "placed"].includes(s.status)).map(s => s.id), [], "仍有未完成输入");
    for (const row of rawDb.prepare("SELECT kind,key_value,owner_id FROM documents WHERE retired_at IS NULL").all()) {
      const kind = JSON.parse(String(row.kind)); if (kind !== "ruukoto.schedule") continue;
      // 计划族由完整base+delta还原，未来360秒内有到期或activeRun则不启动维护。
      const plan = read.document({ definition: { kind, scope: "session", family: true, initial: () => ({}) } }, JSON.parse(String(row.key_value)), null).plan;
      assert.ok(plan && !plan.activeRun && (plan.canceled || plan.nextDueAt === null || Date.parse(plan.nextDueAt) > Date.now() + TOTAL_MS + 60_000), "定时运行与维护窗口重叠");
    }
    audit.phase = "original_authorization"; const group = await personalDelegation(read.tx, GROUP); assert.equal(group.cancelRequested, false); assert.equal(group.report, undefined); assert.equal(group.source.entryId, GROUP.entryId); assert.equal(group.telegram?.platform, "qq"); assert.equal(group.telegram?.ownerId, qq.ownerId); assert.equal(group.telegram?.generation, qq.generation);
    assert.equal(group.members.length, 1); assert.equal(group.members[0].taskId, 602); sourceRequestId = group.source.requestId;
    await requirePersonalDelegationInput(read.tx, GROUP, sourceRequestId); await requirePersonalDelegationReady(read.tx, GROUP);
    const work = await personalWorkStatus(read.tx, group.members[0]); assert.equal(work.task.state.status, "terminal"); assert.equal(work.task.state.outcome.status, "completed"); assert.equal(work.stopVerified, true);
    const command = await personalCommand(read.tx, COMMAND); assert.equal(command.work.ref.taskId, 602); assert.equal(command.command.trim(), "sleep 45"); assert.equal(command.result?.exitCode, 0); assert.equal(command.result?.effect, "returned"); assert.equal(command.stopped, true); assert.equal(personalCommandUnresolved(command), false); assert.ok(command.execution && command.prepared);
    assert.ok(await readPersonalCommandReceipt(path.join(PROFILE, "commands"), command.execution, command.prepared.fingerprint), "原命令完整回执缺失"); assert.equal(read.record("tasks", 616)?.state.status, "terminal");
    const original = read.record("tasks", 620), assistant = read.record("entries", 619), originalResult = read.record("entries", 621); assert.equal(original?.kind, "pi.tool"); assert.equal(original?.conversationId, ROOT_CONVERSATION_ID); assert.equal(original?.state.status, "terminal"); assert.equal(original?.input.assistant, 619); assert.equal(assistant?.byTaskId, original?.owner); assert.equal(original?.state.outcome.result.entryId, 621); assert.ok(originalResult && JSON.stringify(originalResult.model).includes("work_source_paused"));
    const part = assistant?.model?.flatMap((m: Wire) => m.role === "assistant" ? m.content : []).find((p: Wire) => p.type === "toolCall" && p.id === original?.input.callId); assert.equal(part?.name, "background_work"); assert.deepEqual(part?.arguments, { action: "report", delegation: 593 });
    const receipt = (await read.tx.doc(PersonalTelegramReceiptDoc, sourceRequestId, null)).receipt; assert.ok(receipt); owner = qq.ownerId; originalMessage = receipt.messageId; audit.preflightPassed = true; write();
    // 只记录原QQ回报的实际传输次数；正常新入站/其他原生回执不冒充593成果。
    globalThis.WebSocket = class extends PriorWebSocket { override send(data: Parameters<WebSocket["send"]>[0]) {
      if (typeof data === "string") {
        const action = JSON.parse(data) as Wire;
        if (action.action === "send_private_msg") {
          const quoted = action.params?.message?.find((p: Wire) => p.type === "reply")?.data?.id;
          if (String(action.params?.user_id) === owner && String(quoted) === String(originalMessage)) {
            const now = reader(rawDb!).document(PersonalDelegationDoc, "593", null).delegation?.report; assert.equal(now?.taskId, reportId); assert.equal(now?.delivery, "sending"); assert.equal(action.params.message.find((p: Wire) => p.type === "text")?.data?.text, now.reply);
            if (audit.reportFrames >= 1) { stopMaintenance("duplicate_report_frame_blocked"); fail("duplicate_report_frame_blocked"); } audit.reportFrames++;
          } else audit.otherQqFrames++;
          write();
        }
      }
      super.send(data);
    } };
    const modelOrigin = new URL(config.baseUrl).origin;
    globalThis.fetch = async (input, init) => {
      const url = new URL(typeof input === "string" ? input : input instanceof URL ? input.href : input.url);
      if (url.origin !== modelOrigin) return priorFetch(input, init);
      if (!activeModel || activeModel.http >= 1 || audit.httpCalls >= MAX_MODELS || overall.signal.aborted || !url.pathname.endsWith("/responses")) { audit.retryAttemptsBlocked++; stopMaintenance("model_http_budget_or_retry"); fail("model_http_budget_or_retry"); }
      activeModel.http++; audit.httpCalls++; write(); return priorFetch(input, init);
    };
    const base = personalProvider(config);
    const provider: Provider = { ...base, stream: (model) => lazyStream(model, async () => fail("unexpected_stream_api")), streamSimple: (model, input, options) => lazyStream(model, async () => {
      if (!personal || !reportId || audit.modelCalls >= MAX_MODELS || activeModel || overall.signal.aborted) fail("model_source_or_budget");
      const live = await personal.harness.snapshot(LiveDoc, ROOT_CONVERSATION_ID, context), saved = (await personal.harness.snapshot(PersonalDelegationDoc, "593", context))!.delegation!.report!;
      if (!live?.run || live.run.inputs.length !== 1 || saved.taskId !== reportId || saved.attempt !== 0 || saved.pauses.length !== 0) fail("unexpected_report_attempt");
      const submission = await personal.harness.submission(live.run.inputs[0], context), status = await submission?.status(context);
      if (status?.requestId !== `personal-report:${reportId}:0` || !status.entry) fail("unexpected_model_source");
      const entry = await personal.harness.commit(tx => tx.entry(status.entry!), context); assert.equal(entry?.kind, "ruukoto.delegation-report"); assert.deepEqual(entry?.data, { delegation: 593, taskId: reportId, attempt: 0 });
      const first = input.messages[0]; assert.equal(first?.role, "system"); assert.ok(first?.role === "system" && first.sections?.["personal-current-source"]?.includes("宿主委托汇总参考"));
      audit.modelCalls++; const ticket = { number: audit.modelCalls, http: 0 }; activeModel = ticket; write();
      const stream = base.streamSimple(model, input, { ...options, signal: AbortSignal.any([...(options?.signal ? [options.signal] : []), overall.signal, AbortSignal.timeout(MODEL_MS)]) });
      void stream.result().then(() => { if (activeModel === ticket) activeModel = undefined; }, () => { if (activeModel === ticket) activeModel = undefined; }); return stream;
    }) };
    audit.phase = "open_original_configuration"; handedOff = true;
    personal = await openPersonalHarness({ profile, provider, modelId: config.modelId, telegram, qq, ...(services ? { service: { ...services, useSudo: true }, serviceOperations: true } : {}), ...(commands ? { commands } : {}), ...(mcp ? { mcp } : {}), ...(tools ? { tools } : {}), ...(browser ? { browser } : {}), beforeUnlock: async () => { pollStop.abort(); await poll; audit.pollClosed = true; } });
    // 原receive先完整持久接纳，观察器只结束维护，不抛弃或伪造新输入；普通provider失败不自动重投。
    const receive = personal.qq.receive.bind(personal.qq);
    personal.qq.receive = async (event, signal) => { await receive(event, signal); if (event.post_type === "message" && event.message_type === "private" && String(event.user_id) === owner) { audit.newOwnerEvents++; stopMaintenance("concurrent_owner_input_accepted"); } };
    audit.phase = "qq_connect"; poll = personal.qq.poll(pollStop.signal); void poll.catch(error => stopMaintenance(errorCode(error)));
    const onlineBy = Date.now() + 15_000; while (!(await personal.qq.status()).online) { overall.signal.throwIfAborted(); if (Date.now() >= onlineBy) fail("qq_not_online"); await delay(100); }
    timer = setTimeout(() => stopMaintenance("maintenance_timeout"), TOTAL_MS);
    overall.signal.throwIfAborted();
    audit.phase = "register_original_report"; reportId = await personal.harness.commit(async tx => { const current = await personalDelegation(tx, GROUP); assert.equal(current.report, undefined); assert.equal(current.cancelRequested, false); assert.equal(current.source.requestId, sourceRequestId); await requirePersonalDelegationReady(tx, GROUP); const task = await requestPersonalReport(tx, GROUP, sourceRequestId, 620 as TaskId); reportId = task; return task; }, context);
    audit.registered = true; audit.reportTaskId = reportId; write(); personal.harness.resume();
    audit.phase = "wait_report"; const settled = await personal.harness.waitForTask(reportId, withAbortSignal(overall.signal, context)); const final = (await personal.harness.snapshot(PersonalDelegationDoc, "593", context))!.delegation!.report!;
    audit.taskOutcome = settled.state.outcome.status; audit.delivery = final.delivery; audit.platformMessageId = final.platformMessageId; audit.answerEntry = final.answer;
    const result = await personal.harness.commit(tx => personalReportResult(tx, GROUP), context); audit.reportChars = result.totalChars; audit.firstPageSHA256 = result.text === undefined ? undefined : sha(result.text); audit.concurrentActivity = audit.newOwnerEvents > 0 || audit.otherQqFrames > 0;
    assert.equal(final.attempt, 0); assert.equal(final.delivery, "sent"); assert.equal(audit.reportFrames, 1); assert.equal(audit.concurrentActivity, false); audit.success = true;
  } catch (error) {
    audit.success = false; audit.errorCode = errorCode(error); overall.abort(new Error(audit.errorCode));
    // 只撤回本脚本新登记的唯一报告；不取消委托/成员/原620，不制造新模型尝试。
    if (personal && reportId) { try { audit.abortTaskResult = await personal.harness.abortTask(reportId, context); await personal.harness.waitForTask(reportId, withAbortSignal(AbortSignal.timeout(CLEANUP_MS), context)); const cleanupReport = (await personal.harness.snapshot(PersonalDelegationDoc, "593", context))!.delegation!.report!; audit.delivery = cleanupReport.delivery; audit.canceledReportOnFailure = cleanupReport.delivery === "canceled"; audit.reportCleanupTerminal = true; } catch (cleanup) { audit.reportAbortUnverified = errorCode(cleanup); } }
    process.exitCode = 1;
  } finally {
    if (timer) clearTimeout(timer); pollStop.abort();
    try { await poll; audit.pollClosed = true; } catch (error) { audit.pollErrorCode = errorCode(error); }
    if (personal) { const warning = setTimeout(() => { audit.cleanupStillPending = true; write(); process.stderr.write("[ruukoto:maintenance] Harness收尾仍未核实；不得重开后台或强制释放锁。\n"); }, CLEANUP_MS); try { await personal.close(); audit.harnessClosed = true; } catch (error) { audit.closeErrorCode = errorCode(error); process.exitCode = 2; } finally { clearTimeout(warning); } }
    else if (!handedOff) { profile?.release(); audit.preOpenLockReleased = true; }
    rawDb?.close(); globalThis.fetch = priorFetch; globalThis.WebSocket = PriorWebSocket; process.removeListener("SIGINT", signalStop); process.removeListener("SIGTERM", signalStop); audit.endedAt = new Date().toISOString(); write();
    process.stdout.write(JSON.stringify({ output, success: audit.success, reportTaskId: reportId, delivery: audit.delivery, modelCalls: audit.modelCalls, httpCalls: audit.httpCalls, reportFrames: audit.reportFrames, newOwnerEvents: audit.newOwnerEvents, pollClosed: audit.pollClosed, harnessClosed: audit.harnessClosed, errorCode: audit.errorCode }) + "\n");
  }
}
void main().catch(error => { process.stderr.write(`[ruukoto:maintenance] ${errorCode(error)}；维护未完成，不自动重试。\n`); process.exitCode = 1; });
