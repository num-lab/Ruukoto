#!/bin/sh
set -eu
# 仅根审阅后执行；第三个参数是正常/stop收尾后生成的私有停止回执。
export NODE_EXTRA_CA_CERTS=/home/ubuntu/.local/ruukoto39/test-business/mcp/tls/ca.crt
export RUN_MODEL_CHECK=1
cd /home/ubuntu/.local/ruukoto39/current
exec /home/ubuntu/.local/ruukoto39/node-v24.15.0-linux-arm64/bin/node --import tsx /tmp/ruukoto39-report593-once.mts "$@"
