import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { execFileSync } from "node:child_process";
import { WorkCopyManager } from "@ruukoto/runtime/work-copy.ts";
import type { Session } from "@ruukoto/core/types.ts";
import { initGitRepo } from "../test/helpers/git-fixture.ts";

for (const scenario of ["case-rename", "file-to-directory", "directory-to-file"] as const) {
  const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "ruukoto-path-kind-review-"))), source = path.join(root, "source");
  fs.mkdirSync(source);
  if (scenario === "case-rename") fs.writeFileSync(path.join(source, "Value.txt"), "base\n");
  else if (scenario === "file-to-directory") fs.writeFileSync(path.join(source, "node"), "base\n");
  else { fs.mkdirSync(path.join(source, "node")); fs.writeFileSync(path.join(source, "node/value.txt"), "base\n"); }
  initGitRepo(source);
  if (scenario === "case-rename") execFileSync("git", ["-C", source, "mv", "Value.txt", "value.txt"]);
  else if (scenario === "file-to-directory") {
    execFileSync("git", ["-C", source, "rm", "node"]); fs.mkdirSync(path.join(source, "node")); fs.writeFileSync(path.join(source, "node/value.txt"), "new\n");
  } else {
    execFileSync("git", ["-C", source, "rm", "node/value.txt"]); fs.writeFileSync(path.join(source, "node"), "new\n");
  }
  const stat = fs.statSync(source), session = { id: "source", cwdReal: source, cwdDev: stat.dev, cwdIno: stat.ino } as Session;
  const manager = new WorkCopyManager({ worktreeRoot: path.join(root, "copies"), protectedRoots: () => [], execute: async input => {
    try { return { isError: false, content: execFileSync("/bin/sh", ["-c", input.command], { cwd: input.workspace }).toString() }; }
    catch (error) { const failed = error as { stdout?: unknown; stderr?: unknown }; return { isError: true, content: String(failed.stdout ?? ""), errorMessage: String(failed.stderr ?? "") }; }
  } });
  let status = "accepted", message = "";
  try { await manager.prepareWriteTarget(".", session, "probe", "parent"); }
  catch (error) { status = (error as { code?: string }).code ?? "unknown"; message = (error as Error).message; }
  process.stdout.write(JSON.stringify({ root, scenario, status, message, sourceFiles: fs.readdirSync(source).filter(name => name !== ".git") }) + "\n");
}
