import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { execFileSync } from "node:child_process";
import { WorkCopyManager } from "@ruukoto/runtime/work-copy.ts";
import type { Session, WorkDelegation } from "@ruukoto/core/types.ts";
import { initGitRepo } from "../test/helpers/git-fixture.ts";

for (const scenario of ["new-symlink", "retarget-symlink", "add-executable", "remove-executable"] as const) {
  const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "ruukoto-git-config-review-")));
  const source = path.join(root, "source");
  fs.mkdirSync(source);
  fs.writeFileSync(path.join(source, "value.txt"), "base\n");
  fs.writeFileSync(path.join(source, "other.txt"), "other\n");
  if (scenario === "retarget-symlink") fs.symlinkSync("value.txt", path.join(source, "link"));
  if (scenario === "remove-executable") fs.chmodSync(path.join(source, "value.txt"), 0o755);
  initGitRepo(source);
  execFileSync("git", ["-C", source, "config", scenario.includes("symlink") ? "core.symlinks" : "core.filemode", "false"]);
  const stat = fs.statSync(source);
  const session = { id: "source", cwdReal: source, cwdDev: stat.dev, cwdIno: stat.ino } as Session;
  const manager = new WorkCopyManager({ worktreeRoot: path.join(root, "copies"), protectedRoots: () => [], execute: async input => ({ isError: false,
    content: execFileSync("/bin/sh", ["-c", input.command], { cwd: input.workspace }).toString() }) });
  const target = await manager.prepareWriteTarget(".", session, "probe", "parent");
  if (target.kind !== "worktree") throw new Error("expected Git copy");
  const work = { id: "probe", writeTarget: target } as WorkDelegation;
  if (scenario === "new-symlink") fs.symlinkSync("value.txt", path.join(target.path, "link"));
  if (scenario === "retarget-symlink") { fs.unlinkSync(path.join(target.path, "link")); fs.symlinkSync("other.txt", path.join(target.path, "link")); }
  if (scenario === "add-executable") fs.chmodSync(path.join(target.path, "value.txt"), 0o755);
  if (scenario === "remove-executable") fs.chmodSync(path.join(target.path, "value.txt"), 0o644);
  const result = await manager.integrate({ work, target, parentTaskId: "parent", parentSession: session });
  const file = path.join(source, scenario.includes("symlink") ? "link" : "value.txt"), resultStat = fs.lstatSync(file);
  process.stdout.write(JSON.stringify({ root, scenario, state: result.state, isSymlink: resultStat.isSymbolicLink(), executable: Boolean(resultStat.mode & 0o111),
    actual: resultStat.isSymbolicLink() ? fs.readlinkSync(file) : fs.readFileSync(file, "utf8"), expectedSymlink: scenario.includes("symlink"),
    expectedExecutable: scenario === "add-executable" }) + "\n");
}
