import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { execFileSync } from "node:child_process";
import { WORKSPACE_SNAPSHOT_SCRIPT } from "@ruukoto/runtime/workspace-snapshot-script.ts";
import { initGitRepo } from "../test/helpers/git-fixture.ts";

const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "ruukoto-promisor-review-")));
const origin = path.join(root, "origin"), source = path.join(root, "source"), repository = path.join(root, "private");
fs.mkdirSync(origin);
fs.writeFileSync(path.join(origin, "value.txt"), "head-only-blob\n");
initGitRepo(origin);
execFileSync("git", ["-C", origin, "config", "uploadpack.allowFilter", "true"]);
execFileSync("git", ["clone", "-q", "--filter=blob:none", "--no-checkout", `file://${origin}`, source]);
execFileSync("git", ["-C", source, "read-tree", "HEAD"]);
fs.writeFileSync(path.join(source, "value.txt"), "unstaged-current\n");
const files = (directory: string): string[] => fs.readdirSync(directory, { recursive: true }).map(String).sort();
const before = files(path.join(source, ".git", "objects"));
let status = "accepted", stdout = "";
try { stdout = execFileSync(process.execPath, ["-e", WORKSPACE_SNAPSHOT_SCRIPT, "capture", JSON.stringify({ source, gitdir: repository, index: path.join(repository, "capture-index") })]).toString(); }
catch (error) { status = "rejected"; stdout = String((error as { stdout?: unknown }).stdout ?? ""); }
const after = files(path.join(source, ".git", "objects"));
process.stdout.write(JSON.stringify({ root, status, sourceObjectFilesBefore: before, sourceObjectFilesAdded: after.filter(file => !before.includes(file)), stdout: stdout.trim() }) + "\n");
