import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { execFileSync } from "node:child_process";
import { WorkCopyManager } from "@ruukoto/runtime/work-copy.ts";
import type { Session, WorkDelegation } from "@ruukoto/core/types.ts";
import { initGitRepo } from "../test/helpers/git-fixture.ts";

const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "ruukoto-staged-closure-review-")));
const source = path.join(root, "source");
fs.mkdirSync(source);
fs.writeFileSync(path.join(source, "value.txt"), "base\n");
initGitRepo(source);
const git = (...args: string[]) => execFileSync("git", ["-C", source, ...args]).toString().trim();
fs.writeFileSync(path.join(source, "value.txt"), "staged-only\n");
git("add", "value.txt");
const staged = git("rev-parse", ":value.txt");
fs.writeFileSync(path.join(source, "value.txt"), "unstaged-current\n");
const st = fs.statSync(source);
const session = { id: "source", cwdReal: source, cwdDev: st.dev, cwdIno: st.ino } as Session;
const manager = new WorkCopyManager({ worktreeRoot: path.join(root, "copies"), protectedRoots: () => [], execute: async input => ({ isError: false,
  content: execFileSync("/bin/sh", ["-c", input.command], { cwd: input.workspace }).toString() }) });
const target = await manager.prepareWriteTarget(".", session, "probe", "parent");
if (target.kind !== "worktree") throw new Error("expected Git copy");
const work = { id: "probe", writeTarget: target } as WorkDelegation;
const privateObject = path.join(target.snapshot.repository.path, "objects", staged.slice(0, 2), staged.slice(2));
const index = fs.readFileSync(path.join(target.snapshot.repository.path, "ruukoto-source-index"));
const objectExists = fs.existsSync(privateObject);
fs.unlinkSync(privateObject);
let preflight = "accepted", freeze = "accepted";
try { manager.assertCopy(work, target, "review"); }
catch (error) { preflight = (error as { code?: string }).code ?? "unknown"; }
try { await manager.freeze({ work, target, parentTaskId: "parent" }); }
catch (error) { freeze = (error as { code?: string }).code ?? "unknown"; }
process.stdout.write(JSON.stringify({ root, stagedObject: staged, indexReferencesStaged: index.includes(Buffer.from(staged, "hex")), stagedObjectInitiallyPresent: objectExists,
  preflight, freeze, sourceBytes: fs.readFileSync(path.join(source, "value.txt"), "utf8") }) + "\n");
