import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { execFileSync } from "node:child_process";
import { WORKSPACE_SNAPSHOT_SCRIPT } from "@ruukoto/runtime/workspace-snapshot-script.ts";
import { initGitRepo } from "../test/helpers/git-fixture.ts";

const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "ruukoto-template-review-")));
const source = path.join(root, "source"), repository = path.join(root, "private"), template = path.join(root, "template");
fs.mkdirSync(source);
fs.writeFileSync(path.join(source, "value.txt"), "base\n");
initGitRepo(source);
const oid = execFileSync("git", ["-C", source, "rev-parse", ":value.txt"]).toString().trim();
const sourceObject = path.join(source, ".git/objects", oid.slice(0, 2), oid.slice(2));
fs.utimesSync(sourceObject, new Date("2000-01-01"), new Date("2000-01-01"));
fs.mkdirSync(path.join(template, "objects/info"), { recursive: true });
fs.writeFileSync(path.join(template, "objects/info/alternates"), path.join(source, ".git/objects") + "\n");
const before = fs.statSync(sourceObject).mtimeMs;
let status = "accepted", stdout = "";
try { stdout = execFileSync(process.execPath, ["-e", WORKSPACE_SNAPSHOT_SCRIPT, "capture", JSON.stringify({ source, gitdir: repository, index: path.join(repository, "capture-index") })],
  { env: { ...process.env, GIT_TEMPLATE_DIR: template } }).toString(); }
catch (error) { status = "rejected"; stdout = String((error as { stdout?: unknown }).stdout ?? ""); }
process.stdout.write(JSON.stringify({ root, status, templateAlternatesCopied: fs.existsSync(path.join(repository, "objects/info/alternates")),
  sourceObjectMtimeBefore: before, sourceObjectMtimeAfter: fs.statSync(sourceObject).mtimeMs, stdout: stdout.trim() }) + "\n");
