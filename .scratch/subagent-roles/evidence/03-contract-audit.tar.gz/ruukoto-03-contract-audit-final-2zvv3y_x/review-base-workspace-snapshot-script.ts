/** 宿主固定脚本只在工作进程内运行 Git；原始内容不经过仓库过滤器。
 * Note: 见 .agents/notes/implemented/architecture/2026-10-15-current-workspace-snapshots.md
 */
export const WORKSPACE_SNAPSHOT_SCRIPT = `
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { createHash } = require('node:crypto');
const { isUtf8 } = require('node:buffer');

const baseEnv = { ...process.env, GIT_OPTIONAL_LOCKS: '0', GIT_NO_REPLACE_OBJECTS: '1' };
for (const key of ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_COMMON_DIR']) delete baseEnv[key];
function fail(code, message) { const error = new Error(message); error.code = code; throw error; }
function git(args, env = baseEnv, input) {
  const result = spawnSync('git', ['-c', 'core.fsmonitor=false', '-c', 'core.hooksPath=/dev/null', ...args], { env, input, maxBuffer: 64 * 1024 * 1024 });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(\`git failed (\${result.status}): \${result.stderr.toString().trim()}\`);
  return result.stdout;
}
function parsePaths(bytes) {
  if (!isUtf8(bytes)) fail('snapshot_unsupported', '文件名不是 UTF-8，请使用 UTF-8 名字后重新准备目标');
  return bytes.toString('utf8').split('\\0').filter(Boolean);
}
function treeEntries(gitdir, tree) {
  const entries = new Map();
  for (const item of parsePaths(git(['--git-dir', gitdir, 'ls-tree', '-r', '-z', tree]))) {
    const tab = item.indexOf('\\t');
    const [mode, type, oid] = item.slice(0, tab).split(' ');
    if (type !== 'blob') fail('snapshot_unsupported', '目标含嵌套 Git 或子模块，请拆分目标后委派');
    entries.set(item.slice(tab + 1), { mode, oid });
  }
  return entries;
}
function safePath(root, name) {
  const resolved = path.resolve(root, name);
  if (!resolved.startsWith(root + path.sep) || name.split('/').some(part => part === '.git' || part === '..')) fail('snapshot_unsupported', '基线含越界路径，请保留现场并报告拥有者');
  const parts = name.split('/');
  for (let i = 1; i < parts.length; i += 1) {
    let st;
    try { st = fs.lstatSync(path.join(root, ...parts.slice(0, i))); }
    catch (error) { if (error.code === 'ENOENT') return resolved; throw error; }
    if (!st.isDirectory() || st.isSymbolicLink()) fail('snapshot_changed', '文件的父目录已变化或指向来源外，请重新准备目标');
  }
  return resolved;
}
function payloadAt(root, name) {
  const resolved = safePath(root, name);
  let st;
  try { st = fs.lstatSync(resolved); }
  catch (error) { if (error.code === 'ENOENT') return null; throw error; }
  if (st.isSymbolicLink()) return { mode: '120000', bytes: fs.readlinkSync(resolved, { encoding: 'buffer' }) };
  if (!st.isFile()) fail('snapshot_unsupported', '目标含非普通文件或嵌套仓库，请拆分目标后委派');
  return { mode: (st.mode & 0o111) === 0 ? '100644' : '100755', bytes: fs.readFileSync(resolved) };
}
function rawTree(source, gitdir, index, seedTree) {
  const env = { ...baseEnv, GIT_INDEX_FILE: index };
  // 写对象时不使用来源对象或 alternates，避免刷新来源 loose object 的修改时间。
  git(['--git-dir', gitdir, 'read-tree', '--empty'], env);
  const names = new Set(parsePaths(git(['-C', source, '-c', 'core.untrackedCache=false', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'])));
  if (seedTree) for (const name of treeEntries(gitdir, seedTree).keys()) names.add(name);
  else {
    for (const item of parsePaths(git(['-C', source, 'ls-tree', '-r', '-z', 'HEAD']))) {
      const tab = item.indexOf('\\t');
      if (item.slice(0, tab).split(' ')[1] !== 'blob') fail('snapshot_unsupported', '目标含子模块，请拆分目标后委派');
      names.add(item.slice(tab + 1));
    }
  }
  const records = [];
  for (const name of [...names].sort()) {
    const current = payloadAt(source, name);
    if (!current) continue;
    const oid = git(['--git-dir', gitdir, 'hash-object', '--no-filters', '-w', '--stdin'], env, current.bytes).toString().trim();
    records.push(Buffer.from(\`\${current.mode} \${oid}\\t\${name}\\0\`));
  }
  git(['--git-dir', gitdir, 'update-index', '-z', '--index-info'], env, Buffer.concat(records));
  return git(['--git-dir', gitdir, 'write-tree'], env).toString().trim();
}
function materialize(tree, gitdir, destination) {
  for (const [name, item] of treeEntries(gitdir, tree)) {
    const target = safePath(destination, name);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const bytes = git(['--git-dir', gitdir, 'cat-file', 'blob', item.oid]);
    if (item.mode === '120000') fs.symlinkSync(bytes, target);
    else {
      fs.writeFileSync(target, bytes, { flag: 'wx', mode: item.mode === '100755' ? 0o755 : 0o644 });
      fs.chmodSync(target, item.mode === '100755' ? 0o755 : 0o644);
    }
  }
}
function checkAffected(source, gitdir, baselineTree, childTree) {
  const baseline = treeEntries(gitdir, baselineTree);
  const final = treeEntries(gitdir, childTree);
  const names = parsePaths(git(['--git-dir', gitdir, 'diff', '--name-only', '-z', '--no-ext-diff', '--no-textconv', '--no-renames', baselineTree, childTree]));
  let matchesBaseline = true;
  let matchesFinal = true;
  const mismatches = [];
  for (const name of names) {
    const current = payloadAt(source, name);
    const actual = current && { mode: current.mode, oid: createHash('sha1').update(\`blob \${current.bytes.length}\\0\`).update(current.bytes).digest('hex') };
    const same = expected => actual === null ? expected === undefined : expected?.mode === actual.mode && expected.oid === actual.oid;
    const baseMatches = same(baseline.get(name));
    const finalMatches = same(final.get(name));
    matchesBaseline &&= baseMatches;
    matchesFinal &&= finalMatches;
    if (!baseMatches && !finalMatches) mismatches.push(name);
  }
  return { state: matchesBaseline ? 'baseline' : matchesFinal ? 'already' : 'conflict', files: names, mismatches };
}

function fingerprint(source, indexCopy) {
  const head = git(['-C', source, 'rev-parse', '--verify', 'HEAD']).toString().trim();
  const indexPath = git(['-C', source, 'rev-parse', '--path-format=absolute', '--git-path', 'index']).toString().trim();
  const stat = fs.statSync(source);
  const commonGitPath = fs.realpathSync(git(['-C', source, 'rev-parse', '--path-format=absolute', '--git-common-dir']).toString().trim());
  let index = Buffer.alloc(0);
  try { index = fs.readFileSync(indexPath); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  if (indexCopy) fs.writeFileSync(indexCopy, index, { flag: 'wx', mode: 0o600 });
  return { head, commonGitPath, indexDigest: createHash('sha256').update(index).digest('hex'), dev: stat.dev, ino: stat.ino };
}
try {
const action = process.argv[1];
const input = JSON.parse(process.argv[2]);
if (process.argv[3]) input.childTree = process.argv[3];
if (action === 'capture') {
  git(['init', '--bare', '-q', input.gitdir]);
  const before = fingerprint(input.source, path.join(input.gitdir, 'ruukoto-source-index'));
  const tree = rawTree(input.source, input.gitdir, input.index);
  const afterTree = rawTree(input.source, input.gitdir, input.index);
  for (const item of parsePaths(git(['-C', input.source, 'ls-files', '--stage', '-z']))) {
    const oid = item.split(' ')[1];
    const file = path.join(input.gitdir, 'objects', oid.slice(0, 2), oid.slice(2));
    if (!fs.existsSync(file)) {
      const bytes = git(['-C', input.source, 'cat-file', 'blob', oid]);
      git(['--git-dir', input.gitdir, 'hash-object', '--no-filters', '-w', '--stdin'], baseEnv, bytes);
    }
  }
  const after = fingerprint(input.source);
  if (tree !== afterTree || JSON.stringify(before) !== JSON.stringify(after)) fail('snapshot_changed', '捕获期间来源已变化，请重新准备目标');
  fs.writeFileSync(path.join(input.gitdir, 'ruukoto-baseline'), JSON.stringify({ ...before, tree }) + '\\n', { flag: 'wx', mode: 0o600 });
  process.stdout.write('RUUKOTO_SNAPSHOT=' + JSON.stringify({ ...before, tree }) + '\\n');
} else {
  for (const name of ['commondir', 'gitdir', 'objects/info/alternates']) if (fs.existsSync(path.join(input.gitdir, name))) fail('snapshot_corrupt', '私有基线含外部 Git 指向，请保留副本并报告拥有者');
  const inspectObjects = directory => {
    const stat = fs.lstatSync(directory);
    if (!stat.isDirectory() || stat.isSymbolicLink()) fail('snapshot_corrupt', '基线对象目录含路径别名，请保留副本并报告拥有者');
    for (const name of fs.readdirSync(directory)) {
      const file = path.join(directory, name), stat = fs.lstatSync(file);
      if (stat.isDirectory()) inspectObjects(file);
      else if (!stat.isFile() || stat.nlink !== 1) fail('snapshot_corrupt', '基线对象含文件别名，请保留副本并报告拥有者');
    }
  };
  inspectObjects(path.join(input.gitdir, 'objects'));
  git(['--git-dir', input.gitdir, 'fsck', '--full', '--no-reflogs', '--no-dangling', '--no-progress']);
  if (action === 'tree') process.stdout.write(rawTree(input.source, input.gitdir, input.index, input.seedTree) + '\\n');
  else if (action === 'materialize') materialize(input.tree, input.gitdir, input.destination);
  else if (action === 'check') {
    const result = checkAffected(input.source, input.gitdir, input.baselineTree, input.childTree);
    fs.writeFileSync(input.report, JSON.stringify(result) + '\\n', { mode: 0o600 });
    process.stdout.write(result.state + '\\n');
  }
  else fail('snapshot_invalid', '未知宿主快照操作');
}
} catch (error) {
  process.stderr.write('[ruukoto:workspace-snapshot] ' + error.message + '\\n');
  process.stdout.write('RUUKOTO_SNAPSHOT_ERROR=' + JSON.stringify({ code: error.code || 'snapshot_failed', message: error.message }) + '\\n');
  process.exitCode = 1;
}
`;
