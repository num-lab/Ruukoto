from pathlib import Path
import subprocess
script=Path('packages/runtime/src/workspace-snapshot-script.ts')
saved=script.read_bytes()
try:
    script.write_bytes(Path('case-baseline/packages/runtime/src/workspace-snapshot-script.ts').read_bytes())
    with Path('snapshot-path-kind-withdrawal.log').open('wb') as log:
        result=subprocess.run(['npx','tsx','--test','--test-name-pattern=(大小写|file-to-directory|directory-to-file|directory-to-link)','test/workspace-snapshots.test.ts'],stdout=log,stderr=subprocess.STDOUT)
    print('withdrawal_exit='+str(result.returncode))
finally:
    script.write_bytes(saved)
