# File bind 来源只读修复

补丁 `file-bind-fix.patch` 仅改 native.ts、approved-ops.ts 与 subagent-execution-core.test.ts。native 对全部普通文件以 dev/ino 保存访问等级，不再以 nlink > 1 决定是否核实同一对象的混读写权限；现有目录 inode、防环、物理目录条目与硬链接闭合逻辑保留。isProtectedPath 与 approved 执行器复用 identityCovers 的正向保护子树核实，对已有目标及其祖先的 inode 在保护根无 symlink 递归中比对，故目录 bind 下的新文件也被拒绝。assertGrantNotProtected 的反向祖先核实不递归授予树，不扫描 /usr。

## 证据

- 离线撤去 approved-ops 修复：`unit-red.log` 的 source-protect 用例失败；修复：`unit-green-final.log` 26/26（subagent-execution-core、101-native、08-approvals）。真实源文件、hardlink 和保护根 symlink 使用 OS 对象，没有 nlink/mock 模拟。
- 真 Linux fixture 由 `file-bind-regression.mts` 使用 sudo mount 创建 bind alias，worker 仍正式 confirm native 低权限身份。file alias 源与 alias dev/ino 相同且 nlink=1；原代码 approved-host 与真实 native write 均成功改源，active alias 在已启动 worker 后也真改源。修复后启动与 active call 拒绝 execution_unavailable/sandbox_rejected，approved-host 拒绝，源内容原样；无 alias 的副本检查产物写入与来源读取成功。empty-dir bind：native 旧 guard 已拒绝，host 在原代码新建真实源文件，修复后拒绝且源目录仍空。脚本分别断言 red/green 预期，所有执行单元 stopVerified=true，所有 host bind 均已 umount；fixture 保留。绿/红日志与 report 已分别取回：bind-green.log、bind-red.log、bind-green-report.json、bind-red-report.json。
- 输入三文件 base/fixed SHA 与脚本 SHA 见 `inputsha.json`。remote复本 `/tmp/ruukoto-03-filebind-fix.ghkB2C/repo`；green fixture `/tmp/rk03-bind-regression-ObicW6`；red fixture `/tmp/rk03-bind-regression-i03N61`。
- 独立审查 snapshot_probe 无新增契约发现，core 2/2；其成本证据 `/tmp/snapshot-final-filebind-cost.json` 与独立测试 `/tmp/snapshot-final-nonauthor-filebind-core-tests.log`。
- check:static 的 lint 通过，根/agent typecheck 均被当时合并对象既有 `packages/runtime/src/work-copy.ts:105` Buffer 泛型赋值错误阻断，见 static.log、agent-typecheck.log；这不属于本三文件修复，不记 typecheck 通过。最终主仓须重跑静态。

## 成本与失败边界

每次正向宿主保护检查，若文本/祖先身份未命中，lstat 保护根的所有可达节点并读取所有目录；不跟随子 symlink，按目录 dev/ino 去重以防 bind 环，不缓存。成本 O(保护树节点数 + 目标深度)，空间 O(已见目录 + 待遍历节点)。本仓真实保护根 62,985 文件 + 6,370 目录，三次不关联 isProtectedPath 为 278/278/280ms；多个根、fileOpScope、执行器与 native 授权准备各次调用会累计成本。目录子项 lstat、readdir 或 realpath 失败传播给现有调用边界：scope 返回校验错误，approved 返回失败且尚未写入，native prepare 转 execution_unavailable；不会跳过无法读取的子树。保护根本身不存在沿用原 helper 的 false 行为，未新增 root 必存在契约。

R5 覆盖来源、materials、sharedGit、privateSnapshot 等显式 readonly roots 的 bind/hardlink/目录别名与宿主文件绕行。旧的额外前提是 privileged 外部 actor 预先把后台全局 protectedRoots 的子文件 bind 到 workspace，而该全局根不在显式 mounts/readRoots；native 全文件图看不到只读端，目录 grant 的根身份也不会命中子文件身份。这与普通 host 文件保护现已拒绝的路径不同，本补丁不把它作为 native 已通过范围；parent 明确另记后续，不扩成全宿主挂载树交集扫描。

## 旧 Git promisor 补充

`promisor/` 保存 Git 2.43.0、Node v24.21.0 真 partial-clone 前后逐项 `.git` manifest 和报告。blob:none --no-checkout 后仅 read-tree HEAD，再把工作文件手工改为 unstaged-current，缺失原blob由portable source-object只读视图拒绝；capture 返回 snapshot_failed/bad file。来源 `.git` 46项 bytes/mode/mtimeNs/size 前后完全相同、added=[]、无新增pack；工作文件仍是 unstaged-current。fixture `/tmp/rk03-promisor-regression-muP80h` 保留；并未将旧 Git 是否识别 GIT_NO_LAZY_FETCH 当成证明。

额外 global 旧威胁也由 fixed 代码真实复现，独立 fixture `/tmp/rk03-global-bind-oldgap-A77lRm`；`out-of-r5-global/` 保存日志与报告，ordinary approved-host 拒绝、无 explicit readRoot 的 confirm native 实际改源，stopVerified=true、host mount 已卸载。它不污染 R5 成功项。
