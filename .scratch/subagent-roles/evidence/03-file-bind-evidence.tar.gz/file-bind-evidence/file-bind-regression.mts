import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import { createNativeLauncher } from './packages/agent/src/execution/native.ts';
import { ToolWorkerHost } from './packages/agent/src/tool-worker/host.ts';
import { executeApprovedFileOp, isProtectedPath, sha256Hex } from './packages/agent/src/execution/approved-ops.ts';

const expected = process.argv[2];
assert.ok(process.platform === 'linux' && (expected === 'red' || expected === 'green'));
const fixed = expected === 'green';
const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'rk03-bind-regression-')));
const source = path.join(root, 'source'), work = path.join(root, 'work');
fs.mkdirSync(source); fs.mkdirSync(work);
const original = path.join(source, 'value'), fileAlias = path.join(work, 'mounted-file'), empty = path.join(source, 'empty'), dirAlias = path.join(work, 'mounted-directory');
fs.writeFileSync(original, 'original-source\n'); fs.writeFileSync(fileAlias, 'alias-placeholder\n'); fs.mkdirSync(empty); fs.mkdirSync(dirAlias);
const cases: Array<Record<string, unknown>> = [];
const record = (name: string, details: unknown) => { cases.push({name, details}); process.stdout.write(JSON.stringify(cases.at(-1)) + '\n'); };
const mounted = new Set<string>();
const mount = (from: string, to: string) => { execFileSync('sudo', ['-n', 'mount', '--bind', from, to]); mounted.add(to); };
const unmount = (target: string) => { execFileSync('sudo', ['-n', 'umount', target]); mounted.delete(target); };
const statId = (target: string) => { const st = fs.statSync(target); return {path: target, dev: st.dev, ino: st.ino, nlink: st.nlink}; };
const spec = {taskId: `bind-regression-${process.pid}`, mode: 'confirm' as const, workspace: work, workspaceIdentity: statId(work), grantedPaths: [], readRoots: [statId(source)]};
let host: ToolWorkerHost | null = null;
const stop = async () => { if (!host) return; const stopped = await host.stop(); record('stop_verified', {stopped}); assert.equal(stopped, true); host = null; };
const fileOp = (target: string, sourceProtection: boolean, access: 'read' | 'read_write') => { const exists = fs.existsSync(target), st = fs.statSync(exists ? target : path.dirname(target)); return executeApprovedFileOp({path: target, access, content: access === 'read_write' ? 'approved-host-through-bind\n' : undefined, targetDev: st.dev, targetIno: st.ino, originalSha256: exists ? sha256Hex(fs.readFileSync(target)) : null, protectedRoots: sourceProtection ? [] : [source], writeProtectedRoots: sourceProtection ? [source] : []}); };
const rejection = (error: unknown) => { const e = error as {code?: string; reason?: string; message?: string}; return {code:e.code, reason:e.reason, message:e.message}; };
try {
  mount(original, fileAlias);
  const a = statId(original), b = statId(fileAlias);
  assert.equal(a.dev, b.dev); assert.equal(a.ino, b.ino); assert.equal(a.nlink, 1); assert.equal(b.nlink, 1);
  record('file_bind_nlink_1_identity', {source:a, alias:b});
  const protectedPath = isProtectedPath(fileAlias, [source]); assert.equal(protectedPath, fixed); record('shared_guard_file_alias', {protectedPath});
  const ordinary = fileOp(fileAlias, false, 'read'); assert.equal(ordinary.ok, !fixed); record('ordinary_host_read_alias', ordinary);
  const approved = fileOp(fileAlias, true, 'read_write'); assert.equal(approved.ok, !fixed);
  assert.equal(fs.readFileSync(original, 'utf8'), fixed ? 'original-source\n' : 'approved-host-through-bind\n');
  record('approved_host_source_write_alias', {outcome:approved, actualSource:fs.readFileSync(original, 'utf8')});
  fs.writeFileSync(original, 'original-source\n');
  host = ToolWorkerHost.create(createNativeLauncher(), spec);
  let startError: unknown;
  try { await host.start(); } catch(error) { startError = error; }
  if (fixed) { assert.equal(rejection(startError).code, 'execution_unavailable'); assert.equal(rejection(startError).reason, 'sandbox_rejected'); }
  else {
    assert.equal(startError, undefined);
    const result = await host.call({name:'write',params:{path:fileAlias,content:'native-through-bind\n'},opId:'bind-write',sdkCallId:'bind-write',timeoutMs:15_000});
    assert.equal(result.isError, false); assert.equal(fs.readFileSync(original, 'utf8'), 'native-through-bind\n'); record('unfixed_native_actual_write', {result, actualSource:fs.readFileSync(original, 'utf8')});
  }
  if (fixed) assert.equal(fs.readFileSync(original, 'utf8'), 'original-source\n');
  record('preexisting_native_file_alias', {started:!startError, error:startError ? rejection(startError) : null, actualSource:fs.readFileSync(original, 'utf8')});
  await stop(); unmount(fileAlias); fs.writeFileSync(original, 'original-source\n');

  host = ToolWorkerHost.create(createNativeLauncher(), spec); await host.start();
  const artifact = await host.call({name:'write',params:{path:'check.txt',content:'check-output\n'},opId:'artifact',sdkCallId:'artifact',timeoutMs:15_000});
  assert.equal(artifact.isError, false); assert.equal(fs.readFileSync(path.join(work, 'check.txt'),'utf8'),'check-output\n');
  const sourceRead = await host.call({name:'read',params:{path:original},opId:'read',sdkCallId:'read',timeoutMs:15_000}); assert.equal(sourceRead.isError, false); record('control_copy_write_source_read', {artifact, sourceRead});
  mount(original, fileAlias);
  let callError: unknown, callResult: unknown;
  try { callResult = await host.call({name:'write',params:{path:fileAlias,content:'active-through-bind\n'},opId:'active-bind',sdkCallId:'active-bind',timeoutMs:15_000}); } catch(error) { callError = error; }
  assert.equal(Boolean(callError), fixed); if (fixed) { assert.equal(rejection(callError).code,'execution_unavailable'); assert.equal(fs.readFileSync(original,'utf8'),'original-source\n'); }
  record('active_native_recheck_file_alias', {error:callError ? rejection(callError) : null, result:callResult, actualSource:fs.readFileSync(original,'utf8')});
  await stop(); unmount(fileAlias); fs.writeFileSync(original, 'original-source\n');

  mount(empty, dirAlias);
  assert.equal(statId(empty).ino,statId(dirAlias).ino);
  const target = path.join(dirAlias,'new.txt');
  const dirProtected = isProtectedPath(target,[source]); assert.equal(dirProtected, fixed); record('shared_guard_new_file_in_directory_alias',{dirProtected});
  const newFile = fileOp(target,true,'read_write'); assert.equal(newFile.ok,!fixed); assert.equal(fs.existsSync(path.join(empty,'new.txt')),!fixed); record('approved_host_empty_directory_alias',{outcome:newFile, actualSourceFiles:fs.readdirSync(empty)});
  if (!fixed) fs.unlinkSync(path.join(empty,'new.txt'));
  host = ToolWorkerHost.create(createNativeLauncher(), spec);
  let dirError: unknown; try { await host.start(); } catch(error) {dirError = error;}
  assert.equal(rejection(dirError).code,'execution_unavailable'); assert.equal(rejection(dirError).reason,'sandbox_rejected'); assert.deepEqual(fs.readdirSync(empty),[]);
  record('preexisting_empty_directory_alias_native_rejected',{error:rejection(dirError), actualSourceFiles:fs.readdirSync(empty)}); await stop(); unmount(dirAlias);
  assert.equal(fs.readFileSync(original,'utf8'),'original-source\n'); record('all_expected_results',{expected, actualSource:'original-source\n', sourceEmpty:fs.readdirSync(empty)});
} catch(error) { record('probe_failed',{...rejection(error),stack:(error as Error).stack}); process.exitCode=1; }
finally {
  if(host) { const stopped=await host.stop(); record('finally_stop_verified',{stopped}); if(!stopped) process.exitCode=1; }
  for(const target of mounted) { execFileSync('sudo',['-n','umount',target]); record('finally_unmounted',{target}); }
  fs.writeFileSync(path.join(root,'report.json'),JSON.stringify({root,expected,platform:process.platform,node:process.version,cases},null,2)+'\n'); process.stdout.write(JSON.stringify({report:path.join(root,'report.json')})+'\n');
}
