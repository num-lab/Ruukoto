import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createNativeLauncher} from './packages/agent/src/execution/native.ts';
import {ToolWorkerHost} from './packages/agent/src/tool-worker/host.ts';
import {executeApprovedFileOp,sha256Hex} from './packages/agent/src/execution/approved-ops.ts';
const root=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'rk03-global-bind-oldgap-'))),source=path.join(root,'global-protected'),work=path.join(root,'work');fs.mkdirSync(source);fs.mkdirSync(work);
const original=path.join(source,'value'),alias=path.join(work,'alias');fs.writeFileSync(original,'original-global-protected\n');fs.writeFileSync(alias,'placeholder\n');
let mounted=false,host:ToolWorkerHost|null=null;const report:Record<string,unknown>={root,scope:'OUT_OF_R5: protectedRoots exists only as global deny tree; not supplied as explicit readonly mount/readRoot',fixedGuards:true};
try{
 execFileSync('sudo',['-n','mount','--bind',original,alias]);mounted=true;const a=fs.statSync(original),b=fs.statSync(alias),w=fs.statSync(work);assert.equal(a.dev,b.dev);assert.equal(a.ino,b.ino);assert.equal(a.nlink,1);report.identity={dev:a.dev,ino:a.ino,nlink:a.nlink};
 const approved=executeApprovedFileOp({path:alias,access:'read_write',content:'host-forbidden\n',targetDev:b.dev,targetIno:b.ino,originalSha256:sha256Hex(fs.readFileSync(alias)),protectedRoots:[source]});assert.equal(approved.ok,false);report.approvedHostRejected=approved;
 host=ToolWorkerHost.create(createNativeLauncher({protectedRoots:[source]}),{taskId:'out-of-r5-global-bind',mode:'confirm',workspace:work,workspaceIdentity:{dev:w.dev,ino:w.ino},grantedPaths:[]});await host.start();
 const result=await host.call({name:'write',params:{path:alias,content:'native-global-deny-oldgap\n'},opId:'write',sdkCallId:'write',timeoutMs:15000});assert.equal(result.isError,false);assert.equal(fs.readFileSync(original,'utf8'),'native-global-deny-oldgap\n');report.nativeResult=result;report.actualGlobalProtectedSource=fs.readFileSync(original,'utf8');
}catch(error){const e=error as {code?:string;reason?:string;stack?:string};report.error={code:e.code,reason:e.reason,stack:e.stack};process.exitCode=1;}
finally{if(host){report.stopVerified=await host.stop();if(!report.stopVerified)process.exitCode=1;}if(mounted){execFileSync('sudo',['-n','umount',alias]);report.unmounted=true;}fs.writeFileSync(path.join(root,'report.json'),JSON.stringify(report,null,2)+'\n');process.stdout.write(JSON.stringify(report)+'\n');}
