import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { WORKSPACE_SNAPSHOT_SCRIPT } from './packages/runtime/src/workspace-snapshot-script.ts';
import { initGitRepo } from './test/helpers/git-fixture.ts';
const root=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'rk03-promisor-regression-'))), origin=path.join(root,'origin'),source=path.join(root,'source'),repository=path.join(root,'private');
fs.mkdirSync(origin);fs.writeFileSync(path.join(origin,'value.txt'),'head-only-blob\n');initGitRepo(origin);
execFileSync('git',['-C',origin,'config','uploadpack.allowFilter','true']);
execFileSync('git',['clone','-q','--filter=blob:none','--no-checkout',`file://${origin}`,source]);
execFileSync('git',['-C',source,'read-tree','HEAD']);fs.writeFileSync(path.join(source,'value.txt'),'unstaged-current\n');
const manifest=(directory:string) => {
 const result:Record<string,unknown>={};
 const walk=(target:string) => {const stat=fs.lstatSync(target,{bigint:true});const key=path.relative(directory,target)||'.';result[key]={mode:String(stat.mode),mtimeNs:String(stat.mtimeNs),size:String(stat.size),content:stat.isSymbolicLink()?fs.readlinkSync(target):stat.isFile()?crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex'):null};if(stat.isDirectory())for(const name of fs.readdirSync(target).sort())walk(path.join(target,name));};walk(directory);return result;
};
const before=manifest(path.join(source,'.git'));fs.writeFileSync(path.join(root,'before.json'),JSON.stringify(before,null,2)+'\n');
let status='accepted',stdout='',stderr='';
try {stdout=execFileSync(process.execPath,['-e',WORKSPACE_SNAPSHOT_SCRIPT,'capture',JSON.stringify({source,gitdir:repository,index:path.join(repository,'capture-index')})],{stdio:['ignore','pipe','pipe']}).toString();}
catch(error){status='rejected';const e=error as {stdout?:Buffer;stderr?:Buffer};stdout=e.stdout?.toString()??'';stderr=e.stderr?.toString()??'';}
const after=manifest(path.join(source,'.git'));fs.writeFileSync(path.join(root,'after.json'),JSON.stringify(after,null,2)+'\n');
const added=Object.keys(after).filter(key=>!(key in before));
const report={root,status,git:execFileSync('git',['--version']).toString().trim(),node:process.version,stdout,stderr,sourceGitUnchanged:JSON.stringify(before)===JSON.stringify(after),sourceGitEntries:Object.keys(before).length,added};
fs.writeFileSync(path.join(root,'report.json'),JSON.stringify(report,null,2)+'\n');process.stdout.write(JSON.stringify(report)+'\n');
assert.equal(status,'rejected');assert.deepEqual(after,before);assert.equal(fs.readFileSync(path.join(source,'value.txt'),'utf8'),'unstaged-current\n');
