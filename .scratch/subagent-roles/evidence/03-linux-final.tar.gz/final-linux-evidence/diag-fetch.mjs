import fs from 'node:fs';
const nativeFetch = globalThis.fetch;
const path = '/tmp/ruukoto-03-final-linux.Ua1foc/linux-fetch-diagnostic.jsonl';
const chain = error => error && typeof error === 'object' ? {name: error.name, message: error.message, code: error.code, stack: error.stack, cause: error.cause ? chain(error.cause) : undefined} : error;
globalThis.fetch = async function (...args) {
 const input = args[0], url = typeof input === 'string' ? input : input?.url ?? String(input);
 if (!url.startsWith('http://127.0.0.1:')) return Reflect.apply(nativeFetch, this, args);
 const start = Date.now();
 try { const response = await Reflect.apply(nativeFetch, this, args); fs.appendFileSync(path, JSON.stringify({pid: process.pid, started: new Date(start).toISOString(), url, elapsedMs: Date.now()-start, status: response.status})+'\n'); return response; }
 catch(error) { fs.appendFileSync(path, JSON.stringify({pid: process.pid, started: new Date(start).toISOString(), url, elapsedMs: Date.now()-start, error: chain(error)})+'\n'); throw error; }
};
