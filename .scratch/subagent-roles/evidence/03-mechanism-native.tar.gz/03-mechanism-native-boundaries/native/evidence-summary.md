# 03 独立机制核查

核查者只读主检出，所有脚本、副本、夹具与日志位于独立 /tmp；未提交。

## 捕获、登记、增量机制

独立复制并执行 snapshot_probe 修正版 probe.py 与 Node raw-snapshot.mjs/check-node.py，目录为 `/tmp/ruukoto-03-snapshot-independent-Or6V3s`。Python 43/43 通过；Node tree 一致，1374 项物化字节、执行位和符号链接逐项一致。源 Git/worktree 在捕获前后 sha256/mode/mtimeNs/inode/dev 一致；登记仅新增专属 ref/log 与 worktrees/copy 文件，未改已有 Git 文件。原 clean/smudge 过滤器未执行，CRLF/binary 未规范化，冻结增量独立，源 index 保留 staging。同文件不同 hunk 的后续源修改即使 git apply --check 通过，逐文件原基线判定仍拒绝。

原 alternates 对象写入和 add-all/checkout 过滤器反例由原探针保留；修正版完全独立 Git 对象写入，--no-checkout 登记后 raw 字节物化，经本次独立复审无阻断。生产路径若解析 Git NUL 列表为 UTF-8 应先拒绝无效 UTF-8 名字字节，避免 U+FFFD 混淆；普通机制夹具没有这类名字。

## 真实 native 保护

脚本 `repo/native-probe.mts`，macOS 成功日志 `macos-attempt3.log`，Linux 成功日志 `linux-attempt2.log`，报告 `repo/native-darwin-report.json` 与 `native-linux-report.json`。两平台均启动生产 ToolWorkerHost/native，真实 write/bash 能写独立 copy 产物；源码、source index/config、shared worktree index 和外部资料可读但写入拒绝；绝对路径、.. 路径、symlink、活跃与预存 hardlink 拒绝，macOS additionally 核实 /System/Volumes/Data 与大小写路径别名。executeApprovedFileOp 收到既有来源保护根时宿主写入仍拒绝，实际源与外部资料全树字节不变。

LaunchSpec 使用生产 launchSpecFor 计算并显式追加原 source 只读根；source/task/store 记录是夹具，编码工具和 OS 拒绝是真实执行，没有模拟工具结果。批准后宿主写入检查直接执行生产 executeApprovedFileOp，不覆盖审批记录单次消费。共享 Git 与未来 snapshot objects 应同时进入宿主 writeProtectedRoots；只有 native readRoots 无法保护宿主 executor。

前两轮 macOS 失败保留：第一轮错误夹具把 copy 内目录列为来源导致重叠预检拒绝；第二轮依赖 symlink 副本无法在沙箱内解析运行包。第三轮复制独立依赖后通过。Linux npm ci 因 ENOSPC 失败，保留 `npm-ci.log`；复用已安装相同版本依赖的独立硬链接副本，补仅缺少 quickjs 包后验证通过，未改远端生产检出。

## 停止与非 Git 占用

macOS `macos-lifecycle-existing.log` 7/7：真实 helper 未知孤儿停止 false、心跳继续，不误杀；释放夹具后退出。Linux `native-linux-scope-report.json` 3/3：真实 detached 后代停止 true，心跳冻结；快速退出及入口前失败未取得可信 cgroup，停止 false。

macOS 7/7 与 Linux `linux-lifecycle-existing-attempt2.log` 6/6 的最窄现有回归核实真实 worker 在同非 Git 目录让出/重取并实际写字节，父持锁时 direct 子任务排队，false/throws 保留占用、结果和副本。生命周期 false/throws 部分是注入或数据库夹具；平台 false 另由前述真实 OS 探针证明，未把注入项声称为真实模型或真实 native 回收。Linux 首轮缺 quickjs 导入失败日志 `linux-lifecycle-existing.log` 保留。

以上证明所检机制可进入生产接线；尚未证明最终 03 实现，两产品模型入口与审批单次消费未在本任务核查，最终实现须按实际改动重定验证与独立审查范围。
