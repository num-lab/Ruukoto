import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createNativeLauncher, prepareNativeLaunch } from './packages/agent/src/execution/native.ts';
import { ToolWorkerHost } from './packages/agent/src/tool-worker/host.ts';
import { ToolRouter } from './packages/agent/src/tool-router.ts';
import { snapshotSubAgentExecution } from './packages/core/src/subagent-execution.ts';
import { executeApprovedFileOp, sha256Hex } from './packages/agent/src/execution/approved-ops.ts';

const evidence = fs.realpathSync(path.dirname(fileURLToPath(import.meta.url)));
const fixture = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'rk03-protection-fixture-')));
const source = path.join(fixture, 'source'), extra = path.join(fixture, 'extra'), copy = path.join(fixture, 'copy');
const cases: Array<{ name: string; status: string; details?: unknown }> = [];
const record = (name: string, status: string, details?: unknown) => {
  cases.push({name, status, details});
  process.stdout.write(JSON.stringify(cases.at(-1)) + '\n');
};
const git = (cwd: string, ...args: string[]) => execFileSync('git', ['-C', cwd, ...args], {encoding: 'utf8'}).trim();
const quote = (value: string) => "'" + value.replace(/'/g, "'\\''") + "'";
const nodeCommand = (value: string) => `node -e ${quote(value)}`;
const textOf = (result: {content: unknown[]}) => result.content.map((block: any) => block?.text ?? '').join('\n');
const identity = (target: string) => { const stat = fs.statSync(target); return {path: target, dev: stat.dev, ino: stat.ino}; };
const hash = (bytes: Buffer | string) => crypto.createHash('sha256').update(bytes).digest('hex');
function tree(root: string): Record<string, string> {
  const entries: Record<string, string> = {};
  const walk = (dir: string) => {
    for (const name of fs.readdirSync(dir).sort()) {
      const target = path.join(dir, name), stat = fs.lstatSync(target), key = path.relative(root, target);
      if (stat.isDirectory()) walk(target);
      else entries[key] = stat.isSymbolicLink() ? `symlink:${fs.readlinkSync(target)}` : hash(fs.readFileSync(target));
    }
  };
  walk(root); return entries;
}
let host: ToolWorkerHost | null = null;
let safe = true, sequence = 0;
try {
  fs.mkdirSync(source); fs.mkdirSync(extra);
  fs.writeFileSync(path.join(source, 'source.txt'), 'source-original\n');
  fs.writeFileSync(path.join(extra, 'material.txt'), 'extra-original\n');
  git(source, 'init', '-q'); git(source, 'config', 'user.name', 'Probe'); git(source, 'config', 'user.email', 'probe@example.invalid');
  git(source, 'add', '.'); git(source, 'commit', '-qm', 'baseline'); git(source, 'worktree', 'add', '--detach', copy, 'HEAD');
  const commonGitDir = fs.realpathSync(path.join(source, '.git'));
  const worktreeGitDir = git(copy, 'rev-parse', '--absolute-git-dir');
  fs.symlinkSync(path.join(source, 'source.txt'), path.join(copy, 'escape-source'));
  fs.symlinkSync(path.join(extra, 'material.txt'), path.join(copy, 'escape-extra'));
  const nested = path.join(copy, 'readonly'); fs.mkdirSync(nested); fs.writeFileSync(path.join(nested, 'material.txt'), 'nested-original\n');
  const sourceId = identity(source), copyId = identity(copy), extraId = identity(extra), nestedId = identity(nested);
  const execution = snapshotSubAgentExecution({
    source: {product: 'ruukoto-code', projectId: 'project', sessionId: 'parent', taskId: 'parent-task', permissionVersion: 1,
      accessMode: 'full_access', grantedPaths: [{path: extra, access: 'read_write', purpose: 'fixture'}], references: [], capabilities: [],
      authority: {toolClass: 'dev', categories: ['file'], grantIds: [], configuration: 'fixture', workspace: sourceId}},
    roleDigest: 'fixture-role', accessMode: 'confirm', protectSource: true, tools: ['read', 'write', 'edit', 'bash', 'request_file_access'], mcpSignature: '',
  } as any);
  const task = { id: 'child-task', sessionId: 'child', workId: 'work', accessMode: 'confirm', grantedPaths: [{path: extra, access: 'read_write', purpose: 'fixture'}], readScope: {paths: [extraId], execution} } as any;
  const session = {cwdReal: copy, cwdDev: copyId.dev, cwdIno: copyId.ino} as any;
  const store = {getWorkDelegation: () => ({writeTarget: {kind: 'worktree', ...copyId, commonGitDir}}), db: {prepare: () => ({get: () => undefined})}} as any;
  const router = new ToolRouter({store, protectedRoots: []} as any);
  const current = router.launchSpecFor(task, session);
  assert.equal(current.grantedPaths[0].access, 'read');
  assert.ok(current.readRoots?.some(root => root.path === commonGitDir));
  record('production_launchspec_readonly_grants_and_shared_git', 'PASS', current);
  // The parent is adding explicit source roots to preserve readable source access; this uses the unchanged native launcher.
  const spec = {...current, taskId: `rk03-native-${process.pid}`, readRoots: [...(current.readRoots ?? []), sourceId]};
  fs.writeFileSync(path.join(evidence, 'launchspec.json'), JSON.stringify(spec, null, 2) + '\n');
  const beforeSource = tree(source), beforeExtra = tree(extra);
  fs.writeFileSync(path.join(evidence, 'fixture-before.json'), JSON.stringify({fixture, source: beforeSource, extra: beforeExtra}, null, 2) + '\n');
  const native = createNativeLauncher();
  host = ToolWorkerHost.create(native, spec);
  await host.start(); record('production_native_worker_started', 'PASS', host.spec);
  const call = async (name: string, params: Record<string, unknown>) => {
    const result = await host!.call({name, params, opId: `op-${++sequence}`, sdkCallId: `sdk-${sequence}`, timeoutMs: 15000});
    record(`${name}_call_${sequence}`, result.isError ? 'REJECTED' : 'SUCCEEDED', {params, result});
    return result;
  };
  assert.equal((await call('write', {path: 'artifact.txt', content: 'artifact-written\n'})).isError, false);
  assert.equal((await call('bash', {command: 'printf check > check-output.txt && node --version && git --version'})).isError, false);
  assert.equal(fs.readFileSync(path.join(copy, 'artifact.txt'), 'utf8'), 'artifact-written\n');
  assert.equal(fs.readFileSync(path.join(copy, 'check-output.txt'), 'utf8'), 'check');
  record('copy_test_artifacts_are_writable_actual_bytes', 'PASS');
  for (const target of [path.join(source, 'source.txt'), path.join(extra, 'material.txt'), path.join(source, '.git', 'index'), path.join(source, '.git', 'config'), path.join(worktreeGitDir, 'index')]) {
    assert.equal((await call('read', {path: target})).isError, false);
  }
  record('all_readonly_sources_shared_git_and_nested_material_are_readable', 'PASS');
  const targets = [path.join(source, 'source.txt'), path.join(source, '..', 'source', 'source.txt'), path.join(source, '.git', 'index'),
    path.join(source, '.git', 'config'), path.join(worktreeGitDir, 'index'), path.join(extra, 'material.txt'),
    path.join(copy, 'escape-source'), path.join(copy, 'escape-extra'), path.join(source, 'new-forbidden.txt')];
  if (process.platform === 'darwin') {
    for (const alias of ['/System/Volumes/Data' + path.join(source, 'source.txt'), path.join(source, 'SOURCE.TXT')]) {
      if (fs.existsSync(alias)) targets.push(alias);
      else record(`alias_unavailable_${alias}`, 'NOT_APPLICABLE');
    }
  }
  for (const target of targets) {
    assert.equal((await call('write', {path: target, content: 'forbidden'})).isError, true, target);
    const code = `process.stdout.write('started\\n');try{require('node:fs').writeFileSync(${JSON.stringify(target)},'forbidden');process.stdout.write('unexpected-write');process.exit(0)}catch(e){process.stdout.write('denied:'+e.code);process.exit(1)}`;
    const result = await call('bash', {command: nodeCommand(code)});
    assert.equal(result.isError, true, target); assert.match(textOf(result), /started[\s\S]*denied:(EPERM|EACCES|ENOENT|EROFS)/);
  }
  record('absolute_dot_volume_case_and_symlink_writes_rejected_actual_os', 'PASS', {targets});
  const sourceProtection = (router as any).sourceProtection(task) as string[];
  for (const target of targets) {
    const scoped = (router as any).fileOpScope(task, {path: target, operation: 'write', content: 'approved-forbidden'});
    assert.ok('error' in scoped, target);
    const exists = fs.existsSync(target), stat = fs.statSync(exists ? target : path.dirname(target));
    const result = executeApprovedFileOp({path: target, access: 'read_write', content: 'approved-forbidden', targetDev: stat.dev, targetIno: stat.ino,
      originalSha256: exists ? sha256Hex(fs.readFileSync(target)) : null, protectedRoots: [], writeProtectedRoots: sourceProtection});
    assert.equal(result.ok, false, target); assert.equal(result.effectUnknown, undefined);
    record('approved_host_file_write_rejected', 'PASS', {target, scope: scoped, result});
  }
  record('approved_host_bypass_rejected_with_production_protection_roots', 'PASS');
  const hardlink = path.join(copy, 'hardlink-source'); fs.linkSync(path.join(source, 'source.txt'), hardlink);
  let denied = false;
  try { await host.call({name: 'write', params: {path: hardlink, content: 'forbidden'}, opId: 'hardlink', sdkCallId: 'hardlink'}); }
  catch (error: any) { denied = error.code === 'execution_unavailable'; record('active_hardlink_guard_error', 'REJECTED', {code: error.code, reason: error.reason, message: error.message}); }
  assert.ok(denied); assert.equal(fs.readFileSync(path.join(source, 'source.txt'), 'utf8'), 'source-original\n');
  fs.unlinkSync(hardlink); record('new_hardlink_alias_stops_before_actual_write', 'PASS');
  const reaped = await host.stop(); safe &&= reaped; record('worker_stop_verified', reaped ? 'PASS' : 'UNVERIFIED', {identity: (host as any).unit?.entry});
  host = null;
  assert.deepEqual(tree(source), beforeSource); assert.deepEqual(tree(extra), beforeExtra);
  record('source_tree_git_index_objects_refs_config_and_extra_unchanged', 'PASS');
  // Preexisting hardlinks cross permission boundaries are refused before launch.
  fs.linkSync(path.join(source, 'source.txt'), hardlink);
  await assert.rejects(prepareNativeLaunch({}, spec), (error: any) => error.code === 'execution_unavailable' && error.reason === 'sandbox_rejected');
  fs.unlinkSync(hardlink); record('preexisting_cross_scope_hardlink_rejected_before_launch', 'PASS');
  record('probe_complete', 'PASS');
} catch (error: any) {
  record('probe_failure', 'FAIL', {code: error.code, reason: error.reason, stack: error.stack}); process.exitCode = 1;
} finally {
  if (host) { const reaped = await host.stop(); safe &&= reaped; record('finally_stop', reaped ? 'PASS' : 'UNVERIFIED'); }
  fs.writeFileSync(path.join(evidence, `native-${os.platform()}-report.json`), JSON.stringify({platform: os.platform(), release: os.release(), arch: os.arch(), node: process.version, fixture, safe, cases}, null, 2) + '\n');
  record('fixture_preserved_for_independent_inspection', 'INFO', {fixture, safe});
}
