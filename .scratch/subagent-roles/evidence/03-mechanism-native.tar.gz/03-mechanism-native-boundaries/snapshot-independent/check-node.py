from pathlib import Path
import json,os,hashlib,subprocess,stat
ROOT=Path(__file__).resolve().parent
source=ROOT/'source'
helper=ROOT/'raw-snapshot.mjs'
nodegit=ROOT/'node-git'
nodecopy=ROOT/'node-materialized'
nodeindex=ROOT/'node-index'
log=(ROOT/'node-commands.log').open('w')
def run(args,expected=0):
    result=subprocess.run([str(a) for a in args],capture_output=True)
    log.write('$ '+json.dumps([str(a) for a in args])+'\nexit='+str(result.returncode)+'\n'+result.stdout.decode('utf8','backslashreplace')+result.stderr.decode('utf8','backslashreplace')+'\n');log.flush()
    assert expected is None or result.returncode==expected,(args,result.stderr)
    return result

def ledger(root):
    items={}
    for current,dirs,files in os.walk(root):
        for name in files:
            p=Path(current)/name;s=p.lstat();data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
            items[str(p.relative_to(root))]=(hashlib.sha256(data).hexdigest(),s.st_mode,s.st_mtime_ns,s.st_ino)
    return items

before=ledger(source/'.git')
run(['git','init','--bare','--quiet',nodegit])
tree=run(['node',helper,'tree',json.dumps({'source':str(source),'gitdir':str(nodegit),'index':str(nodeindex)})]).stdout.decode().strip()
expected=json.loads((ROOT/'unstable-second/snapshot.json').read_text())['tree']
assert tree==expected,(tree,expected)
assert ledger(source/'.git')==before
nodecopy.mkdir()
run(['node',helper,'materialize',json.dumps({'tree':tree,'gitdir':str(nodegit),'destination':str(nodecopy)})])
entries=run(['git','--git-dir',nodegit,'ls-tree','-r','-z',tree]).stdout.split(b'\0')
checked=0
for entry in entries:
    if not entry:continue
    metadata,rawname=entry.split(b'\t',1)
    mode,kind,oid=metadata.split(b' ')
    p=nodecopy/os.fsdecode(rawname)
    expected_blob=run(['git','--git-dir',nodegit,'cat-file','blob',oid.decode()]).stdout
    if mode==b'120000':actual=os.fsencode(os.readlink(p));assert p.is_symlink()
    else:actual=p.read_bytes();assert bool(p.stat().st_mode&0o111)==(mode==b'100755')
    assert actual==expected_blob,os.fsdecode(rawname)
    checked+=1
report=json.loads((ROOT/'report.json').read_text())
conflict=json.loads(run(['node',helper,'check',json.dumps({'source':str(source),'gitdir':str(ROOT/'capture/git'),'baselineTree':report['snapshot']['tree'],'childTree':report['snapshot']['childTree']})]).stdout)
assert conflict['state']=='conflict' and '.probe-context.txt' in conflict['mismatches'] and '.probe-untracked.bin' in conflict['mismatches']
assert ledger(source/'.git')==before

# A tracked ancestor replaced by a symlink must fail rather than read the target's child bytes.
nested=source/'.probe-nested/deeper'
saved=source/'.probe-nested/deeper.saved'
nested.rename(saved)
external=ROOT/'outside'
external.mkdir();(external/'new file.txt').write_bytes(b'outside confidential\n')
nested.symlink_to(external,target_is_directory=True)
ancestor=run(['node',helper,'tree',json.dumps({'source':str(source),'gitdir':str(ROOT/'capture/git'),'index':str(ROOT/'ancestor-index'),'seedTree':report['snapshot']['tree']})],expected=None)
assert ancestor.returncode!=0 and b'ancestor changed or is a symlink' in ancestor.stderr
nested.unlink();saved.rename(nested)

# Nested Git is explicitly unsupported in first version, not silently dropped.
nested_repo=source/'.probe-nested/git-repo'
nested_repo.mkdir();run(['git','init','--quiet',nested_repo])
(nested_repo/'new.txt').write_bytes(b'child repo\n')
nested=run(['node',helper,'tree',json.dumps({'source':str(source),'gitdir':str(ROOT/'capture/git'),'index':str(ROOT/'nested-index')})],expected=None)
assert nested.returncode!=0 and b'unsupported nested Git/submodule or non-file' in nested.stderr
assert ledger(source/'.git')==before
result={'passed':True,'treeMatchesPython':True,'materializedEntriesChecked':checked,'conflict':conflict,'sourceGitUnchanged':True,'ancestorSymlinkRejected':True,'nestedGitRejected':True}
(ROOT/'node-report.json').write_text(json.dumps(result,indent=2)+'\n')
log.close()
print(json.dumps(result))
