#!/usr/bin/env python3
"""Git-only workspace snapshot experiment; creates no commits and never mutates the input repo."""
from pathlib import Path
import os, sys, subprocess, json, hashlib, shutil, stat

ROOT = Path(__file__).resolve().parent
INPUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path('/Users/eitrous/orca/workspaces/ruukoto/subagent-roles')
LOG = (ROOT / 'commands.log').open('w')
REPORT = {'input': str(INPUT), 'checks': {}, 'expectedFailures': {}}
SOURCE = ROOT / 'source'
CAPTURE = ROOT / 'capture'
COPY = ROOT / 'copy'
ENV_BASE = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}
for key in ['GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_COMMON_DIR']:
    ENV_BASE.pop(key, None)


def command(args, cwd=None, env=None, data=None, expected=0):
    LOG.write('$ ' + json.dumps([str(x) for x in args]) + '\n')
    LOG.flush()
    result = subprocess.run([str(x) for x in args], cwd=cwd, env=env or ENV_BASE, input=data, capture_output=True)
    LOG.write('exit=' + str(result.returncode) + '\n')
    if result.stdout:
        LOG.write(result.stdout.decode('utf8', 'backslashreplace') + '\n')
    if result.stderr:
        LOG.write(result.stderr.decode('utf8', 'backslashreplace') + '\n')
    LOG.flush()
    if expected is not None and result.returncode != expected:
        raise AssertionError(f'command failed: {args}: {result.stderr!r}')
    return result


def git(repo, *args, env=None, data=None, expected=0):
    return command(['git','-C',repo,'-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null',
                    '-c','core.untrackedCache=false',*args], env=env, data=data, expected=expected)


def ledger(directory, exclude_git=False):
    result = {}
    for directory_path, dirs, files in os.walk(directory, followlinks=False):
        current = Path(directory_path)
        if exclude_git and current == directory:
            dirs[:] = [x for x in dirs if x != '.git']
            files[:] = [x for x in files if x != '.git']
        for name in dirs[:]:
            p = current / name
            if p.is_symlink():
                files.append(name)
                dirs.remove(name)
        for name in files:
            p = current / name
            info = p.lstat()
            payload = os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
            result[str(p.relative_to(directory))] = {
                'sha256': hashlib.sha256(payload).hexdigest(), 'bytes': len(payload),
                'mode': stat.S_IMODE(info.st_mode), 'mtimeNs': info.st_mtime_ns,
                'ino': info.st_ino, 'dev': info.st_dev,
            }
    return result


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def checked(name, actual, expected=True):
    assert actual == expected, (name, actual, expected)
    REPORT['checks'][name] = actual


def rawgit(gitdir, *args, env=None, data=None, expected=0):
    return command(['git','--git-dir',gitdir,'-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null',*args], env=env, data=data, expected=expected)


def raw_tree(repo, gitdir, index, objects, seed_names=()):
    # Writes deliberately have no source alternate: Git freshens existing alternate blobs on hash writes.
    writer = {**ENV_BASE, 'GIT_INDEX_FILE': str(index), 'GIT_OBJECT_DIRECTORY': str(objects)}
    writer.pop('GIT_ALTERNATE_OBJECT_DIRECTORIES',None)
    rawgit(gitdir,'read-tree','--empty',env=writer)
    names = {os.fsdecode(x) for x in git(repo,'ls-files','-z','--cached','--others','--exclude-standard').stdout.split(b'\0') if x}
    names.update(seed_names)
    records=[]
    for name in sorted(names):
        p = repo / name
        if not p.exists() and not p.is_symlink():
            continue
        info=p.lstat()
        if p.is_symlink():
            payload=os.fsencode(os.readlink(p));mode='120000'
        elif p.is_file():
            payload=p.read_bytes();mode='100755' if info.st_mode & 0o111 else '100644'
        else:
            raise ValueError('nested Git/submodule or unsupported path: '+name)
        oid=rawgit(gitdir,'hash-object','--no-filters','-w','--stdin',env=writer,data=payload).stdout.strip().decode()
        records.append(mode.encode()+b' '+oid.encode()+b'\t'+os.fsencode(name)+b'\0')
    rawgit(gitdir,'update-index','-z','--index-info',env=writer,data=b''.join(records))
    return rawgit(gitdir,'write-tree',env=writer).stdout.strip().decode()


def capture(repo, directory):
    directory.mkdir()
    gitdir=directory / 'git'
    command(['git','init','--bare','--quiet',gitdir])
    head=git(repo,'rev-parse','HEAD').stdout.strip().decode()
    tree=raw_tree(repo,gitdir,directory / 'index',gitdir / 'objects')
    reader={**ENV_BASE,'GIT_INDEX_FILE':str(directory / 'index'),'GIT_OBJECT_DIRECTORY':str(gitdir / 'objects')}
    save(str(directory.relative_to(ROOT) / 'snapshot.json'),{'head':head,'tree':tree})
    return {'head':head,'tree':tree,'env':reader,'gitdir':gitdir}


def materialize(baseline, destination):
    for name,(mode,oid) in entries(destination,baseline['tree'],baseline['env']).items():
        p=destination / name
        p.parent.mkdir(parents=True,exist_ok=True)
        payload=rawgit(baseline['gitdir'],'cat-file','blob',oid,env=baseline['env']).stdout
        if mode=='120000':
            p.symlink_to(os.fsdecode(payload))
        else:
            p.write_bytes(payload)
            p.chmod(0o755 if mode=='100755' else 0o644)


def current_tree(repo, baseline, directory):
    directory.mkdir()
    tree=raw_tree(repo,baseline['gitdir'],directory / 'index',baseline['gitdir'] / 'objects',entries(repo,baseline['tree'],baseline['env']).keys())
    return tree,baseline['env']


def entries(repo, tree, env):
    parsed = {}
    for record in rawgit(CAPTURE / 'git','ls-tree','-r','-z',tree,env=env).stdout.split(b'\0'):
        if not record:
            continue
        metadata, filename = record.split(b'\t',1)
        mode, kind, oid = metadata.split(b' ')
        parsed[os.fsdecode(filename)] = (mode.decode(),oid.decode())
    return parsed


def actual_entry(repo, name):
    p = repo / name
    if not p.exists() and not p.is_symlink():
        return None
    info = p.lstat()
    if p.is_symlink():
        payload = os.fsencode(os.readlink(p))
        mode = '120000'
    else:
        assert p.is_file(), ('unsupported directory/gitlink', name)
        payload = p.read_bytes()
        mode = '100755' if info.st_mode & 0o111 else '100644'
    oid = hashlib.sha1(b'blob ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()
    return mode,oid


# Clone existing HEAD rather than fabricate a fixture commit.
original_common = Path(git(INPUT,'rev-parse','--git-common-dir').stdout.decode().strip())
if not original_common.is_absolute():
    original_common = INPUT / original_common
original_before = ledger(original_common)
command(['git','clone','--no-hardlinks','--quiet',INPUT,SOURCE])
initial_source_commits=set(git(SOURCE,'rev-list','--all').stdout.splitlines())
checked('clone_did_not_mutate_input_git', ledger(original_common) == original_before)

# A single file contains distinct staged and unstaged content; new binary and nested paths are untracked.
readme_base = (SOURCE / 'README.md').read_bytes()
(SOURCE / 'README.md').write_bytes(readme_base + b'\nPROBE staged version\n')
git(SOURCE,'add','README.md')
(SOURCE / 'README.md').write_bytes(readme_base + b'\nPROBE actual unstaged version\n')
(SOURCE / '.probe-staged-new.txt').write_bytes(b'initial staged new\n')
git(SOURCE,'add','.probe-staged-new.txt')
(SOURCE / '.probe-staged-new.txt').write_bytes(b'latest unstaged new\n')
(SOURCE / 'docs/architecture.md').unlink()
ignore_original = (SOURCE / '.gitignore').read_bytes()
(SOURCE / '.gitignore').write_bytes(ignore_original + b'\n.probe-ignored/\n.probe-ignored.bin\n')
(SOURCE / '.probe-ignored').mkdir()
(SOURCE / '.probe-ignored/secret.txt').write_bytes(b'ignored secret\n')
(SOURCE / '.probe-ignored.bin').write_bytes(b'ignored\x00binary')
(SOURCE / '.probe-untracked.bin').write_bytes(b'\x00\x01\xffsnapshot binary\x00\xfe')
(SOURCE / '.probe-nested/deeper').mkdir(parents=True)
(SOURCE / '.probe-nested/deeper/new file.txt').write_bytes(b'nested current\n')
(SOURCE / '.probe-nested/link').symlink_to('deeper/new file.txt')
(SOURCE / '.probe-nested/run.sh').write_bytes(b'#!/bin/sh\nexit 0\n')
(SOURCE / '.probe-nested/run.sh').chmod(0o755)
(SOURCE / '.probe-context.txt').write_bytes(b'\n'.join([f'line {i}'.encode() for i in range(1,30)]) + b'\n')
git(SOURCE,'add','.probe-context.txt')

# Attributes and a hostile clean filter must not transform bytes or execute during raw capture.
(SOURCE / '.gitattributes').write_bytes(b'.probe-crlf.txt text eol=lf\n.probe-filter.txt filter=probe\n')
(SOURCE / '.probe-crlf.txt').write_bytes(b'raw CRLF one\r\nraw CRLF two\r\n')
(SOURCE / '.probe-filter.txt').write_bytes(b'raw filter content\n')
filter_marker=ROOT / 'source-filter-fired'
filter_script=ROOT / 'clean-filter.sh'
filter_script.write_text('#!/bin/sh\nprintf fired >> '+str(filter_marker)+'\nsed s/raw/FILTERED/g\n')
filter_script.chmod(0o755)
git(SOURCE,'config','filter.probe.clean',str(filter_script))

smudge_marker=ROOT / 'source-smudge-fired'
smudge_script=ROOT / 'smudge-filter.sh'
smudge_script.write_text('#!/bin/sh\nprintf fired >> '+str(smudge_marker)+'\ncat\n')
smudge_script.chmod(0o755)
git(SOURCE,'config','filter.probe.smudge',str(smudge_script))
(SOURCE / '.git/info/attributes').write_bytes(b'README.md filter=probe\n')

# Preserve the add-all negative control; both byte normalization and arbitrary filter invocation occur.
naive=ROOT / 'naive-filter-control'
naive.mkdir();(naive / 'objects').mkdir()
naive_env={**ENV_BASE,'GIT_INDEX_FILE':str(naive / 'index'),'GIT_OBJECT_DIRECTORY':str(naive / 'objects'),
           'GIT_ALTERNATE_OBJECT_DIRECTORIES':str(SOURCE / '.git/objects')}
git(SOURCE,'read-tree','HEAD',env=naive_env)
git(SOURCE,'add','--all','--','.',env=naive_env)
naive_tree=git(SOURCE,'write-tree',env=naive_env).stdout.strip().decode()
naive_crlf=git(SOURCE,'show',naive_tree+':.probe-crlf.txt',env=naive_env).stdout
naive_filter=git(SOURCE,'show',naive_tree+':.probe-filter.txt',env=naive_env).stdout
checked('naive_add_executes_source_clean_filter',filter_marker.exists())
checked('naive_add_changes_CRLF_bytes',naive_crlf != (SOURCE / '.probe-crlf.txt').read_bytes())
checked('naive_add_changes_filter_bytes',naive_filter != (SOURCE / '.probe-filter.txt').read_bytes())
REPORT['expectedFailures']['naiveFilter']={'marker':str(filter_marker),'crlfCaptured':naive_crlf.decode(),'filterCaptured':naive_filter.decode()}
filter_marker_before=filter_marker.read_bytes()

source_git = SOURCE / '.git'
source_before = {'git':ledger(source_git), 'worktree':ledger(SOURCE, exclude_git=True)}
save('source-before.json', source_before)
baseline = capture(SOURCE,CAPTURE)
source_after = {'git':ledger(source_git), 'worktree':ledger(SOURCE, exclude_git=True)}
save('source-after.json', source_after)
checked('capture_source_git_byte_mode_mtime_inode_unchanged', source_before['git'] == source_after['git'])
checked('capture_source_worktree_byte_mode_mtime_inode_unchanged', source_before['worktree'] == source_after['worktree'])
checked('capture_created_objects_only_in_independent_directory', bool(ledger(CAPTURE / 'git/objects')))
checked('capture_baseline_is_tree_without_new_commit', rawgit(baseline['gitdir'],'cat-file','-t',baseline['tree'],env=baseline['env']).stdout == b'tree\n')

checked('raw_capture_did_not_execute_source_filter',filter_marker.read_bytes() == filter_marker_before)

# The separately registered copy may add only the dedicated ref/log and worktree metadata.
git_before_registration = ledger(source_git)
command(['git','--git-dir',source_git,'-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null','worktree','add','--quiet','--no-checkout','-b','ruukoto/probe-copy',COPY,baseline['head']])
git(COPY,'read-tree',baseline['head'])
git_after_registration = ledger(source_git)
added = sorted(set(git_after_registration) - set(git_before_registration))
changed = sorted(k for k in git_before_registration if git_after_registration.get(k) != git_before_registration[k])
save('registration-delta.json', {'added':added,'changed':changed})
checked('registration_changed_no_existing_git_file', changed == [])
checked('registration_only_added_copy_metadata_and_dedicated_ref', all(p.startswith(('worktrees/copy/','refs/heads/ruukoto/probe-copy','logs/refs/heads/ruukoto/probe-copy')) for p in added))
source_git_registered = ledger(source_git)
materialize(baseline,COPY)
checked('materialize_did_not_write_any_git_metadata', ledger(source_git) == source_git_registered)
checked('registration_and_materialize_did_not_execute_smudge_filter',not smudge_marker.exists())
expected = {
 'README.md':readme_base + b'\nPROBE actual unstaged version\n',
 '.probe-staged-new.txt':b'latest unstaged new\n',
 '.probe-untracked.bin':b'\x00\x01\xffsnapshot binary\x00\xfe',
 '.probe-nested/deeper/new file.txt':b'nested current\n',
 '.probe-crlf.txt':b'raw CRLF one\r\nraw CRLF two\r\n',
 '.probe-filter.txt':b'raw filter content\n',
}
for name,payload in expected.items():
    checked('copy_current_content_' + name, (COPY / name).read_bytes() == payload)
checked('copy_tracked_deletion', not (COPY / 'docs/architecture.md').exists())
checked('copy_ignored_directory_omitted', not (COPY / '.probe-ignored').exists())
checked('copy_ignored_binary_omitted', not (COPY / '.probe-ignored.bin').exists())
checked('copy_symlink_preserved', (COPY / '.probe-nested/link').is_symlink() and os.readlink(COPY / '.probe-nested/link') == 'deeper/new file.txt')
checked('copy_executable_mode_preserved', bool((COPY / '.probe-nested/run.sh').stat().st_mode & 0o111))

# Freeze with a second temporary index, preserving the original source and copy indexes.
(COPY / '.probe-staged-new.txt').write_bytes(b'latest unstaged new\nchild addition\n')
(COPY / '.probe-untracked.bin').write_bytes(b'\x00child binary replacement\xff\x00')
(COPY / '.probe-nested/deeper/child.txt').write_bytes(b'child new nested\n')
(COPY / '.probe-context.txt').write_bytes((COPY / '.probe-context.txt').read_bytes().replace(b'line 3\n', b'child line 3\n'))
git_before_freeze = ledger(source_git)
child_tree, child_env = current_tree(COPY,baseline,ROOT / 'freeze')
child_patch = rawgit(baseline['gitdir'],'diff','--binary','--no-ext-diff','--no-textconv','--no-renames',baseline['tree'],child_tree,env=child_env).stdout
(ROOT / 'child.patch').write_bytes(child_patch)
checked('freeze_source_and_copy_git_unchanged', ledger(source_git) == git_before_freeze)
checked('freeze_did_not_execute_source_filter',filter_marker.read_bytes() == filter_marker_before)
affected = [os.fsdecode(x) for x in rawgit(baseline['gitdir'],'diff','--name-only','-z',baseline['tree'],child_tree,env=child_env).stdout.split(b'\0') if x]
checked('child_patch_only_child_changes', sorted(affected) == sorted(['.probe-staged-new.txt','.probe-untracked.bin','.probe-nested/deeper/child.txt','.probe-context.txt']))
checked('child_patch_excludes_parent_staged_unstaged_delete_ignore', all(os.fsencode(p) not in child_patch for p in ['README.md','docs/architecture.md','.probe-ignored.bin']))
base_entries = entries(COPY,baseline['tree'],child_env)
result_entries = entries(COPY,child_tree,child_env)
checked('affected_source_still_matches_baseline', all(actual_entry(SOURCE,p) == base_entries.get(p) for p in affected))

git_before_integrate = ledger(source_git)
git(SOURCE,'apply','--check',ROOT / 'child.patch')
git(SOURCE,'apply',ROOT / 'child.patch')
checked('integrate_git_index_objects_refs_hooks_config_unchanged', ledger(source_git) == git_before_integrate)
checked('integrate_affected_source_equals_child_result', all(actual_entry(SOURCE,p) == result_entries.get(p) for p in affected))
checked('integrate_preserves_parent_unstaged_readme', (SOURCE / 'README.md').read_bytes() == expected['README.md'])
checked('integrate_preserves_parent_tracked_deletion', not (SOURCE / 'docs/architecture.md').exists())
checked('integrate_preserves_ignored_file', (SOURCE / '.probe-ignored.bin').read_bytes() == b'ignored\x00binary')
checked('integrate_source_index_preserves_original_staging', source_before['git']['index'] == ledger(source_git)['index'])
git(SOURCE,'apply','--check','--reverse',ROOT / 'child.patch')
checked('already_full_result_detectable', all(actual_entry(SOURCE,p) == result_entries.get(p) for p in affected))

# Restore only child delta; then concurrent non-overlapping hunk proves apply --check alone is insufficient.
git(SOURCE,'apply','--reverse',ROOT / 'child.patch')
context_baseline = (SOURCE / '.probe-context.txt').read_bytes()
(SOURCE / '.probe-context.txt').write_bytes(context_baseline.replace(b'line 25\n',b'parent line 25\n'))
conflict_before = {'git':ledger(source_git),'worktree':ledger(SOURCE,exclude_git=True)}
nonoverlap = git(SOURCE,'apply','--check',ROOT / 'child.patch')
checked('apply_check_accepts_same_file_different_hunk_concurrent_change', nonoverlap.returncode == 0)
checked('affected_file_guard_rejects_same_file_different_hunk', any(actual_entry(SOURCE,p) != base_entries.get(p) for p in affected))
checked('guard_rejection_preserves_source', conflict_before == {'git':ledger(source_git),'worktree':ledger(SOURCE,exclude_git=True)})
REPORT['expectedFailures']['nonoverlap'] = {'gitApplyCheckExit':nonoverlap.returncode,'guard':'snapshot_changed','path':'.probe-context.txt'}

# Overlapping change is rejected by both the guard and Git, and no source file is overwritten.
(SOURCE / '.probe-context.txt').write_bytes(context_baseline.replace(b'line 3\n',b'parent line 3\n'))
overlap_before = {'git':ledger(source_git),'worktree':ledger(SOURCE,exclude_git=True)}
overlap = git(SOURCE,'apply','--check',ROOT / 'child.patch',expected=None)
(ROOT / 'conflict.stderr.log').write_bytes(overlap.stderr)
checked('apply_check_rejects_same_hunk_concurrent_change', overlap.returncode != 0)
checked('conflict_did_not_overwrite_source', overlap_before == {'git':ledger(source_git),'worktree':ledger(SOURCE,exclude_git=True)})
REPORT['expectedFailures']['overlap'] = {'exit':overlap.returncode,'stderr':overlap.stderr.decode()}

# Two capture passes detect externally changed HEAD/index/content without mutating source.
first = capture(SOURCE,ROOT / 'unstable-first')
(SOURCE / '.probe-untracked.bin').write_bytes(b'changed during snapshot\x00')
second = capture(SOURCE,ROOT / 'unstable-second')
checked('two_capture_trees_detect_concurrent_change', first['tree'] != second['tree'])
REPORT['expectedFailures']['unstableCapture'] = {'guard':'snapshot_changed','firstTree':first['tree'],'secondTree':second['tree']}
checked('experiment_created_no_commits', set(git(SOURCE,'rev-list','--all').stdout.splitlines()) == initial_source_commits)
REPORT['snapshot'] = {'head':baseline['head'],'tree':baseline['tree'],'childTree':child_tree,'affected':affected}
REPORT['passed'] = True
save('report.json', REPORT)
LOG.close()
print(json.dumps({'passed':True,'root':str(ROOT),'checks':len(REPORT['checks'])}, ensure_ascii=False))
