import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const baseEnv = { ...process.env, GIT_OPTIONAL_LOCKS: '0' };
for (const key of ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_COMMON_DIR']) delete baseEnv[key];
function git(args, env = baseEnv, input) {
  const result = spawnSync('git', ['-c', 'core.fsmonitor=false', '-c', 'core.hooksPath=/dev/null', ...args], { env, input, maxBuffer: 64 * 1024 * 1024 });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`git failed (${result.status}): ${result.stderr.toString().trim()}`);
  return result.stdout;
}
function parsePaths(bytes) {
  return bytes.toString('utf8').split('\0').filter(Boolean);
}
function treeEntries(gitdir, tree) {
  const entries = new Map();
  for (const item of parsePaths(git(['--git-dir', gitdir, 'ls-tree', '-r', '-z', tree]))) {
    const tab = item.indexOf('\t');
    const [mode, type, oid] = item.slice(0, tab).split(' ');
    if (type !== 'blob') throw new Error('unsupported nested Git/submodule');
    entries.set(item.slice(tab + 1), { mode, oid });
  }
  return entries;
}
function safePath(root, name) {
  const resolved = path.resolve(root, name);
  if (!resolved.startsWith(root + path.sep) || name.split('/').some(part => part === '.git' || part === '..')) throw new Error('unsupported snapshot path');
  const parts = name.split('/');
  for (let i = 1; i < parts.length; i += 1) {
    let st;
    try { st = fs.lstatSync(path.join(root, ...parts.slice(0, i))); }
    catch (error) { if (error.code === 'ENOENT') return resolved; throw error; }
    if (!st.isDirectory() || st.isSymbolicLink()) throw new Error('snapshot path ancestor changed or is a symlink');
  }
  return resolved;
}
function payloadAt(root, name) {
  const resolved = safePath(root, name);
  let st;
  try { st = fs.lstatSync(resolved); }
  catch (error) { if (error.code === 'ENOENT') return null; throw error; }
  if (st.isSymbolicLink()) return { mode: '120000', bytes: fs.readlinkSync(resolved, { encoding: 'buffer' }) };
  if (!st.isFile()) throw new Error('unsupported nested Git/submodule or non-file');
  return { mode: (st.mode & 0o111) === 0 ? '100644' : '100755', bytes: fs.readFileSync(resolved) };
}
export function rawTree(source, gitdir, index, seedTree) {
  const env = { ...baseEnv, GIT_INDEX_FILE: index };
  // No alternates or source object directory are present during any object write.
  git(['--git-dir', gitdir, 'read-tree', '--empty'], env);
  const names = new Set(parsePaths(git(['-C', source, '-c', 'core.untrackedCache=false', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'])));
  if (seedTree) for (const name of treeEntries(gitdir, seedTree).keys()) names.add(name);
  const records = [];
  for (const name of [...names].sort()) {
    const current = payloadAt(source, name);
    if (!current) continue;
    const oid = git(['--git-dir', gitdir, 'hash-object', '--no-filters', '-w', '--stdin'], env, current.bytes).toString().trim();
    records.push(Buffer.from(`${current.mode} ${oid}\t${name}\0`));
  }
  git(['--git-dir', gitdir, 'update-index', '-z', '--index-info'], env, Buffer.concat(records));
  return git(['--git-dir', gitdir, 'write-tree'], env).toString().trim();
}
export function materialize(tree, gitdir, destination) {
  for (const [name, item] of treeEntries(gitdir, tree)) {
    const target = safePath(destination, name);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const bytes = git(['--git-dir', gitdir, 'cat-file', 'blob', item.oid]);
    if (item.mode === '120000') fs.symlinkSync(bytes, target);
    else {
      fs.writeFileSync(target, bytes, { mode: item.mode === '100755' ? 0o755 : 0o644 });
      fs.chmodSync(target, item.mode === '100755' ? 0o755 : 0o644);
    }
  }
}
export function checkAffected(source, gitdir, baselineTree, childTree) {
  const baseline = treeEntries(gitdir, baselineTree);
  const final = treeEntries(gitdir, childTree);
  const names = parsePaths(git(['--git-dir', gitdir, 'diff', '--name-only', '-z', '--no-ext-diff', '--no-textconv', '--no-renames', baselineTree, childTree]));
  let matchesBaseline = true;
  let matchesFinal = true;
  const mismatches = [];
  for (const name of names) {
    const current = payloadAt(source, name);
    const actual = current && { mode: current.mode, oid: createHash('sha1').update(`blob ${current.bytes.length}\0`).update(current.bytes).digest('hex') };
    const same = expected => actual === null ? expected === undefined : expected?.mode === actual.mode && expected.oid === actual.oid;
    const baseMatches = same(baseline.get(name));
    const finalMatches = same(final.get(name));
    matchesBaseline &&= baseMatches;
    matchesFinal &&= finalMatches;
    if (!baseMatches && !finalMatches) mismatches.push(name);
  }
  return { state: matchesBaseline ? 'baseline' : matchesFinal ? 'already' : 'conflict', files: names, mismatches };
}

if (process.argv[2]) {
  const action = process.argv[2];
  const input = JSON.parse(process.argv[3]);
  if (action === 'tree') process.stdout.write(rawTree(input.source, input.gitdir, input.index, input.seedTree) + '\n');
  else if (action === 'materialize') materialize(input.tree, input.gitdir, input.destination);
  else if (action === 'check') process.stdout.write(JSON.stringify(checkAffected(input.source, input.gitdir, input.baselineTree, input.childTree)) + '\n');
  else throw new Error('unknown action');
}
