# 工作区基线结果失败隔离交付

仅修改 orchestrator.ts、parent-delivery.ts 和新测试 workspace-snapshot-terminal-boundaries.test.ts，主检出未写入，未提交。父级先核实 base-input-sha256.json，再应用 terminal-boundaries-final.patch；最终对象由 final-input-sha256.json 固定。

Orchestrator 对 target_corrupt/snapshot_missing/snapshot_corrupt 在单次终态结果登记处保存 outcome=failed 和具体 failure code，继续处理其他工作。Task 的真实终态、已提交 work JSON 和副本保留，坏基线不制作交付产物，也不自动重放。结果摘要说明向拥有者报告并停止这项工作。未知异常与未知 WorkspaceSnapshotError code 继续传播。

ParentDelivery 在 reserveResult、resultRecorded、来源回调、启动扫尾、普通结果注入、唤醒准入和最终汇报拦住受影响结果；既有 pending AgentReport 持久标 undelivered(code)。不绕开 core.checkTargets 为坏目标合成来源或新 report。原已登记 resultRef/resultSummary 不覆写，不把拒绝当作实际模型已接受，不写 result_delivered_at。报告组沿既有 invalidateAgentReports 规则处理。

事务归属按调用点保留：reserveResult、wakeTerminal 和 takeInjection 内的失效与其宿主事务共用提交；结果提交后的入口或队列准入独立提交。首轮新测试捕获自建事务嵌套失败，修正后日志保留。

验证：terminal-and-delivery-final.log 为新增 7 项 + 88/125 原有 17 项，共 24/24；terminal-boundaries-final.log 重核最终失败指引 7/7；changed-files-lint-final.log、runtime-typecheck.log、root-typecheck.log 均通过。原失败 terminal-boundaries-attempt1.log 保留。contract_audit 在它的独立副本套用生产补丁，并联测真实 Runtime 冷恢复与排队/消息错误边界，最终联合证据由其交付。

本文不构成作者独立实现审查。汇总后的最终实现仍需另一上下文独立审查；全仓 check:static、最终 Linux 与真实模型联合验收由父级按最终范围安排。
