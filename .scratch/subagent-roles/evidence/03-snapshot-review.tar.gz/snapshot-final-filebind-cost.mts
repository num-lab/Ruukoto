import * as fs from 'node:fs';
import * as path from 'node:path';
import { performance } from 'node:perf_hooks';
import { isProtectedPath } from '/tmp/ruukoto-03-file-bind-fix.tZGieX/repo/packages/agent/src/execution/approved-ops.ts';
const root = '/Users/eitrous/orca/workspaces/ruukoto/subagent-roles', candidate = '/tmp/snapshot-filebind-unrelated-new-file';
const walk = [root]; let directories = 0, files = 0;
while (walk.length) { const entry = walk.pop()!, stat = fs.lstatSync(entry); if (stat.isDirectory()) { directories += 1; walk.push(...fs.readdirSync(entry).map(name => path.join(entry, name))); } else files += 1; }
const durations = [];
for (let index = 0; index < 3; index += 1) { const started = performance.now(); const protectedPath = isProtectedPath(candidate, [root]); durations.push({ protectedPath, ms: performance.now() - started }); }
console.log(JSON.stringify({ root, files, directories, durations }, null, 2));
