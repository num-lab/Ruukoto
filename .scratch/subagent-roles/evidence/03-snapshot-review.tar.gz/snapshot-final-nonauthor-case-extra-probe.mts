import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import { createHash } from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { WorkCopyManager } from '/Users/eitrous/orca/workspaces/ruukoto/subagent-roles/packages/runtime/src/work-copy.ts';
import type { Session, WorkDelegation } from '/Users/eitrous/orca/workspaces/ruukoto/subagent-roles/packages/core/src/types.ts';
const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'case-final-extra-')));
const git = (cwd: string, ...args: string[]) => execFileSync('git', ['-C', cwd, ...args], { stdio: ['pipe', 'pipe', 'pipe'] });
function files(root: string) {
  const result: Record<string, { digest: string; mode: number; ino: number; mtime: number }> = {};
  const walk = (directory: string): void => { for (const name of fs.readdirSync(directory)) { const file = path.join(directory, name), stat = fs.lstatSync(file); if (stat.isDirectory()) walk(file); else result[path.relative(root, file)] = { digest: createHash('sha256').update(stat.isSymbolicLink() ? fs.readlinkSync(file, { encoding: 'buffer' }) : fs.readFileSync(file)).digest('hex'), mode: stat.mode, ino: stat.ino, mtime: stat.mtimeMs }; } };
  walk(root); return result;
}
async function fixture(name: string, directory = false) {
  const source = path.join(root, name); fs.mkdirSync(source);
  if (directory) { fs.mkdirSync(path.join(source, 'node')); fs.writeFileSync(path.join(source, 'node/old.txt'), 'base\n'); }
  else fs.writeFileSync(path.join(source, 'Value.txt'), 'base\n');
  git(source, 'init', '-q'); git(source, 'config', 'user.name', 'Probe'); git(source, 'config', 'user.email', 'probe@example.test'); git(source, 'add', '.'); git(source, 'commit', '-qm', 'base');
  const stat = fs.statSync(source), session = { id: name, cwdReal: source, cwdDev: stat.dev, cwdIno: stat.ino } as Session;
  const manager = new WorkCopyManager({ worktreeRoot: path.join(root, name + '-copies'), protectedRoots: () => [], execute: async input => {
    const result = spawnSync('/bin/sh', ['-c', input.command], { cwd: input.workspace, encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 });
    return { isError: result.status !== 0, content: result.stdout, errorMessage: result.stderr };
  } });
  const target = await manager.prepareWriteTarget('.', session, 'work-' + name, 'parent');
  if (target.kind !== 'worktree') throw Error('expected worktree');
  return { source, manager, session, input: { work: { id: 'work-' + name, writeTarget: target } as WorkDelegation, target, parentTaskId: 'parent' } };
}
const reports = [];
{
  const f = await fixture('child-case');
  fs.renameSync(path.join(f.input.target.path, 'Value.txt'), path.join(f.input.target.path, 'value.txt'));
  const frozen = await f.manager.freeze(f.input); assert.ok(frozen.bytes > 0); assert.match(frozen.patch.toString(), /rename to value.txt/);
  const patch = path.join(root, 'stock-patch'); fs.writeFileSync(patch, frozen.patch);
  const before = files(f.source), copy = files(f.input.target.path);
  const stock = spawnSync('git', ['-C', f.source, '-c', 'core.fsmonitor=false', '-c', 'core.hooksPath=/dev/null', '-c', 'core.symlinks=true', 'apply', '--check', patch], { encoding: 'utf8', env: { ...process.env, GIT_OPTIONAL_LOCKS: '0' } });
  const result = await f.manager.integrateFrozen({ ...f.input, frozen, parentSession: f.session });
  assert.equal(result.state, 'conflict'); assert.match(result.detail ?? '', /already exists in working directory/); assert.deepEqual(files(f.source), before); assert.deepEqual(files(f.input.target.path), copy);
  reports.push({ scenario: 'APFS child-case existing Git refusal', frozenBytes: frozen.bytes, stockStatus: stock.status, stockStderr: stock.stderr.trim(), state: result.state, detail: result.detail, sourceZeroWrites: true, copyPreserved: true });
}
{
  const f = await fixture('source-case');
  fs.writeFileSync(path.join(f.input.target.path, 'Value.txt'), 'child\n');
  fs.renameSync(path.join(f.source, 'Value.txt'), path.join(f.source, 'value.txt'));
  const before = files(f.source), result = await f.manager.integrate({ ...f.input, parentSession: f.session });
  assert.equal(result.state, 'conflict'); assert.deepEqual(files(f.source), before);
  reports.push({ scenario: 'source changed literal case with same bytes', state: result.state, detail: result.detail, sourceZeroWrites: true, childBytes: fs.readFileSync(path.join(f.input.target.path, 'Value.txt'), 'utf8') });
}
{
  const f = await fixture('source-parent-link', true), outside = path.join(root, 'outside'); fs.mkdirSync(outside); fs.writeFileSync(path.join(outside, 'new.txt'), 'outside\n');
  fs.writeFileSync(path.join(f.input.target.path, 'node/new.txt'), 'child\n'); fs.rmSync(path.join(f.source, 'node'), { recursive: true }); fs.symlinkSync(outside, path.join(f.source, 'node'));
  const before = files(f.source), outsideBefore = files(outside);
  let rejectedCode = '';
  try { await f.manager.integrate({ ...f.input, parentSession: f.session }); assert.fail('expected source parent rejection'); }
  catch (error) { assert.ok(error instanceof Error && 'code' in error); rejectedCode = String(error.code); assert.equal(rejectedCode, 'integrate_failed'); assert.match(error.message, /父目录已变化或指向来源外/); }
  assert.deepEqual(files(f.source), before); assert.deepEqual(files(outside), outsideBefore);
  reports.push({ scenario: 'source parent replaced by link before nested add', code: rejectedCode, sourceZeroWrites: true, outsideZeroWrites: true });
}
console.log(JSON.stringify({ root, reports }, null, 2));
