import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { Db } from '/Users/eitrous/orca/workspaces/ruukoto/subagent-roles/packages/core/src/db.ts';
import { Store } from '/Users/eitrous/orca/workspaces/ruukoto/subagent-roles/packages/core/src/store.ts';
import { WorkCopyManager } from '/Users/eitrous/orca/workspaces/ruukoto/subagent-roles/packages/runtime/src/work-copy.ts';
import { ParentDelivery } from '/Users/eitrous/orca/workspaces/ruukoto/subagent-roles/packages/runtime/src/parent-delivery.ts';
import { fixtureSubAgentDefinition } from '/Users/eitrous/orca/workspaces/ruukoto/subagent-roles/test/helpers/subagent-definition.ts';
const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'snapshot-final-delivery-')));
fs.mkdirSync(path.join(root, 'data'));
const db = new Db(path.join(root, 'data')), store = new Store(db);
const selection = { provider: 'mock', modelId: 'mock', thinkingLevel: 'off' as const };
const project = store.createProject('probe');
const git = (cwd: string, ...args: string[]) => execFileSync('git', ['-C', cwd, ...args], { stdio: ['pipe', 'pipe', 'pipe'] });
const manager = new WorkCopyManager({ worktreeRoot: path.join(root, 'copies'), protectedRoots: () => [], execute: async input => ({ isError: false, content: execFileSync('/bin/sh', ['-c', input.command], { cwd: input.workspace, encoding: 'utf8' }) }) });
const submissions: string[] = [];
let workspaceChecks = 0;
const delivery = new ParentDelivery({ store, defaultModelSelection: () => selection, readReply: () => 'completed', isReviewEvent: () => false, resultNotice: () => null,
  sendWorkReport: () => assert.fail('unexpected send'), submit: async input => { submissions.push(input.requestId); return store.insertQueuedTask({ ...input, submissionDigest: input.requestId }).task; },
  verifyWork: work => { if (process.env.PROBE_VERIFY_WORK === '0') return; workspaceChecks += 1; if (work.writeTarget?.kind === 'worktree') manager.assertCopy(work, work.writeTarget, 'delivery'); },
  verifyAgentReport: () => assert.fail('report verification called unexpectedly') });
let count = 0;
const session = (directory: string) => { const stat = fs.statSync(directory); return store.createSession({ projectId: project.id, cwd: directory, cwdReal: directory, cwdDev: stat.dev, cwdIno: stat.ino, piSessionId: 'pi-' + ++count, confirmTools: [] }); };
async function child(kind: 'main' | 'dev') {
  const source = path.join(root, kind); fs.mkdirSync(source); fs.writeFileSync(path.join(source, 'value.txt'), 'baseline\n');
  git(source, 'init', '-q'); git(source, 'config', 'user.name', 'Probe'); git(source, 'config', 'user.email', 'probe@example.test'); git(source, 'add', '.'); git(source, 'commit', '-qm', 'baseline');
  const parentSession = session(source);
  if (kind === 'main') store.insertAgentRole({ id: 'main', projectId: project.id, sessionId: parentSession.id, workDir: source, modelSelection: selection, tools: [], createdAt: parentSession.createdAt });
  const parent = store.insertQueuedTask({ sessionId: parentSession.id, requestId: 'parent-' + kind, input: 'parent', submissionDigest: kind, modelSelection: selection }).task;
  store.transitionTask(parent.id, ['queued'], 'completed'); store.setTaskResult(parent.id, 'parent', '{}');
  const workId = 'work-' + kind, agentId = 'agent-' + kind;
  const target = await manager.prepareWriteTarget(source, parentSession, workId, parent.id);
  assert.equal(target.kind, 'worktree'); if (target.kind !== 'worktree') throw Error('expected worktree');
  const sub = session(target.path);
  store.insertSubAgent({ definition: fixtureSubAgentDefinition(), id: agentId, parentSessionId: parentSession.id, sessionId: sub.id, workDir: sub.cwdReal, activeWorkId: workId, currentTaskId: null, state: 'idle', closedAt: null, closedBy: null, createdAt: sub.createdAt });
  store.insertWorkDelegation({ id: workId, parentSessionId: parentSession.id, originTaskId: parent.id, subAgentId: agentId, requestKey: workId, paramsDigest: workId, canceledAt: null, canceledBy: null, cancelReason: null, writeTarget: target, createdAt: sub.createdAt });
  const child = store.insertQueuedTask({ sessionId: sub.id, requestId: 'child-' + kind, input: 'child', modelSelection: selection, submissionDigest: kind, parentTaskId: parent.id, workId, subAgentId: agentId }).task;
  store.transitionTask(child.id, ['queued'], 'completed', { endedAt: new Date().toISOString() }); store.setTaskResult(child.id, 'completed summary', JSON.stringify({ outcome: 'completed' }));
  const messageId = 'message-' + kind;
  store.insertSubAgentMessage({ id: messageId, workId, parentSessionId: parentSession.id, fromSubAgentId: agentId, fromTaskId: child.id, accessMode: child.accessMode, sourcePermissionVersion: child.permissionVersion,
    toSubAgentId: null, requestKey: 'message-key', paramsDigest: 'message-digest', body: '关于当前工作区的工作内消息', createdAt: new Date().toISOString(), deliveredTaskId: null, deliveredAt: null, undeliveredReason: null });
  const before = (store.db.prepare('SELECT write_target FROM work_delegations WHERE id = ?').get(workId) as { write_target: string }).write_target;
  manager.assertCopy(store.getWorkDelegation(workId)!, target, 'before');
  fs.unlinkSync(path.join(target.snapshot.repository.path, 'ruukoto-baseline'));
  assert.throws(() => manager.assertCopy(store.getWorkDelegation(workId)!, target, 'after'), { code: 'snapshot_corrupt' });
  assert.equal((store.db.prepare('SELECT write_target FROM work_delegations WHERE id = ?').get(workId) as { write_target: string }).write_target, before);
  return { child: store.getTask(child.id)!, parentSession, target, messageId };
}
try {
  const main = await child('main'); await delivery.resultRecorded(main.child, 'completed', main.child.resultSummary!);
  const wake = store.findTaskByRequest(main.parentSession.id, 'wake:' + main.child.id);
  const admitted = delivery.wakeAdmitted({ ...main.child, sessionId: main.parentSession.id, requestId: 'wake:' + main.child.id });
  const dev = await child('dev'); const injection = delivery.takeInjection(dev.parentSession.id), injected = injection.results.map(task => task.id);
  console.log(JSON.stringify({ root, deletedPrivateBaselineWithValidMetadata: true, mainWakeCreated: Boolean(wake), mainWakeAdmitted: admitted, devUnsafeCompletedResultInjected: injected.includes(dev.child.id), devUnsafeMessageInjected: injection.messages.some(message => message.id === dev.messageId), devMessageDeliveredAt: store.getSubAgentMessage(dev.messageId)!.deliveredAt, devMessageReason: store.getSubAgentMessage(dev.messageId)!.undeliveredReason, devMessageBody: store.getSubAgentMessage(dev.messageId)!.body,
    reportVerificationCalled: false, workspaceChecks, childStatuses: [store.getTask(main.child.id)!.status, store.getTask(dev.child.id)!.status], submissions }, null, 2));
} finally { db.close(); }
