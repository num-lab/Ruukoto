/**
 * smoke-09（agent-direction issue 09）远端编排器：在 tx 上以 ssh 登录账户运行
 * （本地驱动 .scratch/agent-direction/smoke-09-linux-service-management.mts 上传仓库后
 *  以 node_modules/.bin/tsx 执行；全程自包含，不转发开发机命令）。
 *
 * 真实：Linux systemd（真实 systemctl/systemd-run/journald）、helper
 *   deploy/systemd/ruukoto-service.mjs 以 root 经 sudoers 固定入口执行、白名单策略
 *   /etc/ruukoto/services.json、测试服务 ruukoto-service-test.service（真实
 *   start/restart/ExecStop 窗口）、隔离后台以 ruukoto-backend 身份运行（真实
 *   Runtime/SQLite/审批/中断恢复）、系统账户边界（ruukoto-exec 无提权）。
 * 模拟：模型（MockModelServer 脚本化响应）、NapCat/OneBot（MockOneBot，QQ 私聊；
 *   真实 QQ/Telegram 平台未实测，见末尾声明）。
 *
 * 架构纪律（本会话实测踩坑）：本进程内驻着 mock 桩（WS/HTTP 服务器），一切外部进程
 * 调用（sudo 安装、backendctl、systemctl 查询）一律异步——同步 spawnSync 会阻塞
 * 事件循环冻结桩服务器，使升级握手等在应用层超时（裸 TCP 握手在内核层不受影响，
 * 极易误判成网络问题）。
 *
 * 阶段：安装演练 → 小步验证 → A 主链路 → B 账户边界 → C 重复/越界 → D 中断恢复 →
 *       E 拒绝 → 清理（幂等；helper/策略/ops/sudoers 作为真实部署保留并注明）。
 * 退出码：0 = 全部通过；1 = 有 FAIL 或清理告警。
 */

import assert from "node:assert/strict";
import * as childProcess from "node:child_process";
import * as crypto from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import { MockModelServer, type Responder } from "../../test/helpers/mock-provider.ts";
import { MOCK_QQ_ACCOUNT, MOCK_QQ_SECRET, startMockOneBot, type MockOneBot } from "../../test/helpers/mock-onebot.ts";
import { lastUserText, waitFor, writeModelsJson } from "../../test/helpers/testkit.ts";

const SRC = path.resolve(fileURLToPath(new URL(".", import.meta.url)), "../..");
const SMOKE_HOME = "/var/lib/ruukoto-smoke09";
const DATA = `${SMOKE_HOME}/data`;
const AGENT = `${SMOKE_HOME}/agent`;
const CONTROL = `${SMOKE_HOME}/control`;
const BACKEND_LOG = `${SMOKE_HOME}/backend.log`;
const BACKEND_USER = "ruukoto-backend";
const EXEC_USER = "ruukoto-exec";
const HELPER = "/usr/local/libexec/ruukoto/ruukoto-service";
const POLICY = "/etc/ruukoto/services.json";
const OPS_DIR = "/var/lib/ruukoto/service-ops";
const SUDOERS = "/etc/sudoers.d/ruukoto";
const UNIT = "ruukoto-service-test.service";
const UNIT_PATH = `/etc/systemd/system/${UNIT}`;
const DROPIN_DIR = `/etc/systemd/system/${UNIT}.d`;
const TEST_SH = "/usr/local/libexec/ruukoto/ruukoto-service-test.sh";
const TEST_STATE = "/var/lib/ruukoto-service-test";
const QQ_OWNER = "880001";
const startedAt = Date.now();

// ---------- 小工具（全部异步：本进程驻有 mock 桩，禁止阻塞事件循环） ----------

const results: Array<{ name: string; ok: boolean; detail: string }> = [];
async function check(name: string, fn: () => Promise<void> | void): Promise<void> {
  try {
    await fn();
    results.push({ name, ok: true, detail: "" });
    console.log(`PASS ${name}`);
  } catch (err) {
    results.push({ name, ok: false, detail: String((err as Error).message ?? err) });
    console.log(`FAIL ${name}: ${(err as Error).message}`);
  }
}

/** 证据摘录打印（行数有界）。 */
function evidence(label: string, text: string, maxLines = 12): void {
  const lines = text.trimEnd().split("\n");
  const shown = lines.slice(0, maxLines).join("\n");
  console.log(`--- 证据 ${label} ---\n${shown}${lines.length > maxLines ? `\n…（共 ${lines.length} 行）` : ""}`);
}

function run0(cmd: string, args: string[], opts: { input?: string } = {}): Promise<{ code: number; out: string; err: string }> {
  return new Promise((resolve) => {
    const child = childProcess.execFile(cmd, args, { encoding: "utf8", maxBuffer: 8 * 1024 * 1024 }, (err, stdout, stderr) => {
      const anyErr = err as (Error & { code?: number | string }) | null;
      const code = anyErr === null ? 0 : typeof anyErr.code === "number" ? anyErr.code : -1;
      resolve({ code, out: stdout ?? "", err: stderr ?? "" });
    });
    if (opts.input !== undefined && child.stdin) {
      child.stdin.write(opts.input);
      child.stdin.end();
    }
  });
}
const sudo = (args: string[], opts: { input?: string } = {}) => run0("sudo", ["-n", ...args], opts);
/** 以指定系统账户执行（边界证据用）。 */
const asUser = (user: string, args: string[], opts: { input?: string } = {}) => sudo(["-u", user, ...args], opts);

async function backendctl<T = any>(action: string, payload: Record<string, unknown>): Promise<T> {
  const r = await sudo([
    "-u", BACKEND_USER, process.execPath,
    `${SRC}/node_modules/.bin/tsx`,
    `${SRC}/.scratch/agent-direction/smoke09-backendctl.mts`, action, JSON.stringify(payload),
  ]);
  if (r.code !== 0) throw new Error(`backendctl ${action} 失败：${r.err.slice(0, 500) || r.out.slice(0, 500)}`);
  return JSON.parse(r.out.trim().split("\n").pop()!);
}

const query = (sql: string, params: unknown[] = []): Promise<any[]> =>
  backendctl<{ rows: any[] }>("query", { db: `${DATA}/ruukoto.db`, sql, params }).then((r) => r.rows);

const startsCount = async (): Promise<number> => Number((await sudo(["bash", "-c", `wc -l < ${TEST_STATE}/starts.log 2>/dev/null || echo 0`])).out.trim() || "0");
const startsLog = (): Promise<string> => sudo(["cat", `${TEST_STATE}/starts.log`]).then((r) => r.out);
const invocationId = (): Promise<string> => run0("systemctl", ["show", "-p", "InvocationID", "--value", UNIT]).then((r) => r.out.trim());
const policySha = (): string => crypto.createHash("sha256").update(fs.readFileSync(POLICY)).digest("hex");

/** 最近一次 service_manage 的 hostOpId（账本）。 */
const lastServiceOp = async (): Promise<string | undefined> =>
  (await query("SELECT id FROM tool_ops WHERE tool_name = 'service_manage' ORDER BY intent_recorded_at DESC LIMIT 1"))[0]?.id;
const claimExists = async (op: string): Promise<boolean> =>
  (await sudo(["bash", "-c", `test -d ${OPS_DIR}/${op} && echo yes || echo no`])).out.trim() === "yes";
const opUnitsListed = (): Promise<string> =>
  run0("systemctl", ["list-units", "--all", "--type=service", "--no-legend", "--plain", "ruukoto-service-op-*"]).then((r) => r.out);

// ---------- 脚本化模型（仅模型层打桩；语义同 test/78 responder） ----------

function smokeResponder(): Responder {
  return async (req) => {
    const last = req.messages.at(-1) as any;
    if (last?.role === "tool") {
      const text = typeof last.content === "string" ? last.content : JSON.stringify(last.content);
      return { kind: "text", text: `FINAL: ${text.slice(0, 1200)}` };
    }
    const text = lastUserText(req);
    const status = text.match(/SVC-STATUS\s+(\S+)/);
    if (status) return { kind: "tool_calls", calls: [{ id: "svc-ins-1", name: "service_inspect", arguments: { unit: status[1] } }] };
    const restart = text.match(/SVC-RESTART\s+(\S+)/);
    if (restart) return { kind: "tool_calls", calls: [{ id: "svc-rst-1", name: "service_manage", arguments: { unit: restart[1], action: "restart" } }] };
    return { kind: "text", text: "pong-smoke09" };
  };
}

// ---------- 隔离后台进程 ----------

let backendChild: childProcess.ChildProcess | null = null;
function spawnBackend(): void {
  backendChild = childProcess.spawn("sudo", [
    "-n", "-u", BACKEND_USER, "bash", "-c",
    `export RUUKOTO_CONTROL_DIR=${CONTROL} RUUKOTO_SERVICE_HELPER=${HELPER} RUUKOTO_SERVICE_POLICY=${POLICY} HOME=${SMOKE_HOME}/home; ` +
      `cd ${SRC} && exec ${process.execPath} node_modules/.bin/tsx src/cli.ts server ` +
      `--data-dir ${DATA} --agent-dir ${AGENT} --tools mock >> ${BACKEND_LOG} 2>&1`,
  ], { detached: true, stdio: "ignore" });
}

/** 隔离后台全部进程（tsx 包装 + loader + 主进程都匹配 data-dir；单个 kill 必须全灭，否则孙子进程继续执行——本会话实测踩坑）。 */
const backendPids = async (): Promise<string[]> =>
  (await run0("pgrep", ["-u", BACKEND_USER, "-f", DATA])).out.trim().split("\n").filter(Boolean);

const backendAlive = async (): Promise<boolean> => (await backendPids()).length > 0;

const killBackend = async (signal: "TERM" | "KILL"): Promise<void> => {
  const pids = await backendPids();
  if (pids.length) await sudo(["kill", `-${signal === "KILL" ? "9" : "TERM"}`, ...pids]);
};

async function waitBackendUp(): Promise<void> {
  await waitFor("隔离后台控制面可握手", async () => {
    try {
      await backendctl("handshake", { controlDir: CONTROL });
      return true;
    } catch {
      return false;
    }
  }, 90_000);
}

async function stopBackend(): Promise<void> {
  await killBackend("TERM");
  await waitFor("隔离后台已停止", async () => !(await backendAlive()), 30_000).catch(async () => {
    await killBackend("KILL");
  });
}

// ---------- QQ 文本 ----------

const qqTexts = (ob: MockOneBot) =>
  ob.actions.filter((a) => a.action === "send_private_msg").map((a) => (a.params.message as any[]).filter((s) => s?.type === "text").map((s) => String(s.data?.text ?? "")).join(""));
const noticeId = (text: string) => text.match(/审批 ID：(\S+)/)![1]!;
const noticeVersion = (text: string) => Number(text.match(/权限版本：v(\d+)/)![1]);

let ob!: MockOneBot;
let model!: MockModelServer;
const pushQq = (messageId: number, text: string) => ob.pushPrivateMessage({ userId: QQ_OWNER, messageId, segments: [{ type: "text", data: { text } }] });

async function waitForConf(): Promise<{ id: string; version: number }> {
  const before = qqTexts(ob).filter((t) => t.includes("【需要审批】")).length;
  await waitFor("审批通知送达", () => qqTexts(ob).filter((t) => t.includes("【需要审批】")).length > before, 30_000);
  const notice = qqTexts(ob).filter((t) => t.includes("【需要审批】")).at(-1)!;
  return { id: noticeId(notice), version: noticeVersion(notice) };
}

async function waitForOp(): Promise<string> {
  let op: string | undefined;
  await waitFor(
    "service_manage 操作入账",
    async () => {
      op = await lastServiceOp().catch(() => undefined);
      return op !== undefined;
    },
    30_000,
  );
  return op!;
}

// ==================================================================

const cleanupErrors: string[] = [];
let unitInstalled = false;
let homeCreated = false;

async function installPhase(): Promise<void> {
  // helper（root 0700；幂等覆盖为仓库当前版本）
  await sudo(["install", "-D", "-m", "0700", `${SRC}/deploy/systemd/ruukoto-service.mjs`, HELPER]);
  // 策略（root 0644；本机 identity + 执行 uid/gid + 只列测试服务）
  const [uidR, gidR] = await Promise.all([run0("id", ["-u", EXEC_USER]), run0("id", ["-g", EXEC_USER])]);
  const policy = JSON.stringify({
    machineId: fs.readFileSync("/etc/machine-id", "utf8").trim(),
    execUid: Number(uidR.out.trim()),
    execGid: Number(gidR.out.trim()),
    services: { [UNIT]: { actions: ["restart"] } },
  }, null, 2) + "\n";
  const tmpPolicy = `/tmp/smoke09-policy-${process.pid}.json`;
  fs.writeFileSync(tmpPolicy, policy);
  await sudo(["install", "-d", "-m", "0755", path.dirname(POLICY)]);
  await sudo(["install", "-m", "0644", tmpPolicy, POLICY]);
  fs.rmSync(tmpPolicy, { force: true });
  // ops 目录（root 0700；认领标记按生产语义持久保留）
  await sudo(["install", "-d", "-m", "0700", OPS_DIR]);
  // sudoers 更新为仓库版本（缺失 ruukoto-service 条目时更新；visudo 校验）
  const repoSudoers = fs.readFileSync(`${SRC}/deploy/systemd/sudoers.d.ruukoto`, "utf8");
  const current = (await sudo(["cat", SUDOERS])).out;
  if (current.trim() !== repoSudoers.trim()) {
    const tmp = `/tmp/smoke09-sudoers-${process.pid}`;
    fs.writeFileSync(tmp, repoSudoers);
    const v = await sudo(["visudo", "-cf", tmp]);
    assert.equal(v.code, 0, `visudo 校验仓库 sudoers：${v.err}`);
    await sudo(["install", "-m", "0440", tmp, SUDOERS]);
    fs.rmSync(tmp, { force: true });
  }
  const v2 = await sudo(["visudo", "-cf", SUDOERS]);
  assert.equal(v2.code, 0, "visudo 校验现役 sudoers");

  // 测试服务（root 启动程序；单元 + smoke drop-in 拉长 restart 的 stop 阶段，
  // 制造「已向 PID 1 派发、命令客户端尚在等待」的中断窗口——安装即证据的一部分）
  await sudo(["install", "-D", "-m", "0755", `${SRC}/deploy/systemd/ruukoto-service-test.sh`, TEST_SH]);
  const unitTmp = `/tmp/smoke09-unit-${process.pid}`;
  fs.writeFileSync(unitTmp, fs.readFileSync(`${SRC}/deploy/systemd/ruukoto-service-test.service`, "utf8"));
  await sudo(["install", "-m", "0644", unitTmp, UNIT_PATH]);
  fs.rmSync(unitTmp, { force: true });
  const dropinTmp = `/tmp/smoke09-dropin-${process.pid}.conf`;
  fs.writeFileSync(dropinTmp, "[Service]\n# smoke-09 受控改动：拉长 restart 的 stop 阶段（~20s），制造「已派发、客户端尚在--wait」的中断窗口（覆盖编排器轮询耗时）\nExecStop=/bin/sleep 20\n");
  await sudo(["install", "-D", "-m", "0644", dropinTmp, `${DROPIN_DIR}/50-smoke09-execstop.conf`]);
  fs.rmSync(dropinTmp, { force: true });
  await sudo(["install", "-d", "-o", EXEC_USER, "-g", EXEC_USER, "-m", "0750", TEST_STATE]);
  const verify = await run0("systemd-analyze", ["verify", UNIT]);
  evidence("systemd-analyze verify（安装语法小步验证）", `${verify.out}${verify.err}` || "(无输出 = 通过)", 6);
  await sudo(["systemctl", "daemon-reload"]);
  await sudo(["systemctl", "enable", "--now", UNIT]);
  unitInstalled = true;
  await waitFor("测试服务 active", async () => (await run0("systemctl", ["is-active", UNIT])).out.trim() === "active", 15_000);
  // Type=simple 的 active 先于启动程序写日志：等首行出现（starts.log 竞态）
  await waitFor("starts.log 首行", async () => (await startsCount()) >= 1, 15_000);
}

async function cleanupPhase(): Promise<void> {
  const rec = async (what: string, fn: () => Promise<void> | void) => {
    try {
      await fn();
    } catch (err) {
      cleanupErrors.push(`${what}: ${(err as Error).message}`);
    }
  };
  await rec("停隔离后台", async () => {
    await killBackend("KILL");
  });
  if (unitInstalled) {
    await rec("停用测试服务", async () => {
      await sudo(["systemctl", "disable", "--now", UNIT]);
      await sudo(["rm", "-f", UNIT_PATH, TEST_SH]);
      await sudo(["rm", "-rf", DROPIN_DIR, TEST_STATE]);
      await sudo(["systemctl", "daemon-reload"]);
      await sudo(["systemctl", "reset-failed", UNIT]);
    });
  }
  if (homeCreated) await rec("删隔离目录", () => sudo(["rm", "-rf", SMOKE_HOME]).then(() => {}));
}

// ==================================================================

console.log(`smoke-09 远端编排器开始（${new Date().toISOString()}）`);
{
  const sysv = await run0("systemctl", ["--version"]);
  evidence("环境基线", [
    `node ${process.version}  platform ${process.platform}`,
    (sysv.out.trim().split("\n")[0] ?? ""),
    `日常后台状态：${(await run0("systemctl", ["is-active", "ruukoto-backend"])).out.trim()}（演练期间不中断、不修改）`,
    `machineId ${fs.readFileSync("/etc/machine-id", "utf8").trim()}`,
  ].join("\n"), 8);
}

let exitCode = 0;
try {
  await check("准备：账户/权限/sudo -n 就位", async () => {
    assert.equal((await run0("id", [BACKEND_USER])).code, 0, "ruukoto-backend 存在");
    assert.equal((await run0("id", [EXEC_USER])).code, 0, "ruukoto-exec 存在");
    assert.equal((await sudo(["true"])).code, 0, "sudo -n 可用");
  });

  await check("安装演练：helper/策略/ops/sudoers/测试服务（幂等）", installPhase);
  evidence("安装后策略", (await sudo(["cat", POLICY])).out, 10);
  evidence("现役 sudoers（仓库版本）", (await sudo(["cat", SUDOERS])).out, 8);
  evidence("测试服务初始状态", (await run0("systemctl", ["show", UNIT, "-p", "ActiveState,InvocationID,ExecStart,ExecStop,User"])).out, 10);
  const inv0 = await invocationId();
  const starts0 = await startsCount();
  evidence("初始 InvocationID 与 starts.log", `InvocationID=${inv0}\nstarts.log 行数=${starts0}\n${await startsLog()}`, 8);

  // 小步验证：真实 helper 经后台账户 + sudoers 固定入口 inspect
  await check("小步验证：后台账户经 sudoers 固定入口直接 inspect（真实 helper/sudo/systemd）", async () => {
    const r = await asUser(BACKEND_USER, ["sudo", "-n", HELPER, "inspect", UNIT]);
    assert.equal(r.code, 0, `inspect 应成功：${r.err} ${r.out}`);
    assert.ok(r.out.includes("ActiveState=active"), `fd1 原始 systemctl 输出：${r.out}`);
    assert.ok(r.out.includes(`InvocationID=${inv0}`));
    assert.ok(r.err.includes('"ok":true') || r.out.includes('"ok":true'), "stderr 前缀结构化应答 ok");
    evidence("helper inspect（fd1 原始行 + stderr RUUKOTO_SERVICE_REPLY 应答）", `${r.out}${r.err}`, 16);
  });

  // ---------- 隔离后台 ----------
  model = new MockModelServer(smokeResponder());
  const modelUrl = await model.start();
  ob = await startMockOneBot({});
  await sudo(["install", "-d", "-o", BACKEND_USER, "-g", BACKEND_USER, "-m", "0700", DATA]);
  // 角色引导在数据目录同级建 agent-work（orchestrator.ensureRoles）
  await sudo(["install", "-d", "-o", BACKEND_USER, "-g", BACKEND_USER, "-m", "0700", `${SMOKE_HOME}/agent-work`]);
  await sudo(["install", "-d", "-o", BACKEND_USER, "-g", process.env.USER ?? "eitrous", "-m", "0770", AGENT]);
  await sudo(["install", "-d", "-o", BACKEND_USER, "-g", BACKEND_USER, "-m", "0700", CONTROL, `${SMOKE_HOME}/home`]);
  homeCreated = true;
  await writeModelsJson({ agentDir: AGENT } as any, modelUrl);
  await sudo(["touch", BACKEND_LOG]);
  await sudo(["chown", `${BACKEND_USER}:${BACKEND_USER}`, BACKEND_LOG]);
  spawnBackend();
  await waitBackendUp();
  const conf = await backendctl<{ online: boolean; status: any }>("configure", {
    controlDir: CONTROL,
    url: ob.url,
    secret: MOCK_QQ_SECRET,
    selfId: MOCK_QQ_ACCOUNT,
    owner: QQ_OWNER,
  });
  assert.equal(conf.online, true, `QQ（mock）在线：${JSON.stringify(conf.status).slice(0, 300)}`);
  console.log("隔离后台已启动并完成 QQ 私聊配置（mock onebot 回环）");

  // 链路热身：先发一条普通私聊，等它完整走完 ws 入站 → 编排 → 模型（SSE）→ outbox 发送
  // 的整条回路；超时未走通则先报诊断再失败（一次性冷启动不混入证据断言）
  {
    pushQq(100, "SMOKE-WARMUP");
    try {
      await waitFor("热身回路走通", () => qqTexts(ob).some((t) => t.includes("pong-smoke09")), 180_000);
      console.log(`热身回路走通（T+${((Date.now() - startedAt) / 1000).toFixed(0)}s）`);
    } catch (err) {
      const diag = {
        modelCalls: model.calls.length,
        qqActions: ob.actions.map((a) => a.action),
        inbound: await query("SELECT source, status, event_kind, substr(body,1,80) AS body FROM inbound_events ORDER BY received_at DESC LIMIT 5").catch((e) => String(e)),
        tasks: await query("SELECT status, substr(input,1,40) AS input FROM tasks ORDER BY created_at DESC LIMIT 5").catch((e) => String(e)),
        outbox: await query("SELECT source_kind, status, substr(text,1,60) AS text FROM notification_ops ORDER BY id DESC LIMIT 5").catch((e) => String(e)),
      };
      console.log(`热身诊断：${JSON.stringify(diag, null, 2)}`);
      throw err;
    }
  }

  // ---------- A. 主链路 ----------
  let confA = "";
  let hostOpA = "";
  await check("A1 状态检查：QQ 私聊 SVC-STATUS → 真实 systemctl 状态回原入口", async () => {
    pushQq(1, `SVC-STATUS ${UNIT}`);
    await waitFor("状态检查最终回答", () => qqTexts(ob).some((t) => t.includes("FINAL:") && t.includes("ActiveState=active")), 30_000);
    const final = qqTexts(ob).find((t) => t.includes("FINAL:") && t.includes("ActiveState"))!;
    assert.ok(final.includes(inv0), `回答含初始 InvocationID：${final.slice(0, 300)}`);
    evidence("A1 最终回答摘录", final, 4);
  });

  let inv1 = "";
  await check("A2 批准流程：通知 → 详情 → /approve → 真实重启恰好一次，结果与状态分述", async () => {
    pushQq(2, `SVC-RESTART ${UNIT}`);
    const d = await waitForConf();
    confA = d.id;
    pushQq(3, `/approval ${d.id}`);
    await waitFor("详情回执", () => qqTexts(ob).some((t) => t.includes(`审批 ${d.id}`) && t.includes(UNIT)), 30_000);
    pushQq(4, `/approve ${d.id} ${d.version}`);
    await waitFor("批准回执", () => qqTexts(ob).some((t) => t.includes("已接受批准") && t.includes(d.id)), 30_000);
    await waitFor("最终回答含管理命令结果", () => qqTexts(ob).some((t) => t.includes("FINAL:") && t.includes("管理命令结果")), 60_000);
    const final = qqTexts(ob).find((t) => t.includes("管理命令结果"))!;
    inv1 = await invocationId();
    assert.notEqual(inv1, inv0, "InvocationID 已变化（真实重启）");
    assert.ok(final.includes("随后观察到的服务状态"), "管理命令结果与随后状态分述");
    assert.ok(final.includes(inv1.slice(0, 12)) || final.includes(inv1), "最终回答含新 InvocationID");
    assert.equal(await startsCount(), starts0 + 1, `starts.log 恰好增加一次（${starts0} → ${starts0 + 1}）`);
    assert.equal((await query("SELECT COUNT(*) AS n FROM confirmations WHERE id = ? AND status = 'approved' AND consumed_at IS NOT NULL", [confA]))[0].n, 1, "批准已消费一次");
    hostOpA = (await query("SELECT tool_op_id FROM confirmations WHERE id = ?", [confA]))[0].tool_op_id;
    assert.match(hostOpA, /^op_[0-9a-f]{24}$/);
    assert.ok(await claimExists(hostOpA), `认领标记持久保留：${OPS_DIR}/${hostOpA}`);
    evidence("A2 最终回答摘录", final, 6);
    evidence("starts.log（真实启动计数）", await startsLog(), 6);
  });

  await check("A3 派生命令单元曾真实存在：journalctl 记录 ruukoto-service-op-<hostOpId>", async () => {
    const j = await sudo(["journalctl", "-u", `ruukoto-service-op-${hostOpA}.service`, "--no-pager", "-n", "20", "-o", "cat"]);
    assert.equal(j.code, 0, j.err);
    assert.ok(j.out.trim().length > 0, "journald 留有该瞬态单元记录");
    const claim = (await sudo(["cat", `${OPS_DIR}/${hostOpA}/claim.json`])).out;
    assert.ok(claim.includes(UNIT), "claim.json 记录目标与修订");
    evidence(`journalctl -u ruukoto-service-op-${hostOpA}.service`, j.out, 8);
    evidence("claim.json", claim, 8);
  });

  // ---------- B. 真实账户边界 ----------
  await check("B 边界：执行账户无提权（helper EACCES / 策略写拒绝 / 控制面令牌读拒绝）；后台 sudo -n 入口可用", async () => {
    const [e1, e2, e3, b1] = await Promise.all([
      asUser(EXEC_USER, [HELPER, "inspect", UNIT]),
      asUser(EXEC_USER, ["tee", POLICY], { input: "tamper\n" }),
      asUser(EXEC_USER, ["cat", `${CONTROL}/owner.token`]),
      asUser(BACKEND_USER, ["sudo", "-n", HELPER, "inspect", UNIT]),
    ]);
    assert.notEqual(e1.code, 0, `ruukoto-exec 执行 helper 应拒绝（root 0700）：exit=${e1.code}`);
    assert.ok(/permission denied/i.test(e1.err) || /permission denied/i.test(e1.out), (e1.err || e1.out).slice(0, 200));
    assert.notEqual(e2.code, 0, "ruukoto-exec 写策略应拒绝");
    assert.ok(/permission denied/i.test(e2.err), e2.err.slice(0, 200));
    assert.notEqual(e3.code, 0, "ruukoto-exec 读控制面令牌应拒绝");
    assert.equal(b1.code, 0, `后台账户经 sudoers 固定入口可用：${b1.err.slice(0, 200)}`);
    assert.ok(b1.out.includes("ActiveState=active"));
    evidence("B 越权拒绝（预期非零）", [
      `[ruukoto-exec helper] exit=${e1.code} ${(e1.err || e1.out).trim().split("\n")[0]}`,
      `[ruukoto-exec 写策略] exit=${e2.code} ${e2.err.trim().split("\n")[0]}`,
      `[ruukoto-exec 读令牌] exit=${e3.code} ${(e3.err || e3.out).trim().split("\n")[0]}`,
      `[ruukoto-backend sudo -n inspect] exit=${b1.code}（可用）`,
    ].join("\n"), 8);
  });

  // ---------- C. 重复与越界 ----------
  await check("C1 同 hostOpId 重复启动：already_claimed，真实零重启", async () => {
    const before = await startsCount();
    const r = await asUser(BACKEND_USER, ["sudo", "-n", HELPER, "restart", hostOpA, policySha(), crypto.createHash("sha256").update("x").digest("hex"), UNIT]);
    assert.notEqual(r.code, 0, "应拒绝");
    assert.ok(r.err.includes("already_claimed") || r.out.includes("already_claimed"), `stderr 前缀应答拒绝原因：${r.out}${r.err}`);
    assert.equal(await startsCount(), before, "零重启");
    evidence("C1 already_claimed 应答", `${r.out}${r.err}`.trim().split("\n").pop()!, 3);
  });

  await check("C2 批准期间策略被改：消费事务 recheck 失效，零重启（随后恢复策略）", async () => {
    const canonical = (await sudo(["cat", POLICY])).out;
    const before = await startsCount();
    pushQq(10, `SVC-RESTART ${UNIT}`);
    const d = await waitForConf();
    // 批准到达前追加字节改动（内容变化 → 修订变化）
    await sudo(["bash", "-c", `printf '\\n' >> ${POLICY}`]);
    pushQq(11, `/approve ${d.id} ${d.version}`);
    await waitFor("策略 recheck 拒绝语义到达", () => qqTexts(ob).some((t) => t.includes("FINAL:") && t.includes("策略在确认期间已变化")), 60_000);
    assert.equal(await startsCount(), before, "策略变化：零管理请求");
    assert.equal((await query("SELECT status FROM confirmations WHERE id = ?", [d.id]))[0].status, "stale", "批准失效");
    const tmp = `/tmp/smoke09-policy-restore-${process.pid}`;
    fs.writeFileSync(tmp, canonical);
    await sudo(["install", "-m", "0644", tmp, POLICY]);
    fs.rmSync(tmp, { force: true });
    evidence("C2 最终回答摘录", qqTexts(ob).find((t) => t.includes("策略在确认期间已变化"))!, 3);
  });

  await check("C3 单元已改未 daemon-reload：helper 拒绝请求（revision_mismatch/reload_required），starts 不增（随后恢复）", async () => {
    const before = await startsCount();
    pushQq(12, `SVC-RESTART ${UNIT}`);
    const d = await waitForConf();
    await sudo(["bash", "-c", `printf '# smoke09-tamper\\n' >> ${UNIT_PATH}`]);
    pushQq(13, `/approve ${d.id} ${d.version}`);
    await waitFor("修订拒绝语义到达", () => qqTexts(ob).some((t) => t.includes("FINAL:") && t.includes("管理操作未执行")), 60_000);
    const final = qqTexts(ob).find((t) => t.includes("管理操作未执行"))!;
    assert.ok(final.includes("revision_mismatch") || final.includes("reload_required"), `拒绝原因如实：${final.slice(0, 300)}`);
    assert.equal(await startsCount(), before, "零重启");
    evidence("C3 最终回答摘录", final, 4);
    const tmp = `/tmp/smoke09-unit-restore-${process.pid}`;
    fs.writeFileSync(tmp, fs.readFileSync(`${SRC}/deploy/systemd/ruukoto-service-test.service`, "utf8"));
    await sudo(["install", "-m", "0644", tmp, UNIT_PATH]);
    fs.rmSync(tmp, { force: true });
    await sudo(["systemctl", "daemon-reload"]);
  });

  await check("C4 越界目标：ruukoto-backend.service（固定拒绝清单）与 other.service（白名单外）全部拒绝", async () => {
    const before = qqTexts(ob).filter((t) => t.includes("FINAL:") && t.includes("服务管理不可用")).length;
    pushQq(14, "SVC-STATUS ruukoto-backend.service");
    await waitFor("固定拒绝到达", () => qqTexts(ob).filter((t) => t.includes("FINAL:") && t.includes("服务管理不可用")).length > before, 30_000);
    pushQq(15, "SVC-STATUS other.service");
    await waitFor("白名单外拒绝到达", () => qqTexts(ob).filter((t) => t.includes("FINAL:") && t.includes("服务管理不可用")).length > before + 1, 30_000);
    evidence("C4 摘录", qqTexts(ob).filter((t) => t.includes("服务管理不可用")).slice(-2).join("\n---\n"), 5);
  });

  // ---------- D. 中断恢复（真实 kill -9 隔离后台） ----------
  let hostOpD = "";
  await check("D 中断恢复：派发后 kill -9 隔离后台 → op 效果未知、starts 恰 +1、不自动重发", async () => {
    const before = await startsCount();
    pushQq(20, `SVC-RESTART ${UNIT}`);
    const d = await waitForConf();
    pushQq(21, `/approve ${d.id} ${d.version}`);
    hostOpD = await waitForOp();
    await waitFor("认领目录出现（已消费）", () => claimExists(hostOpD), 15_000);
    await waitFor("派生命令单元在册（ExecStop 窗口）", async () => (await opUnitsListed()).includes(hostOpD), 20_000);
    evidence("D 派发窗口", `${await opUnitsListed()}claim: ${OPS_DIR}/${hostOpD}`, 6);
    assert.ok(await backendAlive(), "后台在运行");
    await killBackend("KILL");
    await waitFor("真实重启完成（starts +1）", async () => (await startsCount()) === before + 1, 90_000);
    await waitFor("派生命令单元已退出", async () => !(await opUnitsListed()).includes(hostOpD), 90_000);
    spawnBackend();
    await waitBackendUp();
    const qq = await backendctl<{ online: boolean }>("qqonline", { controlDir: CONTROL });
    assert.equal(qq.online, true, "新代次 QQ（mock）回在线");
    const op = (await query("SELECT result_summary, effect_unknown FROM tool_ops WHERE id = ?", [hostOpD]))[0];
    assert.equal(op.effect_unknown, 1, `op 效果未知：${JSON.stringify(op)}`);
    const confRow = (await query("SELECT status, consumed_at FROM confirmations WHERE id = ?", [d.id]))[0];
    assert.ok(confRow.consumed_at, "消费事实保留");
    const taskRow = (await query("SELECT status, effect_unknown FROM tasks WHERE id = (SELECT task_id FROM confirmations WHERE id = ?)", [d.id]))[0];
    assert.equal(taskRow.status, "interrupted", "崩溃窗口任务标中断");
    assert.equal(taskRow.effect_unknown, 1, "任务级效果未知标记");
    await new Promise((r) => setTimeout(r, 6_000));
    assert.equal(await startsCount(), before + 1, "恢复后不自动重发（无二次启动）");
    evidence("D 账本行", JSON.stringify({ op, confirmation: confRow, task: taskRow }), 6);
    evidence("D starts.log", await startsLog(), 8);
    // crash 重连后给 ws/入站恢复一个稳定窗口再进 E（否则推送可能落在重连抖动里）
    {
      const qq2 = await backendctl<{ online: boolean }>("qqonline", { controlDir: CONTROL });
      assert.equal(qq2.online, true, "新代次 QQ（mock）稳定在线");
    }
  });

  // ---------- E. 拒绝零执行（先核实崩溃恢复语义：队列暂停、拥有者 resume 后才调度） ----------
  await check("E 拒绝：/reject 零执行，starts 不变；崩溃后会话队列暂停，resume 后排队消息才调度", async () => {
    const before = await startsCount();
    const sess = (await query("SELECT id, queue_state FROM sessions WHERE id = (SELECT session_id FROM agent_roles WHERE id = 'main')"))[0];
    assert.equal(sess.queue_state, "paused", "崩溃恢复后主会话队列按设计暂停（不自动调度，等拥有者 resume）");
    const noticesBefore = qqTexts(ob).filter((t) => t.includes("【需要审批】")).length;
    pushQq(30, `SVC-RESTART ${UNIT}`);
    await new Promise((r) => setTimeout(r, 3_000));
    assert.equal(qqTexts(ob).filter((t) => t.includes("【需要审批】")).length, noticesBefore, "暂停期间排队任务不自动启动（无新审批通知）");
    await backendctl("resume", { controlDir: CONTROL, sessionId: sess.id });
    const d = await waitForConf();
    pushQq(31, `/reject ${d.id} ${d.version}`);
    await waitFor("拒绝回执", () => qqTexts(ob).some((t) => t.includes("已拒绝") && t.includes(d.id)), 30_000);
    await waitFor("拒绝语义最终回答", () => qqTexts(ob).some((t) => t.includes("FINAL:") && t.includes("拥有者拒绝执行 service_manage")), 30_000);
    await new Promise((r) => setTimeout(r, 1_000));
    assert.equal(await startsCount(), before, "拒绝零执行");
    assert.equal((await query("SELECT consumed_at FROM confirmations WHERE id = ?", [d.id]))[0].consumed_at, null, "未消费");
  });

  await check("收尾：日常后台未被波及", async () => {
    assert.equal((await run0("systemctl", ["is-active", "ruukoto-backend"])).out.trim(), "active", "日常后台全程 active");
  });
} catch (err) {
  results.push({ name: "编排器未捕获异常", ok: false, detail: String((err as Error).stack ?? err) });
  console.log(`FAIL 编排器未捕获异常：${(err as Error).stack ?? err}`);
  exitCode = 1;
} finally {
  await stopBackend();
  // 后台日志取一份到 /tmp 供事后查阅（隔离目录随后删除）
  if (fs.existsSync(BACKEND_LOG)) await sudo(["bash", "-c", `cp ${BACKEND_LOG} /tmp/smoke09-backend.log && chmod 0644 /tmp/smoke09-backend.log`]).catch(() => ({}));
  await cleanupPhase().catch((err) => cleanupErrors.push(`清理异常：${(err as Error).message}`));
  if (model) await model.close();
  if (ob) await ob.close();
}

console.log(`\n--- 清理状态 ---`);
console.log(`已还原：测试服务停用并卸载（单元/drop-in/启动程序/状态目录删除）；隔离后台已停止；${SMOKE_HOME} 已删除`);
console.log(`按真实部署保留：${HELPER}（root 0700）、${POLICY}（root 0644）、${OPS_DIR}（root 0700，含历次认领标记）、${SUDOERS}（仓库版本）`);
if (cleanupErrors.length) {
  console.log(`清理告警：${cleanupErrors.join("；")}`);
  exitCode = 1;
}
const failed = results.filter((r) => !r.ok);
console.log("\n模拟：模型（MockModelServer）、NapCat/OneBot（MockOneBot QQ 私聊）——打桩平台，不代表真实 QQ/Telegram 已验收");
console.log("真实：Linux systemd（systemctl/systemd-run/journald）、root helper + sudoers 固定入口、白名单策略、测试服务真实 start/restart、隔离后台（ruukoto-backend 身份）+ 真实 Runtime/SQLite/审批/中断恢复、系统账户边界（ruukoto-exec 无提权）");
console.log(`\n结果：${results.length - failed.length}/${results.length} 通过（耗时 ${((Date.now() - startedAt) / 1000).toFixed(1)}s）`);
if (failed.length > 0 || exitCode !== 0) process.exit(1);
