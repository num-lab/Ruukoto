import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { getWorkflowStep,listWorkflowExecutions,requireWorkflowRun,workflowTerminal } from '@ruukoto/core/workflow.ts';
import { initGitRepo } from './test/helpers/git-fixture.ts';
import { afterTool,lastUserText,realTools,startTestRuntime,waitFor } from './test/helpers/testkit.ts';
const t=await startTestRuntime('zero-verification-audit',req=>{
 const verify=lastUserText(req).includes('"verify":"change"');
 if(verify) return {kind:'text',text:'{"passed":true}'};
 if(afterTool(req))return {kind:'text',text:'修改完成'};
 return {kind:'tool_calls',calls:[{id:'modify',name:'write',arguments:{path:'value.txt',content:'changed\n'}}]};
},{config:realTools(),workDirs:1});
try{
 fs.writeFileSync(path.join(t.work[0],'value.txt'),'base\n');initGitRepo(t.work[0]);
 const rt=t.runtime,session=await rt.createSession({projectName:'audit',cwd:t.work[0]});
 const parent=rt.store.withTx(()=>{
 rt.store.setSessionQueueState(session.id,'paused','test_source');
 const task=rt.store.insertQueuedTask({sessionId:session.id,requestId:'audit',input:'owner',modelSelection:rt.defaultSelection,submissionDigest:'audit',accessMode:'full_access'}).task;
 rt.store.transitionTask(task.id,['queued'],'running');return rt.store.getTask(task.id)!;
 });
 const run=rt.workflows!.start({sourceTaskId:parent.id,requestKey:'audit',input:null,script:'await agent("change",{request:"修改",target:"."});await agent("validate",{request:"验证",verify:"change",dependsOn:["change"]});return await integrate("merge",{steps:["validate"],dependsOn:["validate"],check:"true"});'});
 rt.store.withTx(()=>rt.store.endTask(parent.id,['running'],'completed'));
 await waitFor('audit workflow',()=>workflowTerminal(requireWorkflowRun(rt.store,run.id).status)||requireWorkflowRun(rt.store,run.id).status==='paused',60_000);
 const final=requireWorkflowRun(rt.store,run.id),step=getWorkflowStep(rt.store,run.id,'validate')!;
 const ops=rt.store.listToolOpsByTask(step.verification!.taskId);
 const evidence={status:final.status,reason:final.reason,verification:step.verification,tools:ops.map(o=>o.toolName),sourceContent:fs.readFileSync(path.join(t.work[0],'value.txt'),'utf8')};
 process.stdout.write(JSON.stringify(evidence,null,2)+'\n');
 assert.equal(ops.length,0);assert.equal(step.verification!.passed,false);assert.equal(final.status,'partial');assert.equal(getWorkflowStep(rt.store,run.id,'merge')!.status,'skipped');assert.equal(evidence.sourceContent,'base\n');
}finally{await t.shutdown();}
