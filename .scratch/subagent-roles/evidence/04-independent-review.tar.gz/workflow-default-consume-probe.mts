import assert from 'node:assert/strict';
import { listWorkflowExecutions,requireWorkflowRun } from '@ruukoto/core/workflow.ts';
import { startTestRuntime,waitFor } from './test/helpers/testkit.ts';
for(const damage of ['definition_missing','execution_missing']){
 const t=await startTestRuntime('default-consume-audit',()=>({kind:'text',text:'已读取'}),{workDirs:1});
 try{
  const rt=t.runtime,session=await rt.createSession({projectName:'consume',cwd:t.work[0]});
  const parent=rt.store.withTx(()=>{
   rt.store.setSessionQueueState(session.id,'paused','audit');
   const task=rt.store.insertQueuedTask({sessionId:session.id,requestId:'audit',input:'owner',modelSelection:rt.defaultSelection,submissionDigest:'audit',accessMode:'full_access'}).task;
   rt.store.transitionTask(task.id,['queued'],'running');return rt.store.getTask(task.id)!;
  });
  const run=rt.workflows!.start({sourceTaskId:parent.id,requestKey:'audit',input:null,script:'await agent("read",{request:"读取"});await ask("hold",{prompt:"继续？",dependsOn:["read"]});return 1;'});
  rt.store.withTx(()=>rt.store.endTask(parent.id,['running'],'completed'));
  await waitFor('audit ask',()=>requireWorkflowRun(rt.store,run.id).status==='waiting',20_000);
  const execution=listWorkflowExecutions(rt.store,run.id).find(e=>e.kind==='agent')!;
  const task=rt.store.getTask(execution.taskId)!;
  assert.equal(task.status,'completed');assert.ok(task.readScope?.execution);
  const calls=t.server.calls.length,attempts=requireWorkflowRun(rt.store,run.id).attempts;
  if(damage==='definition_missing')rt.store.db.prepare('UPDATE sub_agents SET definition = ? WHERE id = ?').run('null',task.subAgentId);
  else{const {execution,...scope}=task.readScope!;rt.store.db.prepare('UPDATE tasks SET read_scope = ? WHERE id = ?').run(JSON.stringify(scope),task.id);}
  const q=rt.getWorkflowQuestion(run.id,'hold');
  assert.throws(()=>rt.workflows!.answer(run.id,'hold',q.version,'继续',run.source,{requestKey:'answer',runVersion:q.runVersion}),{code:'stale_answer'});
  assert.equal(rt.getWorkflowQuestion(run.id,'hold').status,'pending');assert.equal(t.server.calls.length,calls);assert.equal(requireWorkflowRun(rt.store,run.id).attempts,attempts);
  process.stdout.write(JSON.stringify({damage,answer:'stale_answer',status:requireWorkflowRun(rt.store,run.id).status,calls,attempts})+'\n');
 }finally{await t.shutdown();}
}
