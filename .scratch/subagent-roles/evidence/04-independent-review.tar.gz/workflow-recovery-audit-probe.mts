import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { Runtime } from '@ruukoto/runtime/runtime.ts';
import { getWorkflowStep,listWorkflowExecutions,requireWorkflowRun,workflowTerminal } from '@ruukoto/core/workflow.ts';
import { initGitRepo } from './test/helpers/git-fixture.ts';
import { afterTool,lastUserText,realTools,startTestRuntime,waitFor } from './test/helpers/testkit.ts';
for(const phase of ['definition_missing','execution_missing','snapshot_missing']){
 const t=await startTestRuntime('recovery-audit',req=>{
  const verify=lastUserText(req).includes('"verify":"change"');
  if(afterTool(req))return {kind:'text',text:verify?'{"passed":true}':'修改完成'};
  return {kind:'tool_calls',calls:[{id:verify?'verify':'modify',name:verify?'read':'write',arguments:verify?{path:'value.txt'}:{path:'value.txt',content:'changed\n'}}]};
 },{config:realTools(),workDirs:1});
 let recovered:Runtime|undefined;
 try{
  fs.writeFileSync(path.join(t.work[0],'value.txt'),'base\n');initGitRepo(t.work[0]);
  const rt=t.runtime,session=await rt.createSession({projectName:'audit',cwd:t.work[0]});
  const parent=rt.store.withTx(()=>{
   rt.store.setSessionQueueState(session.id,'paused','test_source');
   const task=rt.store.insertQueuedTask({sessionId:session.id,requestId:'audit',input:'owner',modelSelection:rt.defaultSelection,submissionDigest:'audit',accessMode:'full_access'}).task;
   rt.store.transitionTask(task.id,['queued'],'running');return rt.store.getTask(task.id)!;
  });
  const run=rt.workflows!.start({sourceTaskId:parent.id,requestKey:'audit',input:null,script:'await agent("change",{request:"修改",target:"."});await agent("validate",{request:"验证",verify:"change",dependsOn:["change"]});await ask("hold",{prompt:"继续？"});return await integrate("merge",{steps:["validate"],dependsOn:["validate","hold"],check:"true"});'});
  rt.store.withTx(()=>rt.store.endTask(parent.id,['running'],'completed'));
  await waitFor('audit hold',()=>requireWorkflowRun(rt.store,run.id).status==='waiting',60_000);
  const verification=getWorkflowStep(rt.store,run.id,'validate')!.verification!;
  const task=rt.store.getTask(verification.taskId)!;
  assert.equal(verification.passed,true);
  if(phase==='definition_missing')rt.store.db.prepare('UPDATE sub_agents SET definition = ? WHERE id = ?').run('null',task.subAgentId);
  else if(phase==='execution_missing'){
   const {execution,...scope}=task.readScope!;
   rt.store.db.prepare('UPDATE tasks SET read_scope = ? WHERE id = ?').run(JSON.stringify(scope),task.id);
  }else{
   const work=rt.store.getWorkDelegation(getWorkflowStep(rt.store,run.id,'change')!.frozen!.workId)!;
   const target=work.writeTarget!;
   if(target.kind!=='worktree')throw new Error('expected copy');
   fs.rmSync(path.join(target.snapshot.repository.path,'ruukoto-baseline'));
  }
  await rt.stop('recovery_audit');
  recovered=await Runtime.start({...rt.config});
  const before=requireWorkflowRun(recovered.store,run.id);
  const calls=t.server.calls.length;
  const expected=phase==='definition_missing'?'definition_missing':phase==='execution_missing'?'execution_missing':'snapshot_corrupt';
  await assert.rejects(recovered.workflows!.control(run.id,'audit-resume',before.version,{action:'resume',stopsConfirmed:true,clockConfirmed:true}),{code:expected});
  assert.equal(before.reason,expected);
  assert.equal(fs.readFileSync(path.join(t.work[0],'value.txt'),'utf8'),'base\n');
  process.stdout.write(JSON.stringify({phase,status:before.status,reason:before.reason,callsDuringRecovery:t.server.calls.length-calls,sourceContent:'base\n'})+'\n');
  continue;
  await waitFor('audit hold resumed',()=>['waiting','paused'].includes(requireWorkflowRun(recovered!.store,run.id).status),60_000);
  const state=requireWorkflowRun(recovered.store,run.id);
  if(state.status==='waiting'){
   const q=recovered.getWorkflowQuestion(run.id,'hold');
   recovered.workflows!.answer(run.id,'hold',q.version,'继续',run.source,{requestKey:'audit-answer',runVersion:q.runVersion});
  }
  await waitFor('audit ended',()=>workflowTerminal(requireWorkflowRun(recovered!.store,run.id).status)||requireWorkflowRun(recovered!.store,run.id).status==='paused',60_000);
  const final=requireWorkflowRun(recovered.store,run.id);
  process.stdout.write(JSON.stringify({phase,status:final.status,reason:final.reason,sourceContent:fs.readFileSync(path.join(t.work[0],'value.txt'),'utf8'),callsDuringRecovery:t.server.calls.length-calls,agentExecutions:listWorkflowExecutions(recovered.store,run.id).filter(x=>x.kind==='agent').length})+'\n');
 }finally{await recovered?.stop('end');await t.shutdown();}
}
