# 14 单条先到夹具竞态证据

旧list_tasks门控场景中，即使新增一轮await app.loadHistory(replace)已返回，更早的list_tasks应答仍可在手工清空flow/tasks后注入合法拥有者输入“启动工作”。原users=[]断言失败，internalVisible=false；它证明候选drain不足，不证明内部输入曾泄露。原红日志为records/14-visibility-list-gated.log，完整诊断源码为versions/old-list-gated-with-new-load-history.ts。

隔离候选将“无任务元数据、单条先到、详情后到”的子场景放入fresh ViewState和未start的独立TuiApp，仍实际调用app.loadEntry并在之后安装真实任务详情。明确选中同一session，核load前后tasks.size=0、users=[]和当前eventFlowView.render无internal marker。它复用已认证connection进行读取，但不启动、不接后台回调、不取得连接生命周期、不quit共享连接。原again的实时、重连、分页、上下键、sticky与搜索断言保留，并追加实际owner historyEntry存在，防Task缓存假绿。

相同旧list_tasks门控下，最终增强候选1/1通过；去门控最终增强候选1/1通过。对应主要日志为records/14-visibility-isolated-gated-confirm.log与records/14-visibility-isolated-final-confirm.log。单文件ESLint与check:static均exit0。初次绿及后续增强的所有现存日志/差异一并保留，inputs逐文件列SHA。确定性门控只用于临时诊断，正式候选patch不含gate、sleep、新生产API或生产改动。

本归档制作时，原Linux full test14:252的精确失败栈尚未匹配，不能把本已证夹具竞态认定为该full失败原因。root将另补loadEntry后实际internal entryId/inputPurpose存在断言，防entry_not_found被吞造成空投影假绿；该最终输入和复验将在root给SHA后单列，未冒充本包候选已经包含。

包内不含原DB/WAL、实例配置、凭据、模型认证文件或业务数据。仅保存测试源码、差异、mock测试日志、哈希与状态。生产160文件保持冻结；本agent未跑Linux或真实模型。原模型验收报告与压缩包不改动。
