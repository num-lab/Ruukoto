from pathlib import Path
from datetime import datetime,timezone
from urllib.parse import urlsplit,unquote
import re,json,hashlib,shutil
base=Path('/Users/eitrous/orca/workspaces/ruukoto/subagent-roles')
files=['.scratch/subagent-roles/issues/05-acceptance.md','.scratch/subagent-roles/evidence/05-acceptance.md']
checks=[]
for rel in files:
 p=base/rel;data=p.read_bytes();text=data.decode();links=[];missing=[];anchors=[]
 for match in re.finditer(r'\[[^\]]*\]\(([^\n)]+)\)',text):
  raw=match.group(1).strip()
  if raw.startswith('<') and '>' in raw:raw=raw[1:raw.index('>')]
  else:raw=raw.split(' "',1)[0]
  url=urlsplit(raw)
  if url.scheme or url.netloc:continue
  target=p if not url.path else (p.parent/unquote(url.path)).resolve()
  line=text[:match.start()].count('\n')+1
  row={'line':line,'raw':raw,'target':str(target.relative_to(base)) if target.is_relative_to(base) else str(target),'exists':target.exists()}
  links.append(row)
  if not row['exists']:missing.append(row)
  if url.fragment:anchors.append({'line':line,'fragment':url.fragment,'target':row['target']})
 assert not missing
 if rel.endswith('/issues/05-acceptance.md'):
  assert re.search(r'^Status: ready-for-human$',text,re.M)
  assert '本次没有最终单次全量绿结论' in text and '真实 MCP/IM 保留待验' in text
  assert '工单不标 resolved' in text
 else:
  for needle in ['最终 v6 没有单次全量绿结论','真实外部 MCP/IM 与拥有者主观体验仍待验','工单不标 resolved','1644 通过、1 失败、13 跳过','TUI 14 整文件 35/35','30/30、24.307 秒','完整静态退出 0、133.177 秒','此后 v5 只有 runtime.ts 机械移动，另 159 项不变','共 137 次模型 POST','不是 60 个测试用例','旧档案的 MCP/QQ/Telegram 配置表均 0 行','状态 ready-for-human']:
   assert needle in text,needle
  assert not any(s in text for s in ['仍待结果','待回填','仍在收口'])
  for n in range(1,15):assert re.search(rf'^\| R{n} \|',text,re.M)
 snapshotName='05-final-reviewed-issue.md' if '/issues/' in rel else '05-final-reviewed-summary.md'
 Path('/tmp',snapshotName).write_bytes(data)
 checks.append({'file':rel,'snapshotFile':snapshotName,'snapshotSha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'localLinks':len(links),'missing':missing,'fragmentLinks':anchors,'links':links})
result={'auditedAt':datetime.now(timezone.utc).isoformat(),'reviewer':'/root/requirements_audit','conclusion':'当前两份正文的范围、版本、状态、实际结果和剩余验收均与已核原证据一致；ready-for-human准确，未把分组当全量通过、未代签外部或拥有者体验，未关闭workflow11。','reviewedSnapshots':checks,'followingChangesBoundary':'协调者后续只加终审链接和本次独有Linux根清理记录，属于追加导航/清理事实，不改源码；本快照不声称包含尚未写入的新增事实。'}
p=Path('/tmp/05-final-summary-audit.json');p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'audit':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'snapshots':[{k:r[k]for k in ['file','snapshotSha256','localLinks','missing','fragmentLinks']}for r in checks]},ensure_ascii=False))
