import http from 'node:http';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
const requests=[];
const server=http.createServer((req,res)=>{
  const info={method:req.method,url:req.url,headers:req.headers,localPort:req.socket.localPort,remotePort:req.socket.remotePort};
  requests.push(info);
  process.stderr.write(`[DEBUG-05-http-alone] ${JSON.stringify(info)}\n`);
  process.stderr.write(spawnSync('lsof',['-nP','-iTCP:'+req.socket.localPort,'-sTCP:ESTABLISHED'],{encoding:'utf8'}).stdout);
  res.writeHead(200,{'Content-Type':'text/plain'});res.end('isolated observer');
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
console.log(JSON.stringify({pid:process.pid,port:server.address().port}));
await new Promise(resolve=>setTimeout(resolve,20000));
server.closeAllConnections();await new Promise(resolve=>server.close(resolve));
assert.equal(requests.length,0,'No application issued requests, unexpected local requests observed');
