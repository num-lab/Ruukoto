import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { compileWorkflowOutput } from '/var/folders/y4/36h8kvvd4q52vjptp522rzfc0000gn/T/rk05-target-independent-sjdtgrlt/packages/agent/src/workflow-output.ts';
const db=new DatabaseSync('/tmp/m05-54al7qu2/ruukoto-workflow-model-x68SKW/data/ruukoto.db',{readOnly:true});
try {
const task=db.prepare('SELECT status,result_summary FROM tasks WHERE id=?').get('task_def57ce794f12f8f1741ac3f')!;
const actual=JSON.parse(String(task.result_summary));
const old={type:'object',properties:{passed:{type:'boolean'}},required:['passed'],additionalProperties:false};
const fixed={...old,properties:{...old.properties,reason:{type:'string'}}};
assert.equal(compileWorkflowOutput(old)(actual),false);
assert.equal(compileWorkflowOutput(fixed)(actual),true);
assert.equal(compileWorkflowOutput(fixed)({passed:true}),true);
assert.equal(compileWorkflowOutput(fixed)({passed:true,unknown:'reject'}),false);
assert.equal(compileWorkflowOutput(fixed)({passed:true,reason:42}),false);
assert.equal(compileWorkflowOutput(fixed)({reason:'missing passed'}),false);
console.log(JSON.stringify({taskStatus:task.status,actualFields:Object.keys(actual),actualPassed:actual.passed,actualReason:actual.reason,oldAccepted:false,fixedAccepted:true,passedRequired:true,unknownRejected:true,reasonTypeChecked:true},null,2));
}finally{db.close();}
