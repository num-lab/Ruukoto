# 05 独立要求与实现审查（进行中）

审查对象：主仓 HEAD `5f9da455072d68180ef19fc92ad02070cea583c1`。审查上下文 `/root/requirements_audit` 全程不写主工作区，探针与报告仅在 `/tmp`；实际读取规格 R1–R14、01–04 工单/独立报告、架构及相关角色、来源、快照与工作流接口笔记。旧作者总结仅用于导航。root 已逐项核实最终 04-production-inputs 40/40 与 04-implementation-inputs 77/77 匹配；仅在这两个最终清单覆盖范围沿用旧独立报告，01–03 已被后续替换的旧清单不视为对当前内容的独立证明。本报告不是工程或产品通过结论，修复后仍需非作者复验。

## 当前阻断

1. `packages/agent/src/subagent-tools.ts:281` 以 `target.trim()` 计算幂等摘要，`:292` 将原始字符串交给委派，`packages/runtime/src/work-copy.ts:182` 按原字符串解析合法路径。真实目录 `foo` 与 ` foo ` 是不同目录，却在同 key 下得到同摘要；第二次调用静默返回第一项工作，没有 `request_conflict`。反例使用真实工具、SubAgentManager、WorkCopyManager 与真实非 Git 目录，不依赖模型/worker。`05-target-digest-probe.log` 记录不同 target、相同摘要和仅一份原目标工作。该行当前 commit 为 5f9da45；`.scratch/subagent-roles/evidence/04-delegate.patch:79` 与 `04-implementation.patch:920` 均将它列为 04 普通接口迁移新增，不能把本次返工笼统归给 02 来源能力。最小修复是摘要保留原 target，增加空白路径回归；不改变实际路径语义。
2. `packages/runtime/src/runtime.ts:1177` 在本工作缺少执行快照且没有旧等待时，从当前 origin/config/grants 重造 WorkflowSource；`:1193` 的任务等待核实只检查资料/记忆/基线，不要求执行记录与角色定义。真实 Runtime/Driver 的普通子任务完成后，探针删除 `tasks.read_scope.execution`，随后普通父模型实际调用 `agent_wait`，仍返回 `reason:result`、原摘要、`stopVerified:true`、报告归属，父任务 completed，工具 isError=false。`05-wait-missing-execution-probe.log` 为原始证据。这违反 R14 与来源笔记缺失记录不补造的约定。修复应去掉 fallback，并按已冻结报告依赖或截止目标子任务的历史依赖逐条核实真实 Task/Session/Work、角色定义、完整执行快照及每条来源；不能遍历该子会话后来复用的新任务扩大旧报告依赖。同一真实反例补记父模型实际输入后，确认在调用 agent_wait 前，普通父请求已含 `[SubAgent 结果]` 及该子任务摘要，即使执行记录已缺失。证据 `05-wait-missing-execution-parent-input.log`；因此单修等待不足，普通自动注入及冷补记唤醒也必须在真正送达前核实相关历史记录。ParentDelivery.takeInjection:285 当前只经 workUnavailable 的物理基线核实。

## R1–R14 对照

| 要求 | 实际源码与调用方 | 本轮证据和边界 |
| --- | --- | --- |
| R1 | runtime.ts:895–930 普通/工作流共同 preflight；subagent-capabilities.ts:20 来源画像；driver.ts:528、537 共用实际装配 | 阅读双方装配；两产品默认真实 bash 与受保护 reviewer 的 native 组合由 root/Linux 角色执行，本上下文未并行抢 native。 |
| R2 | subagent-role-library.ts:16 加载、诊断、安全读取、同名覆盖；subagent-roles.ts:25 解析 | 本轮 role-library 4/4，包含坏覆盖不兜底、链接/编码/目录及读取竞态。 |
| R3 | subagent-roles.ts:80 内置 general/reviewer；subagents.ts:392 默认角色；driver.ts:537 默认工具预检 | 对照来源测试中两产品默认 request/key 的真实 bash 用例；未以工具清单替代 worker 实际结果。 |
| R4 | subagent-roles.ts:25 只认最小字段；subagents.ts:429 来源模型；driver.ts:598 系统 prompt 追加固定正文 | 解析/角色 Runtime/Driver 用例亲自通过；无模型覆盖/继承/模板新接口。 |
| R5 | subagent-capabilities.ts:10 模式收紧；subagents.ts:428 native 要求、:453 direct 保护冲突；tool-router.ts:167 来源保护根 | 权限策略全矩阵亲自通过；原生真实来源/index/file bind 拒写属于最终双平台实物证据，不由本轮非 native 用例替代。 |
| R6 | driver.ts:537–565 MCP 发现、显式工具逐项缺失、实际钉定工具 | 亲自通过缺工具、MCP 缺失/schema/停用、配置变化阻断等来源用例；真实 MCP 外部账号未验证。 |
| R7 | subagents.ts:392 固定身份；workflows.ts:138 roleCatalog；driver.ts:356 正文与执行绑定核实 | role-runtime/role-driver 及消息冷恢复亲自通过；缺记录等待旁路列为阻断，不能整体通过。 |
| R8 | runtime.ts:1129 旧任务来源/记忆复核；driver.ts 记录指令、技能、角色输入；source resolver 保留 grants | 亲自通过实际指令/技能/prompt 重建、资料撤销、memory_list/read 撤销、MCP 旧配置拒复用、通知 grant IDs。 |
| R9 | subagents.ts:424 独立目录、:437 仅显式 target 准备；subagent-tools.ts:253 参数独立 | 无 target 入口可使用来源工具；目标的原值幂等缺陷列为阻断。 |
| R10 | work-copy.ts:169 捕获目标、私有快照/物化；快照脚本与完整受影响文件汇入门 | 读取实际调用与机制笔记，沿最终清单匹配范围利用 03/04 独立实物证据；本上下文未重跑 native 脏字节/二进制组合。 |
| R11 | work-copy.ts:211 非 Git direct/gitOnly；taskWorkspaceFor/目录占用；agent_wait 让出/重取 | 非 Git 实际 worker 与父输入组合由 root/Linux 角色验证；本次补查 wait 缺执行记录反例，角色与接口单元不能覆盖此缺口。 |
| R12 | workflow-steps.ts:65 固定来源/verify策略；:275 非空真实工具账本；:285 汇入再核实 | 阅读 role/verify 与 passed/unknown 门；最终 native 冻结→独立验证→汇入证据仍由执行角色给出。 |
| R13 | subagent-tools.ts:239、subagents.ts:336、workflows.ts:402 拒旧 mode；workflow-library.ts:16 显式接口标记 | 真实 SDK 旧字段拒绝、旧定义/运行查询取消、旧协议拒绝亲自通过。 |
| R14 | core/subagent-execution.ts:44 摘要；runtime.ts:1129 逐次来源；workflow-steps.ts:111 消费核实；parent delivery/agent_wait | 快照损坏、消息与冷恢复拒绝亲自通过；等待缺快照仍补造来源为本轮新阻断，真实模型/外部平台/主观体验仍待验。 |

## GitHub 固定可信入口

`subagents.ts:314` 保留已完成 confirm GitHub 来源资格，`:393` 直接选 `HOST_REVIEW_DEFINITION`，`:1229` 拒绝普通复用；`subagent-roles.ts:85` 固定定义为 host_review。45 实际断言用户 general/reviewer 覆盖不进入评审提示、工具集合仅 read/read_artifact/只读 MCP，伪造 bash、下级委派、写/未知 MCP 未到远端；46 覆盖提交窗口、固定定义、冷恢复、不重跑与唯一归档/outbox。本轮两个文件与定义/侧栏等同批亲自通过，不新增 shell 或真实外发授权。

## 文档核对

`docs/usage.md:230–243` 明确实例 agents 目录、文件名/覆盖、新角色最小样例、可选 tools/permissions、full_access 与保护冲突、坏文件不兜底、主模型及 list_subagent_roles 诊断、修正仅作用新身份/运行、固定版本恢复、Git 不复制忽略依赖及在获准位置准备、非 Git 限制、旧接口升级。可用于本轮角色坏文件/缺依赖操作恢复；未发现内容与已审实现矛盾。target 摘要修复后应同步 runtime 模块的幂等说明，具体由 root 决定最小措辞。

## 亲自执行的检查

- `npx tsx --test test/subagent-role-library.test.ts test/subagent-definition-core.test.ts test/subagent-capabilities.test.ts test/45-github-events.test.ts test/46-github-recovery.test.ts test/126-workflow-sidebar.test.ts`：51/51，通过，原日志 `05-independent-contract-tests.log`。
- `npx tsx --test --test-name-pattern '普通来源项目指令|普通个人来源|显式角色缺工具|MCP 未装配|MCP 配置变化|普通个人通知|工作流显式|普通来源资料授权|普通执行快照|消息按保存|普通 memory_|普通 MCP 旧配置' test/subagent-source-capabilities.test.ts`：13/13，通过，原日志 `05-independent-source-tests.log`；全部为离线模型/本地 mock MCP 或本地业务账本，不记外部平台。
- `npx tsx --test test/subagent-role-runtime.test.ts test/subagent-role-driver.test.ts test/workflow-interface-version.test.ts`：13/13，通过，原日志 `05-independent-role-recovery-tests.log`。
- `npx tsx /tmp/05-target-digest-probe.mts`：确认真实两目录碰撞，退出 0 为“反例捕获成功”，不是实现通过。
- `npx tsx /tmp/05-wait-missing-execution-probe.mts`：确认缺执行记录仍被 agent_wait 作为 completed 结果汇报，退出 0 为“反例捕获成功”，不是实现通过。首次探针因夹具 setSessionQueueState 少传 null 参数退出 1，原失败保留 `05-wait-missing-execution-probe-fixture-error.log`，修正的仅是 /tmp 夹具。

## 08 HTTP 严格断言失败诊断

按 diagnosing-bugs 先保留严格原断言，再在 `/tmp/05-approval-audit/test/08-approvals.test.ts` 仅加带 `[DEBUG-05-approval-request]` 的请求边界日志（授权/cookie/token/key 头统一脱敏），不改主仓文件。第一轮 pattern `'单次 HTTP|拒绝审批|迟到批准'` 实际只选中两例，两例均红；拒绝用例之后按 `'拒绝只阻止'` 单独执行亦红。三项失败服务均收到无关 `GET /`，Accept 为 `text/html,*/*`；预定的 `/ok`、`/danger`、`/late` 请求没有在批准前被记录为执行。

最小无产品反例 `node /tmp/05-http-observer.mjs` 只创建 http.createServer 并 listen(0)，不加载 Ruukoto、模型或任何用例，20 秒内仍收到完全相同 `GET /`。回调同步 `lsof` 证明连接来自 PID 64334、COMMAND Mirasim；`ps` 定位 `/Applications/Mirasim.app/Contents/MacOS/Mirasim`。因此本次计数污染是宿主应用对监听端口的请求，不能称审批门提前执行，也不能再称原因未知。证据在 `05-http-observer.log`。

排除方案：127.0.0.2 在该 macOS 上 bind 实测 `EADDRNOTAVAIL`，没有添加网络别名；IPv6 ::1 的无产品 observer 同样被 Mirasim 请求，回调 lsof 再次确认，同 endpoint 的三例副本也均红，不能解决污染。没有改 DNS、TLS、工具实现或弱化 hits.size 零请求断言；不为规避探测顺带扩大 IPv6 产品支持。主完整 check 保留首次失败结果，Linux 保留严格原例独立结果；本轮 macOS 完整 check 不能以“环境问题”冒充通过。

## 未覆盖与下一步

真实模型、真实外部 MCP/IM、拥有者角色编辑/缺依赖/当前内容审查的主观产品体验未由本上下文执行；没有发消息、提交、推送、部署或改日常实例。macOS/Linux native、共享名额、真实非 Git 等待/侧栏组合与全量检查由 root 及其他独立角色执行并记录。本上下文等待 target 与等待来源缺记录修复后进行非作者最窄复验；当前两个阻断未关闭，不授予 05 通过结论。
