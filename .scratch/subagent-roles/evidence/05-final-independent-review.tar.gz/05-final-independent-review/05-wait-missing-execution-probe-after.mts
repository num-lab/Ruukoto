import assert from 'node:assert/strict';
import { startTestRuntime, afterTool, inputText, lastToolText, lastUserText, waitFor } from '/var/folders/y4/36h8kvvd4q52vjptp522rzfc0000gn/T/rk05-target-independent-sjdtgrlt/test/helpers/testkit.ts';
let childId='', parentInput='';
const kit=await startTestRuntime('wait-missing-execution',req=>{
  if(lastUserText(req)==='WAIT_MISSING_EXECUTION'){
    if(!afterTool(req)){parentInput=inputText(req);console.log(JSON.stringify({parentInputBeforeWait:parentInput}));}
    if(afterTool(req)){console.log(JSON.stringify({toolResult:lastToolText(req)}));return {kind:'text',text:'wait accepted'};}
    return {kind:'tool_calls',calls:[{id:'wait',name:'agent_wait',arguments:{targets:[{kind:'task',task_id:childId}]}}]};
  }
  return {kind:'text',text:'child result sentinel'};
});
try{
 const rt=kit.runtime,session=await rt.createSession({projectName:'probe',cwd:kit.work[0]});
 const source=rt.store.withTx(()=>{rt.store.setSessionQueueState(session.id,'paused','probe');const p=rt.store.insertQueuedTask({sessionId:session.id,requestId:'source',input:'source',accessMode:'full_access',modelSelection:rt.defaultSelection,submissionDigest:'source'}).task;rt.store.transitionTask(p.id,['queued'],'running');return rt.store.getTask(p.id)!;});
 const delegated=await rt.subagents!.delegate({parentTaskId:source.id,key:'child',request:'child',paramsDigest:'child'});childId=delegated.task.id;
 await waitFor('child complete',()=>rt.store.getTask(childId)?.status==='completed');
 const child=rt.store.getTask(childId)!;assert.ok(child.readScope?.execution);
 rt.store.db.prepare("UPDATE tasks SET read_scope=json_remove(read_scope,'$.execution') WHERE id=?").run(childId);
 rt.store.withTx(()=>{rt.store.endTask(source.id,['running'],'completed');rt.store.setSessionQueueState(session.id,'active',null);});
 const parent=await rt.submit({sessionId:session.id,requestId:'wait',input:'WAIT_MISSING_EXECUTION',accessMode:'full_access',modelSelection:rt.defaultSelection});
 await waitFor('wait task end',()=>['completed','failed','interrupted'].includes(rt.store.getTask(parent.id)!.status));
 const result=rt.store.getTask(parent.id)!;
 const waitOp=rt.store.listToolOpsByTask(parent.id).find(op=>op.toolName==='agent_wait')!;
 assert.equal(waitOp.isError,true);
 assert.ok(!parentInput.includes('child result sentinel'));
 assert.equal(rt.store.getTask(childId)!.resultSummary,child.resultSummary);
 console.log('fixed: missing execution refused, no parent injection, child result preserved');
 console.log(JSON.stringify({childExecution:rt.store.getTask(childId)!.readScope?.execution??null,parentStatus:result.status,error:result.errorMessage,waitOps:rt.store.listToolOpsByTask(parent.id).map(o=>({name:o.toolName,isError:o.isError,result:o.resultSummary}))},null,2));
}finally{await kit.shutdown();}
