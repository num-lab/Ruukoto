// packages/agent/src/tool-worker/worker.ts
import * as fs from "node:fs";
import * as path2 from "node:path";
import { spawn } from "node:child_process";

// packages/agent/src/managed-processes.ts
import * as childProcess from "node:child_process";
async function processGroupAlive(pgid, timeoutMs) {
  try {
    process.kill(-pgid, 0);
  } catch (error) {
    return error.code === "ESRCH" ? false : null;
  }
  return new Promise((resolve3) => {
    childProcess.execFile("ps", ["-eo", "pgid=,stat="], { encoding: "utf8", timeout: timeoutMs }, (error, stdout) => {
      if (error) {
        resolve3(null);
        return;
      }
      for (const line of stdout.trim().split("\n")) {
        const match = /^\s*(\d+)\s+(\S+)\s*$/.exec(line);
        if (!match) {
          resolve3(null);
          return;
        }
        if (Number(match[1]) === pgid && !match[2].startsWith("Z")) {
          resolve3(true);
          return;
        }
      }
      resolve3(false);
    });
  });
}
async function killProcessGroup(pgid, opts = {}) {
  if (!Number.isInteger(pgid) || pgid <= 0) return false;
  const signalGroup = (signal) => {
    try {
      process.kill(-pgid, signal);
      return true;
    } catch (error) {
      return error.code === "ESRCH";
    }
  };
  const waitForExit = async (graceMs) => {
    const deadline = Date.now() + graceMs;
    do {
      const alive = await processGroupAlive(pgid, Math.max(1, Math.min(2e3, deadline - Date.now())));
      if (alive === false) return true;
      const remaining = deadline - Date.now();
      if (remaining <= 0) return false;
      await new Promise((resolve3) => setTimeout(resolve3, Math.min(50, remaining)));
    } while (Date.now() < deadline);
    return false;
  };
  signalGroup("SIGTERM");
  if (await waitForExit(opts.termGraceMs ?? 3e3)) return true;
  signalGroup("SIGKILL");
  return await waitForExit(opts.killGraceMs ?? 3e3);
}

// packages/agent/src/tool-worker/worker.ts
import {
  createBashToolDefinition,
  createEditToolDefinition,
  createReadToolDefinition,
  createWriteToolDefinition,
  generateUnifiedPatch,
  getShellConfig
} from "@earendil-works/pi-coding-agent";

// packages/core/src/history.ts
function statsFromPatch(patch) {
  let added = 0;
  let removed = 0;
  let inHunk = false;
  for (const line of patch.split("\n")) {
    if (line.startsWith("@@ ")) inHunk = true;
    else if (line.startsWith("diff ") || line.startsWith("Index: ")) inHunk = false;
    else if (inHunk && line.startsWith("+")) added++;
    else if (inHunk && line.startsWith("-")) removed++;
  }
  return { added, removed };
}

// packages/core/src/worktree.ts
import * as path from "node:path";
function grantCoversPath(grantedReal, targetReal) {
  return targetReal === grantedReal || targetReal.startsWith(grantedReal + path.sep);
}

// packages/agent/src/artifacts.ts
function imageMime(bytes) {
  if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return "image/jpeg";
  if (bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return "image/png";
  if (bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP") return "image/webp";
  return null;
}

// packages/agent/src/tool-worker/protocol.ts
var MAX_FRAME_BYTES = 4 * 1024 * 1024;
var DATA_CHUNK_BYTES = 512 * 1024;
var WORKER_TOOL_NAMES = ["read", "edit", "write", "bash"];

// packages/agent/src/tool-worker/worker.ts
var stdoutDrained = Promise.resolve();
function sendMessage(msg) {
  const line = JSON.stringify(msg);
  if (Buffer.byteLength(line, "utf8") > MAX_FRAME_BYTES) {
    const opId = "opId" in msg ? msg.opId : void 0;
    fail(`\u5DE5\u4F5C\u8FDB\u7A0B\u6D88\u606F\u8D85\u9650\uFF1Aop=${opId ?? "?"}`, opId);
    return;
  }
  stdoutDrained = stdoutDrained.then(async () => {
    const ok = process.stdout.write(`${line}
`);
    if (!ok) await new Promise((resolve3) => process.stdout.once("drain", resolve3));
  });
}
function fail(message, opId) {
  if (opId) {
    sendMessage({ type: "result", opId, ok: false, content: [{ type: "text", text: `\u5DE5\u5177\u6267\u884C\u5931\u8D25\uFF1A${message}` }], isError: true, errorMessage: message });
  } else {
    sendMessage({ type: "fatal", message });
  }
}
function streamData(opId, stream, data) {
  for (let offset = 0; offset < data.length; offset += DATA_CHUNK_BYTES) {
    const chunk = data.subarray(offset, Math.min(offset + DATA_CHUNK_BYTES, data.length));
    sendMessage({ type: "data", opId, stream, chunk: chunk.toString("base64") });
  }
}
var trackedChildren = /* @__PURE__ */ new Map();
var childrenReaped = true;
async function killTrackedChild(pid) {
  const entry = trackedChildren.get(pid);
  if (!entry) return true;
  entry.stop ??= killProcessGroup(pid);
  const reaped = await entry.stop;
  if (reaped) trackedChildren.delete(pid);
  else childrenReaped = false;
  return reaped;
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
async function shutdown() {
  const results = await Promise.all(Array.from(trackedChildren.keys(), (pid) => killTrackedChild(pid)));
  sendMessage({ type: "stopped", reaped: childrenReaped && results.every(Boolean) });
  await stdoutDrained;
  process.exit(0);
}
var activeOpIds = /* @__PURE__ */ new Map();
function bashOperations() {
  return {
    exec: (command, cwd, options) => new Promise((resolve3) => {
      const shell = getShellConfig();
      const child = spawn(shell.shell, [...shell.args, command], {
        cwd,
        detached: true,
        // 独立进程组：中止/关停可整组回收
        env: options.env,
        stdio: ["ignore", "pipe", "pipe"]
      });
      const pid = child.pid;
      if (pid !== void 0) trackedChildren.set(pid, {});
      const opId = currentOpId("bash");
      child.stdout.on("data", (d) => {
        options.onData(d);
        if (opId) streamData(opId, "stdout", d);
      });
      child.stderr.on("data", (d) => {
        options.onData(d);
        if (opId) streamData(opId, "stderr", d);
      });
      const onAbort = () => {
        void killTrackedChild(pid);
      };
      options.signal?.addEventListener("abort", onAbort, { once: true });
      const finish = (exitCode) => {
        options.signal?.removeEventListener("abort", onAbort);
        void killTrackedChild(pid).then(() => resolve3({ exitCode }));
      };
      child.on("error", () => finish(127));
      child.on("close", (code) => finish(code));
    })
  };
}
function currentOpId(toolName) {
  return activeOpIds.get(toolName);
}
function readOperations() {
  return {
    readFile: async (absolutePath) => {
      const buf = await fs.promises.readFile(absolutePath);
      const opId = currentOpId("read");
      if (opId) streamData(opId, "file_read", buf);
      return buf;
    },
    // 路径解析已发生在工作进程内（执行边界内）；access 同样在此核对
    access: async (absolutePath) => {
      await fs.promises.access(absolutePath, fs.constants.R_OK);
    }
  };
}
var readScopeRoots = null;
function pinReadRoots(cwd, roots) {
  const pinned = [];
  for (const root of roots) {
    const real = fs.realpathSync(root.path);
    const st = fs.statSync(real);
    if (root.dev !== void 0 && root.ino !== void 0 && (st.dev !== root.dev || st.ino !== root.ino)) {
      throw new Error(`\u53EA\u8BFB\u6839\u5DF2\u53D8\u5316\uFF08\u5BBF\u4E3B\u9489\u5B9A\u4E0D\u7B26\uFF09\uFF1A${root.path}`);
    }
    pinned.push(real);
  }
  readScopeRoots = [fs.realpathSync(cwd), ...pinned];
}
function scopedResolveInReadScope(target) {
  const resolved = path2.resolve(target);
  const parts = resolved.split(path2.sep).filter((p) => p.length > 0);
  let current = "";
  for (let i = 0; i < parts.length; i++) {
    current = `${current}/${parts[i]}`;
    let st;
    try {
      st = fs.lstatSync(current);
    } catch {
      if (i === parts.length - 1) break;
      throw new Error(`\u8DEF\u5F84\u8D85\u51FA\u5BBF\u4E3B\u9489\u5B9A\u7684\u53EA\u8BFB\u8303\u56F4\uFF08\u4E2D\u95F4\u8DEF\u5F84\u6BB5\u4E0D\u53EF\u8FBE\uFF1A${current}\uFF09`);
    }
    if (st.isSymbolicLink()) {
      throw new Error(`\u8DEF\u5F84\u8D85\u51FA\u5BBF\u4E3B\u9489\u5B9A\u7684\u53EA\u8BFB\u8303\u56F4\uFF08\u7B26\u53F7\u94FE\u63A5\u7EC4\u4EF6\uFF1A${current}\uFF09`);
    }
  }
  let realTarget = resolved;
  try {
    realTarget = fs.realpathSync(resolved);
  } catch {
  }
  for (const root of readScopeRoots) {
    if (grantCoversPath(root, realTarget)) return resolved;
  }
  throw new Error("\u8DEF\u5F84\u8D85\u51FA\u5BBF\u4E3B\u9489\u5B9A\u7684\u53EA\u8BFB\u8303\u56F4");
}
function scopedReadOperations() {
  return {
    readFile: async (absolutePath) => {
      const resolved = scopedResolveInReadScope(absolutePath);
      const fd = fs.openSync(resolved, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
      try {
        if (fs.fstatSync(fd).isDirectory()) throw new Error("\u76EE\u6807\u662F\u76EE\u5F55\uFF0C\u65E0\u6B63\u6587\u53EF\u8BFB");
        const buf = fs.readFileSync(fd);
        const opId = currentOpId("read");
        if (opId) streamData(opId, "file_read", buf);
        return buf;
      } finally {
        fs.closeSync(fd);
      }
    },
    access: async (absolutePath) => {
      const resolved = scopedResolveInReadScope(absolutePath);
      await fs.promises.access(resolved, fs.constants.R_OK);
    }
  };
}
function createWorkerReadTool(cwd) {
  const operations = readScopeRoots ? scopedReadOperations() : readOperations();
  let bytes;
  return createReadToolDefinition(cwd, { operations: {
    ...operations,
    detectImageMimeType: async (absolutePath) => {
      bytes = await operations.readFile(absolutePath);
      return imageMime(bytes);
    },
    readFile: async (absolutePath) => bytes ?? operations.readFile(absolutePath)
  } });
}
function editOperations() {
  return {
    readFile: async (absolutePath) => fs.promises.readFile(absolutePath),
    writeFile: async (absolutePath, content) => {
      await fs.promises.writeFile(absolutePath, content, "utf8");
    },
    access: async (absolutePath) => {
      await fs.promises.access(absolutePath, fs.constants.W_OK | fs.constants.R_OK);
    }
  };
}
function writeOperations(onStats) {
  return {
    writeFile: async (absolutePath, content) => {
      let previous;
      try {
        previous = await fs.promises.readFile(absolutePath, "utf8");
      } catch (err) {
        if (err.code === "ENOENT") previous = "";
      }
      await fs.promises.writeFile(absolutePath, content, "utf8");
      if (previous !== void 0) {
        try {
          onStats(statsFromPatch(generateUnifiedPatch(absolutePath, previous, content)));
        } catch {
        }
      }
    },
    mkdir: async (dir) => {
      await fs.promises.mkdir(dir, { recursive: true });
    }
  };
}
function loadTools(cwd) {
  const tools = /* @__PURE__ */ new Map([
    ["edit", createEditToolDefinition(cwd, { operations: editOperations() })],
    ["bash", createBashToolDefinition(cwd, { operations: bashOperations(), exposeSessionEnvironment: false })]
  ]);
  return { cwd, tools };
}
var inFlight = /* @__PURE__ */ new Map();
var loaded = null;
var initPromise = null;
async function handleToolCall(req) {
  if (!initPromise) {
    fail("\u5DE5\u4F5C\u8FDB\u7A0B\u5C1A\u672A\u521D\u59CB\u5316", req.opId);
    return;
  }
  try {
    await initPromise;
  } catch (err) {
    fail(`\u5DE5\u4F5C\u8FDB\u7A0B\u521D\u59CB\u5316\u5931\u8D25\uFF1A${err.message}`, req.opId);
    return;
  }
  if (!loaded) {
    fail("\u5DE5\u4F5C\u8FDB\u7A0B\u5C1A\u672A\u521D\u59CB\u5316", req.opId);
    return;
  }
  if (!WORKER_TOOL_NAMES.includes(req.name)) {
    fail(`\u672A\u77E5\u5DE5\u5177\uFF1A${req.name}`, req.opId);
    return;
  }
  let writeStats;
  const def = req.name === "read" ? createWorkerReadTool(loaded.cwd) : req.name === "write" ? createWriteToolDefinition(loaded.cwd, { operations: writeOperations((stats) => {
    writeStats = stats;
  }) }) : loaded.tools.get(req.name);
  const controller = new AbortController();
  const timer = req.timeoutMs ? setTimeout(() => controller.abort(new Error("timeout")), req.timeoutMs) : void 0;
  inFlight.set(req.opId, { controller, timer });
  if (!activeOpIds.has(req.name)) activeOpIds.set(req.name, req.opId);
  try {
    const result = await def.execute(req.opId, req.params, controller.signal, void 0, {
      cwd: loaded.cwd
    });
    sendMessage({
      type: "result",
      opId: req.opId,
      ok: true,
      content: result.content,
      details: req.name === "write" ? writeStats ? { editStats: writeStats } : void 0 : result.details,
      isError: Boolean(result.isError)
    });
  } catch (err) {
    const aborted = controller.signal.aborted;
    sendMessage({
      type: "result",
      opId: req.opId,
      ok: false,
      content: [{ type: "text", text: aborted ? "\u64CD\u4F5C\u5DF2\u4E2D\u6B62" : `\u5DE5\u5177\u6267\u884C\u5931\u8D25\uFF1A${err.message}` }],
      isError: true,
      errorMessage: err.message
    });
  } finally {
    if (timer) clearTimeout(timer);
    inFlight.delete(req.opId);
    if (activeOpIds.get(req.name) === req.opId) activeOpIds.delete(req.name);
  }
}
async function handleMessage(raw) {
  let req;
  try {
    req = JSON.parse(raw);
  } catch {
    fail("\u65E0\u6CD5\u89E3\u6790\u7684\u8BF7\u6C42\u5E27");
    return;
  }
  switch (req.type) {
    case "init": {
      const cwd = path2.resolve(req.cwd);
      if (req.readRoots !== void 0) {
        try {
          pinReadRoots(cwd, req.readRoots);
        } catch (err) {
          fail(`\u5BBF\u4E3B\u9489\u5B9A\u7684\u53EA\u8BFB\u8303\u56F4\u590D\u6838\u5931\u8D25\uFF1A${err.message}`);
          await Promise.race([stdoutDrained, sleep(500)]);
          process.exit(1);
        }
      }
      if (req.workspace !== void 0) {
        try {
          const st = fs.statSync(fs.realpathSync(cwd));
          if (st.dev !== req.workspace.dev || st.ino !== req.workspace.ino) {
            fail(`\u5BBF\u4E3B\u9489\u5B9A\u7684\u5DE5\u4F5C\u533A\u8EAB\u4EFD\u590D\u6838\u5931\u8D25\uFF1A${cwd}\uFF08${st.dev}:${st.ino} \u2260 ${req.workspace.dev}:${req.workspace.ino}\uFF09`);
            await Promise.race([stdoutDrained, sleep(500)]);
            process.exit(1);
          }
        } catch (err) {
          fail(`\u5BBF\u4E3B\u9489\u5B9A\u7684\u5DE5\u4F5C\u533A\u8EAB\u4EFD\u590D\u6838\u5931\u8D25\uFF1A${cwd}\uFF08${err.message}\uFF09`);
          await Promise.race([stdoutDrained, sleep(500)]);
          process.exit(1);
        }
      }
      initPromise = (async () => {
        await fs.promises.mkdir(cwd, { recursive: true }).catch(() => {
        });
        loaded = loadTools(cwd);
      })();
      await initPromise;
      break;
    }
    case "tool_call":
      await handleToolCall(req);
      break;
    case "abort": {
      const call = inFlight.get(req.opId);
      call?.controller.abort(new Error("aborted by host"));
      break;
    }
    case "shutdown":
      await shutdown();
      break;
    default:
      break;
  }
}
process.on("uncaughtException", (err) => {
  fail(`\u5DE5\u4F5C\u8FDB\u7A0B\u5185\u90E8\u9519\u8BEF\uFF1A${err.message}`);
});
process.on("unhandledRejection", (err) => {
  fail(`\u5DE5\u4F5C\u8FDB\u7A0B\u672A\u5904\u7406\u7684\u5F02\u6B65\u9519\u8BEF\uFF1A${err.message}`);
});
process.on("SIGTERM", () => {
  void shutdown();
});
sendMessage({ type: "ready", pid: process.pid });
var buffer = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  buffer += chunk;
  for (; ; ) {
    const idx = buffer.indexOf("\n");
    if (idx === -1) break;
    const line = buffer.slice(0, idx);
    buffer = buffer.slice(idx + 1);
    if (line.length === 0) continue;
    if (Buffer.byteLength(line, "utf8") > MAX_FRAME_BYTES) {
      fail("\u8BF7\u6C42\u5E27\u8D85\u9650");
      process.exit(1);
    }
    void handleMessage(line);
  }
});
process.stdin.on("end", () => {
  void shutdown();
});
process.stdin.on("error", () => {
});
