import datetime,hashlib,json,pathlib,re,shutil,subprocess,sys
b=pathlib.Path('/dev/shm/rk05-linux.ZHrgZC');repo=b/'repo';logs=b/'logs'
record=logs/'native-suite.command.json'
if not record.exists():
 print('native-suite still running');sys.exit(3)
command=json.loads(record.read_text())
assert command['exit_code']==0,command
rows=[]
for line in (b/'validation-files.sha256').read_text().splitlines():
 expected,name=line.split('  ',1)
 actual=hashlib.sha256((repo/name).read_bytes()).hexdigest()
 assert actual==expected,name
 rows.append({'file':name,'sha256':actual})
(logs/'source-after-baseline.json').write_text(json.dumps({'commit':'5f9da455072d68180ef19fc92ad02070cea583c1','regular_files_verified':len(rows),'all_match':True,'files':rows},indent=2)+'\n')
with (logs/'source-after-baseline.log').open('w') as out:subprocess.run(['sha256sum','-c',str(b/'validation-files.sha256')],cwd=repo,stdout=out,check=True)
artifacts=[]
(logs/'compiled-baseline').mkdir(exist_ok=True)
for name in ['worker/worker.mjs','worker/workflow-script.mjs','worker/workflow-script.wasm']:
 p=repo/name;artifacts.append({'file':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size});shutil.copy2(p,logs/'compiled-baseline'/p.name)
(logs/'build-artifacts-baseline.json').write_text(json.dumps(artifacts,indent=2)+'\n')
checks=[]
for c in [['git','status','--short','--untracked-files=all'],['git','rev-parse','HEAD'],['systemctl','--user','list-units','--type=scope','--no-legend'],['df','-h','/','/dev/shm'],['free','-m']]:
 r=subprocess.run(c,cwd=repo,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);checks.append({'command':c,'exit_code':r.returncode,'output':r.stdout})
(logs/'environment-after-baseline.json').write_text(json.dumps(checks,indent=2)+'\n')
summaries={}
for name in ['native-suite','approvals']:
 s=(logs/(name+'.log')).read_text();counts={}
 for key in ['tests','pass','fail','cancelled','skipped','todo']:
  match=re.search(r'^ℹ '+key+r' (\d+)$',s,re.M);assert match,(name,key);counts[key]=int(match[1])
 summaries[name]=counts
summary={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':'5f9da455072d68180ef19fc92ad02070cea583c1','validation_archive_sha256':hashlib.sha256((b/'source-validation.tar.gz').read_bytes()).hexdigest(),'source_regular_files_unchanged':len(rows),'tests':summaries,'scope_probes':json.loads((logs/'scope-proof/native-linux-scope-report.json').read_text()),'build_artifacts':artifacts,'real_models':False,'real_IM':False,'production_instances_modified':False}
(logs/'baseline-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['scope_probes','build_artifacts']}))
