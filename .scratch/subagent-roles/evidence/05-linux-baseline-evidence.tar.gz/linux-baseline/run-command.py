import datetime,json,os,pathlib,subprocess,sys,time
base=pathlib.Path('/dev/shm/rk05-linux.ZHrgZC')
label=sys.argv[1]
command=sys.argv[2:]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
env=os.environ.copy()
env.update({'RUN_MODEL_CHECK':'0','npm_config_cache':str(base/'npm-cache'),'TMPDIR':str(base/'tmp')})
begin=time.monotonic()
with (base/'logs'/f'{label}.log').open('wb') as out:
    result=subprocess.run(command,cwd=base/'repo',env=env,stdout=out,stderr=subprocess.STDOUT)
record={'label':label,'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(base/'repo'),'command':command,'environment_overrides':{k:env[k] for k in ['RUN_MODEL_CHECK','npm_config_cache','TMPDIR']},'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-begin,'log':f'{label}.log'}
(base/'logs'/f'{label}.command.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
sys.exit(result.returncode)
