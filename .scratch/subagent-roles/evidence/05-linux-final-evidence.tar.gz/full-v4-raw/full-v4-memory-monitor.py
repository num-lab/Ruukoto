import datetime,json,os,pathlib,time
b=pathlib.Path('/dev/shm/rk05-linux.ZHrgZC')
(b/'full-v4-memory-monitor.pid').write_text(str(os.getpid())+'\n')
with (b/'logs/full-v4-resource-samples.jsonl').open('a',buffering=1) as out:
 for _ in range(720):
  values={line.split(':',1)[0]:int(line.split()[1]) for line in pathlib.Path('/proc/meminfo').read_text().splitlines()}
  assert all(k in values for k in ['MemAvailable','SwapFree','MemFree'])
  disk=os.statvfs(b)
  out.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mem_available_kib':values['MemAvailable'],'swap_free_kib':values['SwapFree'],'mem_free_kib':values['MemFree'],'tmpfs_available_bytes':disk.f_bavail*disk.f_frsize})+'\n')
  if (b/'logs/full-final-check-v4.command.json').exists():break
  time.sleep(10)
