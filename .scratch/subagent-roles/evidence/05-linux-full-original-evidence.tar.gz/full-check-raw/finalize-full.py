import pathlib,json,hashlib,os,subprocess,datetime
b=pathlib.Path("/dev/shm/rk05-linux.ZHrgZC")
r=b/"repo"
command=b/"logs/full-final-check.command.json"
if not command.exists(): raise SystemExit("original full runner is not complete")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify(entries):
 out=[]
 for row in entries:
  name=row.get("path",row.get("file"))
  p=r/name
  kind=row.get("kind",row.get("type"))
  if kind=="symlink":
   actual=os.readlink(p) if p.is_symlink() else None
   ok=actual==row["target"]
   out.append({"path":name,"kind":kind,"target":actual,"match":ok})
  else:
   actual=sha(p) if p.is_file() and not p.is_symlink() else None
   ok=actual==row["sha256"]
   out.append({"path":name,"kind":"file","sha256":actual,"match":ok})
 return out
manifest=json.loads((b/"full-check-inputs.json").read_text())
rows=verify(manifest["files"])
main=json.loads((b/"main-final-source-inputs.json").read_text())
mainrows=verify(main["entries"])
artifacts=[]
for name in ["worker/worker.mjs","worker/workflow-script.mjs","worker/workflow-script.wasm"]:
 p=r/name
 artifacts.append({"path":name,"bytes":p.stat().st_size,"sha256":sha(p)})
log=(b/"logs/full-final-check.log").read_text(errors="replace")
lines=log.splitlines()
samples=[json.loads(x) for x in (b/"logs/full-resource-samples.jsonl").read_text().splitlines()]
report={"captured_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"command":json.loads(command.read_text()),"main_manifest_sha256":sha(b/"main-final-source-inputs.json"),"selected_entries":len(rows),"all_selected_match":all(x["match"] for x in rows),"frozen_entries":len(mainrows),"all_frozen_match":all(x["match"] for x in mainrows),"git_head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=r,text=True).strip(),"git_status":subprocess.check_output(["git","status","--short"],cwd=r,text=True),"artifacts":artifacts,"log_bytes":(b/"logs/full-final-check.log").stat().st_size,"log_sha256":sha(b/"logs/full-final-check.log"),"summary_lines":[x for x in lines if x.startswith("ℹ")],"failure_lines":[x for x in lines if x.startswith("✖")],"resource_samples":len(samples),"resource_minimums":{k:min(x[k] for x in samples) for k in ["mem_available_kib","swap_free_kib","tmpfs_available_bytes"]},"selected_checks":rows,"frozen_checks":mainrows}
(b/"full-check-source-after.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({k:v for k,v in report.items() if k not in ["selected_checks","frozen_checks"]},ensure_ascii=False,indent=2))
if not report["all_selected_match"] or not report["all_frozen_match"]: raise SystemExit(1)
