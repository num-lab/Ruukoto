import fs from 'node:fs';
import { assertGrantNotProtected } from './repo/packages/agent/src/execution/approved-ops.ts';
const source='/var/lib/ruukoto';
const stat=fs.statSync(source);
const facts: Record<string,unknown>={path:source,uid:stat.uid,gid:stat.gid,mode:(stat.mode&0o777).toString(8),directory:stat.isDirectory()};
let blocked=false;
try { fs.accessSync(source,fs.constants.R_OK|fs.constants.X_OK); facts.access='readable'; }
catch(error) { blocked=true; facts.access=(error as NodeJS.ErrnoException).code; }
if(blocked){
  try { assertGrantNotProtected('/',[source]);facts.rootGrant='unexpectedly accepted'; }
  catch(error){ const e=error as NodeJS.ErrnoException; facts.observed={name:e.name,code:e.code,message:e.message,stack:e.stack}; }
}
process.stdout.write(JSON.stringify(facts,null,2)+'\n');
