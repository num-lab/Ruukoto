import fs from 'node:fs';
import path from 'node:path';
import { collectMarkdown, parseMarkdown, visitMarkdown } from '/Users/eitrous/orca/workspaces/ruukoto/subagent-roles/scripts/markdown-scan.ts';
const root = process.cwd();
const patterns = ['README.md','AGENTS.md','CONTEXT.md','docs/**/*.md','.agents/notes/**/*.md','.agents/skills/**/*.md','deploy/**/*.md','verification/**/README.md'];
const records = new Map<string, { file: string; size: number; referencedBy: string[] }>();
for (const file of collectMarkdown(root, patterns, rel => rel.startsWith('.agents/notes/archived/') || rel.includes('node_modules/'))) {
  visitMarkdown(parseMarkdown(fs.readFileSync(file.abs,'utf8')), node => {
    if (!['link','image','definition'].includes(node.type) || !('url' in node) || typeof node.url !== 'string') return;
    const url = node.url;
    if (url.startsWith('/') || /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(url) || /[<>…]/.test(url)) return;
    const target = path.resolve(path.dirname(file.abs),decodeURIComponent(url.replace(/[#?].*$/,'')));
    const rel = path.relative(root,target);
    if (!rel.startsWith('.scratch/') || !fs.existsSync(target) || !fs.statSync(target).isFile()) return;
    const row = records.get(rel) ?? { file: rel, size: fs.statSync(target).size, referencedBy: [] };
    row.referencedBy.push(file.rel); records.set(rel,row);
  });
}
process.stdout.write(JSON.stringify([...records.values()].sort((a,b) => a.file.localeCompare(b.file)),null,2)+'\n');
