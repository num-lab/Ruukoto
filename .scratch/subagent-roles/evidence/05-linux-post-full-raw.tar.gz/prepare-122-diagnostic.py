from pathlib import Path
import hashlib,json,difflib,datetime
b=Path("/dev/shm/rk05-linux.ZHrgZC");r=b/"repo";source=r/"test/122-workflow-code-acceptance.test.ts"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source)=="c63bb044653707976184b582aa3612bbecdee0398a1e2b1cf708f91becab16aa"
original=source.read_text()
oldwait='    try { await waitFor("六输入整项回报", () => requireWorkflowRun(rt.store, started.run.id).delivery?.status === "reported", 90_000); }'
newwait='    const diagnosticReportWaitStarted = performance.now();\n'+oldwait.replace("90_000", "180_000")
oldtail='      throw error;\n    }\n    const final = requireWorkflowRun(rt.store, started.run.id);'
newtail='      throw error;\n    } finally { process.stderr.write(`[ruukoto:acceptance-diagnostic] ${JSON.stringify({ reportWaitMs: performance.now() - diagnosticReportWaitStarted, reported: requireWorkflowRun(rt.store, started.run.id).delivery?.status === "reported", limitMs: 180000, formalLimitMs: 90000 })}\\n`); }\n    const final = requireWorkflowRun(rt.store, started.run.id);'
assert original.count(oldwait)==1
assert original.count(oldtail)==1
modified=original.replace(oldwait,newwait).replace(oldtail,newtail)
target=r/"test/122-workflow-code-acceptance.180-diagnostic.ts"
assert not target.exists()
target.write_text(modified)
assert sha(source)=="c63bb044653707976184b582aa3612bbecdee0398a1e2b1cf708f91becab16aa"
(b/"122-report-wait-180-diagnostic.ts").write_text(modified)
(b/"122-report-wait-formal-before.ts").write_text(original)
patch="".join(difflib.unified_diff(original.splitlines(keepends=True),modified.splitlines(keepends=True),fromfile="formal/test/122-workflow-code-acceptance.test.ts",tofile="diagnostic/test/122-workflow-code-acceptance.180-diagnostic.ts"))
(b/"122-report-wait-180-diagnostic.patch").write_text(patch)
proof={"captured_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"formal_path":str(source),"formal_sha256":sha(source),"diagnostic_path":str(target),"diagnostic_sha256":sha(target),"diagnostic_archive_sha256":sha(b/"122-report-wait-180-diagnostic.ts"),"transform_sha256":sha(b/"122-report-wait-180-diagnostic.patch"),"formal_limit_ms":90000,"diagnostic_limit_ms":180000,"other_changes":"只追加该wait的monotonic起止记录；其余行为与最终断言原样保留","automatic_test_glob_matches_diagnostic":False}
(b/"122-diagnostic-inputs.json").write_text(json.dumps(proof,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(proof,ensure_ascii=False,indent=2))
