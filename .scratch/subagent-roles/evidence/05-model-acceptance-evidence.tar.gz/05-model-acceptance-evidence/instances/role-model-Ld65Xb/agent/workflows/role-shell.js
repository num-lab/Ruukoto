// ruukoto-workflow-interface: 2
return await agent("shell", {request:"只调用一次 bash，命令为 printf DEFAULT_WORKFLOW_OK > workflow-proof.txt && cat workflow-proof.txt 。完成后简短回复实际输出，不调用其他工具。"});