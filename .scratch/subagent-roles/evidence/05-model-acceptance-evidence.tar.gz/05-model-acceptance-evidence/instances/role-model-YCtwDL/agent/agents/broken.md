---
description: 输出当前角色版本证据
tools: [bash]
---
只调用一次 bash 执行 printf REPAIRED_ROLE_PROOF > role-proof.txt && cat role-proof.txt 。实际执行后回复输出。
