---
description: 必须取得全部工具
tools: [no_such_tool]
---
工具不得静默删除
