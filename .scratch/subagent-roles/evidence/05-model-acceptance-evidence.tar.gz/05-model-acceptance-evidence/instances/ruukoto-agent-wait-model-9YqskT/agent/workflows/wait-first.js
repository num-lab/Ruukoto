// ruukoto-workflow-interface: 2
return await agent("result",{request:"只回复 WAIT_RESULT_FIRST，不调用工具。",tools:[]});