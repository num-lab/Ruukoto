// ruukoto-workflow-interface: 2
await ask("hold",{prompt:"继续第二项真实等待验收？",options:["yes"]}); return await agent("result",{request:"只回复 WAIT_CHILD_SECOND，不调用工具。",tools:[]});