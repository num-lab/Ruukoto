import fs from "node:fs";
const cfg=JSON.parse(fs.readFileSync(process.env.RUN_WORKFLOW_MODELS_FILE,"utf8"));
const origins=new Set(Object.values(cfg.providers).map(p=>new URL(p.baseUrl).origin));
const rawFetch=globalThis.fetch;
let sequence=0;
globalThis.fetch=async function(input,options){
 const url=new URL(typeof input==="string"?input:input instanceof URL?input:input.url);
 if(!origins.has(url.origin))return rawFetch(input,options);
 const id=process.pid+":"+(++sequence), append=value=>fs.appendFileSync(process.env.MODEL_FETCH_LOG,JSON.stringify(value)+"\n");
 const method=options?.method??input?.method??"GET";
 append({id,phase:"request",at:new Date().toISOString(),method,path:url.pathname});
 try{const response=await rawFetch(input,options);append({id,phase:"response",at:new Date().toISOString(),status:response.status});return response;}
 catch(error){append({id,phase:"error",at:new Date().toISOString(),name:error instanceof Error?error.name:"NonError"});throw error;}
};
