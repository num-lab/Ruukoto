import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import { createHash } from "node:crypto";
import { Runtime } from "@ruukoto/runtime/runtime.ts";
import { requireSubAgentExecution } from "@ruukoto/core/subagent-execution.ts";
import { listWorkflowExecutions, listWorkflowRuns, requireWorkflowRun } from "@ruukoto/core/workflow.ts";
import { product as personalProduct } from "../apps/ruukoto/src/product.ts";
import { product as codingProduct } from "../apps/ruukoto-code/src/product.ts";
import { initGitRepo, runGitStep } from "./helpers/git-fixture.ts";
import { waitFor } from "./helpers/testkit.ts";

assert.equal(process.env.RUN_MODEL_CHECK, "1");
const models = process.env.RUN_WORKFLOW_MODELS_FILE!;
const evidenceRoot = process.env.MODEL_EVIDENCE_ROOT!;
const config = JSON.parse(fs.readFileSync(models, "utf8"));
const cases: unknown[] = [];
const digest = (value: Buffer | string) => createHash("sha256").update(value).digest("hex");
for (const product of [personalProduct.runtime, codingProduct.runtime]) {
  const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "role-model-")));
  const agentDir = path.join(root, "agent"), workspace = path.join(root, "work");
  fs.mkdirSync(agentDir); fs.mkdirSync(workspace);
  fs.writeFileSync(path.join(agentDir, "models.json"), JSON.stringify(config), { mode: 0o600 });
  fs.writeFileSync(path.join(workspace, "value.txt"), "BASE\n");
  fs.writeFileSync(path.join(workspace, "staged.bin"), Buffer.from([0,1,2,3,255]));
  initGitRepo(workspace);
  fs.writeFileSync(path.join(workspace, "stage.txt"), "CURRENT_STAGED\n");
  fs.writeFileSync(path.join(workspace, "staged.bin"), Buffer.from([0,9,8,7,255]));
  runGitStep(workspace, "git add stage.txt staged.bin");
  fs.writeFileSync(path.join(workspace, "value.txt"), "CURRENT_UNSTAGED\n");
  fs.writeFileSync(path.join(workspace, "new.bin"), Buffer.from([0,6,5,4,254]));
  const expectedFiles = Object.fromEntries(["value.txt","stage.txt","staged.bin","new.bin"].map(name => [name,digest(fs.readFileSync(path.join(workspace,name)))]));
  const indexBefore = digest(fs.readFileSync(path.join(workspace,".git/index")));
  let rt: Runtime | null = null;
  const evidence: any = { product: product.type, root, model: "deepseek/deepseek-flash", sourceFiles: expectedFiles, checks: [] };
  try {
    rt = await Runtime.start({ product, agentDir, dataDir: path.join(root,"data"), socketPath: path.join(root,"c.sock"), modelProvider:"deepseek", modelId:"deepseek-flash", thinkingLevel:"off", qqDisabled:true });
    const runtime = rt;
    const session = product.type === "ruukoto-code" ? await rt.createSession({ projectName:"role-model",cwd:workspace }) : rt.store.getSession(rt.store.getAgentRole("main")!.sessionId)!;
    await rt.setSessionDefaultMode({ sessionId:session.id, expectedVersion:session.defaultAccessModeVersion, mode:"full_access" });
    async function taskDone(id: string) {
      await waitFor("真实模型任务终态",()=>["completed","failed","canceled","interrupted"].includes(runtime.store.getTask(id)!.status),180_000);
      const task=runtime.store.getTask(id)!;
      assert.equal(task.status,"completed",JSON.stringify({taskId:id,status:task.status,error:task.errorMessage}));
      return task;
    }
    async function parent(key: string,input: string) {
      const task=await runtime.submit({sessionId:session.id,requestId:key,modelSelection:runtime.defaultSelection,input});
      await taskDone(task.id);return task;
    }
    async function delegate(key: string,request: string,extra: Record<string, unknown>={}) {
      const args={request,key,...extra};
      const source=await parent("parent-"+key,"这是隔离验收。请只调用一次 subagent_delegate，参数逐字为 "+JSON.stringify(args)+"。不要补充 role、target、资料或其他字段，不轮询，不等待结果，不调用其他工具；工具返回后简短回复已登记即可。");
      const op=runtime.store.listToolOpsByTask(source.id).find(op=>op.toolName==="subagent_delegate")!;
      assert.ok(op);assert.equal(op.isError,false,op.resultSummary!);
      assert.deepEqual(op.params,args,"真实父模型不得悄悄添加旧资料 guard 或 target");
      const work=runtime.store.listWorkDelegationsBySession(session.id).find(work=>extra.work_id ? work.id===extra.work_id : work.requestKey===key)!;
      assert.ok(work,op.resultSummary!);
      const task=runtime.store.listTasksByWork(work.id).at(-1)!;await taskDone(task.id);
      const current=runtime.store.getTask(task.id)!;
      return {work,task:current,execution:requireSubAgentExecution(current.readScope?.execution),ops:runtime.store.listToolOpsByTask(current.id),reply:runtime.readTaskReply(current.id)!.text};
    }
    const ordinary=await delegate("ordinary","只调用一次 bash，命令为 printf DEFAULT_ORDINARY_OK > proof.txt && cat proof.txt 。完成后简短回复实际输出，不调用其他工具。");
    assert.equal(runtime.store.getSubAgent(ordinary.task.subAgentId!)!.definition!.name,"general");
    assert.ok(ordinary.ops.some(op=>op.toolName==="bash"&&op.isError===false&&op.resultSummary?.includes("DEFAULT_ORDINARY_OK")));
    const ordinaryCwd=runtime.store.getSession(ordinary.task.sessionId)!.cwdReal;
    assert.equal(fs.readFileSync(path.join(ordinaryCwd,"proof.txt"),"utf8"),"DEFAULT_ORDINARY_OK");
    assert.ok(!fs.existsSync(path.join(session.cwdReal,"proof.txt")));
    evidence.checks.push({case:"ordinary-default-bash-request-key-only",taskId:ordinary.task.id,execution:ordinary.execution,ops:ordinary.ops,reply:ordinary.reply,bytes:"DEFAULT_ORDINARY_OK"});
    const request="只调用一次 bash，命令为 printf DEFAULT_WORKFLOW_OK > workflow-proof.txt && cat workflow-proof.txt 。完成后简短回复实际输出，不调用其他工具。";
    await runtime.saveWorkflowDefinition({name:"role-shell",script:'return await agent("shell", {request:'+JSON.stringify(request)+'});',expectedDigest:null,requestKey:"save-shell"});
    await parent("workflow-shell",'先调用 workflow_instructions，再调用 workflow_start，参数 name="role-shell",input=null,key="role-shell"。返回后立即回复已启动，不轮询，不执行其他工具。');
    await waitFor("真实默认工作流完成",()=>listWorkflowRuns(runtime.store).some(run=>run.definitionId&&["succeeded","failed","partial","paused"].includes(requireWorkflowRun(runtime.store,run.id).status)),180_000);
    const run=listWorkflowRuns(runtime.store)[0], final=requireWorkflowRun(runtime.store,run.id);
    assert.equal(final.status,"succeeded",JSON.stringify(final));
    const execution=listWorkflowExecutions(runtime.store,run.id).find(item=>item.kind==="agent")!;
    const workflowTask=runtime.store.getTask(execution.taskId)!;
    const workflowScope=requireSubAgentExecution(workflowTask.readScope?.execution);
    const workflowOps=runtime.store.listToolOpsByTask(workflowTask.id);
    assert.equal(workflowScope.roleDigest,ordinary.execution.roleDigest);
    assert.ok(workflowOps.some(op=>op.toolName==="bash"&&op.isError===false&&op.resultSummary?.includes("DEFAULT_WORKFLOW_OK")));
    assert.equal(fs.readFileSync(path.join(runtime.store.getSession(workflowTask.sessionId)!.cwdReal,"workflow-proof.txt"),"utf8"),"DEFAULT_WORKFLOW_OK");
    evidence.checks.push({case:"workflow-default-bash-request-only",runId:run.id,taskId:workflowTask.id,execution:workflowScope,ops:workflowOps,bytes:"DEFAULT_WORKFLOW_OK"});
    const deniedCommand='if printf SHOULD_NOT_WRITE > '+JSON.stringify(path.join(workspace,"value.txt"))+' 2>/dev/null; then printf UNSAFE_WRITE; else printf SOURCE_WRITE_DENIED; fi';
    const review=await delegate("review-current",'仅使用 bash 先执行 cat value.txt stage.txt; shasum -a 256 staged.bin new.bin ，核实当前内容。然后再调用一次 bash 执行 '+JSON.stringify(deniedCommand)+'，这是针对临时测试仓库的来源保护负例。报告实际输出与是否被拒绝；不要调用其他工具。',{role:"reviewer",target:workspace});
    assert.equal(runtime.store.getSubAgent(review.task.subAgentId!)!.definition!.name,"reviewer");
    assert.equal(review.task.accessMode,"confirm");
    const outputs=review.ops.filter(op=>op.toolName==="bash").map(op=>op.resultSummary).join("\n");
    assert.match(outputs,/CURRENT_UNSTAGED/);assert.match(outputs,/CURRENT_STAGED/);
    assert.ok(outputs.includes(expectedFiles["staged.bin"]));assert.ok(outputs.includes(expectedFiles["new.bin"]));
    assert.match(outputs,/SOURCE_WRITE_DENIED/);assert.doesNotMatch(outputs,/UNSAFE_WRITE/);
    for(const [name,hash] of Object.entries(expectedFiles)) assert.equal(digest(fs.readFileSync(path.join(workspace,name))),hash);
    assert.equal(digest(fs.readFileSync(path.join(workspace,".git/index"))),indexBefore);
    evidence.checks.push({case:"reviewer-current-staged-unstaged-untracked-binary-source-protection",taskId:review.task.id,execution:review.execution,ops:review.ops,reply:review.reply,indexUnchanged:true,bytesUnchanged:true});
    if(product.type === "ruukoto-code") {
      const rolesDir=path.join(agentDir,"agents");fs.mkdirSync(rolesDir,{recursive:true});
      const rolePath=path.join(rolesDir,"scout.md");
      const role=(marker:string)=>'---\ndescription: 输出当前角色版本证据\ntools: [bash]\n---\n只调用一次 bash 执行 printf '+marker+' > role-proof.txt && cat role-proof.txt 。实际执行后回复输出。\n';
      fs.writeFileSync(rolePath,role("ROLE_V1_PROOF").replaceAll("\\n","\n"));
      const first=await delegate("role-first","完成角色正文要求的检查。",{role:"scout"});
      assert.ok(first.ops.some(op=>op.toolName==="bash"&&op.isError===false&&op.resultSummary?.includes("ROLE_V1_PROOF")));
      fs.writeFileSync(rolePath,role("ROLE_V2_PROOF").replaceAll("\\n","\n"));
      const second=await delegate("role-new","完成角色正文要求的检查。",{role:"scout"});
      assert.ok(second.ops.some(op=>op.toolName==="bash"&&op.isError===false&&op.resultSummary?.includes("ROLE_V2_PROOF")));
      const old=await delegate("role-old","再次完成已固定角色正文要求的检查。",{work_id:first.work.id});
      assert.ok(old.ops.some(op=>op.toolName==="bash"&&op.isError===false&&op.resultSummary?.includes("ROLE_V1_PROOF")));
      assert.equal(old.execution.roleDigest,first.execution.roleDigest);assert.notEqual(second.execution.roleDigest,first.execution.roleDigest);
      evidence.checks.push({case:"editable-added-role-new-objects-receive-v2-existing-work-remains-v1",first:{taskId:first.task.id,execution:first.execution,ops:first.ops},second:{taskId:second.task.id,execution:second.execution,ops:second.ops},continued:{taskId:old.task.id,execution:old.execution,ops:old.ops}});
      fs.writeFileSync(path.join(rolesDir,"broken.md"),'---\ndescription: ""\n---\n坏文件诊断\n'.replaceAll("\\n","\n"));
      fs.writeFileSync(path.join(rolesDir,"missing.md"),'---\ndescription: 必须取得全部工具\ntools: [no_such_tool]\n---\n工具不得静默删除\n'.replaceAll("\\n","\n"));
      evidence.roleDiagnostics=runtime.listSubAgentRoles().diagnostics;
      assert.ok(evidence.roleDiagnostics.some((d:any)=>d.name==="broken"&&d.code==="role_invalid_description"));
      for(const roleName of ["broken","missing"]) {
        const args={request:"验证配置诊断，不执行其他任务。",key:"bad-"+roleName,role:roleName};
        const source=await parent("bad-"+roleName,"这是配置失败路径验收。必须调用一次 subagent_delegate，参数为 "+JSON.stringify(args)+"。即使目录提示不可用也执行这一次，以取得宿主确切诊断；失败后只解释错误，不重试，不选其他角色。");
        const op=runtime.store.listToolOpsByTask(source.id).find(op=>op.toolName==="subagent_delegate")!;
        assert.ok(op);assert.equal(op.isError,true,op.resultSummary!);
        evidence.checks.push({case:"real-parent-role-error-"+roleName,op,reply:runtime.readTaskReply(source.id)?.text});
      }
      fs.writeFileSync(path.join(rolesDir,"broken.md"),role("REPAIRED_ROLE_PROOF").replaceAll("\\n","\n"));
      const repaired=await delegate("role-repaired","完成角色正文要求的检查。",{role:"broken"});
      assert.ok(repaired.ops.some(op=>op.toolName==="bash"&&op.isError===false&&op.resultSummary?.includes("REPAIRED_ROLE_PROOF")));
      evidence.checks.push({case:"corrected-role-file-works",taskId:repaired.task.id,execution:repaired.execution,ops:repaired.ops});
    }
    evidence.requestCounts=runtime.store.db.prepare("SELECT count(*) as sendRecords, sum(CASE WHEN usage IS NOT NULL THEN 1 ELSE 0 END) as responded FROM selection_records").get();
    evidence.status="passed";
  } catch(error) {
    evidence.status="failed";evidence.error=error instanceof Error?{name:error.name,message:error.message,stack:error.stack}:String(error);
    throw error;
  } finally {
    if(rt){ evidence.tasks=rt.store.db.prepare("SELECT id,session_id,status,request_id,error_message FROM tasks").all(); await rt.stop("role_model_end"); }
    for(const name of ["models.json","auth.json"])fs.rmSync(path.join(agentDir,name),{force:true});
    fs.writeFileSync(path.join(root,"evidence.json"),JSON.stringify(evidence,null,2)+"\n");
    cases.push(evidence);fs.writeFileSync(path.join(evidenceRoot,"role-model-results.json"),JSON.stringify(cases,null,2)+"\n");
    process.stdout.write("[ruukoto:role-model] "+JSON.stringify({product:product.type,status:evidence.status,root,requestCounts:evidence.requestCounts})+"\n");
  }
}
